--────────────────────────────────────────────────────────────────────────────────────────
--─██████████████─██████████████─████████──████████─██████████████─██████──────────██████─
--─██░░░░░░░░░░██─██░░░░░░░░░░██─██░░░░██──██░░░░██─██░░░░░░░░░░██─██░░██████████──██░░██─
--─██░░██████████─██░░██████████─████░░██──██░░████─██░░██████░░██─██░░░░░░░░░░██──██░░██─
--─██░░██─────────██░░██───────────██░░░░██░░░░██───██░░██──██░░██─██░░██████░░██──██░░██─
--─██░░██─────────██░░██████████───████░░░░░░████───██░░██──██░░██─██░░██──██░░██──██░░██─
--─██░░██─────────██░░░░░░░░░░██─────████░░████─────██░░██──██░░██─██░░██──██░░██──██░░██─
--─██░░██─────────██████████░░██───────██░░██───────██░░██──██░░██─██░░██──██░░██──██░░██─
--─██░░██─────────────────██░░██───────██░░██───────██░░██──██░░██─██░░██──██░░██████░░██─
--─██░░██████████─██████████░░██───────██░░██───────██░░██████░░██─██░░██──██░░░░░░░░░░██─
--─██░░░░░░░░░░██─██░░░░░░░░░░██───────██░░██───────██░░░░░░░░░░██─██░░██──██████████░░██─
--─██████████████─██████████████───────██████───────██████████████─██████──────────██████─
--────────────────────────────────────────────────────────────────────────────────────────
function CheckOnlineVersion()
	major, minor, build, patch = menu.get_game_version()
	if build ~= 2944 then
		main = menu.add_submenu("⚠The game current version is: "..major.."."..minor.."."..build.."."..patch)
		main:add_submenu("Game updated!!!")
		main:add_submenu("The sctipt is outdated!!!")
	end
end
CheckOnlineVersion()
require_game_build(2944) -- GTA Online version 1.67

INI, STATS, GLOBAL = {}, {}, {}
GLOBAL.StatIntHash = 1665454 + 4
GLOBAL.StatIntValue = 1010831 + 5525
 
function STATS.STAT_SET_INT(hash, value)
	OldIntHash = globals.get_int(GLOBAL.StatIntHash)
	OldIntValue = globals.get_int(GLOBAL.StatIntValue)
	globals.set_int(GLOBAL.StatIntHash, joaat(hash))
	globals.set_int(GLOBAL.StatIntValue, value)
	sleep(0.5)
	globals.set_int(GLOBAL.StatIntHash, OldIntHash)
	globals.set_int(GLOBAL.StatIntValue, OldIntValue)
	sleep(0.5)
end

print("CSYON Submenu has been loaded! Have Fun")


--░█████╗░░██████╗██╗░░░██╗░█████╗░███╗░░██╗
--██╔══██╗██╔════╝╚██╗░██╔╝██╔══██╗████╗░██║
--██║░░╚═╝╚█████╗░░╚████╔╝░██║░░██║██╔██╗██║
--██║░░██╗░╚═══██╗░░╚██╔╝░░██║░░██║██║╚████║
--╚█████╔╝██████╔╝░░░██║░░░╚█████╔╝██║░╚███║
--░╚════╝░╚═════╝░░░░╚═╝░░░░╚════╝░╚═╝░░╚══╝

--Hotkeys change u can find here Cyson was here
-- https://cherrytree.at/misc/vk.htm

--Required Keyboard Keys--

		keyboard = 
		{
		numpad0 = 96,
		numpad2 = 98,
		numpad5 = 101,
		numpad8 = 104,
		backspace = 8,
		k = 75,
		enter = 13,
		i = 73
		}

mainMenu = menu.add_submenu("【 CSYON 】 SubMenu 1.66 ")
local function Text(text)
	mainMenu:add_action(text,  function() end)
end

local snowAddress = 262145 + 4752
local isEnabled = false
 
function toggleSnow()
    isEnabled = not isEnabled
    globals.set_boolean(snowAddress, isEnabled)
end
------
local mainGlobal = 262145 + 32832 -- Global_262145.f_32832 @ fm_content_sightseeing.c
local ufoSelectorGlobal = 2793046 + 6813 + 3 -- Global_2793046.f_6813.f_3 @ fm_content_sightseeing.c
local mainGlobalOriginalValue = globals.get_int(mainGlobal)
local mainGlobalNewValue = 1665662400
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--Required Stats--
		
		MPX = PI 
		PI = stats.get_int("MPPLY_LAST_MP_CHAR") 
		if PI == 0 then MPX = "MP0_" else MPX = "MP1_" end
		ASS = script("appsecuroserv")
		GCS = script("gb_contraband_sell")
		GCB = script("gb_contraband_buy")
		AMW = script("am_mp_warehouse")
		GB = script("gb_gunrunning")
		FMC = script("fm_mission_controller")
		FMC20 = script("fm_mission_controller_2020") 
		FormatMoney = (function (n)
		n = tostring(n) return n:reverse():gsub("%d%d%d", "%1,"):reverse():gsub("^,", "") end)
		freemodeglobal = 262145 
            fmC2020 = script("fm_mission_controller_2020")
            fmC = script("fm_mission_controller")
            function TP(x, y, z, yaw, roll, pitch)
            if localplayer:is_in_vehicle()
            then
            localplayer:get_current_vehicle():set_position(x, y, z)
            localplayer:get_current_vehicle():set_rotation(yaw, roll, pitch)
            else localplayer:set_position(x, y, z)
            localplayer:set_rotation(yaw, roll, pitch)
            end
            end 

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

----------------------credits ultimate controller-------------------------------------------------------

LUN1=262145+31628

LUN2=262145+31655

ACL1=262145+17425

ACL2=262145+17396

ACL3=262145+18949

ACL4=262145+21869

ACL5=262145+21870

ACL6=262145+21866

TEB1=262145+32702

TEB2=262145+32688

DWU1=262145+33975
DWU2=262145+34113
RPN1=262145+29991
RPN2=262145+29992
TEQ1=262145+29982
RUN1=262145+29983
BEB1=262145+29984
PID1=262145+29985
PAS1=262145+29987
BAS1=262145+29732
RLC1=262145+28817
RLC2=262145+28831
RLC3=262145+28467
RLC4=262145+28818
RLC5=262145+28819
RLC6=262145+28820
RLC7=262145+28821
RLC8=262145+28822
RLC9=262145+28823
RLC10=262145+28824
RLC11=262145+28825
RLC12=262145+28826
RLC13=262145+28827
RLC14=262145+28828
RLC15=262145+28829
RLC16=262145+28830
CDP1=262145+28808
CGP1=262145+28807
CAP1=262145+28806
CCP1=262145+28805
RCP1=262145+31701
RCP2=262145+31765
PAP1=262145+31727
PAH1=262145+31728
DRD1=262145+34062
GUV1=262145+33799
GUV2=262145+33877
TJC1=262145+33770
BSM1=262145+21509
BSM2=262145+21510
EBD1=262145+21621
EBD2=262145+21645
EBD3=262145+21647
EBD4=262145+21650
EBD5=262145+21654
EBD6=262145+21656
EBD7=262145+21658
EBD8=262145+21660
EBD9=262145+21666
EBD10=262145+21668
EBD11=262145+21671
EBD12=262145+21673
EBD13=262145+21675
EBD14=262145+21678
EBD15=262145+21689
EBD16=262145+21691
EBD17=262145+21695
EBD18=262145+21697
EBD19=262145+21699
EBD20=262145+21702
RBD1=262145+21557
RBS1=262145+21555
RBS2=262145+21556
BSU1=262145+21532
BSU2=262145+21531
Csp1=262145+15788
Csp2=262145+15789
CSP3=262145+15790
CSP4=262145+15791
CSP5=262145+15792
CSP6=262145+15793
CSP7=262145+15794
CSP8=262145+15795
CSP9=262145+15796
Csp10=262145+15797
Csp11=262145+15798
Csp12=262145+15799
Csp13=262145+15800
Csp14=262145+15801
Csp15=262145+15802
Csp16=262145+15803
Csp17=262145+15804
Csp18=262145+15805
Csp19=262145+15806
Csp20=262145+15807
Csp21=262145+15808
CRC1=262145+15553
CRC2=262145+15554
NRC1=262145+24447
NRC2=262145+24489
NCR3=262145+24490
PSU1=262145+24107
PSU2=262145+24113
PSU3=262145+24108
PSU4=262145+24109
PSU5=262145+24110
PSU6=262145+24111
PSU7=262145+24112
SGV1=262145+24381
SAV1=262145+24382
PHV1=262145+24383
OPV1=262145+24384
PCV1=262145+24385
CCV1=262145+24386
CSV1=262145+24387
RTC1=262145+24496
ALV1=262145+22811
AMV1=262145+22812
AAV1=262145+22813
CHV1=262145+22814
COV1=262145+22815
JEV1=262145+22816
MSV1=262145+22817
NAV1=262145+22818
TAV1=262145+22819
RRC1=262145+22793
SUP1=262145+17391
SUP2=262145+17395
SUP3=262145+17394
SUP4=262145+17393
SUP5=262145+17392
EMD1=262145+15567
EMD2=262145+18510
EMD3=262145+18514
EMD4=262145+18516
EMD5=262145+18520
EMD6=262145+18523
EMD7=262145+18547
EMD8=262145+18550
EMD9=262145+18552
EMD10=262145+18557
EMD11=262145+18561
EMD12=262145+18565
EMD13=262145+18570
EMD14=262145+18575
RSC1=262145+18953
RSD1=262145+18954
GSM1=262145+18247
MSM1=262145+19066
MSM2=262145+19067
ACC1=262145+31126
CHA1=262145+31127
LOM1=262145+31128
EXT1=262145+31132
MHT1=262145+31136
MMT1=262145+31137
MLT1=262145+31138
TOR1=262145+19412
MIR1=262145+19413
STR1=262145+19414
UCR1=262145+19416
UCS1=262145+19417
VHR1=262145+19682
VHR2=262145+19685
VHR3=262145+19314
VHR4=262145+19683
VHR5=262145+19684
RRC1=262145+19661
RRC2=262145+19662
RRC3=262145+19663
SAH1=262145+19418
SPD1=262145+19419
REM1=262145+20288
RMU1=262145+1
APU1=262145+25926
SRM1=262145+31649
PRM1=262145+31650
SCM1=262145+31651
HH1=262145+31652
LCM1=262145+31653
LMT1=262145+31654
AWA1=262145+24058
AWA2=262145+24060
AWA3=262145+24067
AWA4=262145+24069
AWO1=262145+24052
AWO2=262145+24054
AWO3=262145+24061
AWO4=262145+24063
AWR1=262145+24055
AWR2=262145+24057
AWR3=262145+24064
AWR4=262145+24066
EG1=262145+13149
EB1=262145+13150
CC1=262145+15891
CC2=262145+18025
RF7=262145+12843
RB2=262145+12851
RB3=262145+15890
RB4=262145+12848
RB5=262145+12849
RB6=262145+12850
RF1=262145+12842
RF2=262145+12846
RF3=262145+15968
RF4=262145+15973
RF5=262145+19302
RF6=262145+19304
RF8=262145+12845
RF9=262145+15969
RF10=262145+15970
RF11=262145+15971
RF12=262145+15980
IS1=262145+25302
IS2=262145+25303
IS3=262145+25304
RV1=262145+12832
RM1=262145+28408
RSU1=262145+30187
RSU2=262145+30188
RC1=262145+13081
NM1=262145+8352
NM2=262145+8353
NM3=262145+8354
NM4=262145+8355
NM5=262145+8356
NM6=262145+8357
NM7=262145+8358
NM8=262145+8359
NM9=262145+8360
DR1=262145+33958
DR2=262145+33973
MU1=262145+32865
CG1=262145+24219
CG2=262145+24220
UA1=262145+31859
UA2=262145+31870
CD1=262145+31871
CD2=262145+31872
CD3=262145+31873
AC1=262145+27530
AC2=262145+27531
AC3=262145+27532
AC4=262145+27533
PC1=262145+28200
PC2=262145+28205
PC3=262145+27945
PC4=262145+28011
VU1=262145+7059
VU2=262145+12030
VU3=262145+12031
VU4=262145+12032
VU5=262145+12033
VU5=262145+12034
VU6=262145+13396
VU7=262145+13397
ID1=262145+8259
ID2=262145+8268
ID3=262145+8274
ID4=262145+8297
ID5=262145+8303
HA1=262145+11996
HA2=262145+12036
HA3=262145+12041
HA4=262145+12042
HA5=262145+12043
HA7=262145+12045
HA8=262145+12046
HA9=262145+12047
HA10=262145+12048
HA11=262145+12059
HA12=262145+12702
HA13=262145+17488
XM1=262145+4763
XM2=262145+30902
XM3=262145+25834
XM4=262145+25835
XM5=262145+25836
XM6=262145+19139
XM6=262145+19139
XM7=262145+9395
XM8=262145+9396
XM8=262145+9397
XM9=262145+9398
XM10=262145+12710
XM11=262145+23412
XM12=262145+23413
XM13=262145+23414
XM44=262145+23415
XM15=262145+24203
XM16=262145+12711
XM17=262145+12713
XM18=262145+19256
XM19=262145+23056
XM20=262145+12816
XM21=262145+12817
XM22=262145+12818
XM23=262145+12819
XM24=262145+19115
XM25=262145+19116
XM26=262145+19117
XM27=262145+19118
XM28=262145+23434
XM27=262145+23435
XM29=262145+23436
XM30=262145+23437
XM31=262145+25838
XM32=262145+25841
XM33=262145+25839
XM34=262145+25840
XM35=262145+28690
XM36=262145+28691
XM37=262145+28692
XM38=262145+28693
XM39=262145+31410
XM40=262145+31411
XM41=262145+31756
XM42=262145+31757
XM43=262145+23407
XM45=262145+9449
XM46=262145+9451
XM47=262145+33916
XM48=262145+33917
SN1=262145+4752
CA1=262145+21109
CA2=262145+21112
CA3=262145+21118
CA4=262145+21121
CA5=262145+21129
CA6=262145+21122
CA7=262145+21132
CA8=262145+21134
HA1=262145+12591
MS5=262145+12613
BS1=262145+15222
BS2=262145+15224
BS3=262145+15226
BS4=262145+15228
BS5=262145+15230
BS6=262145+15236
BS7=262145+24205
BS8=262145+24208
BS9=262145+23951
BS10=262145+24210
RS4=262145+24212
BS12=262145+24215
BS13=262145+18255
KT1=262145+24221
KT2=262145+24230
MC1=262145+15225
MC2=262145+17532
MC2=262145+17532
MC3=262145+17553
MC3=262145+17553
MS1=262145+11955
MS2=262145+15229
MS3=262145+11964
MS4=262145+12601
RS1=262145+24204
RS2=262145+24209
RS3=262145+24211
RS5=262145+24214
RS6=262145+24216
RS7=262145+24217
RS8=262145+24744
RS9=262145+24763
CT1=262145+24704
CT2=262145+24712
DT1=262145+24918
DT2=262145+24941
HO1=262145+21110
HO2=262145+21114
HO3=262145+21117
HO4=262145+21119
HO5=262145+21124
HO6=262145+21126
HO7=262145+21130
HO8=262145+21133
SH1=262145+25826
SH2=262145+21111
SH3=262145+21113
SH4=262145+21115
SH5=262145+21116
SH6=262145+21120
SH7=262145+21125
SH8=262145+21131
SH9=262145+21135
SH10=262145+21136
SH11=262145+21147
WB1=262145+16783
WB2=262145+16790
SS2=262145+23411
AC1=262145+25842
AC2=262145+25919
AR1=262145+27027
AR2=262145+27033
AR3=262145+28316
AR4=262145+28335
LS1=262145+29685
LS2=262145+29720
LT1=262145+31187
LT2=262145+31208
LT3=262145+31019
LT4=262145+31025
CP1=262145+30209
CP2=262145+30277
CP3=262145+30282
CP4=262145+30301
CP5=262145+30866
CP6=262145+30901
RE1=262145+24608
RE2=262145+24612
RE3=262145+24609
RB1=262145+12843
RB2=262145+12851
RB3=262145+15890
RB4=262145+12848
RB5=262145+12849
RB6=262145+12850
RB7=262145+12853
RB8=262145+12854
BRE1=262145+21295
BRE2=262145+21547
BRE3=262145+21548
BRE4=262145+21549
BRE5=262145+21551
BRE6=262145+21552
HAS2=262145+12600
BS11=262145+24214				 

--Skin Changer  

NORS1=2639783+61

NORS2=2639783+48

--Request Services

REQS1=2793046 --Offset

--Lobby Switch

LOBS1=1575017
LOBS2=1574589	

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

 xox_00 = 1
 xox_01 = 1
 xox_0 = 1
 xox_1 = 1
 xox_2 = 1
 xox_3 = 1
 xox_4 = 1
 xox_5 = 1
 xox_6 = 1
 xox_7 = 1
 xox_8 = 1
 xox_9 = 1
 xox_10 = 1
 xox_11 = 1
 xox_12 = 1
 xox_13 = 1
 xox_14 = 1
 xox_15 = 1
 xox_16 = 1
 xox_17 = 1
 xox_18 = 1
 xox_19 = 1
 xox_20 = 1
 xox_21 = 1
 xox_22 = 1
 xox_23 = 1
 xox_24 = 1
 xox_25 = 1
 xox_26 = 1
 xox_27 = 1
 xox_28 = 1
 xox_29 = 1
 xox_30 = 1
 xox_31 = 1
 xox_32 = 1
 xox_33 = 1
 xox_34 = 1
 xox_35 = 1
 xox_36 = 1
 xox_37 = 1

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

 e0 = false
 e1 = false
 e2 = false
 e3 = false
 e4 = false
 e5 = false
 e6 = false
 e7 = false
 e8 = false
 e9 = false
 e10 = false
 e11 = false
 e12 = false
 e13 = false
 e14 = false
 e15 = false
 e16 = false
 e17 = false
 e18 = false
 e19 = false
 e20 = false
 e21 = false
 e22 = false
 e23 = false
 e24 = false
 e25 = false
 e26 = false
 e27 = false
 e28 = false
 e29 = false
 e30 = false
 e31 = false
 e32 = false
 e33 = false
 e34 = false
 e35 = false
 e36 = false
 e37 = false
 e38 = false
 e39 = false
 e40 = false
 e41 = false
 e42 = false
 e43 = false
 e44 = false
 e45 = false
 e46 = false
 e47 = false
 e48 = false
 e49 = false
 e50 = false
 e51 = false
 e52 = false
 e53 = false

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
local function createVehicle(modelhash, pos)
	globals.set_int(VehicleSpawnGlobal + 46, modelhash)
	globals.set_float(VehicleSpawnGlobal + 42, pos.x)
	globals.set_float(VehicleSpawnGlobal + 43, pos.y)
	globals.set_float(VehicleSpawnGlobal + 44, pos.z)
	globals.set_boolean(VehicleSpawnGlobal + 41, true)
end
------
OnWeaponChanged=38			--	TelePort Forward, Up Arrow key
if csyon then menu.remove_callback(csyon) end local csyon=nil
if enable then local csyon = menu.register_callback('OnWeaponChanged', OnWeaponChanged) end
------
local bT,WR,LR=0,0,0
local function OnWeaponChanged(oldWeapon, newWeapon)
	if newWeapon~=nil then NAME=localplayer:get_current_weapon():get_name_hash()
		if NAME==joaat("weapon_hominglauncher") then newWeapon:set_range(1500) elseif NAME==joaat("weapon_raypistol") then
			newWeapon:set_heli_force(1075) newWeapon:set_ped_force(63) newWeapon:set_vehicle_force(1075) end
		if bT==0 then if NAME==joaat("weapon_stungun_mp") or NAME==joaat("weapon_stungun") then newWeapon:set_time_between_shots(1)
			elseif NAME==joaat("weapon_raypistol") then newWeapon:set_time_between_shots(0.5) end
			else newWeapon:set_time_between_shots(bT) end
		if WR~=0 then newWeapon:set_range(WR) else if NAME==joaat("weapon_raypistol") then newWeapon:set_range(1200)
			elseif NAME==joaat("weapon_stungun_mp") or NAME==joaat("weapon_stungun") then newWeapon:set_range(1000) end end
		if LR==0 then if NAME==joaat("weapon_hominglauncher") then newWeapon:set_lock_on_range(1500) end
			else newWeapon:set_lock_on_range(LR) end end
end
------
local function OnWeaponChanged(oldWeapon, newWeapon)
	if newWeapon ~= nil then
	    if newWeapon:get_name_hash() == 177293209 then
	         newWeapon:set_aim_fov(150)
			 newWeapon:set_time_between_shots(0.05)
			 newWeapon:set_bullet_damage(99900000.00)
			 newWeapon:set_ped_force(99900000.00)
			 newWeapon:set_heli_force(99900000.00)
			 newWeapon:set_vehicle_force(99900000.00)
		     newWeapon:set_damage_type(5)
		     newWeapon:set_explosion_type(59)
	    end
	end
end
------
local function weaponForce()
	if localplayer == nil then
		return
	end
	
	current_weapon = localplayer:get_current_weapon()
		if current_weapon ~= nil then
			current_weapon:set_vehicle_force(99900000)
		end
end
------
local function weaponPedForce()
	if localplayer == nil then
		return
	end
	
	current_weapon = localplayer:get_current_weapon()
		if current_weapon ~= nil then
			current_weapon:set_ped_force(99900000)
		end
end
------
local function weaponHeliForce()
	if localplayer == nil then
		return
	end
	
	current_weapon = localplayer:get_current_weapon()
		if current_weapon ~= nil then
			current_weapon:set_heli_force(99900000)
		end
end
------
local function weaponDamage()
	if localplayer == nil then
		return
	end
	
	current_weapon = localplayer:get_current_weapon()
		if current_weapon ~= nil then
			current_weapon:set_bullet_damage(99900000)
		end
end
------
local function weaponMod()
	if localplayer == nil then
		return
	end
	current_weapon = localplayer:get_current_weapon()
		if current_weapon ~= nil then
			current_weapon:set_bullet_damage(99900000)
			current_weapon:set_time_between_shots(0.1)
			current_weapon:set_lock_on_range(100000)
		end
end
------
local function PedDrop()
	local position = localplayer:get_position()
	position.z = position.z + 30
 
	for p in replayinterface.get_peds() do
		if p == nil or p == localplayer then
			goto continue
		end
		
		if p:get_pedtype() < 4 then
			goto continue
		end
		
		if p:is_in_vehicle() then
			goto continue
		end
 
		p:set_position(position)
 
		if p:get_health() > 99 then
			p:set_position(position)
			p:set_freeze_momentum(true)
			p:set_health(0)
			p:set_wallet(1337) --1337
			--p:set_wallet(1337)
			break
		end
 
		::continue::
	end
end
menu.register_hotkey(114, PedDrop) --to drop a ped when pressing F3
------
function cv() c=localplayer v=c and c:get_current_vehicle() return v end
x,o=0,0 menu.register_hotkey(16,function() if x==0 then menu.send_key_down(127) if cv() then 
    
    v:set_drift_tyres_enabled(true) 
    v:set_traction_curve_max(0)
	v:set_traction_curve_min(0)
 
end end x=x+1 end) 
------
menu.register_hotkey(127,function() o=o<x and x or o+1 if o>x then menu.send_key_up(127) if cv() then 
 
    v:set_drift_tyres_enabled(false) 
    v:set_traction_curve_max(2.8)
	v:set_traction_curve_min(2.6)
 
end x,o=0,0 end end)
------
local function DrugWarsUnlockClothes_CSYON()
    for i = 33973, 34112, 1 do
	        globals.set_int(262145+33973, 1)
        --globals.set_int(262145 + i, 1)
        sleep(2)
    end
end
------
local function StreetDealer_CSYON()
    for i = 34062, 34062, 1 do
        globals.set_int(262145+34062, 1)
        sleep(2)
    end
end
------
local function twentyfive_SkiMask_CSYON()
    for i = 34045, 34045, 1 do
        globals.set_int(262145+34045, 1)
        sleep(2)
    end
end
------
script_name = "fm_mission_controller_2020"
cayo_fingerprint_clone = 22032
cayo_instant_heist_passed_trigger = 42279
cayo_instant_heist_passed_value = 43655
------
local function UnlockExit_CSYON()
    for i = 32688, 32688, 1 do
        globals.set_int(262145 + i, 0)
        sleep(2)
    end
end
------
local function Baseball_Bat_and_Knife_liveries_CSYON()
    for i = 33877, 33877, 1 do
        globals.set_int(262145+33877,0)
		globals.set_int(262145 + i, 0)
        sleep(2)
    end
end
------Protections
local function KickCrashes(bool)
	if bool then 
		globals.set_bool(1670036, true)
		globals.set_bool(1670051, true)
		globals.set_bool(1669951, true)
		globals.set_bool(1670028, true)
		globals.set_bool(1670238, true)
	else
		globals.set_bool(1670036, false)
		globals.set_bool(1670051, false)
		globals.set_bool(1669951, false)
		globals.set_bool(1670028, false)
		globals.set_bool(1670238, false)
	end
end
 
local function SoundSpam(bool)
	if bool then 
		globals.set_bool(1669879, true)
		globals.set_bool(1670243, true)
		globals.set_bool(1669394, true)
		globals.set_bool(1670529, true)
		globals.set_bool(1670058, true)
		globals.set_bool(1669421, true)
 
	else
		globals.set_bool(1669879, false)
		globals.set_bool(1670243, false) 
		globals.set_bool(1669394, false) 
		globals.set_bool(1670529, false)
		globals.set_bool(1670058, false)
		globals.set_bool(1669421, false)
	end
end
 
local function InfiniteLoad(bool)
	if bool then 		
		globals.set_bool(1669947, true) 
		globals.set_bool(1670076, true)
	else
		globals.set_bool(1669947, false)
		globals.set_bool(1670076, false)
	end
end
 
 
local function Collectibles(bool)
	if bool then 
		globals.set_bool(1670208, true) 
	else
		globals.set_bool(1670208, false)
	end
end
 
local function PassiveMode(bool)
	if bool then 
		globals.set_bool(1669996, true) 
	else
		globals.set_bool(1669996, false)
	end
end
 
local function TransactionError(bool) 
	if bool then 
		globals.set_bool(4536679, true) 
	else
		globals.set_bool(4536679, false)
	end
end
 
local function RemoveMoneyMessage(bool) 
	if bool then 
		globals.set_bool(1669880, true)
		globals.set_bool(1669426, true)
		globals.set_bool(1670057, true)
		globals.set_bool(1669428, true)
	else
		globals.set_bool(1669880, false)
		globals.set_bool(1669426, false)
		globals.set_bool(1670057, false)
		globals.set_bool(1669428, false)
	end
end
 
local function ExtraTeleport(bool) 
	if bool then 
		globals.set_bool(1669741, true) 
		globals.set_bool(1670138, true) 
	else
		globals.set_bool(1669741, false) 
		globals.set_bool(1670138, false) 
	end
end
 
 
local function ClearWanted(bool) 
	if bool then 
		globals.set_bool(1669938, true)
	else
		globals.set_bool(1669938, false)
	end
end
 
local function OffTheRadar(bool) 
	if bool then 
		globals.set_bool(1669940, true)
	else
		globals.set_bool(1669940, false)
	end
end
 
local function SendCutscene(bool) 
	if bool then 
		globals.set_bool(1670198, true)
	else
		globals.set_bool(1670198, false)
	end
end
 
local function Godmode(bool) 
	if bool then 
		globals.set_bool(1669396, true)
	else
		globals.set_bool(1669396, false)
	end
end
 
local function PersonalVehicleDestroy(bool) 
	if bool then 
		globals.set_bool(1669480, true)
		globals.set_bool(1670063, true) 
		globals.set_bool(1669947, true)
		
	else
		globals.set_bool(1669480, false)
		globals.set_bool(1670063, false) 
		globals.set_bool(1669947, false) 
	end
end
local function Bounty(bool) 
	if bool then 
		globals.set_bool(1669471, true)
	else
		globals.set_bool(1669471, false)
	end
end

local function All(bool) 
	SoundSpam(bool)
	InfiniteLoad(bool)
	PassiveMode(bool)
	TransactionError(bool)
	RemoveMoneyMessage(bool)
	ClearWanted(bool)
	OffTheRadar(bool)
	PersonalVehicleDestroy(bool)
	SendCutscene(bool)
	Godmode(bool)
	Collectibles(bool)
	ExtraTeleport(bool)
	KickCrashes(bool)
	Bounty(bool)
end
------
local enabled = false
------
local night = false
local function clubs(state)
    while state do
        stats.set_int("MP0_CLUB_POPULARITY", 1000)
        stats.set_int("MP0_CLUB_PAY_TIME_LEFT", -1)
        sleep(1.5)
        stats.set_int("MP1_CLUB_POPULARITY", 1000)
        stats.set_int("MP1_CLUB_PAY_TIME_LEFT", -1)
        sleep(1.5)
        stats.set_int("MP0_CLUB_POPULARITY", 1000)
        stats.set_int("MP0_CLUB_PAY_TIME_LEFT", -1)
        sleep(1.5)
        stats.set_int("MP1_CLUB_POPULARITY", 1000)
        stats.set_int("MP1_CLUB_PAY_TIME_LEFT", -1)
        sleep(1.5)
        stats.set_int("MP0_CLUB_POPULARITY", 1000)
        stats.set_int("MP0_CLUB_PAY_TIME_LEFT", -1)
        sleep(1.5)
        stats.set_int("MP1_CLUB_POPULARITY", 1000)
        stats.set_int("MP1_CLUB_PAY_TIME_LEFT", -1)
        sleep(1.5)
        stats.set_int("MP0_CLUB_POPULARITY", 1000)
        stats.set_int("MP0_CLUB_PAY_TIME_LEFT", -1)
        sleep(1.5)
        stats.set_int("MP1_CLUB_POPULARITY", 1000)
        stats.set_int("MP1_CLUB_PAY_TIME_LEFT", -1) 
        sleep(1.5)
        stats.set_int("MP0_CLUB_POPULARITY", 1000)
        stats.set_int("MP0_CLUB_PAY_TIME_LEFT", -1)
        sleep(1.5)
        stats.set_int("MP1_CLUB_POPULARITY", 1000)
        stats.set_int("MP1_CLUB_PAY_TIME_LEFT", -1)
        sleep(4)
    end
end
------
function TrickOrTreat(c)
    local index = 34253
    local value = false
    i = math.floor((index - 34251) / 64)
	bit = (index - 34251) % 64
	stathash = MPX.."DLC12022PSTAT_BOOL"..i -- 34251-34763
    stats.set_bool_masked(stathash, value, bit) -- with this stat set to true nothing works... lmao?
 
    globals.set_int(2764906 + 498, 1) -- Timer. Never actually changes. But it is in the code, so we reset it to be safe.
    globals.set_int(262145 + 32759, 0) -- Tunable amount collected.
    globals.set_int(2764906 + 591, c) -- Amount collected. Any value but 10 and 200 will give trick/treat randomly. 10 gives 50k (money method?). 1 should display help text.
    globals.set_int(262145 + 32760, 1) -- Tunable (is halloween enabled?)
    globals.set_int(2765539, 1) -- one of triggers, should be anything but -1
    globals.set_int(2765538, 1)  -- does nothing but maybe important so here for flex
    globals.set_int(2764906 + 564, 8) -- 8 is required for halloween collectibles, can be changed to 17 for buried stash (type of collectible collected maybe?...)
    globals.set_int(2764906 + 512, 1) -- something to do with sound, does maybe nothing but maybe important so here for flex
    globals.set_int(2764906 + 214, 1 << 17) -- Trigger Collect
end
------
function ahc()
--Plushies
globals.set_int(262145+29077,50)--Grindy Poppy Saki Muffy Humpy Smokey
globals.set_int(262145+29078,100)--ShinyWasabiKitty
globals.set_int(262145+29079,150)--PrincessRobotBubblegum
globals.set_int(262145+29080,200)--MasterHentai
end
--Plushies
--globals.set_int(262145+28870,0)--Grindy Poppy Saki Muffy Humpy Smokey
--globals.set_int(262145+28871,0)--ShinyWasabiKitty
--globals.set_int(262145+28872,0)--PrincessRobotBubblegum
--globals.set_int(262145+28873,0)--MasterHentai
--Plushies V2
--globals.set_int(262145+28870,50)--Grindy Poppy Saki Muffy Humpy Smokey
--globals.set_int(262145+28871,100)--ShinyWasabiKitty
--globals.set_int(262145+28872,150)--PrincessRobotBubblegum
--globals.set_int(262145+28873,200)--MasterHentai
--end
------
local function Own_Worst_Enemy_CSYON()
    for i = 33716, 33716, 1 do
        globals.set_int(262145+33716,1)
        sleep(2)
    end
end

local function Stashes_to_Stashes_CSYON()
    for i = 33910, 33910, 1 do
         globals.set_int(262145+33910,1)
        sleep(2)
    end
end

local function Here_Comes_the_Drop_CSYON()
    for i = 33911, 33911, 1 do
         globals.set_int(262145+33911,1)
        sleep(2)
    end
end

local function Good_Samarithan_CSYON()
    for i = 33912, 33912, 1 do
         globals.set_int(262145+33912,1)
        sleep(2)
    end
end

local function Last_Dose_Awards_CSYON()
    for i = 33914, 33914, 1 do
         globals.set_int(262145+33914,1)
        sleep(2)
    end
end

local function Taxi_Awards_CSYON()
    for i = 33914, 33914, 1 do
         globals.set_int(262145+33914,1)
        sleep(2)
    end
end
------
local function denim_jackets_CSYON()
    for i = 34047, 34047, 1 do
        globals.set_int(262145 + i, 0)
        sleep(2)
    end
end

local function designer_jeans_CSYON()
    for i = 34051, 34051, 1 do
        globals.set_int(262145 + i, 0)
        sleep(2)
    end
end

local function designer_jeans2_CSYON()
    for i = 34055, 34055, 1 do
        globals.set_int(262145 + i, 0)
        sleep(2)
    end
end
------
------ local fastRespawnGlobal = 2672505 + 1685 + 756 -- Global_2672505.f_1685.f_756
local fastRespawnGlobal = 2672505 + 1685 + 756 -- Global_2672505.f_1685.f_756
local fastRespawnGlobalValue = 2672505 + 1685 + 755 -- GLOBAL setting to 0 
local isRunning = false	
------
local function toggleFastRespawn()
    isRunning = not isRunning
    if isRunning then
        repeat
            local mp = player.get_player_ped()
            if mp ~= nil and mp:get_health() < 100 then
                local fastRespawnGlobalValue = globals.get_int(fastRespawnGlobal)
                globals.set_int(fastRespawnGlobal, fastRespawnGlobalValue | 1 << 1)
            end
            sleep(1)
        until (isRunning == false)
    else
        local fastRespawnGlobalValue = globals.get_int(fastRespawnGlobal)
        globals.set_int(fastRespawnGlobal, fastRespawnGlobalValue & ~(1 << 1))
    end
 
end
------
local cooldownGlobalAddress = 262145 + 31126
local isRemoved = false
 
local function removeCooldown(state)
    if not localplayer then
        return
    end
    if state then
        globals.set_int(cooldownGlobalAddress, 0)
    else
        globals.set_int(cooldownGlobalAddress, 2880)
    end
end
------
local function GetCopPartner()
	local position = localplayer:get_position()
	position.x = position.x + 3

	for p in replayinterface.get_peds() do
		if p == nil or p == localplayer then
			goto continue
		end
		
		if p:get_pedtype() ~= 6 and not (p:get_pedtype() < 4) then -- is Cop
			goto continue
		end
		
		if p:is_in_vehicle() then
			veh = p:get_current_vehicle()
			veh:set_health(0)
		end

		p:set_position(position)
		p:set_config_flag(292, true) -- PED_FLAG_FREEZE
		p:set_config_flag(301, true) -- PED_FLAG_IS_STILL
		-- p:set_model_hash(-150975354)
		--break

		::continue::
	end
end
------

local function giverp()
    if enn then
      menu.end_cutscene()
    end
end
------
--####################################--
local function loop()
--------------------------------------------------------------

    -- call custom functions here to loop 
	 giverp()

---------------------------------------------------------------
end 
 menu.register_hotkey(105, function() loop() end) -- this is automatically called from other script
--####################################--
-- main protection suite
local function protection()
 
	base_address = 1669394
 
	globals.set_bool(base_address + 792, true) -- CRITICAL TUNNELING PROTECTION
	globals.set_bool(base_address + 504, true) -- CRITICAL TUNNELING PROTECTION
	globals.set_bool(base_address + 642, true) -- kick crashes
	globals.set_bool(base_address + 657, true) -- kick crashes
	globals.set_bool(base_address + 557, true) -- kick crashes
	globals.set_bool(base_address + 634, true) -- kick crashes
	globals.set_bool(base_address + 844, true) -- kick crashes
	globals.set_bool(base_address + 485, true) -- sound spam
	globals.set_bool(base_address + 849, true) -- sound spam
	globals.set_bool(base_address + 0, true) -- sound spam
	globals.set_bool(base_address + 1135, true) -- sound spam
	globals.set_bool(base_address + 664, true) -- sound spam
	globals.set_bool(base_address + 27, true) -- sound spam
	globals.set_bool(base_address + 553, true) -- infinite load 
	globals.set_bool(base_address + 682, true) -- infinite load 
	globals.set_bool(base_address + 814, true) -- prevent +Collectibles
	globals.set_bool(base_address + 602, true) -- Passive Mode
	globals.set_bool(base_address + 403, true) -- Transaction Error
	globals.set_bool(base_address + 486, true) -- block SMS spam
	globals.set_bool(base_address + 32, true) -- block SMS spam
	globals.set_bool(base_address + 663, true) -- block SMS spam
	globals.set_bool(base_address + 34, true) -- block SMS spam
	globals.set_bool(base_address + 804, true) -- send to cutscene
	globals.set_bool(base_address + 2, true) -- deactivate godmode
	globals.set_bool(base_address + 86, true) -- personal vehicle destroy
	globals.set_bool(base_address + 669, true) -- personal vehicle destroy 
	globals.set_bool(base_address + 553, true) -- personal vehicle destroy
 
end
------
menu.register_hotkey(121, function()
	if localplayer:is_in_vehicle() then
		current_vehicle = localplayer:get_current_vehicle()
		current_vehicle:set_health(current_vehicle:get_max_health())
		menu.repair_online_vehicle()
		current_vehicle:set_dirt_level(0.0)
	end
end)
------
local function reloadSpeed()
	if localplayer == number then
		return
	end
	
	current_weapon = localplayer:get_current_weapon()
		if current_weapon ~= number then
			current_weapon:set_time_between_shots(0.05)
		end
end
------
function DropFireworks()
	PedDrop()
	
	execution_limit = 99
	i=0
	repeat
		for p in replayinterface.get_pickups() do
			if p == nil then
				goto continue
			end
		
			if p:get_amount() == 1337 then --1337
				p:set_amount(20) --20
				p:set_pickup_hash(0x22B15640)
				p:set_position(localplayer:get_position())
				return
			end
		
			::continue::
			i=i+1
		end
	until i == execution_limit
end
------
menu.register_hotkey(110, function()
	if localplayer ~= nil and localplayer:is_in_vehicle() then 
		vehicle = localplayer:get_current_vehicle()
		grav = vehicle:get_gravity()
		vehicle:set_gravity(-50)
		sleep(0.2)
		vehicle:set_gravity(grav)
	end
end)
------
Acv0 = false
	AG = 4542597 + 1
	local function AchUnlock()
while Acv0 == true do for i = 1, 78 do globals.set_int(4542597 + 1 , i) end end end
------
local VehicleSpawnGlobal = 2639889
 
local function createVehicle(modelhash, pos)
	globals.set_int(VehicleSpawnGlobal + 46, modelhash)
	globals.set_float(VehicleSpawnGlobal + 42, pos.x)
	globals.set_float(VehicleSpawnGlobal + 43, pos.y)
	globals.set_float(VehicleSpawnGlobal + 44, pos.z)
	globals.set_boolean(VehicleSpawnGlobal + 41, true)
end
 
local weapon_data = {}
local enabled = false
local function spawnCarWhereAiming()
	if not enabled then return end
	--check weapon hit force and put in table
	local weapon = localplayer:get_current_weapon()
	local force = weapon:get_vehicle_force()
	if force < 100000 then
		weapon_data[weapon:get_name_hash()] = force
		weapon:set_vehicle_force(99900000)
	end
	createVehicle(joaat("Youga4"), (localplayer:get_position() + localplayer:get_heading()*4) + vector3(0,0,1))
end
 
local hotkey
local function carAPult()
	if not localplayer or localplayer == nil then return end
	
	enabled = not enabled
	if enabled then
		--register hotkey to right click for continually spawning cars
		hotkey = menu.register_hotkey(1, spawnCarWhereAiming)
	else
		--reset weapon hit force from table
		local weapon = localplayer:get_current_weapon()
		weapon:set_vehicle_force(weapon_data[weapon:get_name_hash()])
		
		--unregister hotkey
		menu.remove_hotkey(hotkey)
	end
end
------
local function CeoKick(bool)
	globals.set_bool(1669984, bool) 
end
 
local function KickCrashes(bool)
	globals.set_bool(1670036, bool)
	globals.set_bool(1670051, bool)
	globals.set_bool(1669951, bool)
	globals.set_bool(1670028, bool)
	globals.set_bool(1670238, bool)
end
 
local function getKickCrashesState()
	return (globals.get_bool(1670036) and
	globals.get_bool(1670051) and
	globals.get_bool(1669951) and
	globals.get_bool(1670028) and
	globals.get_bool(1670238))
end
 
local function CeoBan(bool)
	globals.set_bool(1670006, bool) 
end
 
local function SoundSpam(bool)
	globals.set_bool(1669879, bool)
	globals.set_bool(1670243, bool)
	globals.set_bool(1669394, bool)
	globals.set_bool(1670529, bool)
	globals.set_bool(1670058, bool)
	globals.set_bool(1669421, bool)
end
 
local function getSoundSpamState()
	return (globals.get_bool(1669879) and
	globals.get_bool(1670243) and
	globals.get_bool(1669394) and
	globals.get_bool(1670529) and
	globals.get_bool(1670058) and
	globals.get_bool(1669421))
end
 
local function InfiniteLoad(bool)	
	globals.set_bool(1669947, bool) 
	globals.set_bool(1670076, bool)
end
 
local function getInfiniteLoadState()
	return (globals.get_bool(1669947) and
	globals.get_bool(1670076))
end
 
local function Collectibles(bool)
	globals.set_bool(1670208, bool) 
end
 
local function PassiveMode(bool)
	globals.set_bool(1669996, bool) 
end
 
local function TransactionError(bool) 
	globals.set_bool(4536679, bool) 
	globals.set_bool(4536673, bool) 
end
 
local function RemoveMoneyMessage(bool) 
	globals.set_bool(1669880, bool)
	globals.set_bool(1669426, bool)
	globals.set_bool(1670057, bool)
	globals.set_bool(1669428, bool)
end
 
local function getRemoveMoneyMessageState()
	return (globals.get_bool(1669880) and
	globals.get_bool(1669426) and
	globals.get_bool(1670057) and
	globals.get_bool(1669428))
end
 
local function ExtraTeleport(bool) 
	globals.set_bool(1669741, bool) 
	globals.set_bool(1670138, bool) 
end
 
local function getExtraTeleportState()
	return (globals.get_bool(1669741) and
	globals.get_bool(1670138))
end
 
local function ClearWanted(bool) 
	globals.set_bool(1669938, bool)
end
 
local function OffTheRadar(bool) 
	globals.set_bool(1669940, bool)
end
 
local function SendCutscene(bool) 
	globals.set_bool(1670198, bool)
end
 
local function Godmode(bool) 
	globals.set_bool(1669396, bool)
end
 
local function PersonalVehicleDestroy(bool) 
	globals.set_bool(1669480, bool)
	globals.set_bool(1670063, bool) 
	globals.set_bool(1669947, bool)
end
 
local function getPersonalVehicleDestroyState()
	return (globals.get_bool(1669480) and
	globals.get_bool(1670063) and
	globals.get_bool(1669947))
end
 
local function RemoteGlobalModification(bool)
	local setting = 0
	if bool then
		setting = 1
	end
	globals.set_int(1669394+792, setting)
	globals.set_int(1669394+504, setting)
end
 
local function getRemoteGlobalModificationState()
	return ((globals.get_int(1669394+792) == 1) and
	(globals.get_int(1669394+504) == 1))
end
------
local function Runnyspeed()
		if localplayer == nil then
			return nil
		end
			
		runspeed = localplayer:get_run_speed()
			
		return runspeed
	end
 
local function Runny(Runnyspeed, value)
		if localplayer == nil then
		local value = 0.5, 1.0, 10.0
		
			return nil
		end
	    
		return localplayer:set_run_speed(Runnyspeed,value)
	end
------
local function sqrt(i)
	return i^0.5
end
local function DistanceToSqr(vec1, vec2)
	return ((vec2.x - vec1.x)^2) + ((vec2.y - vec1.y)^2) + ((vec2.z - vec1.z)^2)
end
local function Distance(vec1, vec2)
	return sqrt(DistanceToSqr(vec1, vec2))
end
local lastwaypointlocation = vector3(0, 0, 0)
 
 
 
local function better_teleport_to_waypoint()
 
	if localplayer ~= nil then
	
		if lastwaypointlocation == vector3(0, 0, 0) then
		    local currentlocationn = localplayer:get_position()
			menu:teleport_to_waypoint()
			if currentlocationn ~= localplayer:get_position() then
				lastwaypointlocation = localplayer:get_position()
			end
		else
			if Distance(lastwaypointlocation,localplayer:get_position()) > 1 then
				local currentlocationn = localplayer:get_position()
				menu:teleport_to_waypoint()
				if currentlocationn == localplayer:get_position() then
				-- begin
					
						
						if not localplayer:is_in_vehicle() then
                            -----------------------
                            ---- walking teleport needs a freeze to insta teleport ----
                            -----------------------
							
							for i=1,7 do 
									menu:teleport_to_waypoint()
									localplayer:set_position(lastwaypointlocation)
									menu:teleport_to_waypoint()
									sleep(0.2)
							end
                            -----------------------
						else
						
							
						
                            --##--##--##--##--##--##--##--##--##--##--##--##--##--##
							-- vehicle needs to standing still be level and not trying to drive --
							--##--##--##--##--##--##--##--##--##--##--##--##--##--##
							local v =  localplayer:get_current_vehicle()
							local carnow = v:get_position()
 
						--	v:set_position(lastwaypointlocation)	
								
							local gr_ = v:get_gravity()
							local gd_ = v:get_godmode()
							local cbv_ = v:get_can_be_visibly_damaged()
							local wic_ = v:get_window_collisions_disabled()
							local dl_ = v:get_dirt_level()
							local ms_ = v:get_max_speed()
							local wt_ = v:get_window_tint()
							local bt_ = v:get_bulletproof_tires()
							local gaa_ = v:get_acceleration()
							local cbt_ = v:get_can_be_targeted()
							local acc_ = v:get_acceleration()
							local getseatbelt_ = localplayer:get_seatbelt() 
 
 
							menu:level_current_vehicle()
						--	v:set_godmode(true)
							--menu:kill_current_vehicle()
							v:set_max_speed(5)
							--v:set_health(0)
							
							sleep (0.1)
							
							v:set_max_speed(1000)
		
							v:set_position(lastwaypointlocation)	
							sleep (0.1)
							--menu:heal_vehicle()
							--v:set_health(1000)
							--v:set_godmode(gd_)
							v:set_max_speed(1000)
							--v:set_engine_damage_multiplier(1000)
							localplayer:set_seatbelt(getseatbelt_) 
							menu:level_current_vehicle()
						
							
					     --##--##--##--##--##--##--##--##--##--##--##--##--##--##
							
							  
							
						--end of begin	
					   end 
				else
					lastwaypointlocation = localplayer:get_position()
				end
			else
				local currentlocationn = localplayer:get_position()
				menu:teleport_to_waypoint()
				if currentlocationn ~= localplayer:get_position() then
					lastwaypointlocation = localplayer:get_position()
				end
			end
			
		end
		
	else
	    menu:teleport_to_waypoint()
	end
 
end 
------
local cars_map = {}
cars_map[joaat("BATI2")] = "Bati 801RR"
cars_map[joaat("BIFTA")] = "Bifta"
local car_hash = joaat("BATI2")
------ 
--function SpawnVehicle(Hash)
    --local pos = localplayer:get_position()
    --globals.set_int(2639783 + 27 + 66, Hash)
    --globals.set_float(2639783 + 7 + 0, pos.x)
    --globals.set_float(2639783 + 7 + 1, pos.y)
    --globals.set_float(2639783 + 7 + 2, pos.z)
    --globals.set_boolean(2639783 + 39, true)
    --sleep(0.5)
  --  menu.send_key_press(70)	
   
--end

local SpawnVehicle3 = 2639783
local SpawnVehicle = 2694562
------
function create_vehicle(hash, x, y, z)
    globals.set_int(2639783 + 27 + 66, hash) -- hash
    globals.set_float(2639783 + 7 + 0, x) -- x
    globals.set_float(2639783 + 7 + 1, y) -- y
    globals.set_float(2639783 + 7 + 2, z) -- z
    globals.set_int(2639783 + 5, 1) -- trigger
    globals.set_int(2639783 + 2, 1) -- trigger
end
-------
function create_vehicle_2(hash, x, y, z, heading)
    globals.set_int(2694562 + 46, hash) -- hash
    globals.set_float(2694562 + 42 + 0, x) -- x
    globals.set_float(2694562 + 42 + 1, y) -- y
    globals.set_float(2694562 + 42 + 2, z) -- z
    globals.set_float(2694562 + 45, heading) -- heading
    globals.set_int(2694562 + 41, 1) -- trigger
end
------
local CurrentHash = nil
local vehicle = nil
local SavedVehicles = 0
------
function MPX()
	return "MP"..stats.get_int("MPPLY_LAST_MP_CHAR").."_"
end
-------
function STATS_SET_PACKED_STAT_INT_CODE(index, value)
	if (index >= 384 and index < 457) then
		i = math.floor((index - 384) / 8)
		bit = (index - 384) % 8 * 8
		stathash = MPX.."PSTAT_INT"..i
	end
	if (index >= 1281 and index < 1305) then
		i = math.floor((index - 1281) / 8)
		bit = (index - 1281) % 8 * 8
		stathash = "MP_PSTAT_INT"..i
	end
	if (index >= 1361 and index < 1393) then
		i = math.floor((index - 1361) / 8)
		bit = (index - 1361) % 8 * 8
		stathash = "MP_TUPSTAT_INT"..i
	end
	if (index >= 1393 and index < 2919) then
		i = math.floor((index - 1393) / 8)
		bit = (index - 1393) % 8 * 8
		stathash = MPX.."TUPSTAT_INT"..i
	end
	if (index >= 3879 and index < 4143) then
		i = math.floor((index - 3879) / 8)
		bit = (index - 3879) % 8 * 8
		stathash = MPX.."NGPSTAT_INT"..i
	end
	if (index >= 4143 and index < 4207) then
		i = math.floor((index - 4143) / 8)
		bit = (index - 4143) % 8 * 8
		stathash = "MP_NGPSTAT_INT"..i
	end
	if (index >= 4399 and index < 6028) then
		i = math.floor((index - 4399) / 8)
		bit = (index - 4399) % 8 * 8
		stathash = MPX.."LRPSTAT_INT"..i
	end
	if (index >= 6413 and index < 7262) then
		i = math.floor((index - 6413) / 8)
		bit = (index - 6413) % 8 * 8
		stathash = MPX.."APAPSTAT_INT"..i
	end
	if (index >= 7262 and index < 7313) then
		i = math.floor((index - 7262) / 8)
		bit = (index - 7262) % 8 * 8
		stathash = MPX.."LR2PSTAT_INT"..i
	end
	if (index >= 7313 and index < 7321) then
		i = math.floor((index - 7313) / 8)
		bit = (index - 7313) % 8 * 8
		stathash = "MP_NGDLCPSTAT_INT"..i
	end
	if (index >= 7641 and index < 7681) then
		i = math.floor((index - 7641) / 8)
		bit = (index - 7641) % 8 * 8
		stathash = MPX.."NGDLCPSTAT_INT"..i
	end
	if (index >= 7681 and index < 9361) then
		i = math.floor((index - 7681) / 8)
		bit = (index - 7681) % 8 * 8
		stathash = MPX.."BIKEPSTAT_INT"..i
	end
	if (index >= 9553 and index < 15265) then
		i = math.floor((index - 9553) / 8)
		bit = (index - 9553) % 8 * 8
		stathash = MPX.."IMPEXPPSTAT_INT"..i
	end
	if (index >= 15265 and index < 15369) then
		i = math.floor((index - 15265) / 8)
		bit = ((index - 15265) % 8) * 8
		stathash = MPX.."GUNRPSTAT_INT"..i
	end
	if (index >= 16010 and index < 18098) then
		i = math.floor((index - 16010) / 8)
		bit = (index - 16010) % 8 * 8
		stathash = MPX.."DLCSMUGCHARPSTAT_INT"..i
	end
	if (index >= 18162 and index < 19018) then
		i = math.floor((index - 18162) / 8)
		bit = (index - 18162) % 8 * 8
		stathash = MPX.."GANGOPSPSTAT_INT"..i
	end
	if (index >= 19018 and index < 22066) then
		i = math.floor((index - 19018) / 8)
		bit = ((index - 19018) % 8) * 8
		stathash = MPX.."BUSINESSBATPSTAT_INT"..i
	end
	if (index >= 22194 and index < 24962) then
		i = math.floor((index - 22194) / 8)
		bit = (index - 22194) % 8 * 8
		stathash = MPX.."ARENAWARSPSTAT_INT"..i
	end
	if (index >= 25538 and index < 26810) then
		i = math.floor((index - 25538) / 8)
		bit = (index - 25538) % 8 * 8
		stathash = MPX.."CASINOPSTAT_INT"..i
	end
	if (index >= 27258 and index < 28098) then
		i = math.floor((index - 27258) / 8)
		bit = (index - 27258) % 8 * 8
		stathash = MPX.."CASINOHSTPSTAT_INT"..i
	end
	if (index >= 28483 and index < 30227) then
		i = math.floor((index - 28483) / 8)
		bit = (index - 28483) % 8 * 8
		stathash = MPX.."SU20PSTAT_INT"..i
	end
	if (index >= 30483 and index < 30515) then
		i = math.floor((index - 30483) / 8)
		bit = (index - 30483) % 8 * 8
		stathash = MPX.."HISLANDPSTAT_INT"..i
	end
	if (index >= 30707 and index < 31707) then
		i = math.floor((index - 30707) / 8)
		bit = (index - 30707) % 8 * 8
		stathash = MPX.."TUNERPSTAT_INT"..i
	end
	if (index >= 32475 and index < 34123) then
		i = math.floor((index - 32475) / 8)
		bit = (index - 32475) % 8 * 8
		stathash = MPX.."FIXERPSTAT_INT"..i
	end
	if (index >= 34763 and index < 36627) then
		i = math.floor((index - 34763) / 8)
		bit = (index - 34763) % 8 * 8
		stathash = MPX.."DLC12022PSTAT_INT"..i
	end
	if (index >= 36947 and index < 41251) then
		i = math.floor((index - 36947) / 8)
		bit = (index - 36947) % 8 * 8
		stathash = MPX.."DLC22022PSTAT_INT"..i
	end
	if (stathash ~= nil) then
		stats.set_masked_int(stathash, value, bit, 8)
	end
end
------
function Vehicle()
	return localplayer:get_current_vehicle()
end
------
function Weapons()
	return localplayer:get_current_weapon()
end
------
localTPpos = vector3(0, 0, 0)
------
--Teleports Positions
function setLocalPos()
	localTPpos = localplayer:get_position()
end
------
--Teleports POS
function tpLocalPos()
	local inCar = localplayer:is_in_vehicle()
	localplayer:set_position(localTPpos)
	if inCar == false then
		localplayer:set_position(localTPpos)
	else
		local car = localplayer:get_current_vehicle()
		car:set_position(localTPpos)
	end
end
------
    function GetWeaponExplosionType()
	    if localplayer ~= nil then 
			localweapon = localplayer:get_current_weapon()
			return localweapon:get_explosion_type()
		end 
		return 0
    end
     
    function GetWeaponDamageType()
    	localweapon = localplayer:get_current_weapon()
    	return localweapon:get_damage_type()
    end
     
    function GetWeaponRange()
    	localweapon = localplayer:get_current_weapon()
    	return localweapon:get_range()
    end
     
    function SetWeaponExplosionType(value)
    	localweapon = localplayer:get_current_weapon()
    	if localweapon ~= nil then
    		localweapon:set_explosion_type(value)
    	end
    end
     
    function SetWeaponDamageType(value)
    	localweapon = localplayer:get_current_weapon()
    	if localweapon ~= nil then
    		localweapon:set_damage_type(value)
    	end
    end
     
    function SetWeaponRange(value)
    	localweapon = localplayer:get_current_weapon()
    	if localweapon ~= nil then
    		localweapon:set_range(value)
    	end
    end
     
    local original_explosion_type = -1
    local original_damage_type = -1
    local original_range = -1
     
    function IsAtomizer()
    	explosion_type = GetWeaponExplosionType()
    	return explosion_type == 70
    end
     
    function SetAtomizer(value)
    	if localplayer ~= nil and value then
		    menu:max_all_ammo()
    		ChangeWeaponStats(70, 5, 9999)
    	else
    		ResetWeaponStats()
    	end
    end
     
    function IsZeppelinBoom()
    	explosion_type = GetWeaponExplosionType()
    	return explosion_type == 37
    end
     
    function SetZeppelinBoom(value)
    	if localplayer ~= nil and value then
    		ChangeWeaponStats(37, 5, 9999)
    	else
    		ResetWeaponStats()
    	end
    end
     
    function ChangeWeaponStats(new_expl, new_type, new_range)
    	--save old values
    	original_explosion_type = GetWeaponExplosionType()
    	original_damage_type = GetWeaponDamageType()
    	original_range = GetWeaponRange()
    	--set new values
    	SetWeaponExplosionType(new_expl)
    	SetWeaponDamageType(new_type)
    	SetWeaponRange(new_range)
    end
     
    function ResetWeaponStats()
    	SetWeaponExplosionType(original_explosion_type)
    	SetWeaponDamageType(original_damage_type)
    	SetWeaponRange(original_range)
    end
------
	menu.register_hotkey(35, function()	--END key
	if localplayer:is_in_vehicle() then
		current_vehicle = localplayer:get_current_vehicle()
		 current_vehicle:set_health(current_vehicle:get_max_health())
		 menu.repair_online_vehicle()
		current_vehicle:set_dirt_level(0.0)
	end
end)
------
STATS = {}
--------------------------------------------------------------------------------------------------- Script Function
function STATS.GET_PACKED_STAT_INT_DATA(index)
	if (index >= 384 and index < 457) then
		i = math.floor((index - 384) / 8)
		bit = (index - 384) % 8 * 8
		stathash = MPX.."PSTAT_INT"..i
	end
	if (index >= 1281 and index < 1305) then
		i = math.floor((index - 1281) / 8)
		bit = (index - 1281) % 8 * 8
		stathash = "MP_PSTAT_INT"..i
	end
	if (index >= 1361 and index < 1393) then
		i = math.floor((index - 1361) / 8)
		bit = (index - 1361) % 8 * 8
		stathash = "MP_TUPSTAT_INT"..i
	end
	if (index >= 1393 and index < 2919) then
		i = math.floor((index - 1393) / 8)
		bit = (index - 1393) % 8 * 8
		stathash = MPX.."TUPSTAT_INT"..i
	end
	if (index >= 3879 and index < 4143) then
		i = math.floor((index - 3879) / 8)
		bit = (index - 3879) % 8 * 8
		stathash = MPX.."NGPSTAT_INT"..i
	end
	if (index >= 4143 and index < 4207) then
		i = math.floor((index - 4143) / 8)
		bit = (index - 4143) % 8 * 8
		stathash = "MP_NGPSTAT_INT"..i
	end
	if (index >= 4399 and index < 6028) then
		i = math.floor((index - 4399) / 8)
		bit = (index - 4399) % 8 * 8
		stathash = MPX.."LRPSTAT_INT"..i
	end
	if (index >= 6413 and index < 7262) then
		i = math.floor((index - 6413) / 8)
		bit = (index - 6413) % 8 * 8
		stathash = MPX.."APAPSTAT_INT"..i
	end
	if (index >= 7262 and index < 7313) then
		i = math.floor((index - 7262) / 8)
		bit = (index - 7262) % 8 * 8
		stathash = MPX.."LR2PSTAT_INT"..i
	end
	if (index >= 7313 and index < 7321) then
		i = math.floor((index - 7313) / 8)
		bit = (index - 7313) % 8 * 8
		stathash = "MP_NGDLCPSTAT_INT"..i
	end
	if (index >= 7641 and index < 7681) then
		i = math.floor((index - 7641) / 8)
		bit = (index - 7641) % 8 * 8
		stathash = MPX.."NGDLCPSTAT_INT"..i
	end
	if (index >= 7681 and index < 9361) then
		i = math.floor((index - 7681) / 8)
		bit = (index - 7681) % 8 * 8
		stathash = MPX.."BIKEPSTAT_INT"..i
	end
	if (index >= 9553 and index < 15265) then
		i = math.floor((index - 9553) / 8)
		bit = (index - 9553) % 8 * 8
		stathash = MPX.."IMPEXPPSTAT_INT"..i
	end
	if (index >= 15265 and index < 15369) then
		i = math.floor((index - 15265) / 8)
		bit = ((index - 15265) % 8) * 8
		stathash = MPX.."GUNRPSTAT_INT"..i
	end
	if (index >= 16010 and index < 18098) then
		i = math.floor((index - 16010) / 8)
		bit = (index - 16010) % 8 * 8
		stathash = MPX.."DLCSMUGCHARPSTAT_INT"..i
	end
	if (index >= 18162 and index < 19018) then
		i = math.floor((index - 18162) / 8)
		bit = (index - 18162) % 8 * 8
		stathash = MPX.."GANGOPSPSTAT_INT"..i
	end
	if (index >= 19018 and index < 22066) then
		i = math.floor((index - 19018) / 8)
		bit = ((index - 19018) % 8) * 8
		stathash = MPX.."BUSINESSBATPSTAT_INT"..i
	end
	if (index >= 22194 and index < 24962) then
		i = math.floor((index - 22194) / 8)
		bit = (index - 22194) % 8 * 8
		stathash = MPX.."ARENAWARSPSTAT_INT"..i
	end
	if (index >= 25538 and index < 26810) then
		i = math.floor((index - 25538) / 8)
		bit = (index - 25538) % 8 * 8
		stathash = MPX.."CASINOPSTAT_INT"..i
	end
	if (index >= 27258 and index < 28098) then
		i = math.floor((index - 27258) / 8)
		bit = (index - 27258) % 8 * 8
		stathash = MPX.."CASINOHSTPSTAT_INT"..i
	end
	if (index >= 28483 and index < 30227) then
		i = math.floor((index - 28483) / 8)
		bit = (index - 28483) % 8 * 8
		stathash = MPX.."SU20PSTAT_INT"..i
	end
	if (index >= 30483 and index < 30515) then
		i = math.floor((index - 30483) / 8)
		bit = (index - 30483) % 8 * 8
		stathash = MPX.."HISLANDPSTAT_INT"..i
	end
	if (index >= 30707 and index < 31707) then
		i = math.floor((index - 30707) / 8)
		bit = (index - 30707) % 8 * 8
		stathash = MPX.."TUNERPSTAT_INT"..i
	end
	if (index >= 32475 and index < 34123) then
		i = math.floor((index - 32475) / 8)
		bit = (index - 32475) % 8 * 8
		stathash = MPX.."FIXERPSTAT_INT"..i
	end
	if (index >= 34763 and index < 36627) then
		i = math.floor((index - 34763) / 8)
		bit = (index - 34763) % 8 * 8
		stathash = MPX.."DLC12022PSTAT_INT"..i
	end
	if (index >= 36947 and index < 41251) then
		i = math.floor((index - 36947) / 8)
		bit = (index - 36947) % 8 * 8
		stathash = MPX.."DLC22022PSTAT_INT"..i
	end
end
 
function STATS.GET_PACKED_STAT_BOOL_DATA(index)
	if (index >= 0 and index < 192) then
		i = math.floor((index - 0) / 64)
		bit = (index - 0) % 64
		stathash = MPX.."PSTAT_BOOL"..i -- 0-191
	end
	if (index >= 513 and index < 705) then
		i = math.floor((index - 513) / 64)
		bit = (index - 513) % 64
		stathash = "MP_PSTAT_BOOL"..i -- 513-704
	end
	if (index >= 2919 and index < 3111) then
		i = math.floor((index - 2919) / 64)
		bit = (index - 2919) % 64
		stathash = "MP_TUPSTAT_BOOL"..i -- 2919-3110
	end
	if (index >= 3111 and index < 3879) then
		i = math.floor((index - 3111) / 64)
		bit = (index - 3111) % 64
		stathash = MPX.."TUPSTAT_BOOL"..i -- 3111-3878
	end
	if (index >= 4207 and index < 4335) then
		i = math.floor((index - 4207) / 64)
		bit = (index - 4207) % 64
		stathash = MPX .."NGPSTAT_BOOL"..i --4207--4334
	end
	if (index >= 4335 and index < 4399) then
		i = math.floor((index - 4335) / 64)
		bit = (index - 4335) % 64
		stathash = "MP_NGPSTAT_BOOL"..i -- 4335-4398
	end
	if (index >= 6029 and index < 6413) then
		i = math.floor((index - 6029) / 64)
		bit = (index - 6029) % 64
		stathash = MPX.."NGTATPSTAT_BOOL"..i -- 6029-6412
	end
	if (index >= 7321 and index < 7385) then
		i = math.floor((index - 7321) / 64)
		bit = (index - 7321) % 64
		stathash = "MP_NGDLCPSTAT_BOOL"..i -- 7321-7384
	end
	if (index >= 7385 and index < 7641) then
		i = math.floor((index - 7385) / 64)
		bit = (index - 7385) % 64
		stathash = MPX.."NGDLCPSTAT_BOOL"..i -- 7385--7640
	end
	if (index >= 9361 and index < 9553) then
		i = math.floor((index - 9361) / 64)
		bit = (index - 9361) % 64
		stathash = MPX.."DLCBIKEPSTAT_BOOL"..i -- 9361-9552
	end
	if (index >= 15369 and index < 15561) then
		i = math.floor((index - 15369) / 64)
		bit = (index - 15369) % 64
		stathash = MPX.."DLCGUNPSTAT_BOOL"..i -- 15369-15560
	end
	if (index >= 15562 and index < 15946) then
		i = math.floor((index - 15562) / 64)
		bit = (index - 15562) % 64
		stathash = MPX.."GUNTATPSTAT_BOOL"..i -- 15562-15945
	end
	if (index >= 15946 and index < 16010) then
		i = math.floor((index - 15946) / 64)
		bit = (index - 15946) % 64
		stathash = MPX.."DLCSMUGCHARPSTAT_BOOL"..i -- 15946-16009
	end
	if (index >= 18098 and index < 18162) then
		i = math.floor((index - 18098) / 64)
		bit = (index - 18098) % 64
		stathash = MPX.."GANGOPSPSTAT_BOOL"..i -- 18098-18161
	end
	if (index >= 22066 and index < 22194) then
		i = math.floor((index - 22066) / 64)
		bit = (index - 22066) % 64
		stathash = MPX.."BUSINESSBATPSTAT_BOOL"..i -- 22066-22193
	end
	if (index >= 24962 and index < 25538) then
		i = math.floor((index - 24962) / 64)
		bit = (index - 24962) % 64
		stathash = MPX.."ARENAWARSPSTAT_BOOL"..i -- 24962-25537
	end
	if (index >= 26810 and index < 27258) then
		i = math.floor((index - 26810) / 64)
		bit = (index - 26810) % 64
		stathash = MPX.."CASINOPSTAT_BOOL"..i -- 26810-27257
	end
	if (index >= 28098 and index < 28354) then
		i = math.floor((index - 28098) / 64)
		bit = (index - 28098) % 64
		stathash = MPX.."CASINOHSTPSTAT_BOOL"..i -- 28098-28353
	end
	if (index >= 28355 and index < 28483) then
		i = math.floor((index - 28355) / 64)
		bit = (index - 28355) % 64
		stathash = MPX.."HEIST3TATTOOSTAT_BOOL"..i -- 28355-28482
	end
	if (index >= 30227 and index < 30355) then
		i = math.floor((index - 30227) / 64)
		bit = (index - 30227) % 64
		stathash = MPX .. "SU20PSTAT_BOOL"..i -- 30227-30354
	end
	if (index >= 30355 and index < 30483) then
		i = math.floor((index - 30355) / 64)
		bit = (index - 30355) % 64
		stathash = MPX.."SU20TATTOOSTAT_BOOL"..i -- 30355-30482
	end
	if (index >= 30515 and index < 30707) then
		i = math.floor((index - 30515) / 64)
		bit = (index - 30515) % 64
		stathash = MPX .. "HISLANDPSTAT_BOOL"..i -- 30515-30706
	end
	if (index >= 31707 and index < 32283) then
		i = math.floor((index - 31707) / 64)
		bit = (index - 31707) % 64
		stathash = MPX.."TUNERPSTAT_BOOL"..i -- 31707-32282
	end
	if (index >= 32283 and index < 32411) then
		i = math.floor((index - 32283) / 64)
		bit = (index - 32283) % 64
		stathash = MPX.."FIXERPSTAT_BOOL"..i -- 32283-32410
	end
	if (index >= 32411 and index < 32475) then
		i = math.floor((index - 32411) / 64)
		bit = (index - 32411) % 64
		stathash = MPX.."FIXERTATTOOSTAT_BOOL"..i -- 32411-32474
	end
	if (index >= 34123 and index < 34251) then
		i = math.floor((index - 34123) / 64)
		bit = (index - 34123) % 64
		stathash = MPX.."GEN9PSTAT_BOOL"..i -- 34123-34250
	end
	if (index >= 34251 and index < 34763) then
		i = math.floor((index - 34251) / 64)
		bit = (index - 34251) % 64
		stathash = MPX.."DLC12022PSTAT_BOOL"..i -- 34251-34762
	end
	if (index >= 36627 and index < 36947) then
		i = math.floor((index - 36627) / 64)
		bit = (index - 36627) % 64
		stathash = MPX.."DLC22022PSTAT_BOOL"..i -- 36627-36946
	end
	if (index >= 41251 and index < 41315) then
		i = math.floor((index - 41251) / 64)
		bit = (index - 41251) % 64
		stathash = MPX.."DLC22022TATTOOSTAT_BOOL"..i -- 41251-41314
	end
end
 
function STATS.GET_PACKED_STAT_INT_CODE(index)
	STATS.GET_PACKED_STAT_INT_DATA(index)
	if (stathash ~= nil) then
		return stats.get_masked_int(stathash, bit, 8)
	end
end
 
function STATS.GET_PACKED_STAT_BOOL_CODE(index)
	STATS.GET_PACKED_STAT_BOOL_DATA(index)
	if (stathash ~= nil) then
		return stats.get_bool_masked(stathash, bit)
	end
end
 
function STATS.GET_PACKED_STAT_INT_SBIV(index)
	STATS.GET_PACKED_STAT_INT_DATA(index)
	if (stathash ~= nil) then
		return "STATS: "..stathash.."    ", "BIT: "..bit.."    ", "INDEX: "..index.."    ", "VALUE: "..stats.get_masked_int(stathash, bit, 8)
	end
end
 
function STATS.GET_PACKED_STAT_BOOL_SBIV(index)
	STATS.GET_PACKED_STAT_BOOL_DATA(index)
	if (stathash ~= nil) then
		return "STATS: "..stathash.."    ", "BIT: "..bit.."    ", "INDEX: "..index.."    ", "BOOL:", stats.get_bool_masked(stathash, bit)
	end
end
 
function STATS.GET_PACKED_STAT_INT_SBIV_ALL(min, max, data)
	if data == true then
		for i = min, max do
			oldvalue[i] = STATS.GET_PACKED_STAT_INT_CODE(i)
		end
	end
	if data == false then
		for i = min, max do
			if STATS.GET_PACKED_STAT_INT_CODE(i) ~= oldvalue[i] then
				print(STATS.GET_PACKED_STAT_INT_SBIV(i))
			end
		end
	end
end
 
function STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(min, max, data)
	if data == true then
		for i = min, max do
			oldbool[i] = STATS.GET_PACKED_STAT_BOOL_CODE(i)
		end
	end
	if data == false then
		for i = min, max do
			if STATS.GET_PACKED_STAT_BOOL_CODE(i) ~= oldbool[i] then
				print(STATS.GET_PACKED_STAT_BOOL_SBIV(i))
			end
		end
	end
end
 
--------------------------------------------------------------------------------------------------- Get Packed Data
function add_packed_bool_submenu(DLC, SubmenuName, SubmenuNumber, StatName, Character)
	local SubmenuName = {}
	for num = 0, SubmenuNumber do
		SubmenuName[num] = DLC:add_submenu(StatName..num)
		for i = 0, 63 do
			SubmenuName[num]:add_toggle(""..i, function()
				if Character == true then
					return stats.get_bool_masked(MPX..StatName..num, i)
				end
				if Character == false then
					return stats.get_bool_masked(StatName..num, i)
				end
				end, function()
			end)
		end
	end
end
------
Csyon1=262145+8352
Csyon2=262145+8353
Csyon3=262145+8354
Csyon4=262145+8355
Csyon5=262145+8356
Csyon6=262145+8357
Csyon7=262145+8358
Csyon8=262145+8359
Csyon9=262145+8360
-------
------

------
------
------
------
------
------
------
------
------
------
------
------
------
------
------
------
------
------
------
------
------
------
------
------
------
------
------
------
------
------
------
------ 【 S 】 Car boost Hotkey INSERT
--####################################--
local function loop()
--------------------------------------------------------------

    -- call custom functions here to loop in Cyson Submenu lel Cyson was here Hi guys :D
	 giverp()

---------------------------------------------------------------
end 
------

Text("**************************************************************************")
Text("            ** CSYON SubMenu 1.67 **                  ")
Text("                               **✅ v13 **                   ")
Text("            ** ⚠️Game Build Version 2845⚠️ **                  ")
Text("**************************************************************************")

Online= mainMenu:add_submenu("🚨  GTAOnline")

CSYON2 = Online:add_submenu("✨ Unlock Misc")

CSYON4 = Online:add_submenu("🔫 Weapon Features")

CSYON5 = Online:add_submenu("🚗Vehicles Features")

CSYON24 = Online:add_submenu("🚗 Vehicle Tuning 🚗")

CSYON6 = Online:add_submenu("🛡️ Protections")

CSYON7 = Online:add_submenu("🕺 Players Features")

CSYON8 = Online:add_submenu("🎮Unlock Alls")

CSYON22 = Online:add_submenu("🎴 Collections")

CSYON23 = Online:add_submenu("📈Packed Stat")

CSYON9 = Online:add_submenu("💵 Money Options")

CSYON10 = Online:add_submenu("🗞 Level Options")

CSYON11 = Online:add_submenu("🧨 Trolling Options")

CSYON12 = Online:add_submenu("📔 Other Options")

CSYON13 = Online:add_submenu("🗜Tunables")

CSYON14 = Online:add_submenu("📈Stats Editior")

CSYON15 = Online:add_submenu("🧿Teleports")

CSYON16 = Online:add_submenu("🗺Lobby")

CSYON17 = Online:add_submenu("📁Story Mode")

CSYON18 = Online:add_submenu("📘Hotkeys")

CSYON19 = Online:add_submenu("📶Online Features")

CSYON20 = Online:add_submenu("⚠Risky Options")

CSYON21 = Online:add_submenu("⚠info for help")

CSYONS2 = CSYON2:add_submenu("✨ Misc things activater unlocker ")
CSYONS4 = CSYON4:add_submenu("🔫 Weapon options? ")
CSYONS5 = CSYON5:add_submenu("🚗 Vehicles Modifications? ")
CSYONS24 = CSYON24:add_submenu("🚗Tuning?")
CSYONS6 = CSYON6:add_submenu("🛡️ want Protections? ")
CSYONS7 = CSYON7:add_submenu("🕺 Players Mods? ")
CSYONS8 = CSYON8:add_submenu("🎮Unlock All? ")
CSYONS22 = CSYON22:add_submenu("🎴 Collections or nah? ")
CSYONS9 = CSYON9:add_submenu("💵 Money? ")
CSYONS10 = CSYON10:add_submenu("🗞 Level? ")
CSYONS11 = CSYON11:add_submenu("🧨 do you want Trolling? ")
CSYONS12 = CSYON12:add_submenu("📔 do you want Misc Features? ")
CSYONS13 = CSYON13:add_submenu("🗜holy shit is this Tunables? nice")
CSYONS14 = CSYON14:add_submenu("📈 Holy Stats editing!")
CSYONS15 = CSYON15:add_submenu("🧿The Teleports?")
CSYONS16 = CSYON16:add_submenu("🗺Lobby/Seassion")
CSYONS17 = CSYON17:add_submenu("📁Story Mods")
CSYONS18 = CSYON18:add_submenu("【 CSYON 】 📘Remove Hotkeys📘")
CSYONS19 = CSYON19:add_submenu("📶Online Features")
CSYONS20 = CSYON20:add_submenu("⚠Risky Options")
CSYONS21 = CSYON21:add_submenu("⚠ReadMe")
-- CSYONS8r = CSYON8:add_submenu("Still Slipping Los Santos Outfit")



menu.register_hotkey(110, function()
	if localplayer ~= nil and localplayer:is_in_vehicle() then 
		vehicle = localplayer:get_current_vehicle()
		grav = vehicle:get_gravity()
		vehicle:set_gravity(-50)
		sleep(0.2)
		vehicle:set_gravity(grav)
	end
end)

CSYONS8:add_action("Unlock your Gunvans RailGun", function()
globals.set_int(262145 + 33840 + 3, -22923932) ----- Global is a World
end)

CSYONS8:add_action("Unlock Up-n-Atomizer", function()
		globals.set_int(103634, 90)
		stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 40)
		stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", false, 45)
end)
CSYONS8:add_action("Unlock Festive Tint", function()
		globals.set_int(103635, 90)
		stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL6", true, 59)
		stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL6", false, 60)
end)
CSYONS8:add_action("Valentine Stuff Unlocks", function()
		globals.set_int(269001, 1)
		globals.set_int(273964, 1)
		globals.set_int(273965, 1)
		globals.set_int(273966, 1)
		globals.set_int(273967, 1)
		globals.set_int(273968, 1)
		globals.set_int(275330, 1)
		globals.set_int(275331, 1)
end)

Suspension = CSYONS24:add_submenu("Suspension")
Traction = CSYONS24:add_submenu("Traction")
Roll_Bar = CSYONS24:add_submenu("Roll Bar")

Suspension:add_float_range("Front Bias", 0.01, 0.0, 1.0, function()
	if localplayer:is_in_vehicle() then
		return localplayer:get_current_vehicle():get_suspension_bias_front()
	end
end, function(value)
	if value ~= nil then
		localplayer:get_current_vehicle():set_suspension_bias_front(value)
	end
end)

Suspension:add_float_range("Force", 0.01, -8000000.0, 8000000.0, function()
	if localplayer:is_in_vehicle() then
		return localplayer:get_current_vehicle():get_suspension_force()
	end
end, function(value)
	if value ~= nil then
		localplayer:get_current_vehicle():set_suspension_force(value)
	end
end)

Suspension:add_float_range("Height", 0.01, -8000000.0, 8000000.0, function()
	if localplayer:is_in_vehicle() then
		return localplayer:get_current_vehicle():get_suspension_height()
	end
end, function(value)
	if value ~= nil then
		localplayer:get_current_vehicle():set_suspension_height(value)
	end
end)

Suspension:add_float_range("Lower Limit", 0.01, -8000000.0, 8000000.0, function()
	if localplayer:is_in_vehicle() then
		return localplayer:get_current_vehicle():get_suspension_lower_limit()
	end
end, function(value)
	if value ~= nil then
		localplayer:get_current_vehicle():set_suspension_lower_limit(value)
	end
end)

Suspension:add_float_range("Upper Limit", 0.01, -8000000.0, 8000000.0, function()
	if localplayer:is_in_vehicle() then
		return localplayer:get_current_vehicle():get_suspension_upper_limit()
	end
end, function(value)
	if value ~= nil then
		localplayer:get_current_vehicle():set_suspension_upper_limit(value)
	end
end)

Suspension:add_float_range("Raise", 0.01, -8000000.0, 8000000.0, function()
	if localplayer:is_in_vehicle() then
		return localplayer:get_current_vehicle():get_suspension_raise()
	end
end, function(value)
	if value ~= nil then
		localplayer:get_current_vehicle():set_suspension_raise(value)
	end
end)

Suspension:add_float_range("Compression Damping", 0.01, -8000000.0, 8000000.0, function()
	if localplayer:is_in_vehicle() then
		return localplayer:get_current_vehicle():get_suspension_comp_damp()
	end
end, function(value)
	if value ~= nil then
		localplayer:get_current_vehicle():set_suspension_comp_damp(value)
	end
end)

Suspension:add_float_range("Rebound Damping", 0.01, -8000000.0, 8000000.0, function()
	if localplayer:is_in_vehicle() then
		return localplayer:get_current_vehicle():get_suspension_rebound_damp()
	end
end, function(value)
	if value ~= nil then
		localplayer:get_current_vehicle():set_suspension_rebound_damp(value)
	end
end)

Traction:add_float_range("Front Bias", 0.01, 0.0, 1.0, function()
	if localplayer:is_in_vehicle() then
		return localplayer:get_current_vehicle():get_traction_bias_front()
	end
end, function(value)
	if value ~= nil then
		localplayer:get_current_vehicle():set_traction_bias_front(value)
	end
end)


Traction:add_float_range("Lateral Curve", 0.01, 0.0, 1.0, function()
	if localplayer:is_in_vehicle() then
		return localplayer:get_current_vehicle():get_traction_curve_lateral()
	end
end, function(value)
	if value ~= nil then
		localplayer:get_current_vehicle():set_traction_curve_lateral(value)
	end
end)


Traction:add_float_range("Maximum Curve", 0.01, 0.0, 8000000.0, function()
	if localplayer:is_in_vehicle() then
		return localplayer:get_current_vehicle():get_traction_curve_max()
	end
end, function(value)
	if value ~= nil then
		localplayer:get_current_vehicle():set_traction_curve_max(value)
	end
end)


Traction:add_float_range("Minimum Curve", 0.01, 0.0, 8000000.0, function()
	if localplayer:is_in_vehicle() then
		return localplayer:get_current_vehicle():get_traction_curve_min()
	end
end, function(value)
	if value ~= nil then
		localplayer:get_current_vehicle():set_traction_curve_min(value)
	end
end)


Traction:add_float_range("Loss Multiplier", 0.01, 0.0, 8000000.0, function()
	if localplayer:is_in_vehicle() then
		return localplayer:get_current_vehicle():get_traction_loss_multiplier()
	end
end, function(value)
	if value ~= nil then
		localplayer:get_current_vehicle():set_traction_loss_multiplier(value)
	end
end)


Traction:add_float_range("Max Spring Delta", 0.01, 0.0, 8000000.0, function()
	if localplayer:is_in_vehicle() then
		return localplayer:get_current_vehicle():get_traction_spring_delta_max()
	end
end, function(value)
	if value ~= nil then
		localplayer:get_current_vehicle():set_traction_spring_delta_max(value)
	end
end)

Roll_Bar:add_float_range("Front Bias", 0.01, 0.0, 1.0, function()
	if localplayer:is_in_vehicle() then
		return localplayer:get_current_vehicle():get_anti_roll_bar_bias_front()
	end
end, function(value)
	if value ~= nil then
		localplayer:get_current_vehicle():set_anti_roll_bar_bias_front(value)
	end
end)


Roll_Bar:add_float_range("Force", 0.01, 0.0, 8000000.0, function()
	if localplayer:is_in_vehicle() then
		return localplayer:get_current_vehicle():get_anti_roll_bar_force()
	end
end, function(value)
	if value ~= nil then
		localplayer:get_current_vehicle():set_anti_roll_bar_force(value)
	end
end)

CSYONS8:add_int_range("Grab Jack o' Latern", 1, 0, 200, function()
	return globals.get_int(2788199 + 589)
end, function(value)
	globals.set_int(2788817, value)
	globals.set_int(2788199 + 564, 8)
	globals.set_int(2788199 + 498, 0)
	local current = globals.get_int(2788199 + 214)
	current = current | (1 << 17)
	globals.set_int(2788199 + 214, current)
end)

local function NmP(e) if not localplayer then return end if e then for i = Csyon1, Csyon2 do globals.set_int(i, 0) end else globals.set_int(Csyon1, 1) globals.set_int(Csyon3, 2) globals.set_int(Csyon4, 3) globals.set_int(Csyon5, 4) globals.set_int(Csyon6, 6) globals.set_int(Csyon7, 8) globals.set_int(Csyon8, 10) globals.set_int(Csyon9, 12) globals.set_int(Csyon2, 15) end end CSYONS2:add_toggle("No Mission Time Penalties", function() return e44 end, function() e44 = not e44 NmP(e44) end)

CSYONS2:add_action("CEO/MC Money Clutter", function() stats.set_int(mpx .. "LIFETIME_BUY_COMPLETE", 1000) stats.set_int(mpx .. "LIFETIME_BUY_UNDERTAKEN", 1000) stats.set_int(mpx .. "LIFETIME_SELL_COMPLETE", 1000) stats.set_int(mpx .. "LIFETIME_SELL_UNDERTAKEN", 1000) stats.set_int(mpx .. "LIFETIME_CONTRA_EARNINGS", 20000000) stats.set_int(mpx .. "LIFETIME_BIKER_BUY_COMPLET", 1000) stats.set_int(mpx .. "LIFETIME_BIKER_BUY_UNDERTA", 1000) stats.set_int(mpx .. "LIFETIME_BIKER_SELL_COMPLET", 1000) stats.set_int(mpx .. "LIFETIME_BIKER_SELL_UNDERTA", 1000) stats.set_int(mpx .. "LIFETIME_BIKER_BUY_COMPLET1", 1000) stats.set_int(mpx .. "LIFETIME_BIKER_BUY_UNDERTA1", 1000) stats.set_int(mpx .. "LIFETIME_BIKER_SELL_COMPLET1", 1000) stats.set_int(mpx .. "LIFETIME_BIKER_SELL_UNDERTA1", 1000) stats.set_int(mpx .. "LIFETIME_BIKER_BUY_COMPLET2", 1000) stats.set_int(mpx .. "LIFETIME_BIKER_BUY_UNDERTA2", 1000) stats.set_int(mpx .. "LIFETIME_BIKER_SELL_COMPLET2", 1000) stats.set_int(mpx .. "LIFETIME_BIKER_SELL_UNDERTA2", 1000) stats.set_int(mpx .. "LIFETIME_BIKER_BUY_COMPLET3", 1000) stats.set_int(mpx .. "LIFETIME_BIKER_BUY_UNDERTA3", 1000) stats.set_int(mpx .. "LIFETIME_BIKER_SELL_COMPLET3", 1000) stats.set_int(mpx .. "LIFETIME_BIKER_SELL_UNDERTA3", 1000) stats.set_int(mpx .. "LIFETIME_BIKER_BUY_COMPLET4", 1000) stats.set_int(mpx .. "LIFETIME_BIKER_BUY_UNDERTA4", 1000) stats.set_int(mpx .. "LIFETIME_BIKER_SELL_COMPLET4", 1000) stats.set_int(mpx .. "LIFETIME_BIKER_SELL_UNDERTA4", 1000) stats.set_int(mpx .. "LIFETIME_BIKER_BUY_COMPLET5", 1000) stats.set_int(mpx .. "LIFETIME_BIKER_BUY_UNDERTA5", 1000) stats.set_int(mpx .. "LIFETIME_BIKER_SELL_COMPLET5", 1000) stats.set_int(mpx .. "LIFETIME_BIKER_SELL_UNDERTA5", 1000) stats.set_int(mpx .. "LIFETIME_BKR_SELL_EARNINGS0", 20000000) stats.set_int(mpx .. "LIFETIME_BKR_SELL_EARNINGS1", 20000000) stats.set_int(mpx .. "LIFETIME_BKR_SELL_EARNINGS2", 20000000) stats.set_int(mpx .. "LIFETIME_BKR_SELL_EARNINGS3", 20000000) stats.set_int(mpx .. "LIFETIME_BKR_SELL_EARNINGS4", 20000000) stats.set_int(mpx .. "LIFETIME_BKR_SELL_EARNINGS5", 20000000) stats.set_int(mpx .. "LFETIME_IE_EXPORT_COMPLETED", 1000) stats.set_int(mpx .. "LFETIME_IE_MISSION_EARNINGS", 20000000) stats.set_int(mpx .. "LFETIME_HANGAR_EARNINGS", 20000000) stats.set_int(mpx .. "BKR_PROD_STOP_COUT_S1_0", 500) stats.set_int(mpx .. "BKR_PROD_STOP_COUT_S2_0", 500) stats.set_int(mpx .. "BKR_PROD_STOP_COUT_S3_0", 500) stats.set_int(mpx .. "LIFETIME_BKR_SELL_UNDERTABC", 500) stats.set_int(mpx .. "LIFETIME_BKR_SELL_COMPLETBC", 500) stats.set_int(mpx .. "LFETIME_BIKER_BUY_UNDERTA1", 500) stats.set_int(mpx .. "LFETIME_BIKER_BUY_COMPLET1", 500) stats.set_int(mpx .. "LFETIME_BIKER_SELL_UNDERTA1", 500) stats.set_int(mpx .. "LFETIME_BIKER_SELL_COMPLET1", 500) stats.set_int(mpx .. "LIFETIME_BKR_SEL_UNDERTABC1", 500) stats.set_int(mpx .. "LIFETIME_BKR_SEL_COMPLETBC1", 500) stats.set_int(mpx .. "BKR_PROD_STOP_COUT_S1_1", 500) stats.set_int(mpx .. "BKR_PROD_STOP_COUT_S2_1", 500) stats.set_int(mpx .. "BKR_PROD_STOP_COUT_S3_1", 500) stats.set_int(mpx .. "LFETIME_BIKER_BUY_UNDERTA2", 500) stats.set_int(mpx .. "LFETIME_BIKER_BUY_COMPLET2", 500) stats.set_int(mpx .. "LFETIME_BIKER_SELL_UNDERTA2", 500) stats.set_int(mpx .. "LFETIME_BIKER_SELL_COMPLET2", 500) stats.set_int(mpx .. "LIFETIME_BKR_SEL_UNDERTABC2", 500) stats.set_int(mpx .. "LIFETIME_BKR_SEL_COMPLETBC2", 500) stats.set_int(mpx .. "BKR_PROD_STOP_COUT_S1_2", 500) stats.set_int(mpx .. "BKR_PROD_STOP_COUT_S2_2", 500) stats.set_int(mpx .. "BKR_PROD_STOP_COUT_S3_2", 500) stats.set_int(mpx .. "LFETIME_BIKER_BUY_UNDERTA3", 500) stats.set_int(mpx .. "LFETIME_BIKER_BUY_COMPLET3", 500) stats.set_int(mpx .. "LFETIME_BIKER_SELL_UNDERTA3", 500) stats.set_int(mpx .. "LFETIME_BIKER_SELL_COMPLET3", 500) stats.set_int(mpx .. "LIFETIME_BKR_SEL_UNDERTABC3", 500) stats.set_int(mpx .. "LIFETIME_BKR_SEL_COMPLETBC3", 500) stats.set_int(mpx .. "BKR_PROD_STOP_COUT_S1_3", 500) stats.set_int(mpx .. "BKR_PROD_STOP_COUT_S2_3", 500) stats.set_int(mpx .. "BKR_PROD_STOP_COUT_S3_3", 500) stats.set_int(mpx .. "LFETIME_BIKER_BUY_UNDERTA4", 500) stats.set_int(mpx .. "LFETIME_BIKER_BUY_COMPLET4", 500) stats.set_int(mpx .. "LFETIME_BIKER_SELL_UNDERTA4", 500) stats.set_int(mpx .. "LFETIME_BIKER_SELL_COMPLET4", 500) stats.set_int(mpx .. "LIFETIME_BKR_SEL_UNDERTABC4", 500) stats.set_int(mpx .. "LIFETIME_BKR_SEL_COMPLETBC4", 500) stats.set_int(mpx .. "BKR_PROD_STOP_COUT_S1_4", 500) stats.set_int(mpx .. "BKR_PROD_STOP_COUT_S2_4", 500) stats.set_int(mpx .. "BKR_PROD_STOP_COUT_S3_4", 500) stats.set_int(mpx .. "LFETIME_BIKER_BUY_UNDERTA5", 500) stats.set_int(mpx .. "LFETIME_BIKER_BUY_COMPLET5", 500) stats.set_int(mpx .. "LIFETIME_BKR_SEL_UNDERTABC5", 500) stats.set_int(mpx .. "LIFETIME_BKR_SEL_COMPLETBC5", 500) stats.set_int(mpx .. "LFETIME_BIKER_SELL_UNDERTA5", 500) stats.set_int(mpx .. "LFETIME_BIKER_SELL_COMPLET5", 500) stats.set_int(mpx .. "BUNKER_UNITS_MANUFAC", 500) stats.set_int(mpx .. "LFETIME_HANGAR_BUY_UNDETAK", 500) stats.set_int(mpx .. "LFETIME_HANGAR_BUY_COMPLET", 500) stats.set_int(mpx .. "LFETIME_HANGAR_SEL_UNDETAK", 500) stats.set_int(mpx .. "LFETIME_HANGAR_SEL_COMPLET", 500) stats.set_int(mpx .. "LFETIME_HANGAR_EARN_BONUS", 1598746) stats.set_int(mpx .. "RIVAL_HANGAR_CRATES_STOLEN", 500) stats.set_int(mpx .. "LFETIME_IE_STEAL_STARTED", 500) stats.set_int(mpx .. "LFETIME_IE_EXPORT_STARTED", 500) stats.set_int(mpx .. "AT_FLOW_IMPEXP_NUM", 500) globals.set_int(LOBS2, 1) sleep(0.2) globals.set_int(LOBS2, 0) end)

CSYONS2:add_action("Trigger Alien Egg Mission", function() stats.set_int(MPX.."LFETIME_BIKER_BUY_COMPLET5",1200) stats.set_int(MPX.."LFETIME_BIKER_BUY_UNDERTA5",1200) globals.set_int(REQS1+ 5225 + 344, 20) end)
 
CSYONS23 = CSYON23:add_submenu("📈Packed Stat") -- main submenu
DLC1 = CSYONS23:add_submenu("Get Packed Data") -- DLC submenu
add_packed_bool_submenu(DLC1, PSTAT_BOOL, 2, "PSTAT_BOOL", true) -- add packed stat sub
 
CSYONS23:add_action("initialization all packed int|", function()
	oldvalue = {}
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(384, 456, true)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(1281, 1304, true)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(1361, 1392, true)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(1393, 2918, true)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(3879, 4142, true)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(4143, 4206, true)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(4399, 6027, true)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(6413, 7261, true)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(7262, 7312, true)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(7313, 7321, true)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(7641, 7680, true)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(7681, 9360, true)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(9553, 15264, true)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(15265, 15368, true)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(16010, 18097, true)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(18162, 19017, true)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(19018, 22065, true)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(22194, 24961, true)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(25538, 26809, true)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(27258, 28097, true)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(28483, 30226, true)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(30483, 30514, true)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(30707, 31706, true)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(32475, 34122, true)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(34763, 36626, true)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(36947, 41250, true)
end)
 
CSYONS23:add_action("compare and print all packed int|", function()
	print("----------------------------CSYON WAS HERE--------------------------------------")
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(384, 456, false)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(1281, 1304, false)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(1361, 1392, false)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(1393, 2918, false)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(3879, 4142, false)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(4143, 4206, false)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(4399, 6027, false)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(6413, 7261, false)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(7262, 7312, false)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(7313, 7321, false)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(7641, 7680, false)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(7681, 9360, false)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(9553, 15264, false)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(15265, 15368, false)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(16010, 18097, false)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(18162, 19017, false)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(19018, 22065, false)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(22194, 24961, false)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(25538, 26809, false)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(27258, 28097, false)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(28483, 30226, false)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(30483, 30514, false)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(30707, 31706, false)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(32475, 34122, false)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(34763, 36626, false)
	STATS.GET_PACKED_STAT_INT_SBIV_ALL(36947, 41250, false)
end)
 
CSYONS23:add_action("initialization all packed bool|", function()
	oldbool = {}
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(0, 191, true)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(513, 704, true)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(2919, 3110, true)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(3111, 3878, true)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(4207, 4334, true)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(4335, 4398, true)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(6029, 6412, true)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(7321, 7384, true)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(7385, 7640, true)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(9361, 9552, true)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(15369, 15560, true)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(15562, 15945, true)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(15946, 16009, true)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(18098, 18161, true)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(22066, 22193, true)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(24962, 25537, true)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(26810, 27257, true)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(28098, 28353, true)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(28355, 28482, true)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(30227, 30354, true)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(30355, 30482, true)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(30515, 30706, true)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(31707, 32282, true)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(32283, 32410, true)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(32411, 32474, true)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(34123, 34250, true)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(34251, 34762, true)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(36627, 36946, true)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(41251, 41314, true)
end)
 
CSYONS23:add_action("compare and print all packed bool|", function()
	print("------------------------CSYON Submenu---------------------------------")
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(0, 191, false)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(513, 704, false)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(2919, 3110, false)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(3111, 3878, false)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(4207, 4334, false)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(4335, 4398, false)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(6029, 6412, false)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(7321, 7384, false)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(7385, 7640, false)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(9361, 9552, false)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(15369, 15560, false)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(15562, 15945, false)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(15946, 16009, false)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(18098, 18161, false)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(22066, 22193, false)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(24962, 25537, false)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(26810, 27257, false)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(28098, 28353, false)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(28355, 28482, false)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(30227, 30354, false)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(30355, 30482, false)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(30515, 30706, false)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(31707, 32282, false)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(32283, 32410, false)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(32411, 32474, false)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(34123, 34250, false)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(34251, 34762, false)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(36627, 36946, false)
	STATS.GET_PACKED_STAT_BOOL_SBIV_ALL(41251, 41314, false)
end)

CSYONS8:add_action("Complete Flight School", function()
	stats.set_int(MPX .. "PILOT_SCHOOL_MEDAL_0", 3)
	stats.set_int(MPX .. "PILOT_SCHOOL_MEDAL_1", 3)
	stats.set_int(MPX .. "PILOT_SCHOOL_MEDAL_2", 3)
	stats.set_int(MPX .. "PILOT_SCHOOL_MEDAL_3", 3)
	stats.set_int(MPX .. "PILOT_SCHOOL_MEDAL_4", 3)
	stats.set_int(MPX .. "PILOT_SCHOOL_MEDAL_5", 3)
	stats.set_int(MPX .. "PILOT_SCHOOL_MEDAL_6", 3)
	stats.set_int(MPX .. "PILOT_SCHOOL_MEDAL_7", 3)
	stats.set_int(MPX .. "PILOT_SCHOOL_MEDAL_8", 3)
	stats.set_int(MPX .. "PILOT_SCHOOL_MEDAL_9", 3)
	stats.set_int(MPX .. "PILOT_SCHOOL_LASTMEDAL_0", 3)
	stats.set_int(MPX .. "PILOT_SCHOOL_LASTMEDAL_1", 3)
	stats.set_int(MPX .. "PILOT_SCHOOL_LASTMEDAL_2", 3)
	stats.set_int(MPX .. "PILOT_SCHOOL_LASTMEDAL_3", 3)
	stats.set_int(MPX .. "PILOT_SCHOOL_LASTMEDAL_4", 3)
	stats.set_int(MPX .. "PILOT_SCHOOL_LASTMEDAL_5", 3)
	stats.set_int(MPX .. "PILOT_SCHOOL_LASTMEDAL_6", 3)
	stats.set_int(MPX .. "PILOT_SCHOOL_LASTMEDAL_7", 3)
	stats.set_int(MPX .. "PILOT_SCHOOL_LASTMEDAL_8", 3)
	stats.set_int(MPX .. "PILOT_SCHOOL_LASTMEDAL_9", 3)
	stats.set_int(MPX .. "CRPILOTSCHOOL", 1)
	stats.set_int(MPX .. "PILOT_CHECKPOINTCOUNT_9", 27)
	stats.set_float(MPX .. "PILOT_ELAPSEDTIME_0", 58.0)
	stats.set_float(MPX .. "PILOT_LANDINGDISTANCE_1", 10.0)
	stats.set_float(MPX .. "PILOT_LANDINGDISTANCE_2", 2.0)
	stats.set_float(MPX .. "PILOT_LANDINGDISTANCE_3", 10.0)
	stats.set_float(MPX .. "PILOT_ELAPSEDTIME_4", 19.0)
	stats.set_float(MPX .. "PILOT_LANDINGDISTANCE_5", 600.0)
	stats.set_float(MPX .. "PILOT_LANDINGDISTANCE_6", 25.0)
	stats.set_float(MPX .. "PILOT_LANDINGDISTANCE_7", 1.0)
	stats.set_float(MPX .. "PILOT_ELAPSEDTIME_8", 160.0)
	stats.set_float(MPX .. "PILOT_ELAPSEDTIME_9", 145.0)
	stats.set_float(MPX .. "PILOT_LASTELAPSEDTIME_0", 58.0)
	stats.set_float(MPX .. "PILOT_LASTLANDDISTANCE_1", 10.0)
	stats.set_float(MPX .. "PILOT_LASTLANDDISTANCE_2", 2.0)
	stats.set_float(MPX .. "PILOT_LASTLANDDISTANCE_3", 10.0)
	stats.set_float(MPX .. "PILOT_LASTELAPSEDTIME_4", 19.0)
	stats.set_float(MPX .. "PILOT_LASTLANDDISTANCE_5", 600.0)
	stats.set_float(MPX .. "PILOT_LASTLANDDISTANCE_6", 25.0)
	stats.set_float(MPX .. "PILOT_LASTLANDDISTANCE_7", 1.0)
	stats.set_float(MPX .. "PILOT_LASTELAPSEDTIME_8", 160.0)
	stats.set_float(MPX .. "PILOT_LASTELAPSEDTIME_9", 145.0)
	stats.set_bool(MPX .. "PILOT_ASPASSEDLESSON_0", true)
	stats.set_bool(MPX .. "PILOT_ASPASSEDLESSON_1", true)
	stats.set_bool(MPX .. "PILOT_ASPASSEDLESSON_2", true)
	stats.set_bool(MPX .. "PILOT_ASPASSEDLESSON_3", true)
	stats.set_bool(MPX .. "PILOT_ASPASSEDLESSON_4", true)
	stats.set_bool(MPX .. "PILOT_ASPASSEDLESSON_5", true)
	stats.set_bool(MPX .. "PILOT_ASPASSEDLESSON_6", true)
	stats.set_bool(MPX .. "PILOT_ASPASSEDLESSON_7", true)
	stats.set_bool(MPX .. "PILOT_ASPASSEDLESSON_8", true)
	stats.set_bool(MPX .. "PILOT_ASPASSEDLESSON_9", true)
	stats.set_bool_masked(MPX .. "TUPSTAT_BOOL7", true, 49)
end)

CSYONS8:add_action("Unlock Temporarily Auto Shop Race 'n Chase", function()
	stats.set_bool_masked(MPX.."TUNERPSTAT_BOOL0", true, 48)
end)

CSYONS8:add_action("Unlock All Nightclub Safe Items", function()
	stats.set_masked_int(MPX .. "BUSINESSBATPSTAT_INT379", 5, 0, 8)  --  Unlock Pegassi Oppressor MK II (Trade Price)
	stats.set_masked_int(MPX .. "BUSINESSBATPSTAT_INT379", 50, 8, 8)  --  Unlock Jewerly Box (On Desk) (Nightclub Trinket)
	stats.set_masked_int(MPX .. "BUSINESSBATPSTAT_INT379", 100, 16, 8)  --  Unlock Bullet Case
	stats.set_masked_int(MPX .. "BUSINESSBATPSTAT_INT379", 20, 24, 8)  --  Unlock Bag of Meth
	stats.set_masked_int(MPX .. "BUSINESSBATPSTAT_INT379", 80, 32, 8)  --  Unlock Brick of Weed
	stats.set_masked_int(MPX .. "BUSINESSBATPSTAT_INT379", 60, 40, 8)  --  Unlock Passports
	stats.set_masked_int(MPX .. "BUSINESSBATPSTAT_INT379", 40, 48, 8)  --  Unlock Impotent Rage Statue
	stats.set_masked_int(MPX .. "BUSINESSBATPSTAT_INT379", 10, 56, 8)  --  Unlock Impotent Rage Statue
	stats.set_masked_int(MPX .. "BUSINESSBATPSTAT_INT380", 20, 0, 8)  --  Unlock Gold Business Battle Trophy (On Desk) (Nightclub Trophy)
	stats.set_masked_int(MPX .. "BUSINESSBATPSTAT_INT380", 20, 40, 8)  --  Unlock  Dinka Go Go Monkey Blista
--CSYON SCRIPT -- CSYON SUBMENU
end)

CSYONS2:add_action("Weapons in Gun Van", function()
globals.set_int(262145 + 33840 + 1, -1786099057) ---- Baseball Bat
globals.set_int(262145 + 33840 + 2, -1716189206) ---- Knife
globals.set_int(262145 + 33840 + 3, -22923932) ----- RailGun
stats.set_int(MPX .. "NO_WEAPONS_UNLOCK", -1)
stats.set_int(MPX .. "NO_WEAPON_MODS_UNLOCK", -1)
end)

INI.autoshopcontrats = 0
CSYONS9:add_array_item("Autoshop Contrats", {
	[0] = "300000", 
	[1] = "185000", 
	[2] = "178000", 
	[3] = "172000",
	[4] = "175000",
	[5] = "182000",
	[6] = "180000",
	[7] = "170000"
}, function()
	return INI.autoshopcontrats
end, function(array)
	INI.autoshopcontrats = array
	globals.set_int(262145 + 31042, array)
	globals.set_int(262145 + 31042, array)
	globals.set_int(262145 + 31042, array)
	globals.set_int(262145 + 31042, array)
	globals.set_int(262145 + 31042, array)
	globals.set_int(262145 + 31042, array)
	globals.set_int(262145 + 31042, array)
end)

CSYONS8:add_action("Unlock GTA+ Livery for the Virtue", function()
    stats.set_int("MPPLY_XMASLIVERIES19", -1)
end)

CSYONS15:add_action("Teleport to Current Vehicle", function()  menu.teleport_to_current_vehicle() end)
--CSYONS15:add_action("Teleport to OBJECT", function()  menu.teleport_to_objective() end)
--menu.register_hotkey(88, better_teleport_to_waypoint)
--CSYONS15:add_action("Teleport to WAYPOINT (X)",  better_teleport_to_waypoint)

CSYONS5:add_action("Retrieve Person Vehicle", function()  menu.retrieve_personal_vehicle() end)

CSYONS7:add_toggle("Tiny Player", function()	
    if localplayer == nil then
    	return nil
end

return localplayer:get_config_flag(223)
   end, function(value)
    localplayer:set_config_flag(223, value)
end)

CSYONS4d = CSYON4:add_submenu("Atomizer Mods")
CSYONS4d:add_toggle("FastFire-Atomizer,StunGun", function() return enable end, function()
	enable=not enable if enable then csyon=menu.register_callback('OnWeaponChanged', OnWeaponChanged)else menu.remove_callback(csyon) bT,WR,LR=0,0,0 end
end)
CSYONS4d:add_toggle("Instant shooting Atomizer", IsAtomizer, SetAtomizer)
CSYONS4d:add_toggle("Shoot Big Explosions Atomizer", IsZeppelinBoom, SetZeppelinBoom)

CSYONS8:add_action("Unlock After Hours", function()

 stats.set_int(MPX .. "AWD_DANCE_TO_SOLOMUN", 120)
 stats.set_int(MPX .. "AWD_DANCE_TO_TALEOFUS", 120)
 stats.set_int(MPX .. "AWD_DANCE_TO_DIXON", 120)
 stats.set_int(MPX .. "AWD_DANCE_TO_BLKMAD", 120)
 stats.set_int(MPX .. "AWD_CLUB_DRUNK", 200)
 stats.set_int(MPX .. "NIGHTCLUB_VIP_APPEAR", 700)
 stats.set_int(MPX .. "NIGHTCLUB_JOBS_DONE", 700)
 stats.set_int(MPX .. "NIGHTCLUB_EARNINGS", 5721002)
 stats.set_int(MPX .. "HUB_SALES_COMPLETED", 1001)
 stats.set_int(MPX .. "HUB_EARNINGS", 20721002)
 stats.set_int(MPX .. "DANCE_COMBO_DURATION_MINS", 3600000)
 stats.set_int(MPX .. "NIGHTCLUB_PLAYER_APPEAR", 9506)
 stats.set_int(MPX .. "LIFETIME_HUB_GOODS_SOLD", 784672)
 stats.set_int(MPX .. "LIFETIME_HUB_GOODS_MADE", 507822)
 stats.set_int(MPX .. "DANCEPERFECTOWNCLUB", 120)
 stats.set_int(MPX .. "NUMUNIQUEPLYSINCLUB", 120)
 stats.set_int(MPX .. "DANCETODIFFDJS", 4)
 stats.set_int(MPX .. "NIGHTCLUB_HOTSPOT_TIME_MS", 3600000)
 stats.set_int(MPX .. "NIGHTCLUB_CONT_TOTAL", 20)
 stats.set_int(MPX .. "NIGHTCLUB_CONT_MISSION", -1)
 stats.set_int(MPX .. "CLUB_CONTRABAND_MISSION", 1000)
 stats.set_int(MPX .. "HUB_CONTRABAND_MISSION", 1000)
 stats.set_bool(MPX .. "AWD_CLUB_HOTSPOT", true)
 stats.set_bool(MPX .. "AWD_CLUB_CLUBBER", true)
 stats.set_bool(MPX .. "AWD_CLUB_COORD", true)
	for j = 0, 63 do
 stats.set_bool_masked(MPX.."BUSINESSBATPSTAT_BOOL0", true, j, MPX)
 stats.set_bool_masked(MPX.."BUSINESSBATPSTAT_BOOL1", true, j, MPX)
end
if (stats.get_masked_int(MPX.."BUSINESSBATPSTAT_INT380", 0, 8) <20) then
	stats.set_masked_int(MPX.."BUSINESSBATPSTAT_INT380", 20, 0, 8)
end
	stats.set_masked_int(MPX.."BUSINESSBATPSTAT_INT379", 50, 8, 8)
	stats.set_masked_int(MPX.."BUSINESSBATPSTAT_INT379", 100, 16, 8) 
	stats.set_masked_int(MPX.."BUSINESSBATPSTAT_INT379", 20, 24, 8) 
	stats.set_masked_int(MPX.."BUSINESSBATPSTAT_INT379", 80, 32, 8) 
	stats.set_masked_int(MPX.."BUSINESSBATPSTAT_INT379", 60, 40, 8) 
	stats.set_masked_int(MPX.."BUSINESSBATPSTAT_INT379", 40, 48, 8) 
	stats.set_masked_int(MPX.."BUSINESSBATPSTAT_INT379", 10, 56, 8)
end)
CSYONS8:add_action("Unlock Arena War", function()

 stats.set_int(MPX .. "ARN_BS_TRINKET_TICKERS", -1)
 stats.set_int(MPX .. "ARN_BS_TRINKET_SAVED", -1)
 stats.set_int(MPX .. "AWD_WATCH_YOUR_STEP", 50)
 stats.set_int(MPX .. "AWD_TOWER_OFFENSE", 50)
 stats.set_int(MPX .. "AWD_READY_FOR_WAR", 50)
 stats.set_int(MPX .. "AWD_THROUGH_A_LENS", 50)
 stats.set_int(MPX .. "AWD_SPINNER", 50)
 stats.set_int(MPX .. "AWD_YOUMEANBOOBYTRAPS", 50)
 stats.set_int(MPX .. "AWD_MASTER_BANDITO", 50)
 stats.set_int(MPX .. "AWD_SITTING_DUCK", 50)
 stats.set_int(MPX .. "AWD_CROWDPARTICIPATION", 50)
 stats.set_int(MPX .. "AWD_KILL_OR_BE_KILLED", 50)
 stats.set_int(MPX .. "AWD_MASSIVE_SHUNT", 50)
 stats.set_int(MPX .. "AWD_YOURE_OUTTA_HERE", 200)
 stats.set_int(MPX .. "AWD_WEVE_GOT_ONE", 50)
 stats.set_int(MPX .. "AWD_ARENA_WAGEWORKER", 1000000)
 stats.set_int(MPX .. "AWD_TIME_SERVED", 1000)
 stats.set_int(MPX .. "AWD_TOP_SCORE", 55000)
 stats.set_int(MPX .. "AWD_CAREER_WINNER", 1000)
 stats.set_int(MPX .. "ARENAWARS_SP", 209)
 stats.set_int(MPX .. "ARENAWARS_SKILL_LEVEL", 20)
 stats.set_int(MPX .. "ARENAWARS_SP_LIFETIME", 209)
 stats.set_int(MPX .. "ARENAWARS_AP_TIER", 1000)
 stats.set_int(MPX .. "ARENAWARS_AP_LIFETIME", 47551850)
 stats.set_int(MPX .. "ARENAWARS_CARRER_UNLK", 44)
 stats.set_int(MPX .. "ARN_W_THEME_SCIFI", 1000)
 stats.set_int(MPX .. "ARN_W_THEME_APOC", 1000)
 stats.set_int(MPX .. "ARN_W_THEME_CONS", 1000)
 stats.set_int(MPX .. "ARN_W_PASS_THE_BOMB", 1000)
 stats.set_int(MPX .. "ARN_W_DETONATION", 1000)
 stats.set_int(MPX .. "ARN_W_ARCADE_RACE", 1000)
 stats.set_int(MPX .. "ARN_W_CTF", 1000)
 stats.set_int(MPX .. "ARN_W_TAG_TEAM", 1000)
 stats.set_int(MPX .. "ARN_W_DESTR_DERBY", 1000)
 stats.set_int(MPX .. "ARN_W_CARNAGE", 1000)
 stats.set_int(MPX .. "ARN_W_MONSTER_JAM", 1000)
 stats.set_int(MPX .. "ARN_W_GAMES_MASTERS", 1000)
 stats.set_int(MPX .. "ARN_L_PASS_THE_BOMB", 500)
 stats.set_int(MPX .. "ARN_L_DETONATION", 500)
 stats.set_int(MPX .. "ARN_L_ARCADE_RACE", 500)
 stats.set_int(MPX .. "ARN_L_CTF", 500)
 stats.set_int(MPX .. "ARN_L_TAG_TEAM", 500)
 stats.set_int(MPX .. "ARN_L_DESTR_DERBY", 500)
 stats.set_int(MPX .. "ARN_L_CARNAGE", 500)
 stats.set_int(MPX .. "ARN_L_MONSTER_JAM", 500)
 stats.set_int(MPX .. "ARN_L_GAMES_MASTERS", 500)
 stats.set_int(MPX .. "NUMBER_OF_CHAMP_BOUGHT", 1000)
 stats.set_int(MPX .. "ARN_SPECTATOR_KILLS", 1000)
 stats.set_int(MPX .. "ARN_LIFETIME_KILLS", 1000)
 stats.set_int(MPX .. "ARN_LIFETIME_DEATHS", 500)
 stats.set_int(MPX .. "ARENAWARS_CARRER_WINS", 1000)
 stats.set_int(MPX .. "ARENAWARS_CARRER_WINT", 1000)
 stats.set_int(MPX .. "ARENAWARS_MATCHES_PLYD", 1000)
 stats.set_int(MPX .. "ARENAWARS_MATCHES_PLYDT", 1000)
 stats.set_int(MPX .. "ARN_SPEC_BOX_TIME_MS", 86400000)
 stats.set_int(MPX .. "ARN_SPECTATOR_DRONE", 1000)
 stats.set_int(MPX .. "ARN_SPECTATOR_CAMS", 1000)
 stats.set_int(MPX .. "ARN_SMOKE", 1000)
 stats.set_int(MPX .. "ARN_DRINK", 1000)
 stats.set_int(MPX .. "ARN_VEH_MONSTER", 31000)
 stats.set_int(MPX .. "ARN_VEH_MONSTER", 41000)
 stats.set_int(MPX .. "ARN_VEH_MONSTER", 51000)
 stats.set_int(MPX .. "ARN_VEH_CERBERUS", 1000)
 stats.set_int(MPX .. "ARN_VEH_CERBERUS2", 1000)
 stats.set_int(MPX .. "ARN_VEH_CERBERUS3", 1000)
 stats.set_int(MPX .. "ARN_VEH_BRUISER", 1000)
 stats.set_int(MPX .. "ARN_VEH_BRUISER2", 1000)
 stats.set_int(MPX .. "ARN_VEH_BRUISER3", 1000)
 stats.set_int(MPX .. "ARN_VEH_SLAMVAN4", 1000)
 stats.set_int(MPX .. "ARN_VEH_SLAMVAN5", 1000)
 stats.set_int(MPX .. "ARN_VEH_SLAMVAN6", 1000)
 stats.set_int(MPX .. "ARN_VEH_BRUTUS", 1000)
 stats.set_int(MPX .. "ARN_VEH_BRUTUS2", 1000)
 stats.set_int(MPX .. "ARN_VEH_BRUTUS3", 1000)
 stats.set_int(MPX .. "ARN_VEH_SCARAB", 1000)
 stats.set_int(MPX .. "ARN_VEH_SCARAB2", 1000)
 stats.set_int(MPX .. "ARN_VEH_SCARAB3", 1000)
 stats.set_int(MPX .. "ARN_VEH_DOMINATOR4", 1000)
 stats.set_int(MPX .. "ARN_VEH_DOMINATOR5", 1000)
 stats.set_int(MPX .. "ARN_VEH_DOMINATOR6", 1000)
 stats.set_int(MPX .. "ARN_VEH_IMPALER2", 1000)
 stats.set_int(MPX .. "ARN_VEH_IMPALER3", 1000)
 stats.set_int(MPX .. "ARN_VEH_IMPALER4", 1000)
 stats.set_int(MPX .. "ARN_VEH_ISSI4", 1000)
 stats.set_int(MPX .. "ARN_VEH_ISSI5", 1000)
 stats.set_int(MPX .. "ARN_VEH_ISSI", 61000)
 stats.set_int(MPX .. "ARN_VEH_IMPERATOR", 1000)
 stats.set_int(MPX .. "ARN_VEH_IMPERATOR2", 1000)
 stats.set_int(MPX .. "ARN_VEH_IMPERATOR3", 1000)
 stats.set_int(MPX .. "ARN_VEH_ZR380", 1000)
 stats.set_int(MPX .. "ARN_VEH_ZR3802", 1000)
 stats.set_int(MPX .. "ARN_VEH_ZR3803", 1000)
 stats.set_int(MPX .. "ARN_VEH_DEATHBIKE", 1000)
 stats.set_int(MPX .. "ARN_VEH_DEATHBIKE2", 1000)
 stats.set_int(MPX .. "ARN_VEH_DEATHBIKE3", 1000)
 stats.set_bool(MPX .. "AWD_BEGINNER", true)
 stats.set_bool(MPX .. "AWD_FIELD_FILLER", true)
 stats.set_bool(MPX .. "AWD_ARMCHAIR_RACER", true)
 stats.set_bool(MPX .. "AWD_LEARNER", true)
 stats.set_bool(MPX .. "AWD_SUNDAY_DRIVER", true)
 stats.set_bool(MPX .. "AWD_THE_ROOKIE", true)
 stats.set_bool(MPX .. "AWD_BUMP_AND_RUN", true)
 stats.set_bool(MPX .. "AWD_GEAR_HEAD", true)
 stats.set_bool(MPX .. "AWD_DOOR_SLAMMER", true)
 stats.set_bool(MPX .. "AWD_HOT_LAP", true)
 stats.set_bool(MPX .. "AWD_ARENA_AMATEUR", true)
 stats.set_bool(MPX .. "AWD_PAINT_TRADER", true)
 stats.set_bool(MPX .. "AWD_SHUNTER", true)
 stats.set_bool(MPX .. "AWD_JOCK", true)
 stats.set_bool(MPX .. "AWD_WARRIOR", true)
 stats.set_bool(MPX .. "AWD_T_BONE", true)
 stats.set_bool(MPX .. "AWD_MAYHEM", true)
 stats.set_bool(MPX .. "AWD_WRECKER", true)
 stats.set_bool(MPX .. "AWD_CRASH_COURSE", true)
 stats.set_bool(MPX .. "AWD_ARENA_LEGEND", true)
 stats.set_bool(MPX .. "AWD_PEGASUS", true)
 stats.set_bool(MPX .. "AWD_UNSTOPPABLE", true)
 stats.set_bool(MPX .. "AWD_CONTACT_SPORT", true)
 stats.set_masked_int(MPX.."ARENAWARSPSTAT_INT", 1, 35, 8)

for i = 0, 8 do
	for j = 0, 63 do
 stats.set_bool_masked(MPX.."ARENAWARSPSTAT_BOOL"..i, true, j, MPX)
end end
end)
CSYONS8:add_action("Unlock Diamond Casino'n'Resort", function()
 stats.set_int(MPX .. "AWD_ODD_JOBS", 52)
 stats.set_int(MPX .. "VCM_FLOW_PROGRESS", -1)
 stats.set_int(MPX .. "VCM_STORY_PROGRESS", 5)
 stats.set_bool(MPX .. "AWD_FIRST_TIME1", true)
 stats.set_bool(MPX .. "AWD_FIRST_TIME2", true)
 stats.set_bool(MPX .. "AWD_FIRST_TIME3", true)
 stats.set_bool(MPX .. "AWD_FIRST_TIME4", true)
 stats.set_bool(MPX .. "AWD_FIRST_TIME5", true)
 stats.set_bool(MPX .. "AWD_FIRST_TIME6", true)
 stats.set_bool(MPX .. "AWD_ALL_IN_ORDER", true)
 stats.set_bool(MPX .. "AWD_SUPPORTING_ROLE", true)
 stats.set_bool(MPX .. "AWD_LEADER", true)
 stats.set_bool(MPX .. "AWD_SURVIVALIST", true)
	Paragon = stats.get_bool(MPX .. "CAS_VEHICLE_REWARD")
	if Paragon == true then
 stats.set_bool(MPX .. "CAS_VEHICLE_REWARD",true)
	else
 stats.set_bool(MPX .. "CAS_VEHICLE_REWARD", false)
	end
for i = 0, 6 do
	for j = 0, 63 do
 stats.set_bool_masked(MPX.."CASINOPSTAT_BOOL"..i, true, j, MPX)
end end
end)
CSYONS8:add_action("Unlock Diamond Casino Heist", function()

 stats.set_int(MPX .. "CAS_HEIST_NOTS", -1)
 stats.set_int(MPX .. "CAS_HEIST_FLOW", -1)
 stats.set_int(MPX .. "SIGNAL_JAMMERS_COLLECTED", 50)
 stats.set_int(MPX .. "AWD_PREPARATION", 40)
 stats.set_int(MPX .. "AWD_ASLEEPONJOB", 20)
 stats.set_int(MPX .. "AWD_DAICASHCRAB", 100000)
 stats.set_int(MPX .. "AWD_BIGBRO", 40)
 stats.set_int(MPX .. "AWD_SHARPSHOOTER", 40)
 stats.set_int(MPX .. "AWD_RACECHAMP", 40)
 stats.set_int(MPX .. "AWD_BATSWORD", 1000000)
 stats.set_int(MPX .. "AWD_COINPURSE", 950000)
 stats.set_int(MPX .. "AWD_ASTROCHIMP", 3000000)
 stats.set_int(MPX .. "AWD_MASTERFUL", 40000)
 stats.set_int(MPX .. "H3_BOARD_DIALOGUE0", -1)
 stats.set_int(MPX .. "H3_BOARD_DIALOGUE1", -1)
 stats.set_int(MPX .. "H3_BOARD_DIALOGUE2", -1)
 stats.set_int(MPX .. "H3_VEHICLESUSED", -1)
 stats.set_int(MPX .. "H3_CR_STEALTH_1A", 100)
 stats.set_int(MPX .. "H3_CR_STEALTH_2B_RAPP", 100)
 stats.set_int(MPX .. "H3_CR_STEALTH_2C_SIDE", 100)
 stats.set_int(MPX .. "H3_CR_STEALTH_3A", 100)
 stats.set_int(MPX .. "H3_CR_STEALTH_4A", 100)
 stats.set_int(MPX .. "H3_CR_STEALTH_5A", 100)
 stats.set_int(MPX .. "H3_CR_SUBTERFUGE_1A", 100)
 stats.set_int(MPX .. "H3_CR_SUBTERFUGE_2A", 100)
 stats.set_int(MPX .. "H3_CR_SUBTERFUGE_2B", 100)
 stats.set_int(MPX .. "H3_CR_SUBTERFUGE_3A", 100)
 stats.set_int(MPX .. "H3_CR_SUBTERFUGE_3B", 100)
 stats.set_int(MPX .. "H3_CR_SUBTERFUGE_4A", 100)
 stats.set_int(MPX .. "H3_CR_SUBTERFUGE_5A", 100)
 stats.set_int(MPX .. "H3_CR_DIRECT_1A", 100)
 stats.set_int(MPX .. "H3_CR_DIRECT_2A1", 100)
 stats.set_int(MPX .. "H3_CR_DIRECT_2A2", 100)
 stats.set_int(MPX .. "H3_CR_DIRECT_2BP", 100)
 stats.set_int(MPX .. "H3_CR_DIRECT_2C", 100)
 stats.set_int(MPX .. "H3_CR_DIRECT_3A", 100)
 stats.set_int(MPX .. "H3_CR_DIRECT_4A", 100)
 stats.set_int(MPX .. "H3_CR_DIRECT_5A", 100)
 stats.set_int(MPX .. "CR_ORDER", 100)
 stats.set_bool(MPX .. "AWD_SCOPEOUT", true)
 stats.set_bool(MPX .. "AWD_CREWEDUP", true)
 stats.set_bool(MPX .. "AWD_MOVINGON", true)
 stats.set_bool(MPX .. "AWD_PROMOCAMP", true)
 stats.set_bool(MPX .. "AWD_GUNMAN", true)
 stats.set_bool(MPX .. "AWD_SMASHNGRAB", true)
 stats.set_bool(MPX .. "AWD_INPLAINSI", true)
 stats.set_bool(MPX .. "AWD_UNDETECTED", true)
 stats.set_bool(MPX .. "AWD_ALLROUND", true)
 stats.set_bool(MPX .. "AWD_ELITETHEIF", true)
 stats.set_bool(MPX .. "AWD_PRO", true)
 stats.set_bool(MPX .. "AWD_SUPPORTACT", true)
 stats.set_bool(MPX .. "AWD_SHAFTED", true)
 stats.set_bool(MPX .. "AWD_COLLECTOR", true)
 stats.set_bool(MPX .. "AWD_DEADEYE", true)
 stats.set_bool(MPX .. "AWD_PISTOLSATDAWN", true)
 stats.set_bool(MPX .. "AWD_TRAFFICAVOI", true)
 stats.set_bool(MPX .. "AWD_CANTCATCHBRA", true)
 stats.set_bool(MPX .. "AWD_WIZHARD", true)
 stats.set_bool(MPX .. "AWD_APEESCAPE", true)
 stats.set_bool(MPX .. "AWD_MONKEYKIND", true)
 stats.set_bool(MPX .. "AWD_AQUAAPE", true)
 stats.set_bool(MPX .. "AWD_KEEPFAITH", true)
 stats.set_bool(MPX .. "AWD_TRUELOVE", true)
 stats.set_bool(MPX .. "AWD_NEMESIS", true)
 stats.set_bool(MPX .. "AWD_FRIENDZONED", true)
 stats.set_bool(MPX .. "VCM_FLOW_CS_RSC_SEEN", true)
 stats.set_bool(MPX .. "VCM_FLOW_CS_BWL_SEEN", true)
 stats.set_bool(MPX .. "VCM_FLOW_CS_MTG_SEEN", true)
 stats.set_bool(MPX .. "VCM_FLOW_CS_OIL_SEEN", true)
 stats.set_bool(MPX .. "VCM_FLOW_CS_DEF_SEEN", true)
 stats.set_bool(MPX .. "VCM_FLOW_CS_FIN_SEEN", true)
 stats.set_bool(MPX .. "HELP_FURIA", true)
 stats.set_bool(MPX .. "HELP_MINITAN", true)
 stats.set_bool(MPX .. "HELP_YOSEMITE2", true)
 stats.set_bool(MPX .. "HELP_ZHABA", true)
 stats.set_bool(MPX .. "HELP_IMORGEN", true)
 stats.set_bool(MPX .. "HELP_SULTAN2", true)
 stats.set_bool(MPX .. "HELP_VAGRANT", true)
 stats.set_bool(MPX .. "HELP_VSTR", true)
 stats.set_bool(MPX .. "HELP_STRYDER", true)
 stats.set_bool(MPX .. "HELP_SUGOI", true)
 stats.set_bool(MPX .. "HELP_KANJO", true)
 stats.set_bool(MPX .. "HELP_FORMULA", true)
 stats.set_bool(MPX .. "HELP_FORMULA2", true)
 stats.set_bool(MPX .. "HELP_JB7002", true)
for i = 0, 4 do
	for j = 0, 63 do
 stats.set_bool_masked(MPX.."CASINOHSTPSTAT_BOOL"..i, true, j, MPX)
end end
end)
CSYONS8:add_action("Unlock Arcade", function()

 stats.set_int(MPX .. "AWD_PREPARATION", 50)
 stats.set_int(MPX .. "AWD_ASLEEPONJOB", 20)
 stats.set_int(MPX .. "AWD_DAICASHCRAB", 100000)
 stats.set_int(MPX .. "AWD_BIGBRO", 40)
 stats.set_int(MPX .. "AWD_SHARPSHOOTER", 40)
 stats.set_int(MPX .. "AWD_RACECHAMP", 40)
 stats.set_int(MPX .. "AWD_BATSWORD", 1000000)
 stats.set_int(MPX .. "AWD_COINPURSE", 950000)
 stats.set_int(MPX .. "AWD_ASTROCHIMP", 3000000)
 stats.set_int(MPX .. "AWD_MASTERFUL", 40000)
 stats.set_int(MPX .. "SCGW_NUM_WINS_GANG_0", 50)
 stats.set_int(MPX .. "SCGW_NUM_WINS_GANG_1", 50)
 stats.set_int(MPX .. "SCGW_NUM_WINS_GANG_2", 50)
 stats.set_int(MPX .. "SCGW_NUM_WINS_GANG_3", 50)
 stats.set_int(MPX .. "CH_ARC_CAB_CLAW_TROPHY", -1)
 stats.set_int(MPX .. "CH_ARC_CAB_LOVE_TROPHY", -1)
 stats.set_int(MPX .. "IAP_MAX_MOON_DIST", 2147483647)
 stats.set_int(MPX .. "SCGW_INITIALS_0", 69644)
 stats.set_int(MPX .. "SCGW_INITIALS_1", 50333)
 stats.set_int(MPX .. "SCGW_INITIALS_2", 63512)
 stats.set_int(MPX .. "SCGW_INITIALS_3", 46136)
 stats.set_int(MPX .. "SCGW_INITIALS_4", 21638)
 stats.set_int(MPX .. "SCGW_INITIALS_5", 2133)
 stats.set_int(MPX .. "SCGW_INITIALS_6", 1215)
 stats.set_int(MPX .. "SCGW_INITIALS_7", 2444)
 stats.set_int(MPX .. "SCGW_INITIALS_8", 38023)
 stats.set_int(MPX .. "SCGW_INITIALS_9", 2233)
 stats.set_int(MPX .. "FOOTAGE_INITIALS_0",0)
 stats.set_int(MPX .. "FOOTAGE_INITIALS_1", 64)
 stats.set_int(MPX .. "FOOTAGE_INITIALS_2", 8457)
 stats.set_int(MPX .. "FOOTAGE_INITIALS_3", 91275)
 stats.set_int(MPX .. "FOOTAGE_INITIALS_4", 53260)
 stats.set_int(MPX .. "FOOTAGE_INITIALS_5", 78663)
 stats.set_int(MPX .. "FOOTAGE_INITIALS_6", 25103)
 stats.set_int(MPX .. "FOOTAGE_INITIALS_7", 102401)
 stats.set_int(MPX .. "FOOTAGE_INITIALS_8", 12672)
 stats.set_int(MPX .. "FOOTAGE_INITIALS_9", 74380)
 stats.set_int(MPX .. "FOOTAGE_SCORE_0", 284544)
 stats.set_int(MPX .. "FOOTAGE_SCORE_1", 275758)
 stats.set_int(MPX .. "FOOTAGE_SCORE_2", 100000)
 stats.set_int(MPX .. "FOOTAGE_SCORE_3", 90000)
 stats.set_int(MPX .. "FOOTAGE_SCORE_4", 80000)
 stats.set_int(MPX .. "FOOTAGE_SCORE_5", 70000)
 stats.set_int(MPX .. "FOOTAGE_SCORE_6", 60000)
 stats.set_int(MPX .. "FOOTAGE_SCORE_7", 50000)
 stats.set_int(MPX .. "FOOTAGE_SCORE_8", 40000)
 stats.set_int(MPX .. "FOOTAGE_SCORE_9", 30000)
	for i = 0, 9 do
 stats.set_int(MPX .. "IAP_INITIALS_"..i, 50)
 stats.set_int(MPX .. "IAP_SCORE_"..i, 50)
 stats.set_int(MPX .. "IAP_SCORE_"..i, 50)
 stats.set_int(MPX .. "SCGW_SCORE_"..i, 50)
 stats.set_int(MPX .. "DG_DEFENDER_INITIALS_"..i, 69644)
 stats.set_int(MPX .. "DG_DEFENDER_SCORE_"..i, 50)
 stats.set_int(MPX .. "DG_MONKEY_INITIALS_"..i, 69644)
 stats.set_int(MPX .. "DG_MONKEY_SCORE_"..i, 50)
 stats.set_int(MPX .. "DG_PENETRATOR_INITIALS_"..i, 69644)
 stats.set_int(MPX .. "DG_PENETRATOR_SCORE_"..i, 50)
 stats.set_int(MPX .. "GGSM_INITIALS_"..i, 69644)
 stats.set_int(MPX .. "GGSM_SCORE_"..i, 50)
 stats.set_int(MPX .. "TWR_INITIALS_"..i, 69644)
 stats.set_int(MPX .. "TWR_SCORE_"..i, 50)
	end
 stats.set_bool(MPX .. "AWD_SCOPEOUT", true)
 stats.set_bool(MPX .. "AWD_CREWEDUP", true)
 stats.set_bool(MPX .. "AWD_MOVINGON", true)
 stats.set_bool(MPX .. "AWD_PROMOCAMP", true)
 stats.set_bool(MPX .. "AWD_GUNMAN", true)
 stats.set_bool(MPX .. "AWD_SMASHNGRAB", true)
 stats.set_bool(MPX .. "AWD_INPLAINSI", true)
 stats.set_bool(MPX .. "AWD_UNDETECTED", true)
 stats.set_bool(MPX .. "AWD_ALLROUND", true)
 stats.set_bool(MPX .. "AWD_ELITETHEIF", true)
 stats.set_bool(MPX .. "AWD_PRO", true)
 stats.set_bool(MPX .. "AWD_SUPPORTACT", true)
 stats.set_bool(MPX .. "AWD_SHAFTED", true)
 stats.set_bool(MPX .. "AWD_COLLECTOR", true)
 stats.set_bool(MPX .. "AWD_DEADEYE", true)
 stats.set_bool(MPX .. "AWD_PISTOLSATDAWN", true)
 stats.set_bool(MPX .. "AWD_TRAFFICAVOI", true)
 stats.set_bool(MPX .. "AWD_CANTCATCHBRA", true)
 stats.set_bool(MPX .. "AWD_WIZHARD", true)
 stats.set_bool(MPX .. "AWD_APEESCAP", true)
 stats.set_bool(MPX .. "AWD_MONKEYKIND", true)
 stats.set_bool(MPX .. "AWD_AQUAAPE", true)
 stats.set_bool(MPX .. "AWD_KEEPFAITH", true)
 stats.set_bool(MPX .. "AWD_TRUELOVE", true)
 stats.set_bool(MPX .. "AWD_NEMESIS", true)
 stats.set_bool(MPX .. "AWD_FRIENDZONED", true)
 stats.set_bool(MPX .. "IAP_CHALLENGE_0", true)
 stats.set_bool(MPX .. "IAP_CHALLENGE_1", true)
 stats.set_bool(MPX .. "IAP_CHALLENGE_2v", true)
 stats.set_bool(MPX .. "IAP_CHALLENGE_3", true)
 stats.set_bool(MPX .. "IAP_CHALLENGE_4v", true)
 stats.set_bool(MPX .. "IAP_GOLD_TANK", true)
 stats.set_bool(MPX .. "SCGW_WON_NO_DEATHS", true)
for j = 290125, 290144 do
 globals.set_int(j, 1)
end
end)
CSYONS8:add_action("Unlock LS Summer Special DLC", function()

 stats.set_bool(MPX .. "AWD_KINGOFQUB3D", true)
 stats.set_bool(MPX .. "AWD_QUBISM", true)
 stats.set_bool(MPX .. "AWD_QUIBITS", true)
 stats.set_bool(MPX .. "AWD_GODOFQUB3D", true)
 stats.set_bool(MPX .. "AWD_ELEVENELEVEN", true)
 stats.set_bool(MPX .. "AWD_GOFOR11TH", true)
 stats.set_masked_int(MPX.."SU20PSTAT_INT", 1, 35, 8)

for i = 0, 1 do
	for j = 0, 63 do
 stats.set_bool_masked(MPX.."SU20PSTAT_BOOL"..i, true, j, MPX)
 stats.set_bool_masked(MPX.."SU20TATTOOSTAT_BOOL"..i, true, j, MPX)
end end
end)
CSYONS8:add_action("Unlock Cayo Perico DLC", function()

 stats.set_bool(MPX .. "AWD_INTELGATHER", true)
 stats.set_bool(MPX .. "AWD_COMPOUNDINFILT", true)
 stats.set_bool(MPX .. "AWD_LOOT_FINDER", true)
 stats.set_bool(MPX .. "AWD_MAX_DISRUPT", true)
 stats.set_bool(MPX .. "AWD_THE_ISLAND_HEIST", true)
 stats.set_bool(MPX .. "AWD_GOING_ALONE", true)
 stats.set_bool(MPX .. "AWD_TEAM_WORK", true)
 stats.set_bool(MPX .. "AWD_MIXING_UP", true)
 stats.set_bool(MPX .. "AWD_TEAM_WORK", true)
 stats.set_bool(MPX .. "AWD_MIXING_UP", true)
 stats.set_bool(MPX .. "AWD_PRO_THIEF", true)
 stats.set_bool(MPX .. "AWD_CAT_BURGLAR", true)
 stats.set_bool(MPX .. "AWD_ONE_OF_THEM", true)
 stats.set_bool(MPX .. "AWD_GOLDEN_GUN", true)
 stats.set_bool(MPX .. "AWD_ELITE_THIEF", true)
 stats.set_bool(MPX .. "AWD_PROFESSIONAL", true)
 stats.set_bool(MPX .. "AWD_HELPING_OUT", true)
 stats.set_bool(MPX .. "AWD_COURIER", true)
 stats.set_bool(MPX .. "AWD_PARTY_VIBES", true)
 stats.set_bool(MPX .. "AWD_HELPING_HAND", true)
 stats.set_bool(MPX .. "AWD_ELEVENELEVEN", true)
 stats.set_bool(MPX .. "COMPLETE_H4_F_USING_VETIR", true)
 stats.set_bool(MPX .. "COMPLETE_H4_F_USING_LONGFIN", true)
 stats.set_bool(MPX .. "COMPLETE_H4_F_USING_ANNIH", true)
 stats.set_bool(MPX .. "COMPLETE_H4_F_USING_ALKONOS", true)
 stats.set_bool(MPX .. "COMPLETE_H4_F_USING_PATROLB", true)
 stats.set_int(MPX .. "AWD_LOSTANDFOUND", 500000)
 stats.set_int(MPX .. "AWD_SUNSET", 1800000)
 stats.set_int(MPX .. "AWD_TREASURE_HUNTER", 1000000)
 stats.set_int(MPX .. "AWD_WRECK_DIVING", 1000000)
 stats.set_int(MPX .. "AWD_KEINEMUSIK", 1800000)
 stats.set_int(MPX .. "AWD_PALMS_TRAX", 1800000)
 stats.set_int(MPX .. "AWD_MOODYMANN", 1800000)
 stats.set_int(MPX .. "AWD_FILL_YOUR_BAGS", 1000000000)
 stats.set_int(MPX .. "AWD_WELL_PREPARED", 80)
 stats.set_int(MPX .. "H4_H4_DJ_MISSIONS", -1)
for i = 0, 2 do
	for j = 0, 63 do
 stats.set_bool_masked(MPX.."HISLANDPSTAT_BOOL"..i, true, j, MPX)
end end
end)
CSYONS8:add_action("Unlock LS Tuner DLC", function()

 stats.set_int(MPX .. "AWD_CAR_CLUB_MEM", 100)
 stats.set_int(MPX .. "AWD_SPRINTRACER", 50)
 stats.set_int(MPX .. "AWD_STREETRACER", 50)
 stats.set_int(MPX .. "AWD_PURSUITRACER", 50)
 stats.set_int(MPX .. "AWD_TEST_CAR", 240)
 stats.set_int(MPX .. "AWD_AUTO_SHOP", 50)	
 stats.set_int(MPX .. "AWD_GROUNDWORK", 40)
 stats.set_int(MPX .. "AWD_CAR_EXPORT", 100)
 stats.set_int(MPX .. "AWD_ROBBERY_CONTRACT", 100)
 stats.set_int(MPX .. "AWD_FACES_OF_DEATH", 100)
 stats.set_bool(MPX .. "AWD_CAR_CLUB", true)
 stats.set_bool(MPX .. "AWD_PRO_CAR_EXPORT", true)
 stats.set_bool(MPX .. "AWD_UNION_DEPOSITORY", true)
 stats.set_bool(MPX .. "AWD_MILITARY_CONVOY", true)
 stats.set_bool(MPX .. "AWD_FLEECA_BANK", true)
 stats.set_bool(MPX .. "AWD_FREIGHT_TRAIN", true)
 stats.set_bool(MPX .. "AWD_BOLINGBROKE_ASS", true)
 stats.set_bool(MPX .. "AWD_IAA_RAID", true)
 stats.set_bool(MPX .. "AWD_METH_JOB", true)
 stats.set_bool(MPX .. "AWD_BUNKER_RAID", true)
 stats.set_bool(MPX .. "AWD_STRAIGHT_TO_VIDEO", true)
 stats.set_bool(MPX .. "AWD_MONKEY_C_MONKEY_DO", true)
 stats.set_bool(MPX .. "AWD_TRAINED_TO_KILL", true)
 stats.set_bool(MPX .. "AWD_DIRECTOR", true)
for i = 0, 8 do
	for j = 0, 63 do
 stats.set_bool_masked(MPX.."TUNERPSTAT_BOOL"..i, true, j, MPX)
	end end
end)
CSYONS8:add_action("Unlock Contract DLC", function()

 stats.set_int(MPX .. "AWD_CONTRACTOR", 50)
 stats.set_int(MPX .. "AWD_COLD_CALLER", 50)
 stats.set_int(MPX .. "AWD_PRODUCER", 60)
 stats.set_int(MPX .. "FIXERTELEPHONEHITSCOMPL", 10)
 stats.set_int(MPX .. "PAYPHONE_BONUS_KILL_METHOD", 10)
 stats.set_int(MPX .. "PAYPHONE_BONUS_KILL_METHOD", -1)
 stats.set_int(MPX .. "FIXER_GENERAL_BS", -1)
 stats.set_int(MPX .. "FIXER_COMPLETED_BS", -1)
 stats.set_int(MPX .. "FIXER_STORY_BS", -1)
 stats.set_int(MPX .. "FIXER_STORY_STRAND", -1)
 stats.set_int(MPX .. "FIXER_STORY_COOLDOWN", -1)
 stats.set_int(MPX .. "FIXER_COUNT", 510)
 stats.set_int(MPX .. "FIXER_SC_VEH_RECOVERED", 85)
 stats.set_int(MPX .. "FIXER_SC_VAL_RECOVERED", 85)
 stats.set_int(MPX .. "FIXER_SC_GANG_TERMINATED", 85)
 stats.set_int(MPX .. "FIXER_SC_VIP_RESCUED", 85)
 stats.set_int(MPX .. "FIXER_SC_ASSETS_PROTECTED", 85)
 stats.set_int(MPX .. "FIXER_SC_EQ_DESTROYED", 85)
 stats.set_int(MPX .. "FIXER_EARNINGS", 19734860)
 stats.set_bool(MPX .. "AWD_TEEING_OFF", true)
 stats.set_bool(MPX .. "AWD_PARTY_NIGHT", true)
 stats.set_bool(MPX .. "AWD_BILLIONAIRE_GAMES", true)
 stats.set_bool(MPX .. "AWD_HOOD_PASS", true)
 stats.set_bool(MPX .. "AWD_STUDIO_TOUR", true)
 stats.set_bool(MPX .. "AWD_DONT_MESS_DRE", true)
 stats.set_bool(MPX .. "AWD_BACKUP", true)
 stats.set_bool(MPX .. "AWD_SHORTFRANK_1", true)
 stats.set_bool(MPX .. "AWD_SHORTFRANK_2", true)
 stats.set_bool(MPX .. "AWD_SHORTFRANK_3", true)
 stats.set_bool(MPX .. "AWD_CONTR_KILLER", true)
 stats.set_bool(MPX .. "AWD_DOGS_BEST_FRIEND", true)
 stats.set_bool(MPX .. "AWD_MUSIC_STUDIO", true)
 stats.set_bool(MPX .. "AWD_SHORTLAMAR_1", true)
 stats.set_bool(MPX .. "AWD_SHORTLAMAR_2", true)
 stats.set_bool(MPX .. "AWD_SHORTLAMAR_3", true)
 stats.set_bool(MPX .. "BS_FRANKLIN_DIALOGUE_0", true)
 stats.set_bool(MPX .. "BS_FRANKLIN_DIALOGUE_1", true)
 stats.set_bool(MPX .. "BS_FRANKLIN_DIALOGUE_2", true)
 stats.set_bool(MPX .. "BS_IMANI_D_APP_SETUP", true)
 stats.set_bool(MPX .. "BS_IMANI_D_APP_STRAND", true)
 stats.set_bool(MPX .. "BS_IMANI_D_APP_PARTY", true)
 stats.set_bool(MPX .. "BS_IMANI_D_APP_PARTY_2", true)
 stats.set_bool(MPX .. "BS_IMANI_D_APP_PARTY_F", true)
 stats.set_bool(MPX .. "BS_IMANI_D_APP_BILL", true)
 stats.set_bool(MPX .. "BS_IMANI_D_APP_BILL_2", true)
 stats.set_bool(MPX .. "BS_IMANI_D_APP_BILL_F", true)
 stats.set_bool(MPX .. "BS_IMANI_D_APP_HOOD", true)
 stats.set_bool(MPX .. "BS_IMANI_D_APP_HOOD_2", true)
 stats.set_bool(MPX .. "BS_IMANI_D_APP_HOOD_F", true)
for j = 0, 63 do
 stats.set_bool_masked(MPX .."FIXERPSTAT_BOOL0", true, j, MPX)
 stats.set_bool_masked(MPX .."FIXERPSTAT_BOOL1", true, j, MPX)
 stats.set_bool_masked(MPX .."FIXERTATTOOSTAT_BOOL0", true, j, MPX)
end
end)

CSYONS8:add_action("Unlock Phone Contacts", function()
 stats.set_int(MPX .. "FM_ACT_PHN", -1)
 stats.set_int(MPX .. "FM_ACT_PH2", -1)
 stats.set_int(MPX .. "FM_ACT_PH3", -1)
 stats.set_int(MPX .. "FM_ACT_PH4", -1)
 stats.set_int(MPX .. "FM_ACT_PH5", -1)
 stats.set_int(MPX .. "FM_VEH_TX1", -1)
 stats.set_int(MPX .. "FM_ACT_PH6", -1)
 stats.set_int(MPX .. "FM_ACT_PH7", -1)
 stats.set_int(MPX .. "FM_ACT_PH8", -1)
 stats.set_int(MPX .. "FM_ACT_PH9", -1)
 stats.set_int(MPX .. "FM_CUT_DONE", -1)
 stats.set_int(MPX .. "FM_CUT_DONE_2", -1)
end)

CSYONS7d = CSYON7:add_submenu("Online Character Stats")
CSYONS7d:add_int_range("Increase Stamina", 1, 0, 100, function()
	return stats.get_int("MP"..MPX.."_script_increase_stam")
end, function(value)
	stats.set_int("MP"..MPX.."_script_increase_stam", value)
end)
 
CSYONS7d:add_int_range("Increase Strength", 1, 0, 100, function()
	return stats.get_int("MP"..MPX.."_script_increase_strn")
end, function(value)
	stats.set_int("MP"..MPX.."_script_increase_strn", value)
end)
 
CSYONS7d:add_int_range("Increase Lung capacity", 1, 0, 100, function()
	return stats.get_int("MP"..MPX.."_script_increase_lung")
end, function(value)
	stats.set_int("MP"..MPX.."_script_increase_lung", value)
end)
 
CSYONS7d:add_int_range("Increase Driving", 1, 0, 100, function()
	return stats.get_int("MP"..MPX.."_script_increase_driv")
end, function(value)
	stats.set_int("MP"..MPX.."_script_increase_driv", value)
end)
 
CSYONS7d:add_int_range("Increase Flying", 1, 0, 100, function()
	return stats.get_int("MP"..MPX.."_script_increase_fly")
end, function(value)
	stats.set_int("MP"..MPX.."_script_increase_fly", value)
end)
 
CSYONS7d:add_int_range("Increase Shooting", 1, 0, 100, function()
	return stats.get_int("MP"..MPX.."_script_increase_sho")
end, function(value)
	stats.set_int("MP"..MPX.."_script_increase_sho", value)
end)
 
CSYONS7d:add_int_range("Increase Stealth", 1, 0, 100, function()
	return stats.get_int("MP"..MPX.."_script_increase_stl")
end, function(value)
	stats.set_int("MP"..MPX.."_script_increase_stl", value)
end)
 
CSYONS7d:add_int_range("Increase Mechanic", 1, 0, 100, function()
	return stats.get_int("MP"..MPX.."_script_increase_mech")
end, function(value)
	stats.set_int("MP"..MPX.."_script_increase_mech", value)
end)

CSYONS22:add_action("Collect MOVIE PROPS", function()
    globals.set_int(262145, 29879) 
end)

CSYONS22:add_action("Collect UNDERWATER PACKAGES", function()
    globals.set_int(262145, 29946) 
end)

CSYONS22:add_action("Collect TREASURE CHESTS", function()
    globals.set_int(262145, 29947) 
end)

CSYONS22:add_action("Collect RADIO STATIONS", function()
    globals.set_int(262145, 29948)  
end)

CSYONS22:add_action("Collect SIGNAL JAMMERS", function()
    globals.set_int(262145, 28581) 
end)

CSYONS22:add_action("Collect TRICK OR TREAT", function()
    globals.set_int(262145, 32978) 
end)

CSYONS22:add_action("Collect LD ORGANICS", function()
    globals.set_int(262145, 32993)  
end)

CSYONS22:add_action("Collect SKYDIVES", function()
    globals.set_int(262145, 32998) 
end)

CSYONS22:add_action("Collect DEAD DROP", function()
    globals.set_int(262145, 34044)  
end)

CSYONS22:add_action("Collect SNOWMEN", function()
    globals.set_int(262145, 34049) 
end)

CSYONS22:add_action("Collect SHIPWRECKED", function()
    globals.set_int(262145, 31155) 
end)

CSYONS22:add_action("Collect BURIED STASH", function()
    globals.set_int(262145, 31158) 
end)


acid_lab_production = false
CSYONS2:add_toggle("auto acid lab production", function()
    return acid_lab_production
end, function(bool)
    acid_lab_production = bool
    while (acid_lab_production == true) do
        menu.trigger_acid_lab_production()
        sleep(1)
    end
end)

CSYONS9:add_action("--------------Acid Labs Editior--------------", function() end)
CSYONS9:add_action("--------------Dont Exceed More than 2 Million --------------", function() end)
CSYONS9:add_int_range("Acid Labs Inrease Prodution Speed", 1.0, 1, 10, function()
	return globals.get_int(262145 + 32700)
end, function(value)
	globals.set_int(262145 + 32700, 0)
end)


CSYONS9:add_int_range("Set Acid Value 2Mil", 10000.0, 10000, 99999, function()
return globals.get_int(262145 + 17425)
end, function(value)
globals.set_int(262145 + 17425, value)
end)

CSYONS9:add_int_range("Decrease Production Time", 1.0, 0, 100, function() 
	return globals.get_int(262145 + 17396)
end, function(value)
	globals.set_int(262145 + 17396, value)
end)

CSYONS9:add_int_range("Product Capacity", 1, 0, 100, function() 
	return globals.get_int(262145+18949)
end, function(value)
	globals.set_int(262145+18949, value)
end)


CSYONS9:add_int_range("Change Supplies Cost", 1, 0, 10, function() 
	return globals.get_int(262145+21869)
end, function(value)
	globals.set_int(262145+21869, value)
end)

CSYONS9:add_action("------------------------------------------------------", function() end)

CSYONS9:add_action("--------------WareHouse Editior--------------", function() end)
	
	CSYONS9i = CSYON9:add_submenu("WareHouse Editior Instructions")
	
	CSYONS9i:add_action("                       -->Crates Loop<--", function() end) 
	CSYONS9i:add_action("                	 To turn off the loop,", function() end) 
	CSYONS9i:add_action("     close the menu from Menu Settings", function() end) 
	CSYONS9i:add_action("", function() end) 
	CSYONS9i:add_action("                       Instant Buy:", function() end) 
	CSYONS9i:add_action("       Start the buy mission first, select", function() end) 
	CSYONS9i:add_action("      the number of crates and activate", function() end) 
							
	CSYONS9i:add_action("                    Disable RP Earning:", function() end)
	CSYONS9i:add_action("           Disables earning experience", function() end)
	CSYONS9i:add_action("", function() end)

CSYONS9:add_action("--------------Warehouse Profile Editor--------------", function() end)
CSYONS9:add_int_range("Change Lifetime Sales", 1, 0, 10000, function()
PlayerIndex = globals.get_int(1574918)
	if PlayerIndex == 0 then
		MPX = "MP0_"
	else
		MPX = "MP1_"
	end
                                       return 
                           stats.get_int(MPX.."LIFETIME_SELL_COMPLETE") end,   function(value)
                           stats.set_int(MPX.."LIFETIME_BUY_COMPLETE", value) 
                           stats.set_int(MPX.."LIFETIME_BUY_UNDERTAKEN", value) 
                           stats.set_int(MPX.."LIFETIME_SELL_COMPLETE", value) 
                           stats.set_int(MPX.."LIFETIME_SELL_UNDERTAKEN", value)

 end)

CSYONS9:add_int_range("Change Lifetime Earnings Made", 200000.0, 0, 10000000, function()
PlayerIndex = globals.get_int(1574918)
	if PlayerIndex == 0 then
		MPX = "MP0_"
	else
		MPX = "MP1_"
	end
                                       return 
   stats.get_int(MPX.."LIFETIME_CONTRA_EARNINGS") end,           
	   function(value) 
stats.set_int(MPX.."LIFETIME_CONTRA_EARNINGS", value * 1)
 end)

CSYONS9:add_action("Auto-Reset stats-0/0Sales", function()
        stats.set_int(MPX .. "LIFETIME_BUY_COMPLETE",  0)
        stats.set_int(MPX .. "LIFETIME_BUY_UNDERTAKEN", 0)
        stats.set_int(MPX .. "LIFETIME_SELL_COMPLETE",  0)
        stats.set_int(MPX .. "LIFETIME_SELL_UNDERTAKEN",  0)
        stats.set_int(MPX .. "LIFETIME_CONTRA_EARNINGS",  0)
        globals.set_int(1575017, 1)         ----PlayerSessionBlank--------
        globals.set_int(1574589, 1)         ----PlayerSessionNew----------
        sleep(0.2)
        globals.set_int(1574589, 0)         ----PlayerSessionNew------
    end
)
CSYONS9:add_action("------------------------------------------------------", function() end)

CSYONS7:add_int_range("my level", 1, 0, 8000, function() 
	return globals.get_int(1854122 + localplayer:get_player_id() * 862)
end, function() end)

CSYONS7:add_int_range("my RP Value", 1, 0, 1787576850, function() 
	return globals.get_int(1854117 + localplayer:get_player_id() * 862)
end, function() end)

CSYONS8:add_action("Unlock Diamond Casino Heist Outfits", function()
	stats.set_bool_masked(MPX .. "CASINOHSTPSTAT_BOOL1", true, 63) -- Refuse Collectors
	stats.set_bool_masked(MPX .. "CASINOHSTPSTAT_BOOL2", true, 0) -- Undertakers
	stats.set_bool_masked(MPX .. "CASINOHSTPSTAT_BOOL2", true, 1) -- Valet Outfits
	stats.set_bool_masked(MPX .. "CASINOHSTPSTAT_BOOL2", true, 3) -- Prison Guards
	stats.set_bool_masked(MPX .. "CASINOHSTPSTAT_BOOL2", true, 4) -- FIB Suits
	stats.set_bool_masked(MPX .. "CASINOHSTPSTAT_BOOL2", true, 6) -- Gruppe Sechs Gear
	stats.set_bool_masked(MPX .. "CASINOHSTPSTAT_BOOL2", true, 7) -- Bugstars Uniforms
	stats.set_bool_masked(MPX .. "CASINOHSTPSTAT_BOOL2", true, 8) -- Maintenance
	stats.set_bool_masked(MPX .. "CASINOHSTPSTAT_BOOL2", true, 9) -- Yung Ancestors
	stats.set_bool_masked(MPX .. "CASINOHSTPSTAT_BOOL2", true, 10) -- Firefighter Gear
	stats.set_bool_masked(MPX .. "CASINOHSTPSTAT_BOOL2", true, 11) -- Orderly Armor
	stats.set_bool_masked(MPX .. "CASINOHSTPSTAT_BOOL2", true, 12) -- Upscale Armor
	stats.set_bool_masked(MPX .. "CASINOHSTPSTAT_BOOL2", true, 13) -- Evening Armor
	stats.set_bool_masked(MPX .. "CASINOHSTPSTAT_BOOL2", true, 14) -- Reinforced: Padded Combat
	stats.set_bool_masked(MPX .. "CASINOHSTPSTAT_BOOL2", true, 15) -- Reinforced: Bulk Combat
	stats.set_bool_masked(MPX .. "CASINOHSTPSTAT_BOOL2", true, 16) -- Reinforced: Compact Combat
	stats.set_bool_masked(MPX .. "CASINOHSTPSTAT_BOOL2", true, 17) -- Balaclava Crook
	stats.set_bool_masked(MPX .. "CASINOHSTPSTAT_BOOL2", true, 18) -- Classic Crook
	stats.set_bool_masked(MPX .. "CASINOHSTPSTAT_BOOL2", true, 19) -- High-end Crook
	stats.set_bool_masked(MPX .. "CASINOHSTPSTAT_BOOL2", true, 20) -- Infiltration: Upgraded Tech
	stats.set_bool_masked(MPX .. "CASINOHSTPSTAT_BOOL2", true, 21) -- Infiltration: Advanced Tech
	stats.set_bool_masked(MPX .. "CASINOHSTPSTAT_BOOL2", true, 22) -- Infiltration: Modernized Tech
end)

CSYONS8:add_action("arena warrior", function()
	stats.set_int(MPX .. "ARENAWARS_SKILL_LEVEL", 19)
end)

CSYONS8:add_action("unlock the Number 1 NightClub trophy", function()
	stats.set_int(MPX .. "NIGHTCLUB_HOTSPOT_TIME_MS", 46800)
end)

CSYONS8:add_action("Unlock Budonk-adonk! Tattoo", function()
   globals.set_int(262145 + 34042, 1) 
end)

CSYONS2:add_action("auto shop contracts completed number and total earning shown at the chalkboard", function()
	stats.set_int(MPX .. "TUNER_COUNT", 10) 
	stats.set_int(MPX .. "TUNER_EARNINGS", 1500000) 
end)

add_hotkey = false
CSYONS18:add_toggle("register and remove the hotkey", function()
    return add_hotkey
end, function(bool)
    add_hotkey = bool
    if add_hotkey == false then
        menu.remove_hotkey(hotkey1)
        menu.remove_hotkey(hotkey2)
        menu.remove_hotkey(hotkey3)
        menu.remove_hotkey(hotkey4)
        menu.remove_hotkey(hotkey5)
        menu.remove_hotkey(hotkey6)
        menu.remove_hotkey(hotkey7)
        menu.remove_hotkey(hotkey8)
        menu.remove_hotkey(hotkey9)
        menu.remove_hotkey(hotkey10)
        menu.remove_hotkey(hotkey11)
        menu.remove_hotkey(hotkey12)
        menu.remove_hotkey(hotkey13)
    end
    if add_hotkey == true then
        hotkey1 = menu.register_hotkey(88, better_teleport_to_waypoint)
        hotkey2 = menu.register_hotkey(17, twoDamage)
        hotkey3 = menu.register_hotkey(106, carAPult)
        hotkey4 = menu.register_hotkey(114, PedDrop)
        hotkey5 = menu.register_hotkey(103, weaponMod)
        hotkey6 = menu.register_hotkey(102, weaponForce)
        hotkey7 = menu.register_hotkey(103, weaponDamage)
        hotkey8 = menu.register_hotkey(45, carBoost)
        hotkey9 = menu.register_hotkey(123, toggleSnow)
        hotkey10 = menu.register_hotkey(111, NoClip)
        hotkey11 = menu.register_hotkey(105, loop)
        hotkey12 = menu.register_hotkey(1, spawnCarWhereAiming)
        hotkey13 = menu.register_hotkey(88, better_teleport_to_waypoint)
    end
end)

CSYONS7:add_action("Add 6 ⭐Stars", function() localplayer:set_wanted_level(6) end)

CSYONS4:add_action("Boom Headshot", function() mini_explode_Gun() end)
CSYONS4:add_action("Big Explode Gun", function() Blimp_Explode_Gun() end)

function mini_explode_Gun(mini_explode_Guns)
	local gun = localplayer:get_current_weapon()
	gun:set_explosion_type(1)
	gun:set_damage_type(5)
end

function Blimp_Explode_Gun(Blimp_Explode_Guns)
	local gun = localplayer:get_current_weapon()
	gun:set_explosion_type(82)
	gun:set_damage_type(5)
end

CSYONS5:add_action("resolve Vehicle", function() resolveCar(Vehicle()) end)
function resolveCar(Vehicle)
	local inCar = localplayer:is_in_vehicle()
	if inCar == true then
		VehP = Vehicle:get_position()
		VehR = Vehicle:get_rotation()
		VehP.z = VehP.z + 1
		VehR.y = 0
		VehR.z = 0
		Vehicle:set_position(VehP)
		Vehicle:set_rotation(VehR)
	end
end

CSYONS15:add_action("Teleport To Objective", function() menu.teleport_to_objective() end)
menu.register_hotkey(17, function() menu.teleport_to_objective() end) --- CTRL key
CSYONS15:add_action("Teleport Forward", function() menu.teleport_forward() end)
menu.register_hotkey(89, function() menu.teleport_forward() end)

CSYONS5:add_action("Vehicle in Fire for Explode", function() FireVeh() end)
function FireVeh()
	local vehicle = localplayer:get_current_vehicle()
	vehicle:set_health(-500)
end

CSYONS5:add_toggle("Realistic Car Damage v2 Buggy", function() return RealCar end, function() RealCar = not RealCar (RealCar) end)

CSYONS5:add_action("Realistic Car Damage", function() RealCar() end)
function RealCar()
	local vehicle = localplayer:get_current_vehicle()
	vehicle:set_engine_damage_multiplier(800000)
	vehicle:set_deformation_damage_multiplier(800000)
	vehicle:set_collision_damage_multiplier(800000)
end

CSYONS8:add_action("Unlock RC Bandito and RC Tank", function()
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL4", true, 19) -- Free RC Bandito
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL8", true, 42) -- Free Invade and Persuade Tank
end)

CSYONS8:add_action("Unlock Arena War Pegasus Vehicles", function()
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 30) -- Unlock Taxi Custom
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 31) -- Unlock Dozer
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 32) -- Unlock Clown Van
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 33) -- Unlock Trashmaster
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 34) -- Unlock Barracks Semi
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 35) -- Unlock Mixer
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 36) -- Unlock Space Docker
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 37) -- Unlock Tractor
end)

CSYONS2:add_action("Trade Prices for Colored Headlights", function()
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 18) -- Trade Price Blue Lights
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 19) -- Trade Price Electric Blue Lights
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 20) -- Trade Price Mint Green Lights
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 21) -- Trade Price Lime Green Lights
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 22) -- Trade Price Yellow Lights
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 23) -- Trade Price Golden Shower Lights
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 24) -- Trade Price Orange Lights
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 25) -- Trade Price Red Lights
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 26) -- Trade Price Pony Pink Lights
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 27) -- Trade Price Hot Pink Lights
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 28) -- Trade Price Purple Lights
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 29) -- Trade Price Blacklight Lights
end)

CSYONS2:add_action("Trade Prices for Arena War Vehicles", function()
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 1) -- Trade Price Apocalypse Cerberus
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 2) -- Trade Price Future Shock Cerberus
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 3) -- Trade Price Apocalypse Brutus
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 4) -- Trade Price Nightmare Cerberus
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 5) -- Trade Price Apocalypse ZR380
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 6) -- Trade Price Future Shock Brutus
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 7) -- Trade Price Impaler
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 10) -- Trade Price Rat-Truck
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 11) -- Trade Price Glendale
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 12) -- Trade Price Slamvan
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 13) -- Trade Price Dominator
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 14) -- Trade Price Issi Classic
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 16) -- Trade Price Gargoyle
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL2", true, 11) -- Trade Price Nightmare Brutus
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL2", true, 12) -- Trade Price Apocalypse Scarab
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL2", true, 13) -- Trade Price Future Shock Scarab
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL2", true, 14) -- Trade Price Nightmare Scarab
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL2", true, 15) -- Trade Price Future Shock ZR380
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL2", true, 16) -- Trade Price Nightmare ZR380
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL2", true, 17) -- Trade Price Apocalypse Imperator
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL2", true, 18) -- Trade Price Future Shock Imperator
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL2", true, 19) -- Trade Price Nightmare Imperator
end)

CSYONS9:add_float_range("Money remover Ballastic", 1000000.0, 1000000, 100000000.0, function() 
	return globals.get_int(282433)
end, function(value)
	globals.set_int(282433, value)
end)

CSYONS8:add_action("Auto Shop Race 'n Chase", function()
	stats.set_bool_masked(MPX.."TUNERPSTAT_BOOL0", true, 48)
end)

CSYONS2:add_int_range("Bank Shootout Event", 172, 0, 172, function()
return globals.get_int(2756259+3+1)
end, function(value)
globals.set_int(262145+34059, 1) -- ENABLE_MAZEBANKSHOOTOUT_DLC22022
globals.set_int(2756259+3+1, value)
globals.set_int(2756259+2, 6)
end)

CSYONS8:add_action("Unlock Fast Run", function()
	stats.set_int("MP0_CHAR_ABILITY_1_UNLCK", -1)
	stats.set_int("MP0_CHAR_ABILITY_2_UNLCK", -1)
	stats.set_int("MP0_CHAR_ABILITY_3_UNLCK", -1)
	stats.set_int("MP0_CHAR_FM_ABILITY_1_UNLCK", -1)
	stats.set_int("MP0_CHAR_FM_ABILITY_2_UNLCK", -1)
	stats.set_int("MP0_CHAR_FM_ABILITY_3_UNLCK", -1)
	stats.set_int("MP1_CHAR_ABILITY_1_UNLCK", -1)
	stats.set_int("MP1_CHAR_ABILITY_2_UNLCK", -1)
	stats.set_int("MP1_CHAR_ABILITY_3_UNLCK", -1)
	stats.set_int("MP1_CHAR_FM_ABILITY_1_UNLCK", -1)
	stats.set_int("MP1_CHAR_FM_ABILITY_2_UNLCK", -1)
	stats.set_int("MP1_CHAR_FM_ABILITY_3_UNLCK", -1)
end)

CSYONS8:add_action("Unlock AlienEyeTattoo Current Tattoos 16", function() stats.set_int("MP0_AWD_RUNRABBITRUN", 67108864) stats.set_int("MP1_AWD_RUNRABBITRUN", 32768) end)

CSYONS8:add_action("Unlock Achievements Drug Wars", function()
	stats.set_bool(MPX .. "AWD_ACELIQUOR", true)
	stats.set_bool(MPX .. "AWD_TRUCKAMBUSH", true)
	stats.set_bool(MPX .. "AWD_LOSTCAMPREV", true)
	stats.set_bool(MPX .. "AWD_ACIDTRIP", true)
	stats.set_bool(MPX .. "AWD_HIPPYRIVALS", true)
	stats.set_bool(MPX .. "AWD_TRAINCRASH", true)
	stats.set_bool(MPX .. "AWD_BACKUPB", true)
	stats.set_bool(MPX .. "AWD_GETSTARTED", true)
	stats.set_bool(MPX .. "AWD_CHEMREACTION", true)
	stats.set_bool(MPX .. "AAWD_WAREHODEFEND", true)
	stats.set_bool(MPX .. "AWD_ATTACKINVEST", true)
	stats.set_bool(MPX .. "AWD_RESCUECOOK", true)
	stats.set_bool(MPX .. "AWD_DRUGTRIPREHAB", true)
	stats.set_bool(MPX .. "AWD_CARGOPLANE", true)
	stats.set_bool(MPX .. "AWD_BACKUPB2", true)
	stats.set_bool(MPX .. "AWD_TAXISTAR", true)
	stats.set_int(MPX .. "AWD_RUNRABBITRUN", 5)
	stats.set_int(MPX .. "AWD_CALLME", 50)
	stats.set_int(MPX .. "AWD_CHEMCOMPOUNDS", 50)
end)

CSYONS2:add_action("Male Unlock Rare DJ T-Shirts", function()
	stats.set_bool_masked(MPX .. "GUNTATPSTAT_BOOL2", true, 18) -- Black The Black Madonna Emb. Tee
	stats.set_bool_masked(MPX .. "GUNTATPSTAT_BOOL2", true, 20) -- The Black Madonna Star Tee
	stats.set_bool_masked(MPX .. "GUNTATPSTAT_BOOL2", true, 27) -- White Dixon Repeated Logo Tee
	stats.set_bool_masked(MPX .. "GUNTATPSTAT_BOOL2", true, 30) -- Black Dixon Wilderness Tee
	stats.set_bool_masked(MPX .. "GUNTATPSTAT_BOOL2", true, 34) -- Tale Of Us Black Box Tee
	stats.set_bool_masked(MPX .. "GUNTATPSTAT_BOOL2", true, 38) -- Black Tale Of Us Emb. Tee
	stats.set_bool_masked(MPX .. "GUNTATPSTAT_BOOL2", true, 40) -- Black Solomun Yellow Logo Tee
	stats.set_bool_masked(MPX .. "GUNTATPSTAT_BOOL2", true, 42) -- White Solomun Tee
	stats.set_bool_masked(MPX .. "HISLANDPSTAT_BOOL1", true, 55) -- White Keinemusik Tee*
	stats.set_bool_masked(MPX .. "HISLANDPSTAT_BOOL1", true, 56) -- Blue Keinemusik Tee*
	stats.set_bool_masked(MPX .. "HISLANDPSTAT_BOOL1", true, 57) -- Moodymann Tee*
	stats.set_bool_masked(MPX .. "HISLANDPSTAT_BOOL1", true, 58) -- Palms Trax Tee*
end)

CSYONS2:add_action("Female Unlock Rare DJ T-Shirts", function()
	stats.set_bool_masked(MPX .. "GUNTATPSTAT_BOOL2", true, 29) -- Black The Black Madonna Emb. Tee
	stats.set_bool_masked(MPX .. "GUNTATPSTAT_BOOL2", true, 31) -- The Black Madonna Star Tee
	stats.set_bool_masked(MPX .. "GUNTATPSTAT_BOOL2", true, 38) -- White Dixon Repeated Logo Tee
	stats.set_bool_masked(MPX .. "GUNTATPSTAT_BOOL2", true, 41) -- Black Dixon Wilderness Tee
	stats.set_bool_masked(MPX .. "GUNTATPSTAT_BOOL2", true, 45) -- Tale Of Us Black Box Tee
	stats.set_bool_masked(MPX .. "GUNTATPSTAT_BOOL2", true, 49) -- Black Tale Of Us Emb. Tee
	stats.set_bool_masked(MPX .. "GUNTATPSTAT_BOOL2", true, 51) -- Black Solomun Yellow Logo Tee
	stats.set_bool_masked(MPX .. "GUNTATPSTAT_BOOL2", true, 53) -- White Solomun Tee
	stats.set_bool_masked(MPX .. "HISLANDPSTAT_BOOL1", true, 55) -- White Keinemusik Tee*
	stats.set_bool_masked(MPX .. "HISLANDPSTAT_BOOL1", true, 56) -- Blue Keinemusik Tee*
	stats.set_bool_masked(MPX .. "HISLANDPSTAT_BOOL1", true, 57) -- Moodymann Tee*
	stats.set_bool_masked(MPX .. "HISLANDPSTAT_BOOL1", true, 58) -- Palms Trax Tee*
end)

CSYONS8:add_action("unlock NC Achievements bruh", function()
      STATS_SET_PACKED_STAT_INT_CODE(22058, 20)
end)

CSYONS8:add_action("unlock Dax-Virtue", function()
	stats.set_int(MPX.."XM22_FLOW", -1)
	stats.set_int(MPX.."XM22_MISSIONS", -1)
	stats.set_bool_masked(MPX.."DLC22022PSTAT_BOOL0", true, 41)
	stats.set_bool_masked(MPX .."DLC22022PSTAT_BOOL0", false, 42)
end)

CSYONS8:add_action("Unlock Masks Casino Store", function()
   globals.set_int(262145 + 27530, 1) 
   globals.set_int(262145 + 27531, 1)
   globals.set_int(262145 + 27532, 1)
   globals.set_int(262145 + 27533, 1)
end)

CSYONS8:add_action("Unlock Colored Headlights", function()
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 18) -- Blue Lights
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 19) -- Electric Blue Lights
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 20) -- Mint Green Lights
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 21) -- Lime Green Lights
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 22) -- Yellow Lights
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 23) -- Golden Shower Lights
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 24) -- Orange Lights
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 25) -- Red Lights
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 26) -- Pony Pink Lights
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 27) -- Hot Pink Lights
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 28) -- Purple Lights
	stats.set_bool_masked(MPX .. "ARENAWARSPSTAT_BOOL0", true, 29) -- Blacklight Lights
end)

local function twoDamage()
	if localplayer == nil then
		return
	end
	current_weapon = localplayer:get_current_weapon()
		if current_weapon ~= nil then
			current_weapon:set_bullet_damage(current_weapon:get_bullet_damage()*2)
		end
end
CSYONS4:add_action("TwoDamage", twoDamage)
menu.register_hotkey(17, twoDamage)

CSYONS4:add_action("One Shoot Weapons", function() Weapons():set_bullet_damage(99900000.00) end)

CSYONS21:add_action("***********************************************************", function() end)
CSYONS21:add_action("for Help join my Discord Server", function() end)
CSYONS21:add_action("https://discord.gg/JaCvtj6yQK", function() end)
CSYONS21:add_action("***********************************************************", function() end)

CSYONS18:add_action("*******************Hotkeys*********************************", function() end)
CSYONS18:add_action("【 Hotkey 】 Car boost Hotkey INSERT", function() end)
CSYONS18:add_action("【 Hotkey 】 Drop Ped Money Hotkey F3", function() end)
CSYONS18:add_action("【 Hotkey 】 Stop Car boost Hotkey Shift", function() end)
CSYONS18:add_action("【 Hotkey 】 Clean + Fix Car F10", function() end)
CSYONS18:add_action("【 Hotkey 】 Car Jump Numpad Comma", function() end)
CSYONS18:add_action("【 Hotkey 】 Weapon Force Hotkeynum6", function() end)
CSYONS18:add_action("【 Hotkey 】 Weapon Damage Hotkeynum7", function() end)
CSYONS18:add_action("【 Hotkey 】 Waypoint TP Key X", function() end)
CSYONS18:add_action("【 Hotkey 】 RefillAmour&Snacks numpad Devide", function() end)
CSYONS18:add_action("【 Hotkey 】 CTRL key to TwoDamage", function() end)
CSYONS18:add_action("【 Hotkey 】 (*) key on numpad for Enable or Disable Car-A-Pult", function() end)
CSYONS18:add_action("【 Hotkey 】 TP To object CTRL key", function() end)

CSYONS18:add_action("***********************************************************", function() end)

CSYONS8r = CSYON8:add_submenu("Still Slipping Los Santos Outfit")
CSYONS8r:add_action("Step 1", function()
    globals.set_int(262145 + 29969, 0)
	end)
CSYONS8r:add_action("Step 2", function()
    globals.set_int(2764908 + 213, -1)
	end)
CSYONS8r:add_action("Step 3", function()
    globals.set_int(262145 + 29969, 1)
	end)
CSYONS8r:add_action("Unlock T-shirts", function()
    globals.set_int(262145 + 30215, 1)
	globals.set_int(262145 + 30915, 1)
	globals.set_int(262145 + 30916, 1)
	end)
local function teleport_myself(x,y,z) localplayer:set_position((vector3(x, y, z))) end
CSYONS8r:add_action("Radio Antennas 01", function()
	teleport_myself(-369.873322, 6107.025879, 38.17276)
 end)
CSYONS8r:add_action("Radio Antennas 02", function()
	teleport_myself(442.673492, 5561.108887, 779.9000)
 end)  
CSYONS8r:add_action("Radio Antennas 03", function()
	teleport_myself(2676.284180, 4573.231934, 39.300000)
 end)
CSYONS8r:add_action("Radio Antennas 04", function()
	teleport_myself(1943.071533, 3796.729980, 30.740000)
 end)
CSYONS8r:add_action("Radio Antennas 05", function()
	teleport_myself(717.495789, 2584.313232, 72.05000)
 end)
 CSYONS8r:add_action("Radio Antennas 06", function()
	teleport_myself(770.636475, 1274.550537, 359.000000)
 end)
 CSYONS8r:add_action("Radio Antennas 07", function()
	teleport_myself(-2212.988770, 339.175201, 197.800000)
 end)
  CSYONS8r:add_action("Radio Antennas 08", function()
	teleport_myself(-1186.412231, -1553.260254, 20.076726)
 end)
 CSYONS8r:add_action("Radio Antennas 09", function()
	teleport_myself(-148.416458, -122.707596, 95.860000)
 end)
 CSYONS8r:add_action("Radio Antennas 10", function()
	teleport_myself(840.573669, -2295.953125, 52.373225)
 end)

CSYONS8:add_action("Activate the Convoy Event", function()
    globals.set_int(262145 + 34061, 1) -- Trick type (0-3)
end)

CSYONS14e = CSYONS14:add_submenu("Online Stats Editor")
CSYONS14r = CSYONS14e:add_submenu("Character Data Editor")
CSYONS14g = CSYONS14e:add_submenu("Distance Data Editor")
CSYONS14f = CSYONS14e:add_submenu("Time Data Editor")

CSYONS14r:add_float_range("Mind State", 1.0, 0.0, 100, function() return stats.get_float("MPPLY_PLAYER_MENTAL_STATE") end, function(value) stats.set_float(MPX .. "PLAYER_MENTAL_STATE", value) stats.set_float("MPPLY_PLAYER_MENTAL_STATE", value) end)
CSYONS14r:add_int_range("Earned Money", 500000, 0, 1000000000, function() return stats.get_int("MPPLY_TOTAL_EVC") end, function(value) stats.set_int("MPPLY_TOTAL_EVC",value) end)
CSYONS14r:add_int_range("Spent Money", 500000, 0, 1000000000, function() return stats.get_int("MPPLY_TOTAL_SVC") end, function(value) stats.set_int("MPPLY_TOTAL_SVC",value) end)
CSYONS14r:add_int_range("Players Killed", 10, 0, 999999, function() return stats.get_int("MPPLY_KILLS_PLAYERS") end, function(value) stats.set_int("MPPLY_KILLS_PLAYERS", value) end)
CSYONS14r:add_int_range("Deatsh per player", 10, 0, 999999, function() return stats.get_int("MPPLY_DEATHS_PLAYER") end, function(value) stats.set_int("MPPLY_DEATHS_PLAYER", value) end)
CSYONS14r:add_float_range("PvP K/D Ratio", 0.01, 0, 9999, function() return stats.get_float("MPPLY_KILL_DEATH_RATIO") end, function(value) stats.set_float("MPPLY_KILL_DEATH_RATIO", value) end)
CSYONS14r:add_int_range("Deathmatches Published", 10, 0, 999999, function() return stats.get_int("MPPLY_AWD_FM_CR_DM_MADE") end, function(value) stats.set_int("MPPLY_AWD_FM_CR_DM_MADE", value) end)
CSYONS14r:add_int_range("Races Published", 10, 0, 999999, function() return stats.get_int("MPPLY_AWD_FM_CR_RACES_MADE") end, function(value) stats.set_int("MPPLY_AWD_FM_CR_RACES_MADE", value) end)
CSYONS14r:add_int_range("Screenshots Published", 10, 0, 999999, function() return stats.get_int("MPPLY_NUM_CAPTURES_CREATED") end, function(value) stats.set_int("MPPLY_NUM_CAPTURES_CREATED", value) end)
CSYONS14r:add_int_range("LTS Published", 10, 0, 999999, function() return stats.get_int("MPPLY_LTS_CREATED") end, function(value) stats.set_int("MPPLY_LTS_CREATED", value) end)
CSYONS14r:add_int_range("Persons who have played your misions", 10, 0, 999999, function() return stats.get_int("MPPLY_AWD_FM_CR_PLAYED_BY_PEEP") end, function(value) stats.set_int("MPPLY_AWD_FM_CR_PLAYED_BY_PEEP", value) end)
CSYONS14r:add_int_range("Likes to missions", 10, 0, 999999, function() return stats.get_int("MPPLY_AWD_FM_CR_MISSION_SCORE") end, function(value) stats.set_int("MPPLY_AWD_FM_CR_MISSION_SCORE", value) end)
CSYONS14r:add_int_range("LSCM Rep Lvl Reseter)", 1, 1, 11, function() return 0 end, function(V) if V == 1 then vt = 5 elseif V == 2 then vt = 415 elseif V == 3 then vt = 1040 elseif V == 4 then vt = 3665 elseif V == 5 then vt = 10540 elseif V == 6 then vt = 20540 elseif V == 7 then vt = 33665 elseif V == 8 then vt = 49915 elseif V == 9 then vt = 69290 elseif V == 10 then vt = 91790 else vt = 117430 end stats.set_int(MPX .. "CAR_CLUB_REP", vt) end) 
CSYONS14r:add_action("~[1/5/10/25/50/75/100/125/150/175/200]", function() end) 
CSYONS14r:add_action("-{Change Session to apply}", function() end)

CSYONS14g:add_float_range("Traveled (metters)", 10.00, 0.00, 99999.00, function() return stats.get_float("MPPLY_CHAR_DIST_TRAVELLED")/1000 end, function(value) stats.set_float("MPPLY_CHAR_DIST_TRAVELLED", value*1000) end)
CSYONS14g:add_float_range("Swiming", 10.00, 0.00, 99999.00, function() return stats.get_float(MPX.."DIST_SWIMMING")/1000 end, function(value) stats.set_float(MPX.."DIST_SWIMMING", value*1000) end)
CSYONS14g:add_float_range("Walking", 10.00, 0.00, 99999.00, function() return stats.get_float(MPX.."DIST_WALKING")/1000 end, function(value) stats.set_float(MPX.."DIST_WALKING", value*1000) end)
CSYONS14g:add_float_range("Running", 10.00, 0.00, 99999.00, function() return stats.get_float(MPX.."DIST_RUNNING")/1000 end, function(value) stats.set_float(MPX.."DIST_RUNNING", value*1000) end)
CSYONS14g:add_float_range("Highest fall without dying", 10.00, 0.00, 99999.00, function() return stats.get_float(MPX.."LONGEST_SURVIVED_FREEFALL") end, function(value) stats.set_float(MPX.."LONGEST_SURVIVED_FREEFALL", value) end)
CSYONS14g:add_float_range("Driving Cars", 10.00, 0.00, 99999.00, function() return stats.get_float(MPX.."DIST_CAR")/1000 end, function(value) stats.set_float(MPX.."DIST_CAR", value*1000) end)
CSYONS14g:add_float_range("Driving motorbikes", 10.00, 0.00, 99999.00, function() return stats.get_float(MPX.."DIST_BIKE")/1000 end, function(value) stats.set_float(MPX.."DIST_BIKE", value*1000) end)
CSYONS14g:add_float_range("Flying Helicopters", 10.00, 0.00, 99999.00, function() return stats.get_float(MPX.."DIST_HELI")/1000 end, function(value) stats.set_float(MPX.."DIST_HELI", value*1000) end)
CSYONS14g:add_float_range("Flying Planes", 10.00, 0.00, 99999.00, function() return stats.get_float(MPX.."DIST_PLANE")/1000 end, function(value) stats.set_float(MPX.."DIST_PLANE", value*1000) end)
CSYONS14g:add_float_range("Driving Botes", 10.00, 0.00, 99999.00, function() return stats.get_float(MPX.."DIST_BOAT")/1000 end, function(value) stats.set_float(MPX.."DIST_BOAT", value*1000) end)
CSYONS14g:add_float_range("Driving ATVs", 10.00, 0.00, 99999.00, function() return stats.get_float(MPX.."DIST_QUADBIKE")/1000 end, function(value) stats.set_float(MPX.."DIST_QUADBIKE", value*1000) end)
CSYONS14g:add_float_range("Driving Bicycles", 10.00, 0.00, 99999.00, function() return stats.get_float(MPX.."DIST_BICYCLE")/1000 end, function(value) stats.set_float(MPX.."DIST_BICYCLE", value*1000) end)
CSYONS14g:add_float_range("Longest Front Willie", 10.00, 0.00, 99999.00, function() return stats.get_float(MPX.."LONGEST_STOPPIE_DIST")/1000 end, function(value) stats.set_float(MPX.."LONGEST_STOPPIE_DIST", value*1000) end)
CSYONS14g:add_float_range("Longest Willie", 10.00, 0.00, 99999.00, function() return stats.get_float(MPX.."LONGEST_WHEELIE_DIST")/1000 end, function(value) stats.set_float(MPX.."LONGEST_WHEELIE_DIST", value*1000) end)
CSYONS14g:add_float_range("Largest driving without crashing", 10.00, 0.00, 99999.00, function() return stats.get_float(MPX.."LONGEST_DRIVE_NOCRASH")/1000 end, function(value) stats.set_float(MPX.."LONGEST_DRIVE_NOCRASH", value*1000) end)
CSYONS14g:add_float_range("Longest Jump", 10.00, 0.00, 99999.00, function() return stats.get_float(MPX.."FARTHEST_JUMP_DIST") end, function(value) stats.set_float(MPX.."FARTHEST_JUMP_DIST", value) end)
CSYONS14g:add_float_range("Longest Jump in Vehicle", 10.00, 0.00, 99999.00, function() return stats.get_float(MPX.."HIGHEST_JUMP_REACHED") end, function(value) stats.set_float(MPX.."HIGHEST_JUMP_REACHED", value) end)
CSYONS14g:add_float_range("Highest Hidraulic Jump", 10.00, 0.00, 99999.00, function() return stats.get_float(MPX.."LOW_HYDRAULIC_JUMP") end, function(value) stats.set_float(MPX.."LOW_HYDRAULIC_JUMP", value) end)

CSYONS14f:add_int_range("Time in FP", 1, 0, 24, function() return math.floor(stats.get_int("MP_FIRST_PERSON_CAM_TIME")/86400000) end, function(value) stats.set_int("MP_FIRST_PERSON_CAM_TIME", value*86400000) end)
CSYONS14f:add_int_range("Time In Gta V Online", 1, 0, 24, function() return math.floor(stats.get_int("MP_PLAYING_TIME")/86400000) end, function(value) stats.set_int("MP_PLAYING_TIME", value*86400000) end)
CSYONS14f:add_int_range("Time in DeathMatches", 1, 0, 24, function() return math.floor(stats.get_int("MPPLY_TOTAL_TIME_SPENT_DEATHMAT")/86400000) end, function(value) stats.set_int("MPPLY_TOTAL_TIME_SPENT_DEATHMAT", value*86400000) end)
CSYONS14f:add_int_range("Time in races", 1, 0, 24, function() return math.floor(stats.get_int("MPPLY_TOTAL_TIME_SPENT_RACES")/86400000) end, function(value) stats.set_int("MPPLY_TOTAL_TIME_SPENT_RACES", value*86400000) end)
CSYONS14f:add_int_range("Time in creator mode", 1, 0, 24, function() return math.floor(stats.get_int("MPPLY_TOTAL_TIME_MISSION_CREATO")/86400000) end, function(value) stats.set_int("MPPLY_TOTAL_TIME_MISSION_CREATO", value*86400000) end)
CSYONS14f:add_int_range("Longest alone sesion", 1, 0, 24, function() return math.floor(stats.get_int(MPX.."LONGEST_PLAYING_TIME")/86400000) end, function(value) stats.set_int(MPX.."LONGEST_PLAYING_TIME", value*86400000) end)
CSYONS14f:add_int_range("Time with character", 1, 0, 24, function() return math.floor(stats.get_int(MPX.."TOTAL_PLAYING_TIME")/86400000) end, function(value) stats.set_int(MPX.."TOTAL_PLAYING_TIME", value*86400000) end)
CSYONS14f:add_int_range("Average Time in sesion", 1, 0, 24, function() return math.floor(stats.get_int(MPX.."AVERAGE_TIME_PER_SESSON")/86400000) end, function(value) stats.set_int(MPX.."AVERAGE_TIME_PER_SESSON", value*86400000) end)
CSYONS14f:add_int_range("Time swiming", 1, 0, 24, function() return math.floor(stats.get_int(MPX.."TIME_SWIMMING")/86400000) end, function(value) stats.set_int(MPX.."TIME_SWIMMING", value*86400000) end)
CSYONS14f:add_int_range("Time under water", 1, 0, 24, function() return math.floor(stats.get_int(MPX.."TIME_UNDERWATER")/86400000) end, function(value) stats.set_int(MPX.."TIME_UNDERWATER", value*86400000) end)
CSYONS14f:add_int_range("Time walking", 1, 0, 24, function() return math.floor(stats.get_int(MPX.."TIME_WALKING")/86400000) end, function(value) stats.set_int(MPX.."TIME_WALKING", value*86400000) end)
CSYONS14f:add_int_range("Time in coverage", 1, 0, 24, function() return math.floor(stats.get_int(MPX.."TIME_IN_COVER")/86400000) end, function(value) stats.set_int(MPX.."TIME_IN_COVER", value*86400000) end)
CSYONS14f:add_int_range("Time with stars", 1, 0, 24, function() return math.floor(stats.get_int(MPX.."TOTAL_CHASE_TIME")/86400000) end, function(value) stats.set_int(MPX.."TOTAL_CHASE_TIME", value*86400000) end)
CSYONS14f:add_float_range("Last wanted duration", 1.0, 0.0, 24.0, function() return math.floor(stats.get_float(MPX.."LAST_CHASE_TIME")/86400000) end, function(value) stats.set_float(MPX.."LAST_CHASE_TIME", value*86400000) end)
CSYONS14f:add_float_range("Longest wanted duration", 1.0, 0.0, 24.0, function() return math.floor(stats.get_float(MPX.."LONGEST_CHASE_TIME")/86400000) end, function(value) stats.set_float(MPX.."LONGEST_CHASE_TIME", value*86400000) end)
CSYONS14f:add_float_range("5 Stars", 1.0, 0.0, 24.0, function() return math.floor(stats.get_float(MPX.."TOTAL_TIME_MAX_STARS")/86400000) end, function(value) stats.set_float(MPX.."TOTAL_TIME_MAX_STARS", value*86400000) end)
CSYONS14f:add_action("Time Bassicly", function() end)
CSYONS14f:add_int_range("Driving Cars", 1, 0, 24, function() return math.floor(stats.get_int(MPX.."TIME_DRIVING_CAR")/86400000) end, function(value) stats.set_int(MPX.."TIME_DRIVING_CAR", value*86400000) end)
CSYONS14f:add_int_range("Driving Motorbike", 1, 0, 24, function() return math.floor(stats.get_int(MPX.."TIME_DRIVING_BIKE")/86400000) end, function(value) stats.set_int(MPX.."TIME_DRIVING_BIKE", value*86400000) end)
CSYONS14f:add_int_range("Driving Helicopters", 1, 0, 24, function() return math.floor(stats.get_int(MPX.."TIME_DRIVING_HELI")/86400000) end, function(value) stats.set_int(MPX.."TIME_DRIVING_HELI", value*86400000) end)
CSYONS14f:add_int_range("Driving Planes", 1, 0, 24, function() return math.floor(stats.get_int(MPX.."TIME_DRIVING_PLANE")/86400000) end, function(value) stats.set_int(MPX.."TIME_DRIVING_PLANE", value*86400000) end)
CSYONS14f:add_int_range("Driving Botes", 1, 0, 24, function() return math.floor(stats.get_int(MPX.."TIME_DRIVING_BOAT")/86400000) end, function(value) stats.set_int(MPX.."TIME_DRIVING_BOAT", value*86400000) end)
CSYONS14f:add_int_range("Conduciendo ATVs", 1, 0, 24, function() return math.floor(stats.get_int(MPX.."TIME_DRIVING_QUADBIKE")/86400000) end, function(value) stats.set_int(MPX.."TIME_DRIVING_QUADBIKE", value*86400000) end)
CSYONS14f:add_int_range("Driving MotorBikes", 1, 0, 24, function() return math.floor(stats.get_int(MPX.."TIME_DRIVING_BICYCLE")/86400000) end, function(value) stats.set_int(MPX.."TIME_DRIVING_BICYCLE", value*86400000) end)

CSYONS17:add_action("Max Stats Storymode Character", function() 
			stats.set_int("SCRIPT_INCREASE_DRIV", 100) 
			stats.set_int("SCRIPT_INCREASE_FLY", 100) 
			stats.set_int("SCRIPT_INCREASE_LUNG", 100) 
			stats.set_int("SCRIPT_INCREASE_SHO", 100) 
			stats.set_int("SCRIPT_INCREASE_STAM", 100) 
			stats.set_int("SCRIPT_INCREASE_STL", 100) 
			stats.set_int("SCRIPT_INCREASE_STRN", 100) end)
			
			CysonWasHere = false
		local function SexChanger(On)
			if On then stats.set_int(MPX .. "ALLOW_GENDER_CHANGE", 52) globals.set_int(281050, 0)
			else stats.set_int(MPX .. "ALLOW_GENDER_CHANGE", 0) end end
	CSYONS2:add_toggle("Unlock <Change Gender<", function() return CysonWasHere end, function() CysonWasHere = not CysonWasHere SexChanger(CysonWasHere) end)

local player_index = "MP" .. stats.get_int("MPPLY_LAST_MP_CHAR")

CSYONS19s = CSYONS19:add_submenu("View yours Reports")
CSYONS19s:add_bare_item("", function() return "Griefing:".. (string.format("%03d", stats.get_int("MPPLY_GRIEFING"))) end, function() end, function()end, function() return end)
CSYONS19s:add_bare_item("", function() return "Exploits:".. (string.format("%03d", stats.get_int("MPPLY_EXPLOITS"))) end, function() end, function()end, function()end)
CSYONS19s:add_bare_item("", function() return "Bug Exploits:".. (string.format("%03d", stats.get_int("MPPLY_GAME_EXPLOITS"))) end, function() end, function()end, function()end)
CSYONS19s:add_bare_item("", function() return "Text Chat:Annoying Me:".. (string.format("%03d", stats.get_int("MPPLY_TC_ANNOYINGME"))) end, function() end, function()end, function()end)
CSYONS19s:add_bare_item("", function() return "Text Chat:Using Hate Speech:".. (string.format("%03d", stats.get_int("MPPLY_TC_HATE"))) end, function() end, function()end, function()end)
CSYONS19s:add_bare_item("", function() return "Voice Chat:Annoying Me:".. (string.format("%03d", stats.get_int("MPPLY_VC_ANNOYINGME"))) end, function() end, function()end, function()end)
CSYONS19s:add_bare_item("", function() return "Voice Chat:Using Hate Speech:".. (string.format("%03d", stats.get_int("MPPLY_VC_HATE"))) end, function() end, function()end, function()end)
CSYONS19s:add_bare_item("", function() return "Offensive Language:".. (string.format("%03d", stats.get_int("MPPLY_OFFENSIVE_LANGUAGE"))) end, function() end, function()end, function()end)
CSYONS19s:add_bare_item("", function() return "Offensive Tagplate:".. (string.format("%03d", stats.get_int("MPPLY_OFFENSIVE_TAGPLATE"))) end, function() end, function()end, function()end)
CSYONS19s:add_bare_item("", function() return "Offensive Content:".. (string.format("%03d", stats.get_int("MPPLY_OFFENSIVE_UGC"))) end, function() end, function()end, function()end)
CSYONS19s:add_bare_item("", function() return "Bad Crew Name:".. (string.format("%03d", stats.get_int("MPPLY_BAD_CREW_NAME"))) end, function() end, function()end, function()end)
CSYONS19s:add_bare_item("", function() return "Bad Crew Motto:".. (string.format("%03d", stats.get_int("MPPLY_BAD_CREW_MOTTO"))) end, function() end, function()end, function()end)
CSYONS19s:add_bare_item("", function() return "Bad Crew Status:".. (string.format("%03d", stats.get_int("MPPLY_BAD_CREW_STATUS"))) end, function() end, function()end, function()end)
CSYONS19s:add_bare_item("", function() return "Bad Crew Emblem:".. (string.format("%03d", stats.get_int("MPPLY_BAD_CREW_EMBLEM"))) end, function() end, function()end, function()end)
CSYONS19s:add_bare_item("", function() return "Friendly:".. (string.format("%03d", stats.get_int("MPPLY_FRIENDLY"))) end, function() end, function()end, function()end)
CSYONS19s:add_bare_item("", function() return "Helpful:".. (string.format("%03d", stats.get_int("MPPLY_HELPFUL"))) end, function() end, function()end, function()end)


CSYONS19:add_action("Delete Active Reports", function()
    stats.set_int("MPPLY_REPORT_STRENGTH", 0)
    stats.set_int("MPPLY_COMMEND_STRENGTH", 0)
    stats.set_int("MPPLY_FRIENDLY", 0)
    stats.set_int("MPPLY_GRIEFING", 0)
    stats.set_int("MPPLY_VC_ANNOYINGME", 0)
    stats.set_int("MPPLY_VC_HATE", 0)
    stats.set_int("MPPLY_TC_ANNOYINGME", 0)
    stats.set_int("MPPLY_TC_HATE", 0)
    stats.set_int("MPPLY_OFFENSIVE_LANGUAGE", 0)
    stats.set_int("MPPLY_OFFENSIVE_TAGPLATE", 0)
    stats.set_int("MPPLY_OFFENSIVE_UGC", 0)
    stats.set_int("MPPLY_BAD_CREW_NAME", 0)
    stats.set_int("MPPLY_BAD_CREW_MOTTO", 0)
    stats.set_int("MPPLY_BAD_CREW_STATUS", 0)
    stats.set_int("MPPLY_BAD_CREW_EMBLEM", 0)
    stats.set_int("MPPLY_EXPLOITS", 0)
    stats.set_int("MPPLY_BECAME_BADSPORT_NUM", 0)
    stats.set_int("MPPLY_DESTROYED_PVEHICLES", 0)
    stats.set_int("MPPLY_BADSPORT_MESSAGE", 0)
    stats.set_int("MPPLY_GAME_EXPLOITS", 0)
    stats.set_int("MPPLY_PLAYER_MENTAL_STATE", 0)
    stats.set_int("MPPLY_PLAYERMADE_TITLE", 0)
    stats.set_int("MPPLY_PLAYERMADE_DESC", 0)

    stats.set_int("MPPLY_ISPUNISHED", 0)
    stats.set_int("MPPLY_WAS_I_BAD_SPORT", 0)
    stats.set_int("MPPLY_WAS_I_CHEATER", 0)
    stats.set_int("MPPLY_CHAR_IS_BADSPORT", 0)

    stats.set_int("MPPLY_OVERALL_BADSPORT", 0)
    stats.set_int("MPPLY_OVERALL_CHEAT", 0)

end)

CSYONS2:add_action("Remove the Stupid Orbital Cannon Cooldown", function() 
			stats.set_int(MPX .. "ORBITAL_CANNON_COOLDOWN", 0) end)

CSYONS8:add_action("Unlock 1.66 something",
    function()
        UnlockExit_CSYON()
    end
)

CSYONS8:add_action("Unlock Masks and Dog With Cone", function()
	stats.set_bool_masked(MPX .. "CASINOPSTAT_BOOL4", true, 21) -- Unicorn Mask
	stats.set_bool_masked(MPX .. "CASINOPSTAT_BOOL4", true, 22) -- Gingerbread Mask
	stats.set_bool_masked(MPX .. "CASINOHSTPSTAT_BOOL1", true, 62) -- Dog With Cone Stuff
end)

CSYONS8:add_action("Trade Price for Hotring Everon", function()
	stats.set_int(MPX .. "FINISHED_SASS_RACE_TOP_3", 20) -- Trade Price for Hotring Everon
end)

CSYONS8:add_action("Unlock Flight School", function() stats.set_int("MPPLY_NUM_CAPTURES_CREATED", 100) for i = 0, 9 do stats.set_int("MPPLY_PILOT_SCHOOL_MEDAL_"..i, -1) stats.set_int(mpx.. "PILOT_SCHOOL_MEDAL_"..i, -1) stats.set_bool(mpx .. "PILOT_ASPASSEDLESSON_"..i, true) end end)

CSYONS8:add_action("Unlock Shooting Range", function() stats.set_int(mpx .. "SR_HIGHSCORE_1", 690) stats.set_int(mpx .. "SR_HIGHSCORE_2", 1860) stats.set_int(mpx .. "SR_HIGHSCORE_3", 2690) stats.set_int(mpx .. "SR_HIGHSCORE_4", 2660) stats.set_int(mpx .. "SR_HIGHSCORE_5", 2650) stats.set_int(mpx .. "SR_HIGHSCORE_6", 450) stats.set_int(mpx .. "SR_TARGETS_HIT", 269) stats.set_int(mpx .. "SR_WEAPON_BIT_SET", -1) stats.set_bool(mpx .. "SR_TIER_1_REWARD", true) stats.set_bool(mpx .. "SR_TIER_3_REWARD", true) stats.set_bool(mpx .. "SR_INCREASE_THROW_CAP", true) end)

CSYONS8:add_action("Unlock Vanilla Unicorn", function() stats.set_int(mpx .. "LAP_DANCED_BOUGHT", 0) stats.set_int(mpx .. "LAP_DANCED_BOUGHT", 5) stats.set_int(mpx .. "LAP_DANCED_BOUGHT", 10) stats.set_int(mpx .. "LAP_DANCED_BOUGHT", 15) stats.set_int(mpx .. "LAP_DANCED_BOUGHT", 25) stats.set_int(mpx .. "PROSTITUTES_FREQUENTED", 1000) end)

CSYONS8:add_action("Unlock Tatoos", function() stats.set_int(mpx .. "TATTOO_FM_CURRENT_32", -1) for i = 0, 47 do stats.set_int(mpx .. "TATTOO_FM_UNLOCKS_"..i, -1) end end)

CSYONS8:add_action("Unlock Weapons in Ammonation", function()
	stats.set_int(MPX .. "CHAR_WEAP_UNLOCKED", -1)
	stats.set_int(MPX .. "CHAR_WEAP_UNLOCKED2", -1)
	stats.set_int(MPX .. "CHAR_WEAP_UNLOCKED3", -1)
	stats.set_int(MPX .. "CHAR_WEAP_UNLOCKED4", -1)
	stats.set_int(MPX .. "CHAR_WEAP_ADDON_1_UNLCK", -1)
	stats.set_int(MPX .. "CHAR_WEAP_ADDON_2_UNLCK", -1)
	stats.set_int(MPX .. "CHAR_WEAP_ADDON_3_UNLCK", -1)
	stats.set_int(MPX .. "CHAR_WEAP_ADDON_4_UNLCK", -1)
	stats.set_int(MPX .. "CHAR_WEAP_FREE", -1)
	stats.set_int(MPX .. "CHAR_WEAP_FREE2", -1)
	stats.set_int(MPX .. "CHAR_FM_WEAP_FREE", -1)
	stats.set_int(MPX .. "CHAR_FM_WEAP_FREE2", -1)
	stats.set_int(MPX .. "CHAR_FM_WEAP_FREE3", -1)
	stats.set_int(MPX .. "CHAR_FM_WEAP_FREE4", -1)
	stats.set_int(MPX .. "CHAR_WEAP_PURCHASED", -1)
	stats.set_int(MPX .. "CHAR_WEAP_PURCHASED2", -1)
	stats.set_int(MPX .. "WEAPON_PICKUP_BITSET", -1)
	stats.set_int(MPX .. "WEAPON_PICKUP_BITSET2", -1)
	stats.set_int(MPX .. "CHAR_FM_WEAP_UNLOCKED", -1)
	stats.set_int(MPX .. "NO_WEAPONS_UNLOCK", -1)
	stats.set_int(MPX .. "NO_WEAPON_MODS_UNLOCK", -1)
	stats.set_int(MPX .. "NO_WEAPON_CLR_MOD_UNLOCK", -1) 
	stats.set_int(MPX .. "CHAR_FM_WEAP_UNLOCKED2", -1)
	stats.set_int(MPX .. "CHAR_FM_WEAP_UNLOCKED3", -1)
	stats.set_int(MPX .. "CHAR_FM_WEAP_UNLOCKED4", -1)
	stats.set_int(MPX .. "CHAR_KIT_1_FM_UNLCK", -1)
	stats.set_int(MPX .. "CHAR_KIT_2_FM_UNLCK", -1)
	stats.set_int(MPX .. "CHAR_KIT_3_FM_UNLCK", -1)
	stats.set_int(MPX .. "CHAR_KIT_4_FM_UNLCK", -1)
	stats.set_int(MPX .. "CHAR_KIT_5_FM_UNLCK", -1)
	stats.set_int(MPX .. "CHAR_KIT_6_FM_UNLCK", -1)
	stats.set_int(MPX .. "CHAR_KIT_7_FM_UNLCK", -1)
	stats.set_int(MPX .. "CHAR_KIT_8_FM_UNLCK", -1)
	stats.set_int(MPX .. "CHAR_KIT_9_FM_UNLCK", -1)
	stats.set_int(MPX .. "CHAR_KIT_10_FM_UNLCK", -1)
	stats.set_int(MPX .. "CHAR_KIT_11_FM_UNLCK", -1)
	stats.set_int(MPX .. "CHAR_KIT_12_FM_UNLCK", -1)
	stats.set_int(MPX .. "CHAR_KIT_FM_PURCHASE", -1)
	stats.set_int(MPX .. "CHAR_WEAP_FM_PURCHASE", -1)
	stats.set_int(MPX .. "CHAR_WEAP_FM_PURCHASE2", -1)
	stats.set_int(MPX .. "CHAR_WEAP_FM_PURCHASE3", -1)
	stats.set_int(MPX .. "CHAR_WEAP_FM_PURCHASE4", -1)
	stats.set_int(MPX .. "FIREWORK_TYPE_1_WHITE", 1000)
	stats.set_int(MPX .. "FIREWORK_TYPE_1_RED", 1000)
	stats.set_int(MPX .. "FIREWORK_TYPE_1_BLUE", 1000)
	stats.set_int(MPX .. "FIREWORK_TYPE_2_WHITE", 1000)
	stats.set_int(MPX .. "FIREWORK_TYPE_2_RED", 1000)
	stats.set_int(MPX .. "FIREWORK_TYPE_2_BLUE", 1000)
	stats.set_int(MPX .. "FIREWORK_TYPE_3_WHITE", 1000)
	stats.set_int(MPX .. "FIREWORK_TYPE_3_RED", 1000)
	stats.set_int(MPX .. "FIREWORK_TYPE_3_BLUE", 1000)
	stats.set_int(MPX .. "FIREWORK_TYPE_4_WHITE", 1000)
	stats.set_int(MPX .. "FIREWORK_TYPE_4_RED", 1000)
	stats.set_int(MPX .. "FIREWORK_TYPE_4_BLUE", 1000)
	stats.set_int(MPX .. "WEAP_FM_ADDON_PURCH", -1)
   for i = 2, 19 do stats.set_int(MPX .. "WEAP_FM_ADDON_PURCH"..i, -1) end
   for j = 1, 19 do stats.set_int(MPX .. "CHAR_FM_WEAP_ADDON_"..j.."_UNLCK", -1) end
   for m = 1, 41 do stats.set_int(MPX .. "CHAR_KIT_"..m.."_FM_UNLCK", -1) end
   for l = 2, 41 do stats.set_int(MPX .. "CHAR_KIT_FM_PURCHASE"..l, -1) end
end)

CSYONS8:add_action("Unlock LSC Tuning", function()
	stats.set_int(MPX .. "CHAR_FM_CARMOD_1_UNLCK", -1)
	stats.set_int(MPX .. "CHAR_FM_CARMOD_2_UNLCK",-1)
	stats.set_int(MPX .. "CHAR_FM_CARMOD_3_UNLCK", -1)
	stats.set_int(MPX .. "CHAR_FM_CARMOD_4_UNLCK", -1)
	stats.set_int(MPX .. "CHAR_FM_CARMOD_5_UNLCK", -1)
	stats.set_int(MPX .. "CHAR_FM_CARMOD_6_UNLCK", -1)
	stats.set_int(MPX .. "CHAR_FM_CARMOD_7_UNLCK", -1)
	stats.set_int(MPX .. "AWD_WIN_CAPTURES", 50)
	stats.set_int(MPX .. "AWD_DROPOFF_CAP_PACKAGES", 100)
	stats.set_int(MPX .. "AWD_KILL_CARRIER_CAPTURE", 100)
	stats.set_int(MPX .. "AWD_FINISH_HEISTS", 50)
	stats.set_int(MPX .. "AWD_FINISH_HEIST_SETUP_JOB", 50)
	stats.set_int(MPX .. "AWD_NIGHTVISION_KILLS", 100)
	stats.set_int(MPX .. "AWD_WIN_LAST_TEAM_STANDINGS", 50)
	stats.set_int(MPX .. "AWD_ONLY_PLAYER_ALIVE_LTS", 50)
	stats.set_int(MPX .. "AWD_FMRALLYWONDRIVE", 25)
	stats.set_int(MPX .. "AWD_FMRALLYWONNAV", 25)
	stats.set_int(MPX .. "AWD_FMWINSEARACE", 25)
	stats.set_int(MPX .. "AWD_RACES_WON", 50)
	stats.set_int(MPX .. "MOST_FLIPS_IN_ONE_JUMP", 5)
	stats.set_int(MPX .. "MOST_SPINS_IN_ONE_JUMP", 5)
	stats.set_int(MPX .. "NUMBER_SLIPSTREAMS_IN_RACE", 100)
	stats.set_int(MPX .. "NUMBER_TURBO_STARTS_IN_RACE", 50)
	stats.set_int(MPX .. "RACES_WON", 50)
	stats.set_int(MPX .. "USJS_COMPLETED", 50)
	stats.set_int(MPX .. "AWD_FM_GTA_RACES_WON", 50)
	stats.set_int(MPX .. "AWD_FM_RACE_LAST_FIRST", 25)
	stats.set_int(MPX .. "AWD_FM_RACES_FASTEST_LAP", 50)
	stats.set_int(MPX .. "AWD_FMBASEJMP", 25)
	stats.set_int(MPX .. "AWD_FMWINAIRRACE", 25)
	stats.set_int("MPPLY_TOTAL_RACES_WON", 50)
end)

CSYONS8:add_action("Unlock Contacts", function()
	stats.set_int(MPX .. "FM_ACT_PHN", -1)
	stats.set_int(MPX .. "FM_ACT_PH2", -1)
	stats.set_int(MPX .. "FM_ACT_PH3", -1)
	stats.set_int(MPX .. "FM_ACT_PH4", -1)
	stats.set_int(MPX .. "FM_ACT_PH5", -1)
	stats.set_int(MPX .. "FM_VEH_TX1", -1)
	stats.set_int(MPX .. "FM_ACT_PH6", -1)
	stats.set_int(MPX .. "FM_ACT_PH7", -1)
	stats.set_int(MPX .. "FM_ACT_PH8", -1)
	stats.set_int(MPX .. "FM_ACT_PH9", -1)
	stats.set_int(MPX .. "FM_CUT_DONE", -1)
	stats.set_int(MPX .. "FM_CUT_DONE_2", -1)
end)

CSYONS10:add_int_range("RP Corrections", 1, 0, 8000, function() if PlayerIndex > 1 or PlayerIndex < 0 then return end local currentRP = 0 if PlayerIndex == 0 then currentRP = stats.get_int("MP0_CHAR_SET_RP_GIFT_ADMIN") else currentRP = stats.get_int("MP1_CHAR_SET_RP_GIFT_ADMIN") end if currentRP <= 0 then currentRP = globals.get_int(1659760 + PlayerIndex) end local rpLevel = 0 for i = 0,8000 do if currentRP < globals.get_int(295825 + i) then break else rpLevel = i end end return rpLevel end, function(value) if PlayerIndex > 1 or PlayerIndex < 0 then return end local newRP = globals.get_int(295825 + value) + 100 stats.set_int(MPX.."CHAR_SET_RP_GIFT_ADMIN", newRP) sleep(2) globals.set_int(1575015, 1) globals.set_int(1574589, 1) sleep(0.2) globals.set_int(1574589, 0) end) 

CSYONS12:add_action("Complete Objectives", function() stats.set_int(MPX .. "COMPLETEDAILYOBJ", 100) stats.set_int(MPX .. "COMPLETEDAILYOBJTOTAL", 100) stats.set_int(MPX .. "TOTALDAYCOMPLETED", 100) stats.set_int(MPX .. "TOTALWEEKCOMPLETED", 400) stats.set_int(MPX .. "TOTALMONTHCOMPLETED", 1800) stats.set_int(MPX .. "CONSECUTIVEDAYCOMPLETED", 30) stats.set_int(MPX .. "CONSECUTIVEWEEKCOMPLETED", 4) stats.set_int(MPX .. "CONSECUTIVEMONTHCOMPLETE", 1) stats.set_int(MPX .. "COMPLETEDAILYOBJSA", 100) stats.set_int(MPX .. "COMPLETEDAILYOBJTOTALSA", 100) stats.set_int(MPX .. "TOTALDAYCOMPLETEDSA", 100) stats.set_int(MPX .. "TOTALWEEKCOMPLETEDSA", 400) stats.set_int(MPX .. "TOTALMONTHCOMPLETEDSA", 1800) stats.set_int(MPX .. "CONSECUTIVEDAYCOMPLETEDSA", 30) stats.set_int(MPX .. "CONSECUTIVEWEEKCOMPLETEDSA", 4) stats.set_int(MPX .. "CONSECUTIVEMONTHCOMPLETESA", 1) stats.set_int(MPX .. "AWD_DAILYOBJCOMPLETEDSA", 100) stats.set_int(MPX .. "AWD_DAILYOBJCOMPLETED", 100) stats.set_bool(MPX .. "AWD_DAILYOBJMONTHBONUS", true) stats.set_bool(MPX .. "AWD_DAILYOBJWEEKBONUS", true) stats.set_bool(MPX .. "AWD_DAILYOBJWEEKBONUSSA", true) stats.set_bool(MPX .. "AWD_DAILYOBJMONTHBONUSSA", true) end) 

CSYONS8:add_action("100% Stats Online Mode", function()
	stats.set_int(MPX .. "SCRIPT_INCREASE_DRIV", 100)
	stats.set_int(MPX .. "SCRIPT_INCREASE_FLY", 100)
	stats.set_int(MPX .. "SCRIPT_INCREASE_LUNG", 100)
	stats.set_int(MPX .. "SCRIPT_INCREASE_SHO", 100)
	stats.set_int(MPX .. "SCRIPT_INCREASE_STAM", 100)
	stats.set_int(MPX .. "SCRIPT_INCREASE_STL", 100)
	stats.set_int(MPX .. "SCRIPT_INCREASE_STRN", 100)
end)

-- Vehicle Types
CSYONS5ui = CSYON5:add_submenu("🚗Spawn Vehicles Broken")
--category
car=CSYONS5ui:add_submenu("🚙Car")
bike=CSYONS5ui:add_submenu("🚲Bike/Cycle")
militry=CSYONS5ui:add_submenu("🚓Militry/Emergency")
airvehicele=CSYONS5ui:add_submenu("🛩Plane/Helicopter")
--sub catagoery
CarSedans=car:add_submenu("Sedans")
CarCoupes=car:add_submenu("Coupes")
Carcompacts=car:add_submenu("Compacts")
CarSports=car:add_submenu("Sports")
CarMuscle=car:add_submenu("Muscles")
CarSUV=car:add_submenu("SUVs")
CarOffRoad=car:add_submenu("Off-Road")
CarMotorcycles=bike:add_submenu("Motorcycles")
Truck=CSYONS5ui:add_submenu("Truck")
CarEmergency=militry:add_submenu("Emergency")
CarCycles=bike:add_submenu("Cycles")
CarMilitary=militry:add_submenu("Military")
CarService=CSYONS5ui:add_submenu("Service")
CarUtility=CSYONS5ui:add_submenu("Utility")
CarVans=CSYONS5ui:add_submenu("Vans")
CarsubHeli=airvehicele:add_submenu("Helicopters")
CarPlanes=airvehicele:add_submenu("Planes")
Trailer=CSYONS5ui:add_submenu("Trailer")
CarBoat=CSYONS5ui:add_submenu("Boats")
CarTrain=CSYONS5ui:add_submenu("Train")

--vehicle List

-- Compacts
Carcompacts:add_action("Spawn Blista", function()SpawnVehicle(-344943009)end)
Carcompacts:add_action("Spawn Blista2", function()SpawnVehicle(1039032026)end)
Carcompacts:add_action("Spawn Blista3", function()SpawnVehicle(-591651781)end)
Carcompacts:add_action("Spawn Brioso", function()SpawnVehicle(1549126457)end)
Carcompacts:add_action("Spawn Dilettante", function()SpawnVehicle(-1130810103)end)
Carcompacts:add_action("Spawn Dilettante2", function()SpawnVehicle(1682114128)end)
Carcompacts:add_action("Spawn Issi2", function()SpawnVehicle(-1177863319)end)
Carcompacts:add_action("Spawn Panto", function()SpawnVehicle(-431692672)end)
Carcompacts:add_action("Spawn Prairie", function()SpawnVehicle(-1450650718)end)
Carcompacts:add_action("Spawn Rhapsody", function()SpawnVehicle(841808271)end)

-- Coupes
CarCoupes:add_action("Spawn CogCabrio", function()SpawnVehicle(330661258)end)
CarCoupes:add_action("Spawn Exemplar", function()SpawnVehicle(-5153954)end)
CarCoupes:add_action("Spawn F620", function()SpawnVehicle(-591610296)end)
CarCoupes:add_action("Spawn Felon", function()SpawnVehicle(-391594584)end)
CarCoupes:add_action("Spawn Felon2", function()SpawnVehicle(-89291282)end)
CarCoupes:add_action("Spawn Jackal", function()SpawnVehicle(-624529134)end)
CarCoupes:add_action("Spawn Oracle", function()SpawnVehicle(1348744438)end)
CarCoupes:add_action("Spawn Oracle2", function()SpawnVehicle(-511601230)end)
CarCoupes:add_action("Spawn Sentinel", function()SpawnVehicle(1349725314)end)
CarCoupes:add_action("Spawn Sentinel2", function()SpawnVehicle(873639469)end)
CarCoupes:add_action("Spawn Windsor", function()SpawnVehicle(1581459400)end)
CarCoupes:add_action("Spawn Windsor2", function()SpawnVehicle(1930048799)end)
CarCoupes:add_action("Spawn Zion", function()SpawnVehicle(-1122289213)end)
CarCoupes:add_action("Spawn Zion2", function()SpawnVehicle(-1193103848)end)

-- SUV
CarSUV:add_action("Spawn BJXL", function()SpawnVehicle(850565707)end)
CarSUV:add_action("Spawn Baller", function()SpawnVehicle(-808831384)end)
CarSUV:add_action("Spawn Baller2", function()SpawnVehicle(142944341)end)
CarSUV:add_action("Spawn Baller3", function()SpawnVehicle(1878062887)end)
CarSUV:add_action("Spawn Baller4", function()SpawnVehicle(634118882)end)
CarSUV:add_action("Spawn Baller5", function()SpawnVehicle(470404958)end)
CarSUV:add_action("Spawn Baller6", function()SpawnVehicle(666166960)end)
CarSUV:add_action("Spawn Cavalcade", function()SpawnVehicle(2006918058)end)
CarSUV:add_action("Spawn Cavalcade2", function()SpawnVehicle(-789894171)end)
CarSUV:add_action("Spawn Contender", function()SpawnVehicle(683047626)end)
CarSUV:add_action("Spawn Dubsta", function()SpawnVehicle(1177543287)end)
CarSUV:add_action("Spawn Dubsta2", function()SpawnVehicle(-394074634)end)
CarSUV:add_action("Spawn Dubsta3", function()SpawnVehicle(-1237253773)end)
CarSUV:add_action("Spawn FQ2", function()SpawnVehicle(-1137532101)end)
CarSUV:add_action("Spawn Granger", function()SpawnVehicle(-1775728740)end)
CarSUV:add_action("Spawn Gresley", function()SpawnVehicle(-1543762099)end)
CarSUV:add_action("Spawn Habanero", function()SpawnVehicle(884422927)end)
CarSUV:add_action("Spawn Huntley", function()SpawnVehicle(486987393)end)
CarSUV:add_action("Spawn Landstalker", function()SpawnVehicle(1269098716)end)
CarSUV:add_action("Spawn Patriot", function()SpawnVehicle(-808457413)end)
CarSUV:add_action("Spawn Radi", function()SpawnVehicle(-1651067813)end)
CarSUV:add_action("Spawn Rocoto", function()SpawnVehicle(2136773105)end)
CarSUV:add_action("Spawn Seminole", function()SpawnVehicle(1221512915)end)
CarSUV:add_action("Spawn Serrano", function()SpawnVehicle(1337041428)end)
CarSUV:add_action("Spawn XLS", function()SpawnVehicle(1203490606)end)
CarSUV:add_action("Spawn XLS2", function()SpawnVehicle(-432008408)end)

-- Muscle
CarMuscle:add_action("Spawn Blade", function()SpawnVehicle(-1205801634)end)
CarMuscle:add_action("Spawn Buccaneer", function()SpawnVehicle(-682211828)end)
CarMuscle:add_action("Spawn Buccaneer2", function()SpawnVehicle(-1013450936)end)
CarMuscle:add_action("Spawn Chino", function()SpawnVehicle(349605904)end)
CarMuscle:add_action("Spawn Chino2", function()SpawnVehicle(-1361687965)end)
CarMuscle:add_action("Spawn Dominator", function()SpawnVehicle(80636076)end)
CarMuscle:add_action("Spawn Dominator2", function()SpawnVehicle(-915704871)end)
CarMuscle:add_action("Spawn Dukes", function()SpawnVehicle(723973206)end)
CarMuscle:add_action("Spawn Dukes2", function()SpawnVehicle(-326143852)end)
CarMuscle:add_action("Spawn Faction", function()SpawnVehicle(-2119578145)end)
CarMuscle:add_action("Spawn Faction2", function()SpawnVehicle(-1790546981)end)
CarMuscle:add_action("Spawn Faction3", function()SpawnVehicle(-2039755226)end)
CarMuscle:add_action("Spawn Gauntlet", function()SpawnVehicle(-1800170043)end)
CarMuscle:add_action("Spawn Gauntlet2", function()SpawnVehicle(349315417)end)
CarMuscle:add_action("Spawn Hotknife", function()SpawnVehicle(37348240)end)
CarMuscle:add_action("Spawn Lurcher", function()SpawnVehicle(2068293287)end)
CarMuscle:add_action("Spawn Moonbeam", function()SpawnVehicle(525509695)end)
CarMuscle:add_action("Spawn Moonbeam2", function()SpawnVehicle(1896491931)end)
CarMuscle:add_action("Spawn Nightshade", function()SpawnVehicle(-1943285540)end)
CarMuscle:add_action("Spawn Phoenix", function()SpawnVehicle(-2095439403)end)
CarMuscle:add_action("Spawn Picador", function()SpawnVehicle(1507916787)end)
CarMuscle:add_action("Spawn RatLoader", function()SpawnVehicle(-667151410)end)
CarMuscle:add_action("Spawn RatLoader2", function()SpawnVehicle(-589178377)end)
CarMuscle:add_action("Spawn Ruiner", function()SpawnVehicle(-227741703)end)
CarMuscle:add_action("Spawn Ruiner2", function()SpawnVehicle(941494461)end)
CarMuscle:add_action("Spawn SabreGT", function()SpawnVehicle(-1685021548)end)
CarMuscle:add_action("Spawn SabreGT2", function()SpawnVehicle(223258115)end)
CarMuscle:add_action("Spawn Sadler2", function()SpawnVehicle(734217681)end)
CarMuscle:add_action("Spawn SlamVan", function()SpawnVehicle(729783779)end)
CarMuscle:add_action("Spawn SlamVan2", function()SpawnVehicle(833469436)end)
CarMuscle:add_action("Spawn SlamVan3", function()SpawnVehicle(1119641113)end)
CarMuscle:add_action("Spawn Stalion", function()SpawnVehicle(1923400478)end)
CarMuscle:add_action("Spawn Stalion2", function()SpawnVehicle(-401643538)end)
CarMuscle:add_action("Spawn Tampa", function()SpawnVehicle(972671128)end)
CarMuscle:add_action("Spawn Tampa3", function()SpawnVehicle(-1210451983)end)
CarMuscle:add_action("Spawn Vigero", function()SpawnVehicle(-825837129)end)
CarMuscle:add_action("Spawn Virgo", function()SpawnVehicle(-498054846)end)
CarMuscle:add_action("Spawn Virgo2", function()SpawnVehicle(-899509638)end)
CarMuscle:add_action("Spawn Virgo3", function()SpawnVehicle(16646064)end)
CarMuscle:add_action("Spawn Voodoo", function()SpawnVehicle(2006667053)end)
CarMuscle:add_action("Spawn Voodoo2", function()SpawnVehicle(523724515)end)

-- Emergency
CarEmergency:add_action("Spawn Ambulance", function()SpawnVehicle(1171614426)end)
CarEmergency:add_action("Spawn FBI", function()SpawnVehicle(1127131465)end)
CarEmergency:add_action("Spawn FBI2", function()SpawnVehicle(-1647941228)end)
CarEmergency:add_action("Spawn FireTruck", function()SpawnVehicle(1938952078)end)
CarEmergency:add_action("Spawn PrisonBus", function()SpawnVehicle(-2007026063)end)
CarEmergency:add_action("Spawn Police", function()SpawnVehicle(2046537925)end)
CarEmergency:add_action("Spawn Police2", function()SpawnVehicle(-1627000575)end)
CarEmergency:add_action("Spawn Police3", function()SpawnVehicle(1912215274)end)
CarEmergency:add_action("Spawn Police4", function()SpawnVehicle(-1973172295)end)
CarEmergency:add_action("Spawn PoliceOld1", function()SpawnVehicle(-1536924937)end)
CarEmergency:add_action("Spawn PoliceOld2", function()SpawnVehicle(-1779120616)end)
CarEmergency:add_action("Spawn PoliceTransport", function()SpawnVehicle(456714581)end)
CarEmergency:add_action("Spawn PoliceBike", function()SpawnVehicle(-34623805)end)
CarEmergency:add_action("Spawn PoliceHelicopter", function()SpawnVehicle(353883353)end)
CarEmergency:add_action("Spawn ParkRanger", function()SpawnVehicle(741586030)end)
CarEmergency:add_action("Spawn Predator", function()SpawnVehicle(-488123221)end)
CarEmergency:add_action("Spawn Riot", function()SpawnVehicle(-1205689942)end)
CarEmergency:add_action("Spawn Sheriff", function()SpawnVehicle(-1683328900)end)
CarEmergency:add_action("Spawn Sheriff2", function()SpawnVehicle(1922257928)end)

-- Industrial
Truck:add_action("Spawn Bulldozer", function()SpawnVehicle(1886712733)end)
Truck:add_action("Spawn Cutter", function()SpawnVehicle(-1006919392)end)
Truck:add_action("Spawn Dump", function()SpawnVehicle(-2130482718)end)
Truck:add_action("Spawn Flatbed", function()SpawnVehicle(1353720154)end)
Truck:add_action("Spawn Guardian", function()SpawnVehicle(-2107990196)end)
Truck:add_action("Spawn Handler", function()SpawnVehicle(444583674)end)
Truck:add_action("Spawn Mixer", function()SpawnVehicle(-784816453)end)
Truck:add_action("Spawn Mixer2", function()SpawnVehicle(475220373)end)
Truck:add_action("Spawn Rubble", function()SpawnVehicle(-1705304628)end)
Truck:add_action("Spawn TipTruck", function()SpawnVehicle(48339065)end)
Truck:add_action("Spawn TipTruck2", function()SpawnVehicle(-947761570)end)

-- Military
CarMilitary:add_action("Spawn APC", function()SpawnVehicle(562680400)end)
CarMilitary:add_action("Spawn Barracks", function()SpawnVehicle(-823509173)end)
CarMilitary:add_action("Spawn Barracks2", function()SpawnVehicle(1074326203)end)
CarMilitary:add_action("Spawn Barracks3", function()SpawnVehicle(630371791)end)
CarMilitary:add_action("Spawn Crusader", function()SpawnVehicle(321739290)end)
CarMilitary:add_action("Spawn Halftrack", function()SpawnVehicle(-32236122)end)
CarMilitary:add_action("Spawn Rhino", function()SpawnVehicle(782665360)end)
CarMilitary:add_action("Spawn Trailersmall2", function()SpawnVehicle(-1881846085)end)

-- Motorcycles
CarMotorcycles:add_action("Spawn Akuma", function()SpawnVehicle(1672195559)end)
CarMotorcycles:add_action("Spawn Avarus", function()SpawnVehicle(-2115793025)end)
CarMotorcycles:add_action("Spawn Bagger", function()SpawnVehicle(-2140431165)end)
CarMotorcycles:add_action("Spawn Bati2", function()SpawnVehicle(-891462355)end)
CarMotorcycles:add_action("Spawn Bati", function()SpawnVehicle(-114291515)end)
CarMotorcycles:add_action("Spawn BF400", function()SpawnVehicle(86520421)end)
CarMotorcycles:add_action("Spawn Blazer4", function()SpawnVehicle(-440768424)end)
CarMotorcycles:add_action("Spawn CarbonRS", function()SpawnVehicle(11251904)end)
CarMotorcycles:add_action("Spawn Chimera", function()SpawnVehicle(6774487)end)
CarMotorcycles:add_action("Spawn Cliffhanger", function()SpawnVehicle(390201602)end)
CarMotorcycles:add_action("Spawn Daemon2", function()SpawnVehicle(-1404136503)end)
CarMotorcycles:add_action("Spawn Daemon", function()SpawnVehicle(2006142190)end)
CarMotorcycles:add_action("Spawn Defiler", function()SpawnVehicle(822018448)end)
CarMotorcycles:add_action("Spawn Double", function()SpawnVehicle(-1670998136)end)
CarMotorcycles:add_action("Spawn Enduro", function()SpawnVehicle(1753414259)end)
CarMotorcycles:add_action("Spawn Esskey", function()SpawnVehicle(2035069708)end)
CarMotorcycles:add_action("Spawn Faggio", function()SpawnVehicle(-1842748181)end)
CarMotorcycles:add_action("Spawn Faggio2", function()SpawnVehicle(55628203)end)
CarMotorcycles:add_action("Spawn Faggio3", function()SpawnVehicle(-1289178744)end)
CarMotorcycles:add_action("Spawn Fcr2", function()SpawnVehicle(-757735410)end)
CarMotorcycles:add_action("Spawn Fcr", function()SpawnVehicle(627535535)end)
CarMotorcycles:add_action("Spawn Gargoyle", function()SpawnVehicle(741090084)end)
CarMotorcycles:add_action("Spawn Hakuchou2", function()SpawnVehicle(-255678177)end)
CarMotorcycles:add_action("Spawn Hakuchou", function()SpawnVehicle(1265391242)end)
CarMotorcycles:add_action("Spawn Hexer", function()SpawnVehicle(301427732)end)
CarMotorcycles:add_action("Spawn Innovation", function()SpawnVehicle(-159126838)end)
CarMotorcycles:add_action("Spawn Lectro", function()SpawnVehicle(640818791)end)
CarMotorcycles:add_action("Spawn Manchez", function()SpawnVehicle(-1523428744)end)
CarMotorcycles:add_action("Spawn Nemesis", function()SpawnVehicle(-634879114)end)
CarMotorcycles:add_action("Spawn Nightblade", function()SpawnVehicle(-1606187161)end)
CarMotorcycles:add_action("Spawn Oppressor", function()SpawnVehicle(884483972)end)
CarMotorcycles:add_action("Spawn OppressorMK2", function()SpawnVehicle(884483972)end)
CarMotorcycles:add_action("Spawn PCJ", function()SpawnVehicle(-909201658)end)
CarMotorcycles:add_action("Spawn Ratbike", function()SpawnVehicle(1873600305)end)
CarMotorcycles:add_action("Spawn Ruffian", function()SpawnVehicle(-893578776)end)
CarMotorcycles:add_action("Spawn Sanchez2", function()SpawnVehicle(-1453280962)end)
CarMotorcycles:add_action("Spawn Sanchez", function()SpawnVehicle(788045382)end)
CarMotorcycles:add_action("Spawn Sanctus", function()SpawnVehicle(1491277511)end)
CarMotorcycles:add_action("Spawn Shotaro", function()SpawnVehicle(-405626514)end)
CarMotorcycles:add_action("Spawn Sovereign", function()SpawnVehicle(743478836)end)
CarMotorcycles:add_action("Spawn Thrust", function()SpawnVehicle(1836027715)end)
CarMotorcycles:add_action("Spawn Vader", function()SpawnVehicle(-140902153)end)
CarMotorcycles:add_action("Spawn Vindicator", function()SpawnVehicle(-1353081087)end)
CarMotorcycles:add_action("Spawn Vortex", function()SpawnVehicle(-609625092)end)
CarMotorcycles:add_action("Spawn Wolfsbane", function()SpawnVehicle(-618617997)end)
CarMotorcycles:add_action("Spawn Zombiea", function()SpawnVehicle(-1009268949)end)
CarMotorcycles:add_action("Spawn Zombieb", function()SpawnVehicle(-570033273)end)

-- Cycles
CarCycles:add_action("Spawn BMX", function()SpawnVehicle(1131912276)end)
CarCycles:add_action("Spawn Cruiser", function()SpawnVehicle(448402357)end)
CarCycles:add_action("Spawn Fixter", function()SpawnVehicle(-836512833)end)
CarCycles:add_action("Spawn Scorcher", function()SpawnVehicle(-186537451)end)
CarCycles:add_action("Spawn TriBike", function()SpawnVehicle(1127861609)end)
CarCycles:add_action("Spawn TriBike2", function()SpawnVehicle(-1233807380)end)
CarCycles:add_action("Spawn TriBike3", function()SpawnVehicle(-400295096)end)

-- OffRoad
CarOffRoad:add_action("Spawn BfInjection", function()SpawnVehicle(1126868326)end)
CarOffRoad:add_action("Spawn Bifta", function()SpawnVehicle(-349601129)end)
CarOffRoad:add_action("Spawn Blazer", function()SpawnVehicle(-2128233223)end)
CarOffRoad:add_action("Spawn Blazer2", function()SpawnVehicle(-48031959)end)
CarOffRoad:add_action("Spawn Blazer3", function()SpawnVehicle(-1269889662)end)
CarOffRoad:add_action("Spawn Blazer5", function()SpawnVehicle(-1590337689)end)
CarOffRoad:add_action("Spawn Bodhi2", function()SpawnVehicle(-1435919434)end)
CarOffRoad:add_action("Spawn Brawler", function()SpawnVehicle(-1479664699)end)
CarOffRoad:add_action("Spawn DLoader", function()SpawnVehicle(1770332643)end)
CarOffRoad:add_action("Spawn Dune", function()SpawnVehicle(-1661854193)end)
CarOffRoad:add_action("Spawn Dune2", function()SpawnVehicle(534258863)end)
CarOffRoad:add_action("Spawn Dune3", function()SpawnVehicle(1897744184)end)
CarOffRoad:add_action("Spawn Dune4", function()SpawnVehicle(-827162039)end)
CarOffRoad:add_action("Spawn Dune5", function()SpawnVehicle(-312295511)end)
CarOffRoad:add_action("Spawn Insurgent", function()SpawnVehicle(-1860900134)end)
CarOffRoad:add_action("Spawn Insurgent2", function()SpawnVehicle(2071877360)end)
CarOffRoad:add_action("Spawn Insurgent3", function()SpawnVehicle(-1924433270)end)
CarOffRoad:add_action("Spawn Kalahari", function()SpawnVehicle(92612664)end)
CarOffRoad:add_action("Spawn Lifeguard", function()SpawnVehicle(469291905)end)
CarOffRoad:add_action("Spawn Marshall", function()SpawnVehicle(1233534620)end)
CarOffRoad:add_action("Spawn Mesa", function()SpawnVehicle(914654722)end)
CarOffRoad:add_action("Spawn Mesa2", function()SpawnVehicle(-748008636)end)
CarOffRoad:add_action("Spawn Mesa3", function()SpawnVehicle(-2064372143)end)
CarOffRoad:add_action("Spawn Monster", function()SpawnVehicle(-845961253)end)
CarOffRoad:add_action("Spawn Nightshark", function()SpawnVehicle(433954513)end)
CarOffRoad:add_action("Spawn RancherXL", function()SpawnVehicle(-2064372143)end)
CarOffRoad:add_action("Spawn RancherXL2", function()SpawnVehicle(-845961253)end)
CarOffRoad:add_action("Spawn Rebel", function()SpawnVehicle(-1207771834)end)
CarOffRoad:add_action("Spawn Rebel2", function()SpawnVehicle(-2045594037)end)
CarOffRoad:add_action("Spawn Sandking", function()SpawnVehicle(-1189015600)end)
CarOffRoad:add_action("Spawn Sandking2", function()SpawnVehicle(989381445)end)
CarOffRoad:add_action("Spawn Technical", function()SpawnVehicle(-2096818938)end)
CarOffRoad:add_action("Spawn Technical2", function()SpawnVehicle(1180875963)end)
CarOffRoad:add_action("Spawn Technical3", function()SpawnVehicle(1356124575)end)
CarOffRoad:add_action("Spawn TrophyTruck", function()SpawnVehicle(101905590)end)
CarOffRoad:add_action("Spawn TrophyTruck2", function()SpawnVehicle(-663299102)end)

-- Sedans
CarSedans:add_action("Spawn Asea", function()SpawnVehicle(-1809822327)end)
CarSedans:add_action("Spawn Asea2", function()SpawnVehicle(-1807623979)end)
CarSedans:add_action("Spawn Asterope", function()SpawnVehicle(-1903012613)end)
CarSedans:add_action("Spawn Cog55", function()SpawnVehicle(906642318)end)
CarSedans:add_action("Spawn Cog552", function()SpawnVehicle(704435172)end)
CarSedans:add_action("Spawn Cognoscenti", function()SpawnVehicle(-2030171296)end)
CarSedans:add_action("Spawn Cognoscenti2", function()SpawnVehicle(-604842630)end)
CarSedans:add_action("Spawn Emperor", function()SpawnVehicle(-685276541)end)
CarSedans:add_action("Spawn Emperor2", function()SpawnVehicle(-1883002148)end)
CarSedans:add_action("Spawn Emperor3", function()SpawnVehicle(-1241712818)end)
CarSedans:add_action("Spawn Fugitive", function()SpawnVehicle(1909141499)end)
CarSedans:add_action("Spawn Glendale", function()SpawnVehicle(75131841)end)
CarSedans:add_action("Spawn Ingot", function()SpawnVehicle(-1289722222)end)
CarSedans:add_action("Spawn Intruder", function()SpawnVehicle(886934177)end)
CarSedans:add_action("Spawn Limo2", function()SpawnVehicle(-114627507)end)
CarSedans:add_action("Spawn Premier", function()SpawnVehicle(-1883869285)end)
CarSedans:add_action("Spawn Primo", function()SpawnVehicle(-1150599089)end)
CarSedans:add_action("Spawn Primo2", function()SpawnVehicle(-2040426790)end)
CarSedans:add_action("Spawn Regina", function()SpawnVehicle(-14495224)end)
CarSedans:add_action("Spawn Romero", function()SpawnVehicle(627094268)end)
CarSedans:add_action("Spawn Stanier", function()SpawnVehicle(-1477580979)end)
CarSedans:add_action("Spawn Stratum", function()SpawnVehicle(1723137093)end)
CarSedans:add_action("Spawn Stretch", function()SpawnVehicle(-1961627517)end)
CarSedans:add_action("Spawn Surge", function()SpawnVehicle(-1894894188)end)
CarSedans:add_action("Spawn Tailgater", function()SpawnVehicle(-1008861746)end)
CarSedans:add_action("Spawn Warrener", function()SpawnVehicle(1373123368)end)
CarSedans:add_action("Spawn Washington", function()SpawnVehicle(1777363799)end)

-- Service
CarService:add_action("Spawn Airbus", function()SpawnVehicle(1283517198)end)
CarService:add_action("Spawn Brickade", function()SpawnVehicle(-305727417)end)
CarService:add_action("Spawn Bus", function()SpawnVehicle(-713569950)end)
CarService:add_action("Spawn Coach", function()SpawnVehicle(-2072933068)end)
CarService:add_action("Spawn Rallytruck", function()SpawnVehicle(-2103821244)end)
CarService:add_action("Spawn RentalBus", function()SpawnVehicle(-1098802077)end)
CarService:add_action("Spawn Taxi", function()SpawnVehicle(-956048545)end)
CarService:add_action("Spawn Tourbus", function()SpawnVehicle(1941029835)end)
CarService:add_action("Spawn Trash", function()SpawnVehicle(1917016601)end)
CarService:add_action("Spawn Trash2", function()SpawnVehicle(-1255698084)end)

-- Sports
CarSports:add_action("Spawn Alpha", function()SpawnVehicle(767087018)end)
CarSports:add_action("Spawn Banshee", function()SpawnVehicle(-1041692462)end)
CarSports:add_action("Spawn Banshee2", function()SpawnVehicle(633712403)end)
CarSports:add_action("Spawn BestiaGTS", function()SpawnVehicle(1274868363)end)
CarSports:add_action("Spawn Buffalo", function()SpawnVehicle(-304802106)end)
CarSports:add_action("Spawn Buffalo2", function()SpawnVehicle(736902334)end)
CarSports:add_action("Spawn Buffalo3", function()SpawnVehicle(237764926)end)
CarSports:add_action("Spawn Carbonizzare", function()SpawnVehicle(2072687711)end)
CarSports:add_action("Spawn Comet2", function()SpawnVehicle(-1045541610)end)
CarSports:add_action("Spawn Comet3", function()SpawnVehicle(-2022483795)end)
CarSports:add_action("Spawn Coquette", function()SpawnVehicle(108773431)end)
CarSports:add_action("Spawn Elegy", function()SpawnVehicle(196747873)end)
CarSports:add_action("Spawn Elegy2", function()SpawnVehicle(-566387422)end)
CarSports:add_action("Spawn Feltzer2", function()SpawnVehicle(-1995326987)end)
CarSports:add_action("Spawn Feltzer3", function()SpawnVehicle(-1566741232)end)
CarSports:add_action("Spawn Furoregt", function()SpawnVehicle(-1089039904)end)
CarSports:add_action("Spawn Fusilade", function()SpawnVehicle(499169875)end)
CarSports:add_action("Spawn Futo", function()SpawnVehicle(2016857647)end)
CarSports:add_action("Spawn Infernus2", function()SpawnVehicle(-1405937764)end)
CarSports:add_action("Spawn Jester", function()SpawnVehicle(-1297672541)end)
CarSports:add_action("Spawn Jester2", function()SpawnVehicle(-1106353882)end)
CarSports:add_action("Spawn Khamelion", function()SpawnVehicle(544021352)end)
CarSports:add_action("Spawn Kuruma", function()SpawnVehicle(-1372848492)end)
CarSports:add_action("Spawn ArmoredKuruma", function()SpawnVehicle(410882957)end)
CarSports:add_action("Spawn Lynx", function()SpawnVehicle(482197771)end)
CarSports:add_action("Spawn Massacro", function()SpawnVehicle(-142942670)end)
CarSports:add_action("Spawn Massacro2", function()SpawnVehicle(-631760477)end)
CarSports:add_action("Spawn Ninef", function()SpawnVehicle(1032823388)end)
CarSports:add_action("Spawn Ninef2", function()SpawnVehicle(-1461482751)end)
CarSports:add_action("Spawn Omnis", function()SpawnVehicle(-777172681)end)
CarSports:add_action("Spawn Penumbra", function()SpawnVehicle(-377465520)end)
CarSports:add_action("Spawn RapidGT", function()SpawnVehicle(-1934452204)end)
CarSports:add_action("Spawn RapidGT2", function()SpawnVehicle(1737773231)end)
CarSports:add_action("Spawn Raptor", function()SpawnVehicle(-674927303)end)
CarSports:add_action("Spawn Ruston", function()SpawnVehicle(719660200)end)
CarSports:add_action("Spawn Schafter2", function()SpawnVehicle(-1255452397)end)
CarSports:add_action("Spawn Schafter3", function()SpawnVehicle(-1485523546)end)
CarSports:add_action("Spawn Schafter4", function()SpawnVehicle(1489967196)end)
CarSports:add_action("Spawn Schafter5", function()SpawnVehicle(-888242983)end)
CarSports:add_action("Spawn Schafter6", function()SpawnVehicle(1922255844)end)
CarSports:add_action("Spawn Schwarzer", function()SpawnVehicle(-746882698)end)
CarSports:add_action("Spawn Seven70", function()SpawnVehicle(-1757836725)end)
CarSports:add_action("Spawn Specter", function()SpawnVehicle(1886268224)end)
CarSports:add_action("Spawn Specter2", function()SpawnVehicle(1074745671)end)
CarSports:add_action("Spawn Sultan", function()SpawnVehicle(970598228)end)
CarSports:add_action("Spawn Surano", function()SpawnVehicle(384071873)end)
CarSports:add_action("Spawn Tampa2", function()SpawnVehicle(-1071380347)end)
CarSports:add_action("Spawn Tropos", function()SpawnVehicle(1887331236)end)
CarSports:add_action("Spawn Verlierer2", function()SpawnVehicle(1102544804)end)

-- Utility
CarUtility:add_action("Spawn Airtug", function()SpawnVehicle(1560980623)end)
CarUtility:add_action("Spawn Caddy", function()SpawnVehicle(1147287684)end)
CarUtility:add_action("Spawn Caddy2", function()SpawnVehicle(-537896628)end)
CarUtility:add_action("Spawn Caddy3", function()SpawnVehicle(-769147461)end)
CarUtility:add_action("Spawn Docktug", function()SpawnVehicle(-884690486)end)
CarUtility:add_action("Spawn Forklift", function()SpawnVehicle(1491375716)end)
CarUtility:add_action("Spawn Mower", function()SpawnVehicle(1783355638)end)
CarUtility:add_action("Spawn Ripley", function()SpawnVehicle(-845979911)end)
CarUtility:add_action("Spawn Sadler", function()SpawnVehicle(-599568815)end)
CarUtility:add_action("Spawn Scrap", function()SpawnVehicle(-1700801569)end)
CarUtility:add_action("Spawn TowTruck", function()SpawnVehicle(-1323100960)end)
CarUtility:add_action("Spawn TowTruck2", function()SpawnVehicle(-442313018)end)
CarUtility:add_action("Spawn Tractor", function()SpawnVehicle(1641462412)end)
CarUtility:add_action("Spawn Tractor2", function()SpawnVehicle(-2076478498)end)
CarUtility:add_action("Spawn Tractor3", function()SpawnVehicle(1445631933)end)
CarUtility:add_action("Spawn TrailerLarge", function()SpawnVehicle(1502869817)end)
CarUtility:add_action("Spawn TrailerS4", function()SpawnVehicle(-1100548694)end)
CarUtility:add_action("Spawn UtilliTruck", function()SpawnVehicle(516990260)end)
CarUtility:add_action("Spawn UtilliTruck2", function()SpawnVehicle(887537515)end)
CarUtility:add_action("Spawn UtilliTruck3", function()SpawnVehicle(2132890591)end)

-- Vans
CarVans:add_action("Spawn Bison", function()SpawnVehicle(-16948145)end)
CarVans:add_action("Spawn Bison2", function()SpawnVehicle(2072156101)end)
CarVans:add_action("Spawn Bison3", function()SpawnVehicle(1739845664)end)
CarVans:add_action("Spawn BobcatXL", function()SpawnVehicle(1069929536)end)
CarVans:add_action("Spawn Boxville", function()SpawnVehicle(-1987130134)end)
CarVans:add_action("Spawn Boxville2", function()SpawnVehicle(-233098306)end)
CarVans:add_action("Spawn Boxville3", function()SpawnVehicle(121658888)end)
CarVans:add_action("Spawn Boxville4", function()SpawnVehicle(444171386)end)
CarVans:add_action("Spawn Boxville5", function()SpawnVehicle(682434785)end)
CarVans:add_action("Spawn Burrito", function()SpawnVehicle(-1346687836)end)
CarVans:add_action("Spawn Burrito2", function()SpawnVehicle(-907477130)end)
CarVans:add_action("Spawn Burrito3", function()SpawnVehicle(-1743316013)end)
CarVans:add_action("Spawn Burrito4", function()SpawnVehicle(893081117)end)
CarVans:add_action("Spawn Burrito5", function()SpawnVehicle(1132262048)end)
CarVans:add_action("Spawn Camper", function()SpawnVehicle(1876516712)end)
CarVans:add_action("Spawn GBurrito", function()SpawnVehicle(-1745203402)end)
CarVans:add_action("Spawn GBurrito2", function()SpawnVehicle(296357396)end)
CarVans:add_action("Spawn Journey", function()SpawnVehicle(296357396)end)
CarVans:add_action("Spawn Minivan", function()SpawnVehicle(-310465116)end)
CarVans:add_action("Spawn Minivan2", function()SpawnVehicle(-1126264336)end)
CarVans:add_action("Spawn Paradise", function()SpawnVehicle(1488164764)end)
CarVans:add_action("Spawn Pony", function()SpawnVehicle(-119658072)end)
CarVans:add_action("Spawn Pony2", function()SpawnVehicle(943752001)end)
CarVans:add_action("Spawn Rumpo", function()SpawnVehicle(1162065741)end)
CarVans:add_action("Spawn Rumpo2", function()SpawnVehicle(-1776615689)end)
CarVans:add_action("Spawn Rumpo3", function()SpawnVehicle(1475773103)end)
CarVans:add_action("Spawn Speedo", function()SpawnVehicle(-810318068)end)
CarVans:add_action("Spawn Speedo2", function()SpawnVehicle(728614474)end)
CarVans:add_action("Spawn Surfer", function()SpawnVehicle(699456151)end)
CarVans:add_action("Spawn Surfer2", function()SpawnVehicle(-1311240698)end)
CarVans:add_action("Spawn Taco", function()SpawnVehicle(1951180813)end)
CarVans:add_action("Spawn Youga", function()SpawnVehicle(65402552)end)
CarVans:add_action("Spawn Youga2", function()SpawnVehicle(1026149675)end)

-- Commercial
Truck:add_action("Spawn Benson", function()SpawnVehicle(2053223216)end)
Truck:add_action("Spawn Biff", function()SpawnVehicle(850991848)end)
Truck:add_action("Spawn Hauler", function()SpawnVehicle(1518533038)end)
Truck:add_action("Spawn Hauler2", function()SpawnVehicle(387748548)end)
Truck:add_action("Spawn Mule", function()SpawnVehicle(904750859)end)
Truck:add_action("Spawn Mule2", function()SpawnVehicle(-1050465301)end)
Truck:add_action("Spawn Mule3", function()SpawnVehicle(-2052737935)end)
Truck:add_action("Spawn Packer", function()SpawnVehicle(569305213)end)
Truck:add_action("Spawn Phantom", function()SpawnVehicle(-2137348917)end)
Truck:add_action("Spawn Phantom2", function()SpawnVehicle(-1649536104)end)
Truck:add_action("Spawn Phantom3", function()SpawnVehicle(177270108)end)
Truck:add_action("Spawn Pounder", function()SpawnVehicle(2112052861)end)
Truck:add_action("Spawn Stockade", function()SpawnVehicle(1747439474)end)
Truck:add_action("Spawn Stockade2", function()SpawnVehicle(-214455498)end)

-- Planes
CarPlanes:add_action("Spawn Besra", function()SpawnVehicle(1824333165)end)
CarPlanes:add_action("Spawn Blimp", function()SpawnVehicle(-150975354)end)
CarPlanes:add_action("Spawn Blimp2", function()SpawnVehicle(-613725916)end)
CarPlanes:add_action("Spawn CargoPlane", function()SpawnVehicle(368211810)end)
CarPlanes:add_action("Spawn Cuban800", function()SpawnVehicle(-644710429)end)
CarPlanes:add_action("Spawn Dodo", function()SpawnVehicle(-901163259)end)
CarPlanes:add_action("Spawn Duster", function()SpawnVehicle(-970356638)end)
CarPlanes:add_action("Spawn Hydra", function()SpawnVehicle(970385471)end)
CarPlanes:add_action("Spawn Jet", function()SpawnVehicle(1058115860)end)
CarPlanes:add_action("Spawn Lazer", function()SpawnVehicle(-1281684762)end)
CarPlanes:add_action("Spawn Luxor", function()SpawnVehicle(621481054)end)
CarPlanes:add_action("Spawn Luxor2", function()SpawnVehicle(-1214293858)end)
CarPlanes:add_action("Spawn Mammatus", function()SpawnVehicle(-1746576111)end)
CarPlanes:add_action("Spawn Miljet", function()SpawnVehicle(165154707)end)
CarPlanes:add_action("Spawn Nimbus", function()SpawnVehicle(-1295027632)end)
CarPlanes:add_action("Spawn Shamal", function()SpawnVehicle(-1214505995)end)
CarPlanes:add_action("Spawn Stunt", function()SpawnVehicle(-2122757008)end)
CarPlanes:add_action("Spawn Titan", function()SpawnVehicle(1981688531)end)
CarPlanes:add_action("Spawn Velum", function()SpawnVehicle(-1673356438)end)
CarPlanes:add_action("Spawn Velum2", function()SpawnVehicle(1077420264)end)
CarPlanes:add_action("Spawn Vestra", function()SpawnVehicle(1341619767)end)

-- Helicopters
CarsubHeli:add_action("Spawn Annihilator", function()SpawnVehicle(837858166)end)
CarsubHeli:add_action("Spawn Buzzard", function()SpawnVehicle(788747387)end)
CarsubHeli:add_action("Spawn Buzzard2", function()SpawnVehicle(745926877)end)
CarsubHeli:add_action("Spawn Cargobob", function()SpawnVehicle(-50547061)end)
CarsubHeli:add_action("Spawn Cargobob2", function()SpawnVehicle(1621617168)end)
CarsubHeli:add_action("Spawn Cargobob3", function()SpawnVehicle(1394036463)end)
CarsubHeli:add_action("Spawn Cargobob4", function()SpawnVehicle(2025593404)end)
CarsubHeli:add_action("Spawn Frogger", function()SpawnVehicle(744705981)end)
CarsubHeli:add_action("Spawn Frogger2", function()SpawnVehicle(1949211328)end)
CarsubHeli:add_action("Spawn Maverick", function()SpawnVehicle(-1660661558)end)
CarsubHeli:add_action("Spawn Savage", function()SpawnVehicle(-82626025)end)
CarsubHeli:add_action("Spawn Skylift", function()SpawnVehicle(1044954915)end)
CarsubHeli:add_action("Spawn Supervolito", function()SpawnVehicle(710198397)end)
CarsubHeli:add_action("Spawn Supervolito2", function()SpawnVehicle(-1671539132)end)
CarsubHeli:add_action("Spawn Swift", function()SpawnVehicle(-339587598)end)
CarsubHeli:add_action("Spawn Swift2", function()SpawnVehicle(1075432268)end)
CarsubHeli:add_action("Spawn Valkyrie", function()SpawnVehicle(-1600252419)end)
CarsubHeli:add_action("Spawn Valkyrie2", function()SpawnVehicle(1543134283)end)
CarsubHeli:add_action("Spawn Volatus", function()SpawnVehicle(-1845487887)end)

-- Boats
CarBoat:add_action("Spawn Dinghy1", function()SpawnVehicle(1033245328)end)
CarBoat:add_action("Spawn Dinghy2", function()SpawnVehicle(276773164)end)
CarBoat:add_action("Spawn Dinghy3", function()SpawnVehicle(509498602)end)
CarBoat:add_action("Spawn Dinghy4", function()SpawnVehicle(867467158)end)
CarBoat:add_action("Spawn Jetmax", function()SpawnVehicle(861409633)end)
CarBoat:add_action("Spawn Marquis", function()SpawnVehicle(-1043459709)end)
CarBoat:add_action("Spawn SeaShark", function()SpawnVehicle(-1030275036)end)
CarBoat:add_action("Spawn SeaShark2", function()SpawnVehicle(-616331036)end)
CarBoat:add_action("Spawn SeaShark3", function()SpawnVehicle(-311022263)end)
CarBoat:add_action("Spawn Speeder", function()SpawnVehicle(231083307)end)
CarBoat:add_action("Spawn Speeder2", function()SpawnVehicle(437538602)end)
CarBoat:add_action("Spawn Squalo", function()SpawnVehicle(400514754)end)
CarBoat:add_action("Spawn Submersible", function()SpawnVehicle(771711535)end)
CarBoat:add_action("Spawn Submersible2", function()SpawnVehicle(-1066334226)end)
CarBoat:add_action("Spawn Suntrap", function()SpawnVehicle(-282946103)end)
CarBoat:add_action("Spawn Toro", function()SpawnVehicle(1070967343)end)
CarBoat:add_action("Spawn Toro2", function()SpawnVehicle(908897389)end)
CarBoat:add_action("Spawn Tropic", function()SpawnVehicle(290013743)end)
CarBoat:add_action("Spawn Tropic2", function()SpawnVehicle(1448677353)end)
CarBoat:add_action("Spawn Tug", function()SpawnVehicle(-2100640717)end)
---Train
CarTrain:add_action("Spawn Freight", function()SpawnVehicle(1030400667)end)
CarTrain:add_action("Spawn FreightCar", function()SpawnVehicle(184361638)end)
CarTrain:add_action("Spawn FreightCont1", function()SpawnVehicle(920453016)end)
CarTrain:add_action("Spawn FreightCont2", function()SpawnVehicle(240201337)end)
CarTrain:add_action("Spawn FreightGrain", function()SpawnVehicle(642617954)end)
CarTrain:add_action("Spawn FreightTrailer", function()SpawnVehicle(-777275802)end)
CarTrain:add_action("Spawn TankerCar", function()SpawnVehicle(586013744)end)
--Triler
Trailer:add_action("Spawn ArmyTanker", function()SpawnVehicle(-1207431159)end)
Trailer:add_action("Spawn ArmyTrailer", function()SpawnVehicle(-1476447243)end)
Trailer:add_action("Spawn BaleTrailer", function()SpawnVehicle(-399841706)end)
Trailer:add_action("Spawn BoatTrailer", function()SpawnVehicle(524108981)end)
Trailer:add_action("Spawn CableCar", function()SpawnVehicle(-960289747)end)
Trailer:add_action("Spawn DockTrailer", function()SpawnVehicle(-2140210194)end)
Trailer:add_action("Spawn GrainTrailer", function()SpawnVehicle(1019737494)end)
Trailer:add_action("Spawn  PropTrailer", function()SpawnVehicle(356391690)end)
Trailer:add_action("Spawn RakeTrailer", function()SpawnVehicle(390902130)end)
Trailer:add_action("Spawn TR2", function()SpawnVehicle(2078290630)end)
Trailer:add_action("Spawn TR3", function()SpawnVehicle(1784254509)end)
--- 
Trailer:add_action("Spawn  TR4", function()SpawnVehicle(2091594960)end)
Trailer:add_action("Spawn TRFlat", function()SpawnVehicle(-1352468814)end)
Trailer:add_action("Spawn TVTrailer", function()SpawnVehicle(-1770643266)end)
Trailer:add_action("Spawn Tanker2", function()SpawnVehicle(1956216962)end)
Trailer:add_action("Spawn TrailerLogs", function()SpawnVehicle(2016027501)end)
Trailer:add_action("Spawn TrailerSmall", function()SpawnVehicle( 712162987)end)
Trailer:add_action("Spawn Trailers", function()SpawnVehicle( -877478386)end)
Trailer:add_action("Spawn Trailers2", function()SpawnVehicle(-1579533167)end)
Trailer:add_action("Spawn Trailers3", function()SpawnVehicle(-2058878099)end)
----vehicle Spawn End

local function orb(e) if not localplayer then return end if e then stats.set_int(MPX.."ORBITAL_CANNON_COOLDOWN", 0) else stats.get_int(MPX.."ORBITAL_CANNON_COOLDOWN") end end
CSYONS2:add_action("Remove delay of orbital canon", function() return e2 end, function() e2 = not e2 orb(e2) end)


CSYONS2:add_action("Remove cooldown for VIP/MC", function() stats.set_int("MPPLY_VIPGAMEPLAYDISABLEDTIMER", 0) end)

CSYONS2:add_action("Skip Lamar Mision", function() stats.set_bool(mpx .. "LOW_FLOW_CS_DRV_SEEN", true) stats.set_bool(mpx .. "LOW_FLOW_CS_TRA_SEEN", true) stats.set_bool(mpx .. "LOW_FLOW_CS_FUN_SEEN", true) stats.set_bool(mpx .. "LOW_FLOW_CS_PHO_SEEN", true) stats.set_bool(mpx .. "LOW_FLOW_CS_FIN_SEEN", true) stats.set_bool(mpx .. "LOW_BEN_INTRO_CS_SEEN", true) stats.set_int(mpx .. "LOWRIDER_FLOW_COMPLETE", 4) stats.set_int(mpx .. "LOW_FLOW_CURRENT_PROG", 9) stats.set_int(mpx .. "LOW_FLOW_CURRENT_CALL", 9) stats.set_int(mpx .. "LOW_FLOW_CS_HELPTEXT", 66) end) 

CSYONS2:add_action("Skip Yatch Misions", function() stats.set_int(mpx .. "YACHT_MISSION_PROG", 0) stats.set_int(mpx .. "YACHT_MISSION_FLOW", 21845) stats.set_int(mpx .. "CASINO_DECORATION_GIFT_1", -1) end)

CSYONS2:add_action("Skip ULP Missions", function() stats.set_int(mpx .. "ULP_MISSION_PROGRESS", 127) stats.set_int(mpx .. "ULP_MISSION_CURRENT", 0) end)

CSYONS2:add_action("Bypass Transaction error", function() if globals.get_int(4536679) == 20 or globals.get_int(4536679) == 4 then globals.set_int(4536673, 0) end end)

CSYONS2:add_toggle("Enable Peyote", function() return globals.get_boolean(270497) end, function(v) globals.set_boolean(270497, v) globals.set_boolean(283842, v) end)
local function FCv(e) if not localplayer then return end if e then for i = 296022, 275164 do globals.set_int(i, 0) end for j = DOCT3, 293272 do globals.set_int(j, 0) end globals.set_int(281827, 0) globals.set_int(262145+21119, 0) else globals.set_int(262145+33877, 20000) for i = 262145+24217, 262145+24744 do globals.set_int(i, 5000) end globals.set_int(262145+13019, 25000) globals.set_int(DOCT3, 10000) globals.set_int(262145+21673, 7000) globals.set_int(262145+31132, 9000) for j = XM28, RBD1 do globals.set_int(j, 5000) end globals.set_int(262145+19682, 5000) globals.set_int(262145+21119, 10000)end end 

CSYONS2:add_toggle("Free CEO Vehicles", function() return e40 end, function() e40 = not e40 FCv(e40) end)

CSYONS2:add_action("💰Get Visitor Bonus Again", function() stats.set_int("MPPLY_CHIPS_COL_TIME", 0) globals.set_int(1575015, 1) globals.set_int(1574589, 1) sleep(0.2) globals.set_int(1574589, 0) end)

CSYONS5:add_action("🚁 Request luxury Helicopter", function() menu.trigger_heli_vip_pickup() end)

CSYONS16:add_action("Empty Session (Solo)", function() menu.empty_session() end)

CSYONS2:add_action("Max all Stats", function() stats.set_int(MPX .. "SCRIPT_INCREASE_DRIV", 100) stats.set_int(MPX .. "SCRIPT_INCREASE_FLY", 100) stats.set_int(MPX .. "SCRIPT_INCREASE_LUNG", 100) stats.set_int(MPX .. "SCRIPT_INCREASE_SHO", 100) stats.set_int(MPX .. "SCRIPT_INCREASE_STAM", 100) stats.set_int(MPX .. "SCRIPT_INCREASE_STL", 100) stats.set_int(MPX .. "SCRIPT_INCREASE_STRN", 100) end)

PlayerIndex = stats.get_int("MPPLY_LAST_MP_CHAR")

CSYONS5:add_action("Destroy Vehicle", function() menu.kill_current_vehicle() end)

CSYONS16:add_array_item("Online Session", {"Join Public", "Start New Public", "Invite Only", "Closed Crew Session", "Crew Session", "Closed Friend Session", "Find Friend Session", "Solo Session", "Leave Online"}, function() return xox_00 end, function(value) xox_00 = value if value == 1 then globals.set_int(1575015, 0) globals.set_int(1574589, 1) sleep(0.2) globals.set_int(1574589, 0) elseif value == 2 then globals.set_int(1575015, 1) globals.set_int(1574589, 1) sleep(0.2) globals.set_int(1574589, 0) elseif value == 3 then globals.set_int(1575015, 11) globals.set_int(1574589, 1) sleep(0.2) globals.set_int(1574589, 0) elseif value == 4 then globals.set_int(1575015, 2) globals.set_int(1574589, 1) sleep(0.2) globals.set_int(1574589, 0) elseif value == 5 then globals.set_int(1575015, 3) globals.set_int(1574589, 1) sleep(0.2) globals.set_int(1574589, 0) elseif value == 6 then globals.set_int(1575015, 6) globals.set_int(1574589, 1) sleep(0.2) globals.set_int(1574589, 0) elseif value == 7 then globals.set_int(1575015, 9) globals.set_int(1574589, 1) sleep(0.2) globals.set_int(1574589, 0) elseif value == 8 then globals.set_int(1575015, 8) globals.set_int(1574589, 1) sleep(0.2) globals.set_int(1574589, 0) elseif value == 9 then globals.set_int(1575015, -1) globals.set_int(1574589, 1) sleep(0.2) globals.set_int(1574589, 0) end end)

DisableRP = false
CSYONS2:add_toggle("Disable RP Level", function() return DisableRP end, function() DisableRP = not DisableRP end)
if  DisableRP== true then globals.set_float(262146, 1)
else globals.set_float(262146, 0) end

mpx = PlayerIndex
if PlayerIndex == 0 then mpx = "MP0_"
else mpx = "MP1_"
end lowda_31 = 1
CSYONS7s=CSYON7:add_submenu("🧍‍♂️Ped Model Changer")
local PedModelAnimal = {}
PedModelAnimal[joaat("a_c_poodle")] = "Poodle"
PedModelAnimal[joaat("a_c_westy")] = "Westy"
PedModelAnimal[joaat("a_c_cat_01")] = "Cat"
PedModelAnimal[joaat("a_c_chimp")] = "Chimp Black"
PedModelAnimal[joaat("a_c_chop")] = "Chop"
PedModelAnimal[joaat("a_c_pug")] = "Pug"
PedModelAnimal[joaat("a_c_rabbit_01")] = "Rabbit"
PedModelAnimal[joaat("a_c_rat")] = "Rat"
PedModelAnimal[joaat("a_c_retriever")] = "Retriever"
PedModelAnimal[joaat("a_c_rhesus")] = "Rhesus Monkey"
PedModelAnimal[joaat("a_c_rottweiler")] = "Rottweiler"
PedModelAnimal[joaat("a_c_shepherd")] = "Shepherd"
PedModelAnimal[joaat("a_c_cow")] = "Cow"
PedModelAnimal[joaat("a_c_coyote")] = "Coyote"
PedModelAnimal[joaat("a_c_deer")] = "Deer"
PedModelAnimal[joaat("a_c_husky")] = "Husky"
PedModelAnimal[joaat("a_c_mtlion")] = "Mountian Lion"
PedModelAnimal[joaat("a_c_panther")] = "Panther"
PedModelAnimal[joaat("a_c_pig")] = "Pig"
local PedModelSeaAnimal = {}
PedModelSeaAnimal[joaat("a_c_stingray")] = "Sting Ray"
PedModelSeaAnimal[joaat("a_c_sharktiger")] = "Tiger Shark"
PedModelSeaAnimal[joaat("a_c_humpback")] = "Humpback"
PedModelSeaAnimal[joaat("a_c_sharkhammer")] = "Hammer Shark"
PedModelSeaAnimal[joaat("a_c_killerwhale")] = "Killer Whale"
PedModelSeaAnimal[joaat("a_c_dolphin")] = "Dolphin"
PedModelSeaAnimal[joaat("a_c_fish")] = "Fish"
local PedModelBird = {}
PedModelBird[joaat("a_c_seagull")] = "Seagull"
PedModelBird[joaat("a_c_pigeon")] = "Pigeon"
PedModelBird[joaat("a_c_crow")] = "Crow"
PedModelBird[joaat("a_c_hen")] = "Hen"
PedModelBird[joaat("a_c_cormorant")] = "Cormorant"
PedModelBird[joaat("a_c_chickenhawk")] = "Hawk Eagle"
local PedModel1 = {}
PedModel1[joaat("a_f_o_salton_01")] = "a_f_o_salton_01"
PedModel1[joaat("a_f_y_clubcust_01")] = "a_f_y_clubcust_01"
PedModel1[joaat("a_f_y_clubcust_02")] = "a_f_y_clubcust_02"
PedModel1[joaat("a_f_y_clubcust_03")] = "a_f_y_clubcust_03"
PedModel1[joaat("a_f_y_clubcust_04")] = "a_f_y_clubcust_04"
PedModel1[joaat("a_f_y_eastsa_01")] = "a_f_y_eastsa_01"
PedModel1[joaat("a_f_y_eastsa_02")] = "a_f_y_eastsa_02"
PedModel1[joaat("a_f_y_eastsa_03")] = "a_f_y_eastsa_03"
PedModel1[joaat("a_f_y_epsilon_01")] = "a_f_y_epsilon_01"
PedModel1[joaat("a_f_y_femaleagent")] = "a_f_y_femaleagent"
PedModel1[joaat("a_f_y_fitness_01")] = "a_f_y_fitness_01"
PedModel1[joaat("a_f_y_fitness_02")] = "a_f_y_fitness_02"
PedModel1[joaat("a_f_y_gencaspat_01")] = "a_f_y_gencaspat_01"
PedModel1[joaat("a_f_y_genhot_01")] = "a_f_y_genhot_01"
PedModel1[joaat("a_f_y_golfer_01")] = "a_f_y_golfer_01"
PedModel1[joaat("a_f_y_hiker_01")] = "a_f_y_hiker_01"
PedModel1[joaat("a_f_y_hippie_01")] = "a_f_y_hippie_01"
PedModel1[joaat("a_f_y_hipster_01")] = "a_f_y_hipster_01"
PedModel1[joaat("a_f_y_hipster_02")] = "Binco Cashier"
PedModel1[joaat("a_f_o_soucent_01")] = "a_f_o_soucent_01"
PedModel1[joaat("a_f_o_soucent_02")] = "a_f_o_soucent_02"
PedModel1[joaat("a_f_y_beach_01")] = "a_f_y_beach_01"
PedModel1[joaat("a_f_y_beach_02")] = "a_f_y_beach_02"
PedModel1[joaat("player_one")] = "Franklin"
PedModel1[joaat("player_two")] = "Trevor"
PedModel1[joaat("player_zero")] = "Michael"
PedModel1[joaat("a_f_m_beach_01")] = "a_f_m_beach_01"
PedModel1[joaat("a_f_m_bevhill")] = "a_f_m_bevhill"
PedModel1[joaat("a_f_m_bevhills_02")] = "Ponsonbys Cashier"
PedModel1[joaat("a_f_m_bodybuild_01")] = "a_f_m_bodybuild_01"
PedModel1[joaat("a_f_m_business_02")] = "a_f_m_business_02"
PedModel1[joaat("a_f_m_downtown_01")] = "a_f_m_downtown_01"
PedModel1[joaat("a_f_m_eastsa_01")] = "a_f_m_eastsa_01"
PedModel1[joaat("a_f_m_eastsa_02")] = "a_f_m_eastsa_02"
PedModel1[joaat("a_f_m_fatbla_01")] = "a_f_m_fatbla_01"
PedModel1[joaat("a_f_m_fatcult_01")] = "a_f_m_fatcult_01"
PedModel1[joaat("a_f_m_fatwhite_01")] = "a_f_m_fatwhite_01"
PedModel1[joaat("a_f_m_ktown_01")] = "a_f_m_ktown_01"
PedModel1[joaat("a_f_m_ktown_02")] = "a_f_m_ktown_02"
PedModel1[joaat("a_f_m_sabsbprotectionslhost_01")] = "a_f_m_sabsbprotectionslhost_01"
PedModel1[joaat("a_f_m_salton_01")] = "a_f_m_salton_01"
PedModel1[joaat("a_f_m_skidrow_01")] = "a_f_m_skidrow_01"
PedModel1[joaat("a_f_m_soucent_01")] = "a_f_m_soucent_01"
PedModel1[joaat("a_f_m_soucent_02")] = "a_f_m_soucent_02"
PedModel1[joaat("a_f_m_soucentmc_01")] = "a_f_m_soucentmc_01"
PedModel1[joaat("a_f_m_tourist_01")] = "a_f_m_tourist_01"
PedModel1[joaat("a_f_m_tramp_01")] = "a_f_m_tramp_01"
PedModel1[joaat("a_f_m_trampbeac_01")] = "a_f_m_trampbeac_01"
PedModel1[joaat("a_f_o_genstreet_01")] = "a_f_o_genstreet_01"
PedModel1[joaat("a_f_o_indian_01")] = "a_f_o_indian_01"
PedModel1[joaat("a_f_o_ktown_01")] = "a_f_o_ktown_01"
PedModel1[joaat("a_f_y_bevhills_01")] = "a_f_y_bevhills_01"
PedModel1[joaat("a_f_y_bevhills_02")] = "a_f_y_bevhills_02"
PedModel1[joaat("a_f_y_bevhills_03")] = "a_f_y_bevhills_03"
PedModel1[joaat("a_f_y_bevhills_04")] = "a_f_y_bevhills_04"
PedModel1[joaat("a_f_y_bevhills_05")] = "a_f_y_bevhills_05"
PedModel1[joaat("a_f_y_business_01")] = "a_f_y_business_01"
PedModel1[joaat("a_f_y_business_02")] = "a_f_y_business_02"
PedModel1[joaat("a_f_y_business_03")] = "a_f_y_business_03"
PedModel1[joaat("a_f_y_business_04")] = "a_f_y_business_04"
PedModel1[joaat("a_f_y_hipster_03")] = "a_f_y_hipster_03"
PedModel1[joaat("a_f_y_hipster_04")] = "a_f_y_hipster_04"
PedModel1[joaat("a_f_y_indian_01")] = "a_f_y_indian_01"
PedModel1[joaat("a_f_y_juggalo_01")] = "a_f_y_juggalo_01"
PedModel1[joaat("a_f_y_runner_01")] = "a_f_y_runner_01"
PedModel1[joaat("a_f_y_rurmeth_01")] = "a_f_y_rurmeth_01"
PedModel1[joaat("a_f_y_scdressy_01")] = "a_f_y_scdressy_01"
PedModel1[joaat("a_f_y_skater_01")] = "a_f_y_skater_01"
PedModel1[joaat("a_f_y_smartcaspat_01")] = "a_f_y_smartcaspat_01"
PedModel1[joaat("a_f_y_soucent_01")] = "a_f_y_soucent_01"
PedModel1[joaat("a_f_y_soucent_02")] = "a_f_y_soucent_02"
PedModel1[joaat("a_f_y_soucent_03")] = "a_f_y_soucent_03"
PedModel1[joaat("a_f_y_tennis_01")] = "a_f_y_tennis_01"
PedModel1[joaat("a_f_y_topless_01")] = "a_f_y_topless_01"
PedModel1[joaat("a_f_y_tourist_01")] = "a_f_y_tourist_01"
PedModel1[joaat("a_f_y_tourist_02")] = "a_f_y_tourist_02"
PedModel1[joaat("a_f_y_vinewood_01")] = "a_f_y_vinewood_01"
PedModel1[joaat("a_f_y_vinewood_02")] = "a_f_y_vinewood_02"
PedModel1[joaat("a_f_y_vinewood_03")] = "a_f_y_vinewood_03"
PedModel1[joaat("a_f_y_vinewood_04")] = "a_f_y_vinewood_04"
PedModel1[joaat("a_f_y_yoga_01")] = "a_f_y_yoga_01"
PedModel1[joaat("a_m_m_acult_01")] = "a_m_m_acult_01"
PedModel1[joaat("a_m_m_afriamer_01")] = "a_m_m_afriamer_01"
PedModel1[joaat("a_m_m_beach_01")] = "a_m_m_beach_01"
PedModel1[joaat("a_m_m_beach_02")] = "a_m_m_beach_02"
PedModel1[joaat("a_m_m_bevhills_01")] = "a_m_m_bevhills_01"
PedModel1[joaat("a_m_m_bevhills_02")] = "a_m_m_bevhills_02"
PedModel1[joaat("a_m_m_business_01")] = "a_m_m_business_01"
PedModel1[joaat("a_m_m_eastsa_01")] = "a_m_m_eastsa_01"
PedModel1[joaat("a_m_m_eastsa_02")] = "a_m_m_eastsa_02"
PedModel1[joaat("a_m_m_farmer_01")] = "a_m_m_farmer_01"
PedModel1[joaat("a_m_m_fatlatin_01")] = "a_m_m_fatlatin_01"
PedModel1[joaat("a_m_m_genfat_01")] = "a_m_m_genfat_01"
PedModel1[joaat("a_m_m_genfat_02")] = "a_m_m_genfat_02"
PedModel1[joaat("a_m_m_golfer_01")] = "a_m_m_golfer_01"
PedModel1[joaat("a_m_m_hasjew_01")] = "a_m_m_hasjew_01"
PedModel1[joaat("a_m_m_hillbilly_01")] = "a_m_m_hillbilly_01"
PedModel1[joaat("a_m_m_hillbilly_02")] = "a_m_m_hillbilly_02"
PedModel1[joaat("a_m_m_indian_01")] = "a_m_m_indian_01"
PedModel1[joaat("a_m_m_ktown_01")] = "a_m_m_ktown_01"
PedModel1[joaat("a_m_m_malibu_01")] = "a_m_m_malibu_01"
PedModel1[joaat("a_m_m_mexcntry_01")] = "a_m_m_mexcntry_01"
PedModel1[joaat("a_m_m_mexlabor_01")] = "a_m_m_mexlabor_01"
PedModel1[joaat("a_m_m_mlcrisis_01")] = "a_m_m_mlcrisis_01"
PedModel1[joaat("a_m_m_og_boss_01")] = "a_m_m_og_boss_01"
PedModel1[joaat("a_m_m_paparazzi_01")] = "a_m_m_paparazzi_01"
PedModel1[joaat("a_m_m_polynesian_01")] = "a_m_m_polynesian_01"
PedModel1[joaat("a_m_m_sabsbprotectionslhost_01")] = "a_m_m_sabsbprotectionslhost_01"
PedModel1[joaat("a_m_m_rurmeth_01")] = "a_m_m_rurmeth_01"
PedModel1[joaat("a_m_m_salton_01")] = "a_m_m_salton_01"
PedModel1[joaat("a_m_m_salton_02")] = "a_m_m_salton_02"
PedModel1[joaat("a_m_m_salton_03")] = "a_m_m_salton_03"
PedModel1[joaat("a_m_m_salton_04")] = "a_m_m_salton_04"
PedModel1[joaat("a_m_m_skater_01")] = "a_m_m_skater_01"
PedModel1[joaat("a_m_m_skidrow_01")] = "a_m_m_skidrow_01"
PedModel1[joaat("a_m_m_socenlat_01")] = "a_m_m_socenlat_01"
PedModel1[joaat("a_m_m_soucent_01")] = "a_m_m_soucent_01"
PedModel1[joaat("a_m_m_soucent_02")] = "a_m_m_soucent_02"
PedModel1[joaat("a_m_m_soucent_03")] = "a_m_m_soucent_03"
PedModel1[joaat("a_m_m_soucent_04")] = "a_m_m_soucent_04"
PedModel1[joaat("a_m_m_stlat_02")] = "a_m_m_stlat_02"
PedModel1[joaat("a_m_m_tennis_01")] = "a_m_m_tennis_01"
PedModel1[joaat("a_m_m_tourist_01")] = "a_m_m_tourist_01"
PedModel1[joaat("a_m_m_tramp_01")] = "a_m_m_tramp_01"
PedModel1[joaat("a_m_m_trampbeac_01")] = "a_m_m_trampbeac_01"
PedModel1[joaat("a_m_m_tranvest_01")] = "a_m_m_tranvest_01"
PedModel1[joaat("a_m_m_tranvest_02")] = "a_m_m_tranvest_02"
PedModel1[joaat("a_m_o_acult_01")] = "a_m_o_acult_01"
PedModel1[joaat("a_m_o_acult_02")] = "a_m_o_acult_02"
PedModel1[joaat("a_m_o_beach_01")] = "a_m_o_beach_01"
PedModel1[joaat("a_m_o_beach_02")] = "a_m_o_beach_02"
PedModel1[joaat("a_m_o_genstreet_01")] = "a_m_o_genstreet_01"
PedModel1[joaat("a_m_o_ktown_01")] = "a_m_o_ktown_01"
PedModel1[joaat("a_m_o_salton_01")] = "a_m_o_salton_01"
PedModel1[joaat("a_m_o_soucent_01")] = "a_m_o_soucent_01"
PedModel1[joaat("a_m_o_soucent_02")] = "a_m_o_soucent_02"
PedModel1[joaat("a_m_o_soucent_03")] = "a_m_o_soucent_03"
PedModel1[joaat("a_m_o_tramp_01")] = "a_m_o_tramp_01"
PedModel1[joaat("a_m_y_acult_01")] = "a_m_y_acult_01"
PedModel1[joaat("a_m_y_acult_02")] = "a_m_y_acult_02"
PedModel1[joaat("a_m_y_beach_01")] = "a_m_y_beach_01"
PedModel1[joaat("a_m_y_beach_02")] = "a_m_y_beach_02"
PedModel1[joaat("a_m_y_beach_03")] = "a_m_y_beach_03"
PedModel1[joaat("a_m_y_beach_04")] = "a_m_y_beach_04"
PedModel1[joaat("a_m_y_beachvesp_01")] = "a_m_y_beachvesp_01"
PedModel1[joaat("a_m_y_beachvesp_02")] = "a_m_y_beachvesp_02"
PedModel1[joaat("a_m_y_bevhills_01")] = "a_m_y_bevhills_01"
PedModel1[joaat("a_m_y_bevhills_02")] = "a_m_y_bevhills_02"
PedModel1[joaat("a_m_y_breakdance_01")] = "a_m_y_breakdance_01"
PedModel1[joaat("a_m_y_busicas_01")] = "a_m_y_busicas_01"
PedModel1[joaat("a_m_y_business_01")] = "a_m_y_business_01"
PedModel1[joaat("a_m_y_business_02")] = "a_m_y_business_02"
PedModel1[joaat("a_m_y_business_03")] = "a_m_y_business_03"
PedModel1[joaat("a_m_y_clubcust_01")] = "a_m_y_clubcust_01"
PedModel1[joaat("a_m_y_clubcust_02")] = "a_m_y_clubcust_02"
PedModel1[joaat("a_m_y_clubcust_03")] = "a_m_y_clubcust_03"
PedModel1[joaat("a_m_y_clubcust_04")] = "a_m_y_clubcust_04"
PedModel1[joaat("a_m_y_cyclist_01")] = "a_m_y_cyclist_01"
PedModel1[joaat("a_m_y_dhill_01")] = "a_m_y_dhill_01"
PedModel1[joaat("a_m_y_downtown_01")] = "a_m_y_downtown_01"
PedModel1[joaat("a_m_y_eastsa_01")] = "a_m_y_eastsa_01"
PedModel1[joaat("a_m_y_eastsa_02")] = "a_m_y_eastsa_02"
PedModel1[joaat("a_m_y_epsilon_01")] = "a_m_y_epsilon_01"
PedModel1[joaat("a_m_y_epsilon_02")] = "a_m_y_epsilon_02"
PedModel1[joaat("a_m_y_gay_01")] = "a_m_y_gay_01"
PedModel1[joaat("a_m_y_gay_02")] = "a_m_y_gay_02"
PedModel1[joaat("a_m_y_gencaspat_01")] = "a_m_y_gencaspat_01"
PedModel1[joaat("a_m_y_genstreet_01")] = "a_m_y_genstreet_01"
PedModel1[joaat("a_m_y_genstreet_02")] = "a_m_y_genstreet_02"
PedModel1[joaat("a_m_y_golfer_01")] = "a_m_y_golfer_01"
PedModel1[joaat("a_m_y_hasjew_01")] = "a_m_y_hasjew_01"
PedModel1[joaat("a_m_y_hiker_01")] = "a_m_y_hiker_01"
PedModel1[joaat("a_m_y_hippy_01")] = "a_m_y_hippy_01"
PedModel1[joaat("a_m_y_hipster_01")] = "a_m_y_hipster_01"
PedModel1[joaat("a_m_y_hipster_02")] = "a_m_y_hipster_02"
PedModel1[joaat("a_m_y_hipster_03")] = "a_m_y_hipster_03"
PedModel1[joaat("a_m_y_indian_01")] = "a_m_y_indian_01"
PedModel1[joaat("a_m_y_jetski_01")] = "a_m_y_jetski_01"
PedModel1[joaat("a_m_y_juggalo_01")] = "a_m_y_juggalo_01"
PedModel1[joaat("a_m_y_ktown_01")] = "a_m_y_ktown_01"
PedModel1[joaat("a_m_y_ktown_02")] = "a_m_y_ktown_02"
PedModel1[joaat("a_m_y_latino_01")] = "a_m_y_latino_01"
PedModel1[joaat("a_m_y_methhead_01")] = "a_m_y_methhead_01"
PedModel1[joaat("a_m_y_mexthug_01")] = "a_m_y_mexthug_01"
PedModel1[joaat("a_m_y_motox_01")] = "a_m_y_motox_01"
PedModel1[joaat("a_m_y_motox_02")] = "a_m_y_motox_02"
PedModel1[joaat("a_m_y_musclbeac_01")] = "a_m_y_musclbeac_01"
PedModel1[joaat("a_m_y_musclbeac_02")] = "a_m_y_musclbeac_02"
PedModel1[joaat("a_m_y_polynesian_01")] = "a_m_y_polynesian_01"
PedModel1[joaat("a_m_y_roadcyc_01")] = "a_m_y_roadcyc_01"
PedModel1[joaat("a_m_y_runner_01")] = "a_m_y_runner_01"
PedModel1[joaat("a_m_y_runner_02")] = "a_m_y_runner_02"
PedModel1[joaat("a_m_y_salton_01")] = "a_m_y_salton_01"
PedModel1[joaat("a_m_y_skater_01")] = "a_m_y_skater_01"
PedModel1[joaat("a_m_y_skater_02")] = "a_m_y_skater_02"
PedModel1[joaat("a_m_y_smartcaspat_01")] = "a_m_y_smartcaspat_01"
PedModel1[joaat("a_m_y_soucent_01")] = "a_m_y_soucent_01"
PedModel1[joaat("a_m_y_soucent_02")] = "a_m_y_soucent_02"
PedModel1[joaat("a_m_y_soucent_03")] = "a_m_y_soucent_03"
PedModel1[joaat("a_m_y_soucent_04")] = "a_m_y_soucent_04"
PedModel1[joaat("a_m_y_stbla_01")] = "a_m_y_stbla_01"
PedModel1[joaat("a_m_y_stbla_02")] = "a_m_y_stbla_02"
PedModel1[joaat("a_m_y_stlat_01")] = "a_m_y_stlat_01"
PedModel1[joaat("a_m_y_stwhi_01")] = "a_m_y_stwhi_01"
PedModel1[joaat("a_m_y_stwhi_02")] = "a_m_y_stwhi_02"
PedModel1[joaat("a_m_y_sunbathe_01")] = "a_m_y_sunbathe_01"
PedModel1[joaat("a_m_y_surfer_01")] = "a_m_y_surfer_01"
PedModel1[joaat("a_m_y_vindouche_01")] = "a_m_y_vindouche_01"
PedModel1[joaat("a_m_y_vinewood_01")] = "a_m_y_vinewood_01"
PedModel1[joaat("a_m_y_vinewood_02")] = "a_m_y_vinewood_02"
PedModel1[joaat("a_m_y_vinewood_03")] = "a_m_y_vinewood_03"
PedModel1[joaat("a_m_y_vinewood_04")] = "a_m_y_vinewood_04"
PedModel1[joaat("a_m_y_yoga_01")] = "a_m_y_yoga_01"
PedModel1[joaat("cs_amandatownley")] = "Amanda"
PedModel1[joaat("cs_andreas")] = "cs_andreas"
PedModel1[joaat("cs_ashley")] = "cs_ashley"
PedModel1[joaat("cs_bankman")] = "cs_bankman"
PedModel1[joaat("cs_barry")] = "cs_barry"
PedModel1[joaat("cs_beverly")] = "cs_beverly"
PedModel1[joaat("cs_brad")] = "cs_brad"
PedModel1[joaat("cs_bradcadaver")] = "cs_bradcadaver"
PedModel1[joaat("cs_carbuyer")] = "cs_carbuyer"
PedModel1[joaat("cs_casey")] = "cs_casey"
PedModel1[joaat("cs_chengsr")] = "cs_chengsr"
PedModel1[joaat("cs_chrisformage")] = "cs_chrisformage"
PedModel1[joaat("cs_clay")] = "cs_clay"
PedModel1[joaat("cs_dale")] = "cs_dale"
PedModel1[joaat("Dave Norton")] = "cs_davenorton"
PedModel1[joaat("cs_debra")] = "cs_debra"
PedModel1[joaat("cs_denise")] = "cs_denise"
PedModel1[joaat("cs_devin")] = "cs_devin"
PedModel1[joaat("cs_dom")] = "cs_dom"
PedModel1[joaat("cs_dreyfuss")] = "cs_dreyfuss"
PedModel1[joaat("cs_drfriedlander")] = "Isiah Friedlander"
PedModel1[joaat("cs_fabien")] = "cs_fabien"
PedModel1[joaat("cs_fbisuit_01")] = "cs_fbisuit_01"
PedModel1[joaat("cs_floyd")] = "cs_floyd"
PedModel1[joaat("cs_guadalope")] = "cs_guadalope"
PedModel1[joaat("cs_gurk")] = "cs_gurk"
PedModel1[joaat("cs_hunter")] = "cs_hunter"
PedModel1[joaat("cs_janet")] = "cs_janet"
PedModel1[joaat("cs_jewelass")] = "cs_jewelass"
PedModel1[joaat("cs_jimmyboston")] = "cs_jimmyboston"
PedModel1[joaat("cs_jimmydisanto")] = "cs_jimmydisanto"
PedModel1[joaat("cs_jimmydisanto2")] = "cs_jimmydisanto2"
PedModel1[joaat("cs_joeminuteman")] = "cs_joeminuteman"
PedModel1[joaat("cs_johnnyklebitz")] = "cs_johnnyklebitz"
PedModel1[joaat("cs_josef")] = "cs_josef"
PedModel1[joaat("cs_josh")] = "cs_josh"
PedModel1[joaat("cs_karen_daniels")] = "cs_karen_daniels"
PedModel1[joaat("cs_lamardavis")] = "cs_lamardavis"
PedModel1[joaat("cs_lazlow")] = "Lazlow 1"
PedModel1[joaat("cs_lazlow_2")] = "cs_lazlow_2"
PedModel1[joaat("cs_lestercrest")] = "cs_lestercrest"
PedModel1[joaat("cs_lestercrest_2")] = "cs_lestercrest_2"
PedModel1[joaat("cs_lestercrest_3")] = "cs_lestercrest_3"
PedModel1[joaat("cs_lifeinvad_01")] = "cs_lifeinvad_01"
PedModel1[joaat("cs_magenta")] = "cs_magenta"
PedModel1[joaat("cs_manuel")] = "cs_manuel"
PedModel1[joaat("cs_marnie")] = "cs_marnie"
PedModel1[joaat("cs_martinmadrazo")] = "cs_martinmadrazo"
PedModel1[joaat("cs_maryann")] = "cs_maryann"
PedModel1[joaat("cs_michelle")] = "cs_michelle"
PedModel1[joaat("cs_milton")] = "cs_milton"
PedModel1[joaat("cs_molly")] = "cs_molly"
PedModel1[joaat("cs_movpremf_01")] = "cs_movpremf_01"
PedModel1[joaat("cs_movpremmale")] = "cs_movpremmale"
PedModel1[joaat("cs_mrk")] = "cs_mrk"
PedModel1[joaat("cs_mrs_thornhill")] = "cs_mrs_thornhill"
PedModel1[joaat("cs_mrsphillips")] = "cs_mrsphillips"
PedModel1[joaat("cs_natalia")] = "cs_natalia"
PedModel1[joaat("cs_nervousron")] = "cs_nervousron"
PedModel1[joaat("cs_nigel")] = "cs_nigel"
PedModel1[joaat("cs_old_man1a")] = "cs_old_man1a"
PedModel1[joaat("cs_old_man2")] = "cs_old_man2"
PedModel1[joaat("cs_omega")] = "cs_omega"
PedModel1[joaat("cs_orleans")] = "cs_orleans"
PedModel1[joaat("cs_paper")] = "cs_paper"
PedModel1[joaat("cs_patricia")] = "cs_patricia"
PedModel1[joaat("cs_patricia_02")] = "cs_patricia_02"
PedModel1[joaat("cs_priest")] = "cs_priest"
PedModel1[joaat("cs_sabsbprotectionslsec_02")] = "cs_sabsbprotectionslsec_02"
PedModel1[joaat("cs_russiandrunk")] = "cs_russiandrunk"
PedModel1[joaat("cs_siemonyetarian")] = "cs_siemonyetarian"
PedModel1[joaat("cs_solomon")] = "cs_solomon"
PedModel1[joaat("cs_stevehains")] = "Steven Haines"
PedModel1[joaat("cs_stretch")] = "Stretch"
PedModel1[joaat("cs_tanisha")] = "cs_tanisha"
PedModel1[joaat("cs_taocheng")] = "Tao Cheng"
PedModel1[joaat("cs_taocheng2")] = "cs_taocheng2"
PedModel1[joaat("cs_taostranslator")] = "cs_taostranslator"
PedModel1[joaat("cs_taostranslator2")] = "cs_taostranslator2"
PedModel1[joaat("cs_tenniscoach")] = "cs_tenniscoach"
PedModel1[joaat("cs_terry")] = "cs_terry"
PedModel1[joaat("cs_tom")] = "cs_tom"
PedModel1[joaat("cs_tomepsilon")] = "cs_tomepsilon"
PedModel1[joaat("cs_tracydisanto")] = "cs_tracydisanto"
PedModel1[joaat("cs_wade")] = "cs_wade"
PedModel1[joaat("cs_zimbor")] = "cs_zimbor"
PedModel1[joaat("csb_abigail")] = "Abigail"
PedModel1[joaat("csb_agatha")] = "csb_agatha"
PedModel1[joaat("csb_agent")] = "csb_agent"
PedModel1[joaat("csb_alan")] = "csb_alan"
PedModel1[joaat("csb_anita")] = "csb_anita"
PedModel1[joaat("csb_anton")] = "csb_anton"
PedModel1[joaat("csb_ary")] = "csb_ary"
PedModel1[joaat("csb_avery")] = "csb_avery"
PedModel1[joaat("csb_avon")] = "csb_avon"
PedModel1[joaat("csb_ballasog")] = "csb_ballasog"
PedModel1[joaat("csb_bogdan")] = "csb_bogdan"
PedModel1[joaat("csb_bride")] = "csb_bride"
PedModel1[joaat("csb_brucie2")] = "csb_brucie2"
PedModel1[joaat("csb_bryony")] = "csb_bryony"
PedModel1[joaat("csb_burgerdrug")] = "csb_burgerdrug"
PedModel1[joaat("csb_car3guy1")] = "csb_car3guy1"
PedModel1[joaat("csb_car3guy2")] = "csb_car3guy2"
PedModel1[joaat("csb_celeb_01")] = "csb_celeb_01"
PedModel1[joaat("csb_chef")] = "csb_chef"
PedModel1[joaat("csb_chef2")] = "csb_chef2"
PedModel1[joaat("csb_chin_goon")] = "csb_chin_goon"
PedModel1[joaat("csb_cletus")] = "csb_cletus"
PedModel1[joaat("csb_cop")] = "csb_cop"
PedModel1[joaat("csb_customer")] = "csb_customer"
PedModel1[joaat("csb_denise_friend")] = "csb_denise_friend"
PedModel1[joaat("csb_dix")] = "csb_dix"
PedModel1[joaat("csb_djblamadon")] = "csb_djblamadon"
PedModel1[joaat("csb_englishdave")] = "English Dave"
PedModel1[joaat("csb_englishdave_02")] = "csb_englishdave_02"
PedModel1[joaat("csb_fos_rep")] = "csb_fos_rep"
PedModel1[joaat("csb_g")] = "Gerald 2"
PedModel1[joaat("csb_georginacheng")] = "csb_georginacheng"
PedModel1[joaat("csb_groom")] = "csb_groom"
PedModel1[joaat("csb_grove_str_dlr")] = "csb_grove_str_dlr"
PedModel1[joaat("csb_gustavo")] = "Gustavo"
PedModel1[joaat("csb_hao")] = "Hao"
PedModel1[joaat("csb_helmsmanpavel")] = "Pavel"
PedModel1[joaat("csb_huang")] = "csb_huang"
PedModel1[joaat("csb_hugh")] = "csb_hugh"
PedModel1[joaat("csb_imran")] = "csb_imran"
PedModel1[joaat("csb_isldj_00")] = "csb_isldj_00"
PedModel1[joaat("csb_isldj_01")] = "csb_isldj_01"
PedModel1[joaat("csb_isldj_02")] = "csb_isldj_02"
PedModel1[joaat("csb_isldj_03")] = "csb_isldj_03"
PedModel1[joaat("csb_isldj_04")] = "csb_isldj_04"
PedModel1[joaat("csb_jackhowitzer")] = "csb_jackhowitzer"
PedModel1[joaat("csb_janitor")] = "csb_janitor"
PedModel1[joaat("csb_jio")] = "Jimmy Iovine"
PedModel1[joaat("csb_juanstrickler")] = "csb_juanstrickler"
PedModel1[joaat("csb_maude")] = "csb_maude"
PedModel1[joaat("csb_miguelmadrazo")] = "csb_miguelmadrazo"
PedModel1[joaat("csb_mjo")] = "DJ Pooh"
PedModel1[joaat("csb_money")] = "Avi Schwartzman"
PedModel1[joaat("csb_mp_agent14")] = "csb_mp_agent14"
PedModel1[joaat("csb_mrs_r")] = "Mrs Rackman"
PedModel1[joaat("csb_mweather")] = "csb_mweather"
PedModel1[joaat("csb_ortega")] = "csb_ortega"
PedModel1[joaat("csb_oscar")] = "csb_oscar"
PedModel1[joaat("csb_paige")] = "csb_paige"
PedModel1[joaat("csb_popov")] = "csb_popov"
PedModel1[joaat("csb_porndudes")] = "csb_porndudes"
PedModel1[joaat("csb_sabsbprotectionsloguedriver")] = "csb_sabsbprotectionsloguedriver"
PedModel1[joaat("csb_sabsbprotectionslsec")] = "csb_sabsbprotectionslsec"
PedModel1[joaat("csb_ramp_gang")] = "csb_ramp_gang"
PedModel1[joaat("csb_ramp_hic")] = "csb_ramp_hic"
PedModel1[joaat("csb_ramp_hipster")] = "csb_ramp_hipster"
PedModel1[joaat("csb_ramp_marine")] = "csb_ramp_marine"
PedModel1[joaat("csb_ramp_mex")] = "csb_ramp_mex"
PedModel1[joaat("csb_rashcosvki")] = "csb_rashcosvki"
PedModel1[joaat("csb_reporter")] = "csb_reporter"
PedModel1[joaat("csb_roccopelosi")] = "csb_roccopelosi"
PedModel1[joaat("csb_screen_writer")] = "csb_screen_writer"
PedModel1[joaat("csb_sol")] = "csb_sol"
PedModel1[joaat("csb_sss")] = "csb_sss"
PedModel1[joaat("csb_stripper_01")] = "csb_stripper_01"
PedModel1[joaat("csb_stripper_02")] = "csb_stripper_02"
PedModel1[joaat("csb_talcc")] = "csb_talcc"
PedModel1[joaat("csb_talmm")] = "csb_talmm"
PedModel1[joaat("csb_thornton")] = "csb_thornton"
PedModel1[joaat("csb_tomcasino")] = "csb_tomcasino"
PedModel1[joaat("csb_tonya")] = "csb_tonya"
PedModel1[joaat("csb_tonyprince")] = "csb_tonyprince"
PedModel1[joaat("csb_trafficwarden")] = "csb_trafficwarden"
PedModel1[joaat("csb_undercover")] = "csb_undercover"
PedModel1[joaat("csb_vagspeak")] = "csb_vagspeak"
PedModel1[joaat("csb_vincent")] = "csb_vincent"
PedModel1[joaat("csb_vincent_2")] = "Vincent 2"
PedModel1[joaat("csb_wendy")] = "csb_wendy"
PedModel1[joaat("g_f_importexport_01")] = "g_f_importexport_01"
PedModel1[joaat("g_f_y_ballas_01")] = "g_f_y_ballas_01"
PedModel1[joaat("g_f_y_families_01")] = "g_f_y_families_01"
PedModel1[joaat("g_f_y_lost_01")] = "g_f_y_lost_01"
PedModel1[joaat("g_f_y_vagos_01")] = "g_f_y_vagos_01"
PedModel1[joaat("g_m_importexport_01")] = "g_m_importexport_01"
PedModel1[joaat("g_m_m_armboss_01")] = "g_m_m_armboss_01"
PedModel1[joaat("g_m_m_armgoon_01")] = "g_m_m_armgoon_01"
PedModel1[joaat("g_m_m_armlieut_01")] = "g_m_m_armlieut_01"
PedModel1[joaat("g_m_m_cartelguards_01")] = "g_m_m_cartelguards_01"
PedModel1[joaat("g_m_m_cartelguards_02")] = "g_m_m_cartelguards_02"
PedModel1[joaat("g_m_m_casrn_01")] = "g_m_m_casrn_01"
PedModel1[joaat("g_m_m_chemwork_01")] = "g_m_m_chemwork_01"
PedModel1[joaat("g_m_m_chiboss_01")] = "g_m_m_chiboss_01"
PedModel1[joaat("g_m_m_chicold_01")] = "g_m_m_chicold_01"
PedModel1[joaat("g_m_m_chigoon_01")] = "g_m_m_chigoon_01"
PedModel1[joaat("g_m_m_chigoon_02")] = "g_m_m_chigoon_02"
PedModel1[joaat("g_m_m_korboss_01")] = "g_m_m_korboss_01"
PedModel1[joaat("g_m_m_mexboss_01")] = "g_m_m_mexboss_01"
PedModel1[joaat("g_m_m_mexboss_02")] = "g_m_m_mexboss_02"
PedModel1[joaat("g_m_y_armgoon_02")] = "g_m_y_armgoon_02"
PedModel1[joaat("g_m_y_azteca_01")] = "g_m_y_azteca_01"
PedModel1[joaat("g_m_y_ballaeast_01")] = "g_m_y_ballaeast_01"
PedModel1[joaat("g_m_y_ballaorig_01")] = "g_m_y_ballaorig_01"
PedModel1[joaat("g_m_y_ballasout_01")] = "g_m_y_ballasout_01"
PedModel1[joaat("g_m_y_famca_01")] = "g_m_y_famca_01"
PedModel1[joaat("g_m_y_famdnf_01")] = "g_m_y_famdnf_01"
PedModel1[joaat("g_m_y_famfor_01")] = "g_m_y_famfor_01"
PedModel1[joaat("g_m_y_korean_01")] = "g_m_y_korean_01"
PedModel1[joaat("g_m_y_korean_02")] = "g_m_y_korean_02"
PedModel1[joaat("g_m_y_korlieut_01")] = "g_m_y_korlieut_01"
PedModel1[joaat("g_m_y_lost_01")] = "g_m_y_lost_01"
PedModel1[joaat("g_m_y_lost_02")] = "g_m_y_lost_02"
PedModel1[joaat("g_m_y_lost_03")] = "g_m_y_lost_03"
PedModel1[joaat("g_m_y_mexgang_01")] = "g_m_y_mexgang_01"
PedModel1[joaat("g_m_y_mexgoon_01")] = "g_m_y_mexgoon_01"
PedModel1[joaat("g_m_y_mexgoon_02")] = "g_m_y_mexgoon_02"
PedModel1[joaat("g_m_y_mexgoon_03")] = "g_m_y_mexgoon_03"
PedModel1[joaat("g_m_y_pologoon_01")] = "g_m_y_pologoon_01"
PedModel1[joaat("g_m_y_pologoon_02")] = "g_m_y_pologoon_02"
PedModel1[joaat("g_m_y_salvaboss_01")] = "g_m_y_salvaboss_01"
PedModel1[joaat("g_m_y_salvagoon_01")] = "g_m_y_salvagoon_01"
PedModel1[joaat("g_m_y_salvagoon_02")] = "g_m_y_salvagoon_02"
PedModel1[joaat("g_m_y_salvagoon_03")] = "g_m_y_salvagoon_03"
PedModel1[joaat("g_m_y_strpunk_01")] = "g_m_y_strpunk_01"
PedModel1[joaat("g_m_y_strpunk_02")] = "g_m_y_strpunk_02"
PedModel1[joaat("hc_driver")] = "hc_driver"
PedModel1[joaat("hc_gunman")] = "hc_gunman"
PedModel1[joaat("hc_hacker")] = "hc_hacker"
PedModel1[joaat("ig_abigail")] = "Abigail"
PedModel1[joaat("ig_agatha")] = "Agatha"
PedModel1[joaat("ig_agent")] = "Agent"
PedModel1[joaat("ig_amandatownley")] = "Amanda 1"
PedModel1[joaat("ig_andreas")] = "Andreas"
PedModel1[joaat("ig_ary")] = "Ary"
PedModel1[joaat("ig_ashley")] = "Ashley"
PedModel1[joaat("ig_avery")] = "Avery"
PedModel1[joaat("ig_avon")] = "Avon Hertz"
PedModel1[joaat("ig_ballasog")] = "Ballas Chilli D"
PedModel1[joaat("ig_bankman")] = "Bankman"
PedModel1[joaat("ig_barry")] = "Barry"
PedModel1[joaat("ig_benny")] = "Benny"
PedModel1[joaat("ig_bestmen")] = "Bestmen"
PedModel1[joaat("ig_beverly")] = "Beverly"
PedModel1[joaat("ig_brad")] = "Brad"
PedModel1[joaat("ig_bride")] = "ig_bride"
PedModel1[joaat("ig_brucie2")] = "Brucie 2"
PedModel1[joaat("ig_car3guy1")] = "ig_car3guy1"
PedModel1[joaat("ig_car3guy2")] = "ig_car3guy2"
PedModel1[joaat("ig_casey")] = "Casey"
PedModel1[joaat("ig_celeb_01")] = "ig_celeb_01"
PedModel1[joaat("ig_chef")] = "ig_chef"
PedModel1[joaat("ig_chef2")] = "ig_chef2"
PedModel1[joaat("ig_chengsr")] = "Cheng Sr"
PedModel1[joaat("ig_chrisformage")] = "Cris Formage"
PedModel1[joaat("ig_clay")] = "Clay Simons"
PedModel1[joaat("ig_claypain")] = "Claypain"
PedModel1[joaat("ig_cletus")] = "Cletus"
PedModel1[joaat("ig_dale")] = "Dale"
PedModel1[joaat("ig_davenorton")] = "Dave Norton"
PedModel1[joaat("ig_denise")] = "Denise"
PedModel1[joaat("ig_devin")] = "Devin"
PedModel1[joaat("ig_dix")] = "dix"
PedModel1[joaat("ig_djblamadon")] = "djblamadon"
PedModel1[joaat("ig_djblamrupert")] = "Rupert Murray"
PedModel1[joaat("ig_djblamryanh")] = "djblamryanh"
PedModel1[joaat("ig_djblamryans")] = "djblamryans"
PedModel1[joaat("ig_djdixmanager")] = "djdixmanager"
PedModel1[joaat("ig_djgeneric_01")] = "djgeneric_01"
PedModel1[joaat("ig_djsolfotios")] = "djsolfotios"
PedModel1[joaat("ig_djsoljakob")] = "Jakob Grunert"
PedModel1[joaat("ig_djsolmanager")] = "djsolmanager"
PedModel1[joaat("ig_djsolmike")] = "djsolmike"
PedModel1[joaat("ig_djsolrobt")] = "djsolrobt"
PedModel1[joaat("ig_djtalaurelia")] = "djtalaurelia"
PedModel1[joaat("ig_djtalignazio")] = "djtalignazio"
PedModel1[joaat("ig_dom")] = "Dom"
PedModel1[joaat("ig_dreyfuss")] = "dreyfuss"
PedModel1[joaat("ig_drfriedlander")] = "drfriedlander"
PedModel1[joaat("ig_englishdave")] = "englishdave"
PedModel1[joaat("ig_englishdave_02")] = "englishdave_02"
PedModel1[joaat("ig_fabien")] = "fabien"
PedModel1[joaat("ig_fbisuit_01")] = "fbisuit_01"
PedModel1[joaat("ig_floyd")] = "floyd"
PedModel1[joaat("ig_g")] = "Gerald"
PedModel1[joaat("ig_georginacheng")] = "georginacheng"
PedModel1[joaat("ig_groom")] = "groom"
PedModel1[joaat("ig_gustavo")] = "gustavo"
PedModel1[joaat("ig_hao")] = "hao"
PedModel1[joaat("ig_helmsmanpavel")] = "helmsmanpavel"
PedModel1[joaat("ig_huang")] = "huang"
PedModel1[joaat("ig_hunter")] = "hunter"
PedModel1[joaat("ig_isldj_00")] = "isldj_00"
PedModel1[joaat("ig_isldj_01")] = "isldj_01"
PedModel1[joaat("ig_isldj_02")] = "isldj_02"
PedModel1[joaat("ig_isldj_03")] = "isldj_03"
PedModel1[joaat("ig_isldj_04")] = "Moodyman"
PedModel1[joaat("ig_isldj_04_d_01")] = "isldj_04_d_01"
PedModel1[joaat("ig_isldj_04_d_02")] = "isldj_04_d_02"
PedModel1[joaat("ig_isldj_04_e_01")] = "isldj_04_e_01"
PedModel1[joaat("ig_jackie")] = "jackie"
PedModel1[joaat("ig_janet")] = "janet"
PedModel1[joaat("ig_jay_norris")] = "jay_norris"
PedModel1[joaat("ig_jewelass")] = "jewelass"
PedModel1[joaat("ig_jimmyboston")] = "jimmyboston"
PedModel1[joaat("ig_jimmyboston_02")] = "jimmyboston_02"
PedModel1[joaat("ig_jimmydisanto")] = "jimmydisanto"
PedModel1[joaat("ig_jimmydisanto2")] = "Jimmy 2"
PedModel1[joaat("ig_jio")] = "jio"
PedModel1[joaat("ig_joeminuteman")] = "joeminuteman"
PedModel1[joaat("ig_johnnyklebitz")] = "johnnyklebitz"
PedModel1[joaat("ig_josef")] = "josef"
PedModel1[joaat("ig_josh")] = "josh"
PedModel1[joaat("ig_juanstrickler")] = "juanstrickler"
PedModel1[joaat("ig_karen_daniels")] = "karen_daniels"
PedModel1[joaat("ig_kaylee")] = "kaylee"
PedModel1[joaat("ig_kerrymcintosh")] = "kerrymcintosh"
PedModel1[joaat("ig_kerrymcintosh_02")] = "kerrymcintosh_02"
PedModel1[joaat("ig_lacey_jones_02")] = "lacey_jones_02"
PedModel1[joaat("ig_lamardavis")] = "lamardavis"
PedModel1[joaat("ig_lazlow")] = "lazlow"
PedModel1[joaat("ig_lazlow_2")] = "Lazlow 2"
PedModel1[joaat("ig_lestercrest")] = "lestercrest"
PedModel1[joaat("ig_lestercrest_2")] = "lestercrest_2"
PedModel1[joaat("ig_lestercrest_3")] = "lestercrest_3"
PedModel1[joaat("ig_lifeinvad_01")] = "lifeinvad_01"
PedModel1[joaat("ig_lifeinvad_02")] = "lifeinvad_02"
PedModel1[joaat("ig_magenta")] = "magenta"
PedModel1[joaat("ig_malc")] = "malc"
PedModel1[joaat("ig_manuel")] = "manuel"
PedModel1[joaat("ig_marnie")] = "marnie"
PedModel1[joaat("ig_maryann")] = "Mary Ann"
PedModel1[joaat("ig_maude")] = "Maude"
PedModel1[joaat("ig_michelle")] = "Michelle"
PedModel1[joaat("ig_miguelmadrazo")] = "Miguel Madrazo"
PedModel1[joaat("ig_milton")] = "Milton"
PedModel1[joaat("ig_mjo")] = "DJ Pooh"
PedModel1[joaat("ig_molly")] = "molly"
PedModel1[joaat("ig_money")] = "Avi Schwartzman 1"
PedModel1[joaat("ig_mp_agent14")] = "mp_agent14"
PedModel1[joaat("ig_mrk")] = "mrk"
PedModel1[joaat("ig_mrs_thornhill")] = "mrs_thornhill"
PedModel1[joaat("ig_mrsphillips")] = "Mrs Phillips"
PedModel1[joaat("ig_natalia")] = "natalia"
PedModel1[joaat("ig_nervousron")] = "nervousron"
PedModel1[joaat("ig_nigel")] = "nigel"
PedModel1[joaat("ig_old_man1a")] = "old_man1a"
PedModel1[joaat("ig_old_man2")] = "old_man2"
PedModel1[joaat("ig_oldrichguy")] = "oldrichguy"
PedModel1[joaat("ig_omega")] = "omega"
PedModel1[joaat("ig_oneil")] = "oneil"
PedModel1[joaat("ig_orleans")] = "orleans"
PedModel1[joaat("ig_ortega")] = "ortega"
PedModel1[joaat("ig_paige")] = "paige"
PedModel1[joaat("ig_paper")] = "paper"
PedModel1[joaat("ig_patricia")] = "patricia"
PedModel1[joaat("ig_patricia_02")] = "patricia_02"
PedModel1[joaat("ig_pilot")] = "pilot"
PedModel1[joaat("ig_popov")] = "popov"
PedModel1[joaat("ig_priest")] = "priest"
PedModel1[joaat("ig_sabsbprotectionslsec_02")] = "sabsbprotectionslsec_02"
PedModel1[joaat("ig_ramp_gang")] = "ramp_gang"
PedModel1[joaat("ig_ramp_hic")] = "ramp_hic"
PedModel1[joaat("ig_ramp_hipster")] = "ramp_hipster"
PedModel1[joaat("ig_ramp_mex")] = "ramp_mex"
PedModel1[joaat("ig_rashcosvki")] = "Rashcosvki"
PedModel1[joaat("ig_roccopelosi")] = "roccopelosi"
PedModel1[joaat("ig_russiandrunk")] = "russiandrunk"
PedModel1[joaat("ig_sacha")] = "sacha"
PedModel1[joaat("ig_screen_writer")] = "screen_writer"
PedModel1[joaat("ig_siemonyetarian")] = "siemonyetarian"
PedModel1[joaat("ig_sol")] = "sol"
PedModel1[joaat("ig_solomon")] = "Solomon"
PedModel1[joaat("ig_sss")] = "Scott Storch"
PedModel1[joaat("ig_stevehains")] = "Steven Haines"
PedModel1[joaat("ig_stretch")] = "Harold 'Stretch' Joseph"
PedModel1[joaat("ig_talcc")] = "talcc"
PedModel1[joaat("ig_talina")] = "talina"
PedModel1[joaat("ig_talmm")] = "talmm"
PedModel1[joaat("ig_tanisha")] = "tanisha"
PedModel1[joaat("ig_taocheng")] = "taocheng"
PedModel1[joaat("ig_taocheng2")] = "taocheng2"
PedModel1[joaat("ig_taostranslator")] = "taostranslator"
PedModel1[joaat("ig_taostranslator2")] = "taostranslator2"
PedModel1[joaat("ig_tenniscoach")] = "tenniscoach"
PedModel1[joaat("ig_terry")] = "Terry Thorpe"
PedModel1[joaat("ig_thornton")] = "Thornton Duggan"
PedModel1[joaat("ig_tomcasino")] = "tomcasino"
PedModel1[joaat("ig_tomepsilon")] = "tomepsilon"
PedModel1[joaat("ig_tonya")] = "tonya"
PedModel1[joaat("ig_tonyprince")] = "tonyprince"
PedModel1[joaat("ig_tracydisanto")] = "tracydisanto"
PedModel1[joaat("ig_trafficwarden")] = "trafficwarden"
PedModel1[joaat("ig_tylerdix")] = "tylerdix"
PedModel1[joaat("ig_tylerdix_02")] = "tylerdix_02"
PedModel1[joaat("ig_vagspeak")] = "Vagspeak"
PedModel1[joaat("ig_vincent")] = "Vincent"
PedModel1[joaat("ig_vincent_2")] = "Vincent 2"
PedModel1[joaat("ig_wade")] = "Wade"
PedModel1[joaat("ig_wendy")] = "Wendy"
PedModel1[joaat("ig_zimbor")] = "Zimbor"
PedModel1[joaat("mp_f_bennymech_01")] = "mp_f_bennymech_01"
PedModel1[joaat("mp_f_boatstaff_01")] = "mp_f_boatstaff_01"
PedModel1[joaat("mp_f_cardesign_01")] = "mp_f_cardesign_01"
PedModel1[joaat("mp_f_chbar_01")] = "mp_f_chbar_01"
PedModel1[joaat("mp_f_cocaine_01")] = "mp_f_cocaine_01"
PedModel1[joaat("mp_f_counterfeit_01")] = "mp_f_counterfeit_01"
PedModel1[joaat("mp_f_deadhooker")] = "mp_f_deadhooker"
PedModel1[joaat("mp_f_execpa_01")] = "mp_f_execpa_01"
PedModel1[joaat("mp_f_execpa_02")] = "mp_f_execpa_02"
PedModel1[joaat("mp_f_forgery_01")] = "mp_f_forgery_01"
PedModel1[joaat("mp_f_helistaff_01")] = "mp_f_helistaff_01"
PedModel1[joaat("mp_f_meth_01")] = "mp_f_meth_01"
PedModel1[joaat("mp_f_misty_01")] = "mp_f_misty_01"
PedModel1[joaat("mp_f_stripperlite")] = "Nikki"
PedModel1[joaat("mp_f_weed_01")] = "mp_f_weed_01"
PedModel1[joaat("mp_g_m_sabsbprotectionss_01")] = "mp_g_m_sabsbprotectionss_01"
PedModel1[joaat("mp_headtargets")] = "mp_headtargets"
PedModel1[joaat("mp_m_avongoon")] = "mp_m_avongoon"
PedModel1[joaat("mp_m_boatstaff_01")] = "mp_m_boatstaff_01"
PedModel1[joaat("mp_m_bogdangoon")] = "mp_m_bogdangoon"
PedModel1[joaat("mp_m_claude_01")] = "mp_m_claude_01"
PedModel1[joaat("mp_m_cocaine_01")] = "mp_m_cocaine_01"
PedModel1[joaat("mp_m_counterfeit_01")] = "mp_m_counterfeit_01"
PedModel1[joaat("mp_m_exarmy_01")] = "mp_m_exarmy_01"
PedModel1[joaat("mp_m_execpa_01")] = "mp_m_execpa_01"
PedModel1[joaat("mp_m_famdd_01")] = "mp_m_famdd_01"
PedModel1[joaat("mp_m_fibsec_01")] = "mp_m_fibsec_01"
PedModel1[joaat("mp_m_forgery_01")] = "mp_m_forgery_01"
PedModel1[joaat("mp_m_g_vagfun_01")] = "mp_m_g_vagfun_01"
PedModel1[joaat("mp_m_marston_01")] = "mp_m_marston_01"
PedModel1[joaat("mp_m_meth_01")] = "mp_m_meth_01"
PedModel1[joaat("mp_m_niko_01")] = "mp_m_niko_01"
PedModel1[joaat("mp_m_securoguard_01")] = "mp_m_securoguard_01"
PedModel1[joaat("mp_m_shopkeep_01")] = "mp_m_shopkeep_01"
PedModel1[joaat("mp_m_waremech_01")] = "mp_m_waremech_01"
PedModel1[joaat("mp_m_weapexp_01")] = "mp_m_weapexp_01"
PedModel1[joaat("mp_m_weapwork_01")] = "mp_m_weapwork_01"
PedModel1[joaat("mp_m_weed_01")] = "mp_m_weed_01"
PedModel1[joaat("mp_s_m_armoured_01")] = "mp_s_m_armoured_01"
PedModel1[joaat("s_f_m_fembarber")] = "s_f_m_fembarber"
PedModel1[joaat("s_f_m_maid_01")] = "s_f_m_maid_01"
PedModel1[joaat("s_f_m_shop_high")] = "s_f_m_shop_high"
PedModel1[joaat("s_f_m_sweatshop_01")] = "s_f_m_sweatshop_01"
PedModel1[joaat("s_f_y_airhostess_01")] = "s_f_y_airhostess_01"
PedModel1[joaat("s_f_y_bartender_01")] = "s_f_y_bartender_01"
PedModel1[joaat("s_f_y_baywatch_01")] = "s_f_y_baywatch_01"
PedModel1[joaat("s_f_y_beachbarstaff_01")] = "s_f_y_beachbarstaff_01"
PedModel1[joaat("s_f_y_casino_01")] = "s_f_y_casino_01"
PedModel1[joaat("s_f_y_clubbar_01")] = "s_f_y_clubbar_01"
PedModel1[joaat("s_f_y_clubbar_02")] = "s_f_y_clubbar_02"
PedModel1[joaat("s_f_y_cop_01")] = "s_f_y_cop_01"
PedModel1[joaat("s_f_y_factory_01")] = "s_f_y_factory_01"
PedModel1[joaat("s_f_y_hooker_01")] = "s_f_y_hooker_01"
PedModel1[joaat("s_f_y_hooker_02")] = "s_f_y_hooker_02"
PedModel1[joaat("s_f_y_hooker_03")] = "s_f_y_hooker_03"
PedModel1[joaat("s_f_y_migrant_01")] = "s_f_y_migrant_01"
PedModel1[joaat("s_f_y_movprem_01")] = "s_f_y_movprem_01"
PedModel1[joaat("s_f_y_ranger_01")] = "s_f_y_ranger_01"
PedModel1[joaat("s_f_y_scrubs_01")] = "s_f_y_scrubs_01"
PedModel1[joaat("s_f_y_sheriff_01")] = "s_f_y_sheriff_01"
PedModel1[joaat("s_f_y_shop_low")] = "s_f_y_shop_low"
PedModel1[joaat("s_f_y_shop_mid")] = "s_f_y_shop_mid"
PedModel1[joaat("s_f_y_stripper_01")] = "s_f_y_stripper_01"
PedModel1[joaat("s_f_y_stripper_02")] = "s_f_y_stripper_02"
PedModel1[joaat("s_f_y_stripperlite")] = "s_f_y_stripperlite"
PedModel1[joaat("s_f_y_sweatshop_01")] = "s_f_y_sweatshop_01"
PedModel1[joaat("s_m_m_ammucountry")] = "s_m_m_ammucountry"
PedModel1[joaat("s_m_m_armoured_01")] = "s_m_m_armoured_01"
PedModel1[joaat("s_m_m_armoured_02")] = "s_m_m_armoured_02"
PedModel1[joaat("s_m_m_autoshop_01")] = "s_m_m_autoshop_01"
PedModel1[joaat("s_m_m_autoshop_02")] = "s_m_m_autoshop_02"
PedModel1[joaat("s_m_m_bouncer_01")] = "s_m_m_bouncer_01"
PedModel1[joaat("s_m_m_bouncer_02")] = "s_m_m_bouncer_02"
PedModel1[joaat("s_m_m_ccrew_01")] = "s_m_m_ccrew_01"
PedModel1[joaat("s_m_m_chemsec_01")] = "s_m_m_chemsec_01"
PedModel1[joaat("s_m_m_ciasec_01")] = "s_m_m_ciasec_01"
PedModel1[joaat("s_m_m_cntrybar_01")] = "s_m_m_cntrybar_01"
PedModel1[joaat("s_m_m_dockwork_01")] = "s_m_m_dockwork_01"
PedModel1[joaat("s_m_m_doctor_01")] = "s_m_m_doctor_01"
PedModel1[joaat("s_m_m_drugsabsbprotectionscess_01")] = "s_m_m_drugsabsbprotectionscess_01"
PedModel1[joaat("s_m_m_fiboffice_01")] = "s_m_m_fiboffice_01"
PedModel1[joaat("s_m_m_fiboffice_02")] = "s_m_m_fiboffice_02"
PedModel1[joaat("s_m_m_fibsec_01")] = "s_m_m_fibsec_01"
PedModel1[joaat("s_m_m_fieldworker_01")] = "s_m_m_fieldworker_01"
PedModel1[joaat("s_m_m_gaffer_01")] = "s_m_m_gaffer_01"
PedModel1[joaat("s_m_m_gardener_01")] = "s_m_m_gardener_01"
PedModel1[joaat("s_m_m_gentransport")] = "s_m_m_gentransport"
PedModel1[joaat("s_m_m_hairdress_01")] = "s_m_m_hairdress_01"
PedModel1[joaat("s_m_m_highsec_01")] = "s_m_m_highsec_01"
PedModel1[joaat("s_m_m_highsec_02")] = "s_m_m_highsec_02"
PedModel1[joaat("s_m_m_highsec_03")] = "s_m_m_highsec_03"
PedModel1[joaat("s_m_m_highsec_04")] = "s_m_m_highsec_04"
PedModel1[joaat("s_m_m_janitor")] = "s_m_m_janitor"
PedModel1[joaat("s_m_m_lathandy_01")] = "s_m_m_lathandy_01"
PedModel1[joaat("s_m_m_lifeinvad_01")] = "s_m_m_lifeinvad_01"
PedModel1[joaat("s_m_m_linecook")] = "s_m_m_linecook"
PedModel1[joaat("s_m_m_lsmetro_01")] = "s_m_m_lsmetro_01"
PedModel1[joaat("s_m_m_mariachi_01")] = "s_m_m_mariachi_01"
PedModel1[joaat("s_m_m_marine_01")] = "s_m_m_marine_01"
PedModel1[joaat("s_m_m_marine_02")] = "s_m_m_marine_02"
PedModel1[joaat("s_m_m_migrant_01")] = "s_m_m_migrant_01"
PedModel1[joaat("s_m_m_movalien_01")] = "s_m_m_movalien_01"
PedModel1[joaat("s_m_m_movprem_01")] = "s_m_m_movprem_01"
PedModel1[joaat("s_m_m_movspace_01")] = "s_m_m_movspace_01"
PedModel1[joaat("s_m_m_paramedic_01")] = "s_m_m_paramedic_01"
PedModel1[joaat("s_m_m_pilot_01")] = "s_m_m_pilot_01"
PedModel1[joaat("s_m_m_pilot_02")] = "s_m_m_pilot_02"
PedModel1[joaat("s_m_m_postal_01")] = "s_m_m_postal_01"
PedModel1[joaat("s_m_m_postal_02")] = "s_m_m_postal_02"
PedModel1[joaat("s_m_m_prisguard_01")] = "s_m_m_prisguard_01"
PedModel1[joaat("s_m_m_scientist_01")] = "s_m_m_scientist_01"
PedModel1[joaat("s_m_m_security_01")] = "s_m_m_security_01"
PedModel1[joaat("s_m_m_snowcop_01")] = "s_m_m_snowcop_01"
PedModel1[joaat("s_m_m_strperf_01")] = "s_m_m_strperf_01"
PedModel1[joaat("s_m_m_strpreach_01")] = "s_m_m_strpreach_01"
PedModel1[joaat("s_m_m_strvend_01")] = "s_m_m_strvend_01"
PedModel1[joaat("s_m_m_trucker_01")] = "s_m_m_trucker_01"
PedModel1[joaat("s_m_m_ups_01")] = "s_m_m_ups_01"
PedModel1[joaat("s_m_m_ups_02")] = "s_m_m_ups_02"
PedModel1[joaat("s_m_o_busker_01")] = "s_m_o_busker_01"
PedModel1[joaat("s_m_y_airworker")] = "s_m_y_airworker"
PedModel1[joaat("s_m_y_ammucity_01")] = "s_m_y_ammucity_01"
PedModel1[joaat("s_m_y_armymech_01")] = "s_m_y_armymech_01"
PedModel1[joaat("s_m_y_autopsy_01")] = "s_m_y_autopsy_01"
PedModel1[joaat("s_m_y_barman_01")] = "s_m_y_barman_01"
PedModel1[joaat("s_m_y_baywatch_01")] = "s_m_y_baywatch_01"
PedModel1[joaat("s_m_y_blackops_01")] = "s_m_y_blackops_01"
PedModel1[joaat("s_m_y_blackops_02")] = "s_m_y_blackops_02"
PedModel1[joaat("s_m_y_blackops_03")] = "s_m_y_blackops_03"
PedModel1[joaat("s_m_y_busboy_01")] = "s_m_y_busboy_01"
PedModel1[joaat("s_m_y_casino_01")] = "s_m_y_casino_01"
PedModel1[joaat("s_m_y_chef_01")] = "s_m_y_chef_01"
PedModel1[joaat("s_m_y_clown_01")] = "s_m_y_clown_01"
PedModel1[joaat("s_m_y_clubbar_01")] = "s_m_y_clubbar_01"
PedModel1[joaat("s_m_y_construct_01")] = "s_m_y_construct_01"
PedModel1[joaat("s_m_y_construct_02")] = "s_m_y_construct_02"
PedModel1[joaat("s_m_y_cop_01")] = "s_m_y_cop_01"
PedModel1[joaat("s_m_y_dealer_01")] = "s_m_y_dealer_01"
PedModel1[joaat("s_m_y_devinsec_01")] = "s_m_y_devinsec_01"
PedModel1[joaat("s_m_y_dockwork_01")] = "s_m_y_dockwork_01"
PedModel1[joaat("s_m_y_doorman_01")] = "s_m_y_doorman_01"
PedModel1[joaat("s_m_y_dwservice_01")] = "s_m_y_dwservice_01"
PedModel1[joaat("s_m_y_dwservice_02")] = "s_m_y_dwservice_02"
PedModel1[joaat("s_m_y_factory_01")] = "s_m_y_factory_01"
PedModel1[joaat("s_m_y_fireman_01")] = "s_m_y_fireman_01"
PedModel1[joaat("s_m_y_garbage")] = "s_m_y_garbage"
PedModel1[joaat("s_m_y_grip_01")] = "s_m_y_grip_01"
PedModel1[joaat("s_m_y_hwaycop_01")] = "s_m_y_hwaycop_01"
PedModel1[joaat("s_m_y_marine_01")] = "s_m_y_marine_01"
PedModel1[joaat("s_m_y_marine_02")] = "s_m_y_marine_02"
PedModel1[joaat("s_m_y_marine_03")] = "s_m_y_marine_03"
PedModel1[joaat("s_m_y_mime")] = "s_m_y_mime"
PedModel1[joaat("s_m_y_pestcont_01")] = "s_m_y_pestcont_01"
PedModel1[joaat("s_m_y_pilot_01")] = "s_m_y_pilot_01"
PedModel1[joaat("s_m_y_prismuscl_01")] = "s_m_y_prismuscl_01"
PedModel1[joaat("s_m_y_prisoner_01")] = "s_m_y_prisoner_01"
PedModel1[joaat("s_m_y_ranger_01")] = "s_m_y_ranger_01"
PedModel1[joaat("s_m_y_robber_01")] = "s_m_y_robber_01"
PedModel1[joaat("s_m_y_sheriff_01")] = "s_m_y_sheriff_01"
PedModel1[joaat("s_m_y_shop_mask")] = "s_m_y_shop_mask"
PedModel1[joaat("s_m_y_strvend_01")] = "s_m_y_strvend_01"
PedModel1[joaat("s_m_y_swat_01")] = "s_m_y_swat_01"
PedModel1[joaat("s_m_y_uscg_01")] = "s_m_y_uscg_01"
PedModel1[joaat("s_m_y_valet_01")] = "s_m_y_valet_01"
PedModel1[joaat("s_m_y_waiter_01")] = "s_m_y_waiter_01"
PedModel1[joaat("s_m_y_waretech_01")] = "s_m_y_waretech_01"
PedModel1[joaat("s_m_y_westsec_01")] = "s_m_y_westsec_01"
PedModel1[joaat("s_m_y_westsec_02")] = "s_m_y_westsec_02"
PedModel1[joaat("s_m_y_winclean_01")] = "s_m_y_winclean_01"
PedModel1[joaat("s_m_y_xmech_01")] = "s_m_y_xmech_01"
PedModel1[joaat("s_m_y_xmech_02")] = "s_m_y_xmech_02"
PedModel1[joaat("s_m_y_xmech_02_mp")] = "s_m_y_xmech_02_mp"
PedModel1[joaat("u_f_m_casinocash_01")] = "u_f_m_casinocash_01"
PedModel1[joaat("u_f_m_casinoshop_01")] = "u_f_m_casinoshop_01"
PedModel1[joaat("u_f_m_corpse_01")] = "u_f_m_corpse_01"
PedModel1[joaat("u_f_m_debbie_01")] = "u_f_m_debbie_01"
PedModel1[joaat("u_f_m_drowned_01")] = "u_f_m_drowned_01"
PedModel1[joaat("u_f_m_miranda")] = "u_f_m_miranda"
PedModel1[joaat("u_f_m_miranda_02")] = "u_f_m_miranda_02"
PedModel1[joaat("u_f_m_sabsbprotectionsmourn_01")] = "u_f_m_sabsbprotectionsmourn_01"
PedModel1[joaat("u_f_o_carol")] = "u_f_o_carol"
PedModel1[joaat("u_f_o_eileen")] = "u_f_o_eileen"
PedModel1[joaat("u_f_o_moviestar")] = "u_f_o_moviestar"
PedModel1[joaat("u_f_o_sabsbprotectionslhost_01")] = "u_f_o_sabsbprotectionslhost_01"
PedModel1[joaat("u_f_y_beth")] = "u_f_y_beth"
PedModel1[joaat("u_f_y_bikerchic")] = "u_f_y_bikerchic"
PedModel1[joaat("u_f_y_comjane")] = "u_f_y_comjane"
PedModel1[joaat("u_f_y_corpse_01")] = "u_f_y_corpse_01"
PedModel1[joaat("u_f_y_corpse_02")] = "u_f_y_corpse_02"
PedModel1[joaat("u_f_y_danceburl_01")] = "u_f_y_danceburl_01"
PedModel1[joaat("u_f_y_dancelthr_01")] = "u_f_y_dancelthr_01"
PedModel1[joaat("u_f_y_dancerave_01")] = "u_f_y_dancerave_01"
PedModel1[joaat("u_f_y_hotposh_01")] = "u_f_y_hotposh_01"
PedModel1[joaat("u_f_y_jewelass_01")] = "u_f_y_jewelass_01"
PedModel1[joaat("u_f_y_lauren")] = "u_f_y_lauren"
PedModel1[joaat("u_f_y_mistress")] = "u_f_y_mistress"
PedModel1[joaat("u_f_y_poppymich")] = "u_f_y_poppymich"
PedModel1[joaat("u_f_y_poppymich_02")] = "u_f_y_poppymich_02"
PedModel1[joaat("u_f_y_princess")] = "u_f_y_princess"
PedModel1[joaat("u_f_y_spyactress")] = "u_f_y_spyactress"
PedModel1[joaat("u_f_y_taylor")] = "u_f_y_taylor"
PedModel1[joaat("u_m_m_aldinapoli")] = "u_m_m_aldinapoli"
PedModel1[joaat("u_m_m_bankman")] = "u_m_m_bankman"
PedModel1[joaat("u_m_m_bikehire_01")] = "u_m_m_bikehire_01"
PedModel1[joaat("u_m_m_blane")] = "u_m_m_blane"
PedModel1[joaat("u_m_m_curtis")] = "u_m_m_curtis"
PedModel1[joaat("u_m_m_doa_01")] = "u_m_m_doa_01"
PedModel1[joaat("u_m_m_edtoh")] = "u_m_m_edtoh"
PedModel1[joaat("u_m_m_fibarchitect")] = "u_m_m_fibarchitect"
PedModel1[joaat("u_m_m_filmdirector")] = "u_m_m_filmdirector"
PedModel1[joaat("u_m_m_glenstank_01")] = "u_m_m_glenstank_01"
PedModel1[joaat("u_m_m_griff_01")] = "u_m_m_griff_01"
PedModel1[joaat("u_m_m_jesus_01")] = "u_m_m_jesus_01"
PedModel1[joaat("u_m_m_jewelsec_01")] = "u_m_m_jewelsec_01"
PedModel1[joaat("u_m_m_jewelthief")] = "u_m_m_jewelthief"
PedModel1[joaat("u_m_m_markfost")] = "u_m_m_markfost"
PedModel1[joaat("u_m_m_sabsbprotectionslsec_01")] = "u_m_m_sabsbprotectionslsec_01"
PedModel1[joaat("u_m_m_sabsbprotectionsmourn_01")] = "u_m_m_sabsbprotectionsmourn_01"
PedModel1[joaat("u_m_m_rivalpap")] = "u_m_m_rivalpap"
PedModel1[joaat("u_m_m_spyactor")] = "u_m_m_spyactor"
PedModel1[joaat("u_m_m_streetart_01")] = "u_m_m_streetart_01"
PedModel1[joaat("u_m_m_vince")] = "u_m_m_vince"
PedModel1[joaat("u_m_m_willyfist")] = "u_m_m_willyfist"
PedModel1[joaat("u_m_o_dean")] = "u_m_o_dean"
PedModel1[joaat("u_m_o_filmnoir")] = "u_m_o_filmnoir"
PedModel1[joaat("u_m_o_finguru_01")] = "u_m_o_finguru_01"
PedModel1[joaat("u_m_o_taphillbilly")] = "u_m_o_taphillbilly"
PedModel1[joaat("u_m_o_tramp_01")] = "u_m_o_tramp_01"
PedModel1[joaat("u_m_y_abner")] = "u_m_y_abner"
PedModel1[joaat("u_m_y_antonb")] = "u_m_y_antonb"
PedModel1[joaat("u_m_y_babyd")] = "u_m_y_babyd"
PedModel1[joaat("u_m_y_baygor")] = "u_m_y_baygor"
PedModel1[joaat("u_m_y_burgerdrug_01")] = "u_m_y_burgerdrug_01"
PedModel1[joaat("u_m_y_caleb")] = "u_m_y_caleb"
PedModel1[joaat("u_m_y_cyclist_01")] = "u_m_y_cyclist_01"
PedModel1[joaat("u_m_y_dancerave_01")] = "u_m_y_dancerave_01"
PedModel1[joaat("u_m_y_fibmugger_01")] = "u_m_y_fibmugger_01"
PedModel1[joaat("u_m_y_gabriel")] = "u_m_y_gabriel"
PedModel1[joaat("u_m_y_guido_01")] = "u_m_y_guido_01"
PedModel1[joaat("u_m_y_gunvend_01")] = "u_m_y_gunvend_01"
PedModel1[joaat("u_m_y_hippie_01")] = "u_m_y_hippie_01"
PedModel1[joaat("u_m_y_imporage")] = "u_m_y_imporage"
PedModel1[joaat("u_m_y_juggernaut_01")] = "u_m_y_juggernaut_01"
PedModel1[joaat("u_m_y_justin")] = "u_m_y_justin"
PedModel1[joaat("u_m_y_mani")] = "u_m_y_mani"
PedModel1[joaat("u_m_y_militarybum")] = "u_m_y_militarybum"
PedModel1[joaat("u_m_y_paparazzi")] = "u_m_y_paparazzi"
PedModel1[joaat("u_m_y_party_01")] = "u_m_y_party_01"
PedModel1[joaat("u_m_y_pogo_01")] = "u_m_y_pogo_01"
PedModel1[joaat("u_m_y_prisoner_01")] = "u_m_y_prisoner_01"
PedModel1[joaat("u_m_y_sabsbprotectionsldriver_01")] = "u_m_y_sabsbprotectionsldriver_01"
PedModel1[joaat("u_m_y_rsranger_01")] = "Space Ranger"
PedModel1[joaat("u_m_y_sbike")] = "u_m_y_sbike"
PedModel1[joaat("u_m_y_smugmech_01")] = "u_m_y_smugmech_01"
PedModel1[joaat("u_m_y_staggrm_01")] = "u_m_y_staggrm_01"
PedModel1[joaat("u_m_y_tattoo_01")] = "u_m_y_tattoo_01"
PedModel1[joaat("u_m_y_ushi")] = "u_m_y_ushi"
PedModel1[joaat("u_m_y_zombie_01")] = "u_m_y_zombie_01"
local PedSelf = {}
PedSelf[joaat("mp_f_freemode_01")] = "Female"
PedSelf[joaat("mp_m_freemode_01")] = "Male"
local animal_hash = joaat("a_c_cat_01")
local ped_hash = joaat("player_one")
local bird_hash = joaat("a_c_seagull")
local sea_hash = joaat("a_c_dolphin")
local self_hash = joaat("mp_m_freemode_01")

CSYONS7s:add_array_item("Set Delay First Dude", {"1", "2", "3", "4", "5", "6", "7", "8"}, function() return xox_31 end, function(value) xox_31 = value if value == 1 then duFF = 0.01 elseif value == 2 then duFF = 0.05 elseif value == 3 then duFF = 0.08 elseif value == 4 then duFF = 0.1 elseif value == 5 then duFF = 0.15 elseif value == 6 then duFF = 0.2 elseif value == 7 then duFF = 0.25 else duFF = 0.3 end end)
CSYONS7s:add_array_item("Return Default Model", PedSelf, function() return self_hash end,
	function(value) self_hash = value globals.set_int(2671449 + 59, 1) globals.set_int(2671449 + 46, value) sleep(0.02) globals.set_int(2671449 + 59, 0) end)
	CSYONS7s: add_array_item("Change into Peds", PedModel1, function() return ped_hash end,
	function(value) ped_hash = value globals.set_int(2671449 + 59, 1) globals.set_int(2671449 + 46, value) sleep(0.02) globals.set_int(2671449 + 59, 0) end)
	CSYONS7s: add_array_item("Change into  Birds", PedModelBird, function() return bird_hash end,
	function(value) bird_hash = value globals.set_int(2671449 + 59, 1) globals.set_int(2671449 + 46, value) sleep(0.02) globals.set_int(2671449 + 59, 0) end)
CSYONS7s: add_array_item("Change into  Animals", PedModelAnimal, function() return animal_hash end,
	function(value) animal_hash = value globals.set_int(2671449 + 59, 1) globals.set_int(2671449 + 46, value) sleep(0.02) globals.set_int(2671449 + 59, 0) end)
CSYONS7s: add_array_item("Change into Sea Animals", PedModelSeaAnimal, function() return sea_hash end,
	function(value) sea_hash = value globals.set_int(2671449 + 59, 1) globals.set_int(2671449 + 46, value) sleep(0.02) globals.set_int(2671449 + 59, 0) end)
CSYONS7s:add_action("Become Bigfoot", function()
	globals.set_int(NORS1, 1) globals.set_int(NORS2, -1389097126) sleep(duFF) globals.set_int(NORS1, 0) end)
CSYONS7s:add_action("      ~~~[Change delay if not working then it should works]~~~", function() end)

CSYONS5sr=CSYON5:add_submenu("Speedometer")
local units_selection = 1
local units_text = {"kilometres per hour", "miles per hour", "metres per second"}
local units_text_short = {"km/h", "m/s", "mi/h"}
local units_text_numberplate = {"kmh", "mps", "mph"}
local units_value = {3.6, 1, 2.2369362921, 3.280839895}
local numberplate_enabled = false
local numberplate_key = {87, 65, 83, 68}-- W, A, S, D
local numberplate_ref = {}

local function round(value, dec)
	dec = dec or 0
	return tonumber(string.format("%." .. dec .. "f", value))
end
 
local function get_vehicle_speed(veh)
	if not veh then return 0 end
	local velocity = veh:get_velocity()
	return math.sqrt(velocity.x ^ 2 + velocity.y ^ 2 + velocity.z ^ 2)
end
 
CSYONS5sr:add_toggle("Speedometer Numberplates", function()
	return numberplate_enabled
end, function(value)
	numberplate_enabled = value
	if value then
		for i = 1, #numberplate_key do
			numberplate_ref[i] = menu.register_hotkey(numberplate_key[i], function()
				if not localplayer:is_in_vehicle() then return end
				local veh = localplayer:get_current_vehicle()
				if not veh then return end
				local speed = round(get_vehicle_speed(veh) * units_value[units_selection], 0)
				veh:set_number_plate_text((speed < 10 and "   " or speed < 100 and "  " or speed < 1000 and " " or "") .. speed .. " " .. units_text_numberplate[units_selection])
			end)
		end
	else
		for i = 1, #numberplate_ref do
			menu.remove_hotkey(numberplate_ref[i])
		end
	end
end)
 
CSYONS5sr:add_array_item("Speed unit", units_text, function()
	return units_selection
end, function(value)
	units_selection = value
end)

CSYONS5sr:add_bare_item("Speed", function()
	if not localplayer:is_in_vehicle() then return "Speed: not in vehicle" end
	local veh = localplayer:get_current_vehicle()
	if not veh then return "Speed: invalid vehicle" end
	local speed = round(get_vehicle_speed(veh) * units_value[units_selection], 1)
	return "Speed: " .. speed .. " " .. units_text_short[units_selection]
end, function() end, function() end, function() end)

CSYONS2:add_action("Reset Casino Chip Purchase", function() stats.set_int("MPPLY_CASINO_CHIPS_PUR_GD", 0) stats.set_int("MPPLY_CASINO_CHIPS_PURTIM", 0) end)

CSYONS8:add_action("Unlock Halloween Mask",function()globals.set_int(2788788,9)end)
CSYONS8:add_action("Unlock Halloween Shirt",function()globals.set_int(2788788,199)end)

CSYONS8:add_action("Unlock the Candy Cane", function()
    globals.set_int(262145, 339151)
end)

CSYONS8:add_action("Unlock the R* Crosswalk Tee", function()
    for i = 0, 2 do
        for j = 0, 63 do
            stats.set_bool_masked(MPX .. "DLCBIKEPSTAT_BOOL" .. i, true, j)
            sleep(0.1)
        end
    end
end)

CSYONS8o = CSYON8:add_submenu("🎮Collectibles Unlock All (Temporarily)")
	
CSYONS8o:add_action("Action Figures", function() globals.set_int(2764906 + 209 , 100) end)
CSYONS8o:add_action("Movie Props", function() globals.set_int(2764906 + 494 , 10) end)
CSYONS8o:add_action("Playing Cards", function() globals.set_int(2764906 + 210 , 54) end)
CSYONS8o:add_action("Signal Jammers", function() globals.set_int(2764906 + 211 , 50) end)
CSYONS8o:add_action("LD Organics", function() globals.set_int(2764906 + 593 , 100) end)
CSYONS8o:add_action("Buried Stashs", function() globals.set_int(2764906 + 553 , 10) end)
CSYONS8o:add_action("Jack o Lantern", function() globals.set_int(2764906 + 591 , 10) end)
CSYONS8o:add_action("Hidden Caches", function() globals.set_int(2764906 + 504 , 10) end)
CSYONS8o:add_action("Treasure Chests", function() globals.set_int(2764906 + 506 , 30) end)
	
CSYONS8o = CSYON8:add_submenu("🎮Collectibles Unlock All (Permanently)")
	
CSYONS8o:add_action("Action Figures", function() globals.set_int(2764906 + 209 , 99) end)
CSYONS8o:add_action("Movie Props", function() globals.set_int(2764906 + 494 , 9) end)
CSYONS8o:add_action("Playing Cards", function() globals.set_int(2764906 + 210 , 53) end)
CSYONS8o:add_action("Signal Jammers", function() globals.set_int(2764906 + 211 , 49) end)
CSYONS8o:add_action("LD Organics", function() globals.set_int(2764906 + 593 , 99) end)
CSYONS8o:add_action("Buried Stashs", function() globals.set_int(2764906 + 553 , 9) end)
CSYONS8o:add_action("Jack o Lantern", function() globals.set_int(2764906 + 591 , 9) end)
CSYONS8o:add_action("Hidden Caches", function() globals.set_int(2764906 + 504 , 9) end)
CSYONS8o:add_action("Treasure Chests", function() globals.set_int(2764906 + 506 , 29) end)

CSYONS5:add_toggle("Vehicle God Mode", function()
	return vehiclegodmode
end, function()
	if localplayer ~= nil and localplayer:is_in_vehicle() then
            localplayer:get_current_vehicle():set_godmode(true)
	end
end)

CSYONS5:add_action("Repair Vehicle", function() menu.repair_online_vehicle() end)
CSYONS5:add_action("Remove Insurance Claims", function() menu.remove_insurance_claims() end)

local CSYONS2l = CSYONS2:add_submenu("Freeze All Npcs Menu")

CSYONS2l:add_action("Freeze All NPC Enable", function()
    for p in replayinterface.get_peds() do
        if p ~= nil and p ~= localplayer then
            p:set_freeze_momentum(true)
        end
    end
end)
CSYONS2l:add_action("Freeze All NPC Disable", function()
    for p in replayinterface.get_peds() do
        if p ~= nil and p ~= localplayer then
            p:set_freeze_momentum(false)
        end
    end
end)

CSYONS2l:add_action("Kill All Npcs", function() menu.kill_all_npcs() end)
CSYONS2l:add_action("Kill Mission Npcs", function() menu.kill_all_mission_peds() end) 

CSYONS4:add_action("Fill Ammo ", function() menu.max_all_ammo() end)

--menu.register_hotkey(111, RefillingInvsAmourLel) -------------------------------For Refil your Inventory Snacks And Armour bcs Csyon know what is the best 🤨
local function RefillingInvsAmourLel()
      stats.set_int(MPX .. "NO_BOUGHT_YUM_SNACKS", 1000)
      stats.set_int(MPX .. "NO_BOUGHT_HEALTH_SNACKS", 1000)
      stats.set_int(MPX .. "NO_BOUGHT_EPIC_SNACKS", 1000)
      stats.set_int(MPX .. "NUMBER_OF_CHAMP_BOUGHT", 1000)
      stats.set_int(MPX .. "NUMBER_OF_ORANGE_BOUGHT", 1000)
      stats.set_int(MPX .. "NUMBER_OF_BOURGE_BOUGHT", 1000)
      stats.set_int(MPX .. "CIGARETTES_BOUGHT", 1000)
      stats.set_int(MPX .. "MP_CHAR_ARMOUR_1_COUNT", 1000)
      stats.set_int(MPX .. "MP_CHAR_ARMOUR_2_COUNT", 1000)
      stats.set_int(MPX .. "MP_CHAR_ARMOUR_3_COUNT", 1000)
      stats.set_int(MPX .. "MP_CHAR_ARMOUR_4_COUNT", 1000)
      stats.set_int(MPX .. "MP_CHAR_ARMOUR_5_COUNT", 1000)
      stats.set_int(MPX .. "BREATHING_APPAR_BOUGHT", 1000)
      end

CSYONS7:add_action("Refill Inventory/Armour", function()
	stats.set_int(MPX .. "NO_BOUGHT_YUM_SNACKS", 30)
      stats.set_int(MPX .. "NO_BOUGHT_HEALTH_SNACKS", 15)
      stats.set_int(MPX .. "NO_BOUGHT_EPIC_SNACKS", 5)
      stats.set_int(MPX .. "NUMBER_OF_CHAMP_BOUGHT", 5)
      stats.set_int(MPX .. "NUMBER_OF_ORANGE_BOUGHT", 11)
      stats.set_int(MPX .. "NUMBER_OF_BOURGE_BOUGHT", 10)
      stats.set_int(MPX .. "CIGARETTES_BOUGHT", 20)
      stats.set_int(MPX .. "MP_CHAR_ARMOUR_1_COUNT", 10)
      stats.set_int(MPX .. "MP_CHAR_ARMOUR_2_COUNT", 10)
      stats.set_int(MPX .. "MP_CHAR_ARMOUR_3_COUNT", 10)
      stats.set_int(MPX .. "MP_CHAR_ARMOUR_4_COUNT", 10)
      stats.set_int(MPX .. "MP_CHAR_ARMOUR_5_COUNT", 10)
      stats.set_int(MPX .. "BREATHING_APPAR_BOUGHT", 20) 
end) 

CSYONS7:add_action("Refill Inventory/Armour x9000", function()
 stats.set_int(MPX .. "NO_BOUGHT_YUM_SNACKS", 9000)
 stats.set_int(MPX .. "NO_BOUGHT_HEALTH_SNACKS", 9000)
 stats.set_int(MPX .. "NO_BOUGHT_EPIC_SNACKS", 9000)
 stats.set_int(MPX .. "NUMBER_OF_CHAMP_BOUGHT", 9000)
 stats.set_int(MPX .. "NUMBER_OF_ORANGE_BOUGHT", 9000)
 stats.set_int(MPX .. "NUMBER_OF_BOURGE_BOUGHT", 9000)
 stats.set_int(MPX .. "CIGARETTES_BOUGHT", 9000)
 stats.set_int(MPX .. "MP_CHAR_ARMOUR_1_COUNT", 9000)
 stats.set_int(MPX .. "MP_CHAR_ARMOUR_2_COUNT", 9000)
 stats.set_int(MPX .. "MP_CHAR_ARMOUR_3_COUNT", 9000)
 stats.set_int(MPX .. "MP_CHAR_ARMOUR_4_COUNT", 9000)
 stats.set_int(MPX .. "MP_CHAR_ARMOUR_5_COUNT", 9000)
 stats.set_int(MPX .. "BREATHING_APPAR_BOUGHT", 9000)
 end)

CSYONS2:add_action("Complete Daily Objectives", function() stats.set_int(MPX .. "COMPLETEDAILYOBJ", 100) stats.set_int(MPX .. "COMPLETEDAILYOBJTOTAL", 100) stats.set_int(MPX .. "TOTALDAYCOMPLETED", 100) stats.set_int(MPX .. "TOTALWEEKCOMPLETED", 400) stats.set_int(MPX .. "TOTALMONTHCOMPLETED", 1800) stats.set_int(MPX .. "CONSECUTIVEDAYCOMPLETED", 30) stats.set_int(MPX .. "CONSECUTIVEWEEKCOMPLETED", 4) stats.set_int(MPX .. "CONSECUTIVEMONTHCOMPLETE", 1) stats.set_int(MPX .. "COMPLETEDAILYOBJSA", 100) stats.set_int(MPX .. "COMPLETEDAILYOBJTOTALSA", 100) stats.set_int(MPX .. "TOTALDAYCOMPLETEDSA", 100) stats.set_int(MPX .. "TOTALWEEKCOMPLETEDSA", 400) stats.set_int(MPX .. "TOTALMONTHCOMPLETEDSA", 1800) stats.set_int(MPX .. "CONSECUTIVEDAYCOMPLETEDSA", 30) stats.set_int(MPX .. "CONSECUTIVEWEEKCOMPLETEDSA", 4) stats.set_int(MPX .. "CONSECUTIVEMONTHCOMPLETESA", 1) stats.set_int(MPX .. "AWD_DAILYOBJCOMPLETEDSA", 100) stats.set_int(MPX .. "AWD_DAILYOBJCOMPLETED", 100) stats.set_bool(MPX .. "AWD_DAILYOBJMONTHBONUS", true) stats.set_bool(MPX .. "AWD_DAILYOBJWEEKBONUS", true) stats.set_bool(MPX .. "AWD_DAILYOBJWEEKBONUSSA", true) stats.set_bool(MPX .. "AWD_DAILYOBJMONTHBONUSSA", true) end)

CSYONS8:add_action("Arena War", function()
stats.set_int(MPX .. "ARN_BS_TRINKET_TICKERS", -1)
stats.set_int(MPX .. "ARN_BS_TRINKET_SAVED", -1)
stats.set_int(MPX .. "AWD_WATCH_YOUR_STEP", 50)
stats.set_int(MPX .. "AWD_TOWER_OFFENSE", 50)
stats.set_int(MPX .. "AWD_READY_FOR_WAR", 50)
stats.set_int(MPX .. "AWD_THROUGH_A_LENS", 50)
stats.set_int(MPX .. "AWD_SPINNER", 50)
stats.set_int(MPX .. "AWD_YOUMEANBOOBYTRAPS", 50)
stats.set_int(MPX .. "AWD_MASTER_BANDITO", 50)
stats.set_int(MPX .. "AWD_SITTING_DUCK", 50)
stats.set_int(MPX .. "AWD_CROWDPARTICIPATION", 50)
stats.set_int(MPX .. "AWD_KILL_OR_BE_KILLED", 50)
stats.set_int(MPX .. "AWD_MASSIVE_SHUNT", 50)
stats.set_int(MPX .. "AWD_YOURE_OUTTA_HERE", 200)
stats.set_int(MPX .. "AWD_WEVE_GOT_ONE", 50)
stats.set_int(MPX .. "AWD_ARENA_WAGEWORKER", 1000000)
stats.set_int(MPX .. "AWD_TIME_SERVED", 1000)
stats.set_int(MPX .. "AWD_TOP_SCORE", 55000)
stats.set_int(MPX .. "AWD_CAREER_WINNER", 1000)
stats.set_int(MPX .. "ARENAWARS_SP", 0)
stats.set_int(MPX .. "ARENAWARS_SKILL_LEVEL", 20)
stats.set_int(MPX .. "ARENAWARS_SP_LIFETIME", 100)
stats.set_int(MPX .. "ARENAWARS_AP", 0)
stats.set_int(MPX .. "ARENAWARS_AP_TIER", 1000)
stats.set_int(MPX .. "ARENAWARS_AP_LIFETIME", 5055000)
stats.set_int(MPX .. "ARENAWARS_CARRER_UNLK", -1)
stats.set_int(MPX .. "ARN_W_THEME_SCIFI", 1000)
stats.set_int(MPX .. "ARN_W_THEME_APOC", 1000)
stats.set_int(MPX .. "ARN_W_THEME_CONS", 1000)
stats.set_int(MPX .. "ARN_W_PASS_THE_BOMB", 1000)
stats.set_int(MPX .. "ARN_W_DETONATION", 1000)
stats.set_int(MPX .. "ARN_W_ARCADE_RACE", 1000)
stats.set_int(MPX .. "ARN_W_CTF", 1000)
stats.set_int(MPX .. "ARN_W_TAG_TEAM", 1000)
stats.set_int(MPX .. "ARN_W_DESTR_DERBY", 1000)
stats.set_int(MPX .. "ARN_W_CARNAGE", 1000)
stats.set_int(MPX .. "ARN_W_MONSTER_JAM", 1000)
stats.set_int(MPX .. "ARN_W_GAMES_MASTERS", 1000)
stats.set_int(MPX .. "ARN_L_PASS_THE_BOMB", 500)
stats.set_int(MPX .. "ARN_L_DETONATION", 500)
stats.set_int(MPX .. "ARN_L_ARCADE_RACE", 500)
stats.set_int(MPX .. "ARN_L_CTF", 500)
stats.set_int(MPX .. "ARN_L_TAG_TEAM", 500)
stats.set_int(MPX .. "ARN_L_DESTR_DERBY", 500)
stats.set_int(MPX .. "ARN_L_CARNAGE", 500)
stats.set_int(MPX .. "ARN_L_MONSTER_JAM", 500)
stats.set_int(MPX .. "ARN_L_GAMES_MASTERS", 500)
stats.set_int(MPX .. "NUMBER_OF_CHAMP_BOUGHT", 1000)
stats.set_int(MPX .. "ARN_SPECTATOR_KILLS", 1000)
stats.set_int(MPX .. "ARN_LIFETIME_KILLS", 1000)
stats.set_int(MPX .. "ARN_LIFETIME_DEATHS", 500)
stats.set_int(MPX .. "ARENAWARS_CARRER_WINS", 1000)
stats.set_int(MPX .. "ARENAWARS_CARRER_WINT", 1000)
stats.set_int(MPX .. "ARENAWARS_MATCHES_PLYD", 1000)
stats.set_int(MPX .. "ARENAWARS_MATCHES_PLYDT", 1000)
stats.set_int(MPX .. "ARN_SPEC_BOX_TIME_MS", 86400000)
stats.set_int(MPX .. "ARN_SPECTATOR_DRONE", 1000)
stats.set_int(MPX .. "ARN_SPECTATOR_CAMS", 1000)
stats.set_int(MPX .. "ARN_SMOKE", 1000)
stats.set_int(MPX .. "ARN_DRINK", 1000)
stats.set_int(MPX .. "ARN_VEH_MONSTER", 1000)
stats.set_int(MPX .. "ARN_VEH_MONSTER", 1000)
stats.set_int(MPX .. "ARN_VEH_MONSTER", 1000)
stats.set_int(MPX .. "ARN_VEH_CERBERUS", 1000)
stats.set_int(MPX .. "ARN_VEH_CERBERUS2", 1000)
stats.set_int(MPX .. "ARN_VEH_CERBERUS3", 1000)
stats.set_int(MPX .. "ARN_VEH_BRUISER", 1000)
stats.set_int(MPX .. "ARN_VEH_BRUISER2", 1000)
stats.set_int(MPX .. "ARN_VEH_BRUISER3", 1000)
stats.set_int(MPX .. "ARN_VEH_SLAMVAN4", 1000)
stats.set_int(MPX .. "ARN_VEH_SLAMVAN5", 1000)
stats.set_int(MPX .. "ARN_VEH_SLAMVAN6", 1000)
stats.set_int(MPX .. "ARN_VEH_BRUTUS", 1000)
stats.set_int(MPX .. "ARN_VEH_BRUTUS2", 1000)
stats.set_int(MPX .. "ARN_VEH_BRUTUS3", 1000)
stats.set_int(MPX .. "ARN_VEH_SCARAB", 1000)
stats.set_int(MPX .. "ARN_VEH_SCARAB2", 1000)
stats.set_int(MPX .. "ARN_VEH_SCARAB3", 1000)
stats.set_int(MPX .. "ARN_VEH_DOMINATOR4", 1000)
stats.set_int(MPX .. "ARN_VEH_DOMINATOR5", 1000)
stats.set_int(MPX .. "ARN_VEH_DOMINATOR6", 1000)
stats.set_int(MPX .. "ARN_VEH_IMPALER2", 1000)
stats.set_int(MPX .. "ARN_VEH_IMPALER3", 1000)
stats.set_int(MPX .. "ARN_VEH_IMPALER4", 1000)
stats.set_int(MPX .. "ARN_VEH_ISSI4", 1000)
stats.set_int(MPX .. "ARN_VEH_ISSI5", 1000)
stats.set_int(MPX .. "ARN_VEH_ISSI", 61000)
stats.set_int(MPX .. "ARN_VEH_IMPERATOR", 1000)
stats.set_int(MPX .. "ARN_VEH_IMPERATOR2", 1000)
stats.set_int(MPX .. "ARN_VEH_IMPERATOR3", 1000)
stats.set_int(MPX .. "ARN_VEH_ZR380", 1000)
stats.set_int(MPX .. "ARN_VEH_ZR3802", 1000)
stats.set_int(MPX .. "ARN_VEH_ZR3803", 1000)
stats.set_int(MPX .. "ARN_VEH_DEATHBIKE", 1000)
stats.set_int(MPX .. "ARN_VEH_DEATHBIKE2", 1000)
stats.set_int(MPX .. "ARN_VEH_DEATHBIKE3", 1000)
stats.set_bool(MPX .. "AWD_BEGINNER", true)
stats.set_bool(MPX .. "AWD_FIELD_FILLER", true)
stats.set_bool(MPX .. "AWD_ARMCHAIR_RACER", true)
stats.set_bool(MPX .. "AWD_LEARNER", true)
stats.set_bool(MPX .. "AWD_SUNDAY_DRIVER", true)
stats.set_bool(MPX .. "AWD_THE_ROOKIE", true)
stats.set_bool(MPX .. "AWD_BUMP_AND_RUN", true)
stats.set_bool(MPX .. "AWD_GEAR_HEAD", true)
stats.set_bool(MPX .. "AWD_DOOR_SLAMMER", true)
stats.set_bool(MPX .. "AWD_HOT_LAP", true)
stats.set_bool(MPX .. "AWD_ARENA_AMATEUR", true)
stats.set_bool(MPX .. "AWD_PAINT_TRADER", true)
stats.set_bool(MPX .. "AWD_SHUNTER", true)
stats.set_bool(MPX .. "AWD_JOCK", true)
stats.set_bool(MPX .. "AWD_WARRIOR", true)
stats.set_bool(MPX .. "AWD_T_BONE", true)
stats.set_bool(MPX .. "AWD_MAYHEM", true)
stats.set_bool(MPX .. "AWD_WRECKER", true)
stats.set_bool(MPX .. "AWD_CRASH_COURSE", true)
stats.set_bool(MPX .. "AWD_ARENA_LEGEND", true)
stats.set_bool(MPX .. "AWD_PEGASUS", true)
stats.set_bool(MPX .. "AWD_UNSTOPPABLE", true)
stats.set_bool(MPX .. "AWD_CONTACT_SPORT", true)
stats.set_masked_int(MPX.."ARENAWARSPSTAT_INT", 1, 35, 8)
for i = 0, 8 do for j = 0, 63 do stats.set_bool_masked(MPX.."ARENAWARSPSTAT_BOOL"..i, true, j, MPX) end end end)

--Required--
		
		MPX = PlayerIndex 
		PlayerIndex = stats.get_int("MPPLY_LAST_MP_CHAR") 
		if PlayerIndex == 0 then MPX = "MP0_" else MPX = "MP1_" end

--X TelePort To WAYPOINT--
menu.register_hotkey(88, better_teleport_to_waypoint)
CSYONS15:add_action("Teleport to WAYPOINT (X)",  better_teleport_to_waypoint)



CSYONS2:add_action("Unlock Pajamas and Smoking Jackets [Temporarily]", function()
	stats.set_bool_masked(MPX .. "NGDLCPSTAT_BOOL1", true, 33) -- Pastel Blue Pajamas
	stats.set_bool_masked(MPX .. "NGDLCPSTAT_BOOL1", true, 34) -- Pastel Yellow Pajamas
	stats.set_bool_masked(MPX .. "NGDLCPSTAT_BOOL1", true, 35) -- Pastel Pink Pajamas
	stats.set_bool_masked(MPX .. "NGDLCPSTAT_BOOL1", true, 36) -- Pastel Green Pajamas
	stats.set_bool_masked(MPX .. "NGDLCPSTAT_BOOL1", true, 37) -- Vibrant Check Pajamas
	stats.set_bool_masked(MPX .. "NGDLCPSTAT_BOOL1", true, 38) -- Blue Check Pajamas
	stats.set_bool_masked(MPX .. "NGDLCPSTAT_BOOL1", true, 39) -- Red Swirl Motif Pajamas
	stats.set_bool_masked(MPX .. "NGDLCPSTAT_BOOL1", true, 40) -- White Graphic Pajamas
	stats.set_bool_masked(MPX .. "NGDLCPSTAT_BOOL1", true, 41) -- Blue Swirl Pajamas
	stats.set_bool_masked(MPX .. "NGDLCPSTAT_BOOL1", true, 42) -- Yellow Swirl Pajamas
	stats.set_bool_masked(MPX .. "NGDLCPSTAT_BOOL1", true, 43) -- Red Swirl Pajamas
	stats.set_bool_masked(MPX .. "NGDLCPSTAT_BOOL1", true, 44) -- Navy Pinstripe Pajamas
	stats.set_bool_masked(MPX .. "NGDLCPSTAT_BOOL1", true, 45) -- Bold Pinstripe Pajamas
	stats.set_bool_masked(MPX .. "NGDLCPSTAT_BOOL1", true, 46) -- Orange Pinstripe Pajamas
	stats.set_bool_masked(MPX .. "NGDLCPSTAT_BOOL2", true, 2) -- Pastel Blue Smoking Jacket
	stats.set_bool_masked(MPX .. "NGDLCPSTAT_BOOL2", true, 3) -- Pastel Yellow Smoking Jacket
	stats.set_bool_masked(MPX .. "NGDLCPSTAT_BOOL2", true, 4) -- Pastel Pink Smoking Jacket
	stats.set_bool_masked(MPX .. "NGDLCPSTAT_BOOL2", true, 5) -- Pastel Green Smoking Jacket
	stats.set_bool_masked(MPX .. "NGDLCPSTAT_BOOL2", true, 6) -- Vibrant Check Smoking Jacket
	stats.set_bool_masked(MPX .. "NGDLCPSTAT_BOOL2", true, 7) -- Blue Check Smoking Jacket
	stats.set_bool_masked(MPX .. "NGDLCPSTAT_BOOL2", true, 8) -- Red Swirl Motif Smoking Jacket
	stats.set_bool_masked(MPX .. "NGDLCPSTAT_BOOL2", true, 9) -- White Graphic Smoking Jacket
	stats.set_bool_masked(MPX .. "NGDLCPSTAT_BOOL2", true, 10) -- Blue Swirl Smoking Jacket
	stats.set_bool_masked(MPX .. "NGDLCPSTAT_BOOL2", true, 11) -- Yellow Swirl Smoking Jacket
	stats.set_bool_masked(MPX .. "NGDLCPSTAT_BOOL2", true, 12) -- Red Swirl Smoking Jacket
	stats.set_bool_masked(MPX .. "NGDLCPSTAT_BOOL2", true, 13) -- Navy Pinstripe Smoking Jacket
	stats.set_bool_masked(MPX .. "NGDLCPSTAT_BOOL2", true, 14) -- Bold Pinstripe Smoking Jacket
	stats.set_bool_masked(MPX .. "NGDLCPSTAT_BOOL2", true, 15) -- Orange Pinstripe Smoking Jacket
end)

packed_bool = false
CSYONS2:add_toggle("Unlock snowman etc.", function()
	return packed_bool
end, function(status)
	packed_bool = status
	stats.set_bool_masked(MPX.. "DLC22022PSTAT_BOOL2", status, 20)
	stats.set_bool_masked(MPX.. "DLC22022PSTAT_BOOL2", status, 21)
    stats.set_bool_masked(MPX.. "DLC22022PSTAT_BOOL1", status, 28)
end)

CSYONS2:add_action("Clothing unlocker Drug was Part2", function()
	globals.set_int(296190, 1)
	globals.set_int(296191, 1)
	globals.set_int(296192, 1)
	globals.set_int(296193, 1)
	globals.set_int(296194, 1)
	globals.set_int(296195, 1)
	globals.set_int(296196, 1)
	globals.set_int(296197, 1)
	globals.set_int(296198, 1)
	globals.set_int(296199, 1)
	globals.set_int(296200, 1)
	globals.set_int(296201, 1)
	globals.set_int(296203, 1)
	globals.set_int(296204, 1)
	globals.set_int(296206, 1)
	globals.set_int(296207, 1)
	globals.set_int(296211, 1)
	globals.set_int(296215, 1)
	globals.set_int(296223, 1)
	globals.set_int(296254, 1)
end)

CSYONS7:add_float_range("Run Speed Advance", 0.5,  1.0, 10.0, Runnyspeed, Runny)

CSYONS2:add_int_range("Nightclub Sells Timer", 20000, 0, 60000, function() if localplayer then return globals.get_int(262145+24497)end end, function(value) globals.set_int(262145+24497, value) end)

CSYONS2:add_action("Unlock unreleased Vehicles And Weapon Skins", function() stats.set_int("MPPLY_XMASLIVERIES", -1) for i = 1, 20 do stats.set_int("MPPLY_XMASLIVERIES"..i, -1) end end)

CSYONS2:add_action("Unlock All Flight School Missions", function() stats.set_int("MPPLY_NUM_CAPTURES_CREATED", 100) for i = 0, 9 do stats.set_int("MPPLY_PILOT_SCHOOL_MEDAL_"..i, -1) stats.set_int(MPX .. "PILOT_SCHOOL_MEDAL_"..i, -1) stats.set_bool(MPX .. "PILOT_ASPASSEDLESSON_"..i, true) end end)

CSYONS2:add_action("Unlock All Bunkers Shooting Range", function() stats.set_int(MPX .. "SR_HIGHSCORE_1", 690) stats.set_int(MPX .. "SR_HIGHSCORE_2", 1860) stats.set_int(MPX .. "SR_HIGHSCORE_3", 2690) stats.set_int(MPX .. "SR_HIGHSCORE_4", 2660) stats.set_int(MPX .. "SR_HIGHSCORE_5", 2650) stats.set_int(MPX .. "SR_HIGHSCORE_6", 450) stats.set_int(MPX .. "SR_TARGETS_HIT", 269) stats.set_int(MPX .. "SR_WEAPON_BIT_SET", -1) stats.set_bool(MPX .. "SR_TIER_1_REWARD", true) stats.set_bool(MPX .. "SR_TIER_3_REWARD", true) stats.set_bool(MPX .. "SR_INCREASE_THROW_CAP", true) end)

CSYONS2:add_action("unlock all special liveries", function()
 stats.set_int("MP0_XMASLIVERIES0", -1)
 stats.set_int("MP1_XMASLIVERIES0", -1)
 stats.set_int("MP0_XMASLIVERIES1", -1)
 stats.set_int("MP1_XMASLIVERIES1", -1)
 stats.set_int("MP0_XMASLIVERIES2", -1)
 stats.set_int("MP1_XMASLIVERIES2", -1)
 stats.set_int("MP0_XMASLIVERIES3", -1)
 stats.set_int("MP1_XMASLIVERIES3", -1)
 stats.set_int("MP0_XMASLIVERIES4", -1)
 stats.set_int("MP1_XMASLIVERIES4", -1)
 stats.set_int("MP0_XMASLIVERIES5", -1)
 stats.set_int("MP1_XMASLIVERIES5", -1)
 stats.set_int("MP0_XMASLIVERIES6", -1)
 stats.set_int("MP1_XMASLIVERIES6", -1)
 stats.set_int("MP0_XMASLIVERIES7", -1)
 stats.set_int("MP1_XMASLIVERIES7", -1)
 stats.set_int("MP0_XMASLIVERIES8", -1)
 stats.set_int("MP1_XMASLIVERIES8", -1)
 stats.set_int("MP0_XMASLIVERIES9", -1)
 stats.set_int("MP1_XMASLIVERIES9", -1)
 stats.set_int("MP0_XMASLIVERIES10", -1)
 stats.set_int("MP1_XMASLIVERIES10", -1)
 stats.set_int("MP0_XMASLIVERIES11", -1)
 stats.set_int("MP1_XMASLIVERIES11", -1)
 stats.set_int("MP0_XMASLIVERIES12", -1)
 stats.set_int("MP1_XMASLIVERIES12", -1)
 stats.set_int("MP0_XMASLIVERIES13", -1)
 stats.set_int("MP1_XMASLIVERIES13", -1)
 stats.set_int("MP0_XMASLIVERIES14", -1)
 stats.set_int("MP1_XMASLIVERIES14", -1)
 stats.set_int("MP0_XMASLIVERIES15", -1)
 stats.set_int("MP1_XMASLIVERIES15", -1)
 stats.set_int("MP0_XMASLIVERIES16", -1)
 stats.set_int("MP1_XMASLIVERIES16", -1)
 stats.set_int("MP0_XMASLIVERIES17", -1)
 stats.set_int("MP1_XMASLIVERIES17", -1)
 stats.set_int("MP0_XMASLIVERIES18", -1)
 stats.set_int("MP1_XMASLIVERIES18", -1)
 stats.set_int("MP0_XMASLIVERIES19", -1)
 stats.set_int("MP1_XMASLIVERIES19", -1)
end)

CSYONS2:add_action("Unlock Mambas 24 Livery", function()
 stats.set_int("MP0_XMASLIVERIES18", -1)
 stats.set_int("MP1_XMASLIVERIES18", -1)
end)

CSYONS2:add_action("Stats Drug Wars DLC", function()
 stats.set_int("WCT_PISTMK2_XM3", 1141184690)
 stats.set_int("WCT_MSMG_XM3", -1566778158)
 stats.set_int("WCT_PUMPSHT_XM3", 330905451)
 stats.set_int("WCT_CLIP1", 375646046)
 stats.set_int("WCT_SUPP", 503494624)
end)

CSYONS2:add_action("Drug Wars Part 2 Liverys", function()
 stats.set_int("MP0_AWD_STASHHORAID", 50)
 stats.set_int("MP1_AWD_STASHHORAID", 50)
 stats.set_int("MP0_AWD_DEADDROP", 50)
 stats.set_int("MP1_AWD_DEADDROP", 50)
 stats.set_int("MP0_AWD_GOODSAMARITAN", 5)
 stats.set_int("MP1_AWD_GOODSAMARITAN", 5)
 stats.set_int("MP0_AWD_OWNWORSTENEMY", 60)
 stats.set_int("MP1_AWD_OWNWORSTENEMY", 60)
 stats.set_int("MP0_AWD_TAXIDRIVER", 50)
 stats.set_int("MP01_AWD_TAXIDRIVER", 50)
end)

------
CSYONS5i = CSYONS5:add_submenu("Call Vehicle from Mechanicer")
function s(x)		--sleep
for i=1,x*4*10^7 do end end
function gi(x,o)		--get or set a global variable
local i=globals.get_int(x) if o and o~=i then globals.set_int(x,o) end return i end
function wf(x,o,i,l)		--wait for a global variable
for x=1,100*x do x=gi(o) if l and x~=i or not l and x==i then return else s(0.01) end end end
gpv={2359980,1586468,2793343,2639791}
function spvx()		--get the current personal vehicle controller global variable
return gpv[2]+104+142*gi(gpv[1]) end
function spv(x,guarda)		
    if x then 
        if gi(gpv[3])~=-1 then 
            gi(spvx(),4)
            wf(5,gpv[3],-1)
        end
        gi(gpv[1],x)
    end
    if guarda  then --to know if he keeps the car or calls him
    --
    else
    menu.remove_insurance_claims()  --remove insurance 
    menu.deliver_personal_vehicle() -- call the personal vehicle 
	sleep(1)
	menu.enter_personal_vehicle()
    end
end
 
h=menu.register_hotkey 
CSYONS5i:add_int_range("Personal vehicle number",
1,0,300,function() return gi(gpv[1]) end,spv)
h(97,function() spv() end) --Press num1 for spawn & enter current PV
------
--function MPXreturn stats.get_int("MPPLY_LAST_MP_CHAR")end   --check if character MP0_ or MP1_  The Checker

--CSYONS5 = menu.add_submenu("Call Vehicle from Mechanicer")
--                                                                      MP0-↓↓↓              ↓↓↓-MP1 
CSYONS5i:add_action("Anis300R          ", function() if MPX == 0 then spv(260)  else    spv(4)  end end)
CSYONS5i:add_action("BMX               ", function() if MPX == 0 then  spv(49)  else   spv(50)  end end)
CSYONS5i:add_action("Calico GTF        ", function() if MPX == 0 then spv(136)  else   spv(80)  end end)
CSYONS5i:add_action("CometS2           ", function() if MPX == 0 then spv(143)  else   spv(91)  end end)
CSYONS5i:add_action("Deluxo            ", function() if MPX == 0 then spv(105)  else  spv(218)  end end)
CSYONS5i:add_action("Hakuchou          ", function() if MPX == 0 then  spv(71)  else  spv(139)  end end)
CSYONS5i:add_action("Insurgent Pickup  ", function() if MPX == 0 then  spv(95)  else  spv(129)  end end)
CSYONS5i:add_action("Italy GTO         ", function() if MPX == 0 then spv(113)  else   spv(17)  end end)
CSYONS5i:add_action("Italy RSX         ", function() if MPX == 0 then  spv(80)  else  spv(137)  end end)
CSYONS5i:add_action("Krieger           ", function() if MPX == 0 then spv(247)  else  spv(135)  end end)
CSYONS5i:add_action("Kuruma            ", function() if MPX == 0 then  spv(29)  else  spv(247)  end end)
CSYONS5i:add_action("Lost Slamvan      ", function() if MPX == 0 then spv(249)  else   spv(42)  end end)
CSYONS5i:add_action("Monroe            ", function() if MPX == 0 then  spv(47)  else  spv(126)  end end)
CSYONS5i:add_action("Opressor          ", function() if MPX == 0 then  spv(48)  else  spv(220)  end end)
CSYONS5i:add_action("Pariah            ", function() if MPX == 0 then spv(121)  else   spv(48)  end end)
CSYONS5i:add_action("Scramjet          ", function() if MPX == 0 then spv(122)  else   spv(52)  end end)
CSYONS5i:add_action("Sentinel Widebody ", function() if MPX == 0 then spv(262)  else  spv(248)  end end)
CSYONS5i:add_action("Shotaro           ", function() if MPX == 0 then  spv(32)  else   spv(41)  end end)
CSYONS5i:add_action("Sovereign         ", function() if MPX == 0 then spv(127)  else   spv(58)  end end)
CSYONS5i:add_action("Toreador          ", function() if MPX == 0 then  spv(58)  else   spv(39)  end end)
CSYONS5i:add_action("Vagrant           ", function() if MPX == 0 then spv(244)  else  spv(183)  end end)
CSYONS5i:add_action("Veto Classic      ", function() if MPX == 0 then  spv(59)  else    spv(9)  end end)
CSYONS5i:add_action("Vigilante         ", function() if MPX == 0 then spv(263)  else  spv(104)  end end)
CSYONS5i:add_action("  Keep the car  ", function() -- Keep in the Vehicle 
        carinuse = gi(gpv[1])    
        spv(carinuse,true)
end)
--------

CSYONS8:add_action("Unlock Go Go Monkey Blista", function()
	stats.set_masked_int(MPX .. "BUSINESSBATPSTAT_INT380", 20, 40, 8)  --  Unlock for Go Go Monkey Blista
end)
 
CSYONS8:add_action("Unlock Festive Surprise", function()
	stats.set_bool_masked(MPX .. "PSTAT_BOOL2", true, 7)  --  Free Vapid Clique
	stats.set_bool_masked(MPX .. "PSTAT_BOOL2", true, 8)  --  Free Buzzard Attack Chopper
	stats.set_bool_masked(MPX .. "PSTAT_BOOL2", true, 9)  --  Free Insurgent Pick-Up
end)

local CSYONS14i = CSYONS14:add_submenu("Money Stats")
CSYONS14i:add_int_range("SPENTWEAPARMO", 0, 0, 0, function() return stats.get_int(MPX .. "MONEY_SPENT_WEAPON_ARMOR") end, function(value) stats.set_int(MPX .. "MONEY_SPENT_WEAPON_ARMOR",value) end)
CSYONS14i:add_int_range("SPENTVEHMAINT", 0, 0, 0, function() return stats.get_int(MPX .. "MONEY_SPENT_VEH_MAINTENANCE") end, function(value) stats.set_int(MPX .. "MONEY_SPENT_VEH_MAINTENANCE",value) end)
CSYONS14i:add_int_range("SPENTSTYLEENT", 0, 0, 0, function() return stats.get_int(MPX .. "MONEY_SPENT_STYLE_ENT") end, function(value) stats.set_int(MPX .. "MONEY_SPENT_STYLE_ENT",value) end)
CSYONS14i:add_int_range("SPENTPROPERTY", 0, 0, 0, function() return stats.get_int(MPX .. "MONEY_SPENT_PROPERTY_UTIL") end, function(value) stats.set_int(MPX .. "MONEY_SPENT_PROPERTY_UTIL",value) end)
CSYONS14i:add_int_range("EARNBETTING", 0, 0, 0, function() return stats.get_int(MPX .. "MONEY_EARN_BETTING") end, function(value) stats.set_int(MPX .. "MONEY_EARN_BETTING",value) end)

----local CSYONS10i = CSYONS10:add_submenu("2022 Halloween UFOs Event") 
----CSYONS10i:add_action("Instructions UFOs Event", function() end) 

local CSYONS8i = CSYONS8:add_submenu("Achievements") 
CSYONS8i:add_action("Choose what for achievement you are missing", function() end) 
	CSYONS8i:add_action("Welcome to Los Santos", function() globals.set_int(AG, 1) end)
	CSYONS8i:add_action("A Friendship Resurrected", function() globals.set_int(AG, 2) end)
	CSYONS8i:add_action("A Fair Day's Pay", function() globals.set_int(AG, 3) end)
	CSYONS8i:add_action("The Moment of Truth", function() globals.set_int(AG, 4) end)
	CSYONS8i:add_action("To Live or Die in Los Santos", function() globals.set_int(AG, 5) end)
	CSYONS8i:add_action("Diamond Hard", function() globals.set_int(AG, 6) end)
	CSYONS8i:add_action("Subversive", function() globals.set_int(AG, 7) end)
	CSYONS8i:add_action("Blitzed", function() globals.set_int(AG, 8) end)
	CSYONS8i:add_action("Small Town, Big Job", function() globals.set_int(AG, 9) end)
	CSYONS8i:add_action("The Government Gimps", function() globals.set_int(AG, 10) end)
	CSYONS8i:add_action("The Big One!", function() globals.set_int(AG, 11) end)
	CSYONS8i:add_action("Solid Gold, Baby!", function() globals.set_int(AG, 12) end)
	CSYONS8i:add_action("Career Criminal", function() globals.set_int(AG, 13) end)
	CSYONS8i:add_action("San Andreas Sightseer", function() globals.set_int(AG, 14) end)
	CSYONS8i:add_action("All's Fare in Love and War", function() globals.set_int(AG, 15) end)
	CSYONS8i:add_action("TP Industries Arms Race", function() globals.set_int(AG, 16) end)
	CSYONS8i:add_action("Multi-Disciplined", function() globals.set_int(AG, 17) end)
	CSYONS8i:add_action("From Beyond the Stars", function() globals.set_int(AG, 18) end)
	CSYONS8i:add_action("A Mystery, Solved", function() globals.set_int(AG, 19) end)
	CSYONS8i:add_action("Waste Management", function() globals.set_int(AG, 20) end)
	CSYONS8i:add_action("Red Mist", function() globals.set_int(AG, 21) end)
	CSYONS8i:add_action("Show Off", function() globals.set_int(AG, 22) end)
	CSYONS8i:add_action("Kifflom!", function() globals.set_int(AG, 23) end)
	CSYONS8i:add_action("Three Man Army", function() globals.set_int(AG, 24) end)
	CSYONS8i:add_action("Out of Your Depth", function() globals.set_int(AG, 25) end)
	CSYONS8i:add_action("Altruist Acolyte", function() globals.set_int(AG, 26) end)
	CSYONS8i:add_action("A Lot of Cheddar", function() globals.set_int(AG, 27) end)
	CSYONS8i:add_action("Trading Pure Alpha", function() globals.set_int(AG, 28) end)
	CSYONS8i:add_action("Pimp My Sidearm", function() globals.set_int(AG, 29) end)
	CSYONS8i:add_action("Wanted: Alive Or Alive", function() globals.set_int(AG, 30) end)
	CSYONS8i:add_action("Los Santos Customs", function() globals.set_int(AG, 31) end)
	CSYONS8i:add_action("Close Shave", function() globals.set_int(AG, 32) end)
	CSYONS8i:add_action("Off the Plane", function() globals.set_int(AG, 33) end)
	CSYONS8i:add_action("Three-Bit Gangster", function() globals.set_int(AG, 34) end)
	CSYONS8i:add_action("Making Moves", function() globals.set_int(AG, 35) end)
	CSYONS8i:add_action("Above the Law", function() globals.set_int(AG, 36) end)
	CSYONS8i:add_action("Numero Uno", function() globals.set_int(AG, 37) end)
	CSYONS8i:add_action("The Midnight Club", function() globals.set_int(AG, 38) end)
	CSYONS8i:add_action("Unnatural Selection", function() globals.set_int(AG, 39) end)
	CSYONS8i:add_action("Backseat Driver", function() globals.set_int(AG, 40) end)
	CSYONS8i:add_action("Run Like The Wind", function() globals.set_int(AG, 41) end)
	CSYONS8i:add_action("Clean Sweep", function() globals.set_int(AG, 42) end)
	CSYONS8i:add_action("Decorated", function() globals.set_int(AG, 43) end)
	CSYONS8i:add_action("Stick Up Kid", function() globals.set_int(AG, 44) end)
	CSYONS8i:add_action("Enjoy Your Stay", function() globals.set_int(AG, 45) end)
	CSYONS8i:add_action("Crew Cut", function() globals.set_int(AG, 46) end)
	CSYONS8i:add_action("Full Refund", function() globals.set_int(AG, 47) end)
	CSYONS8i:add_action("Dialling Digits", function() globals.set_int(AG, 48) end)
	CSYONS8i:add_action("American Dream", function() globals.set_int(AG, 49) end)
	CSYONS8i:add_action("A New Perspective", function() globals.set_int(AG, 50) end)
	CSYONS8i:add_action("Be Prepared", function() globals.set_int(AG, 51) end)
	CSYONS8i:add_action("In the Name of Science", function() globals.set_int(AG, 52) end)
	CSYONS8i:add_action("Dead Presidents", function() globals.set_int(AG, 53) end)
	CSYONS8i:add_action("Parole Day", function() globals.set_int(AG, 54) end)
	CSYONS8i:add_action("Shot Caller", function() globals.set_int(AG, 55) end)
	CSYONS8i:add_action("Four Way", function() globals.set_int(AG, 56) end)
	CSYONS8i:add_action("Live a Little", function() globals.set_int(AG, 57) end)
	CSYONS8i:add_action("Can't Touch This", function() globals.set_int(AG, 58) end)
	CSYONS8i:add_action("Mastermind", function() globals.set_int(AG, 59) end)
	CSYONS8i:add_action("Vinewood Visionary", function() globals.set_int(AG, 60) end)
	CSYONS8i:add_action("Majestic", function() globals.set_int(AG, 61) end)
	CSYONS8i:add_action("Humans of Los Santos", function() globals.set_int(AG, 62) end)
	CSYONS8i:add_action("First Time Director", function() globals.set_int(AG, 63) end)
	CSYONS8i:add_action("Animal Lover", function() globals.set_int(AG, 64) end)
	CSYONS8i:add_action("Ensemble Piece", function() globals.set_int(AG, 65) end)
	CSYONS8i:add_action("Cult Movie", function() globals.set_int(AG, 66) end)
	CSYONS8i:add_action("Location Scout", function() globals.set_int(AG, 67) end)
	CSYONS8i:add_action("Method Actor", function() globals.set_int(AG, 68) end)
	CSYONS8i:add_action("Cryptozoologist", function() globals.set_int(AG, 69) end)
	CSYONS8i:add_action("Getting Started", function() globals.set_int(AG, 70) end)
	CSYONS8i:add_action("The Data Breaches", function() globals.set_int(AG, 71) end)
	CSYONS8i:add_action("The Bogdan Problem", function() globals.set_int(AG, 72) end)
	CSYONS8i:add_action("The Doomsday Scenario", function() globals.set_int(AG, 73) end)
	CSYONS8i:add_action("A World Worth Saving", function() globals.set_int(AG, 74) end)
	CSYONS8i:add_action("Orbital Obliteration", function() globals.set_int(AG, 75) end)
	CSYONS8i:add_action("Elitist", function() globals.set_int(AG, 76) end)
	CSYONS8i:add_action("Masterminds", function() globals.set_int(AG, 77) end)

CSYONS8:add_toggle("Unlock All", function() return Acv0 end, function() Acv0 = not Acv0 AchUnlock(Acv0) end)

CSYONS12:add_action("Destroy All Cars", function()
    for v in replayinterface.get_vehicles() do
        if v ~= nil then
            v:set_health(0)
        end
    end
end)

CSYONS13:add_float_range("RP Multi", 1, 1, 100000, function() return globals.get_float(262146) end, function(v) globals.set_float(262146, v) end)
CSYONS13:add_float_range("AP Multi", 1, 1, 100000, function() return globals.get_float(288059) end, function(v) globals.set_float(288059, v) end)
CSYONS13:add_float_range("Street Races Multi", 1, 1, 100000, function() return globals.get_float(293782) end, function(v) globals.set_float(293782, v) end)
CSYONS13:add_float_range("Pursuits Multi", 1, 1, 100000, function() return globals.get_float(293783) end, function(v) globals.set_float(293783, v) end)
CSYONS13:add_float_range("Face2Face Multi", 1, 1, 100000, function() return globals.get_float(293785) end, function(v) globals.set_float(293785, v) end)
CSYONS13:add_float_range("LS Car Meet Multi", 1, 1, 100000, function() return globals.get_float(293786) end, function(v) globals.set_float(293786, v) end)
CSYONS13:add_float_range("LS Car Meet on track Multi", 1, 1, 100000, function() return globals.get_float(293787) end, function(v) globals.set_float(293787, v) end) local awa = 0 local awc = 0 local awr = 0
CSYONS13:add_int_range("AP Arena Wars Multi", 5000, 0, 500000, function() return awa end, function(v) for i = 286231, 286233 do globals.set_int(i, v) end for j = 286240, 286242 do globals.set_int(j, v) end awa = v end)
CSYONS13:add_float_range("Street Race Multiplier", 1.0, 1, 50, function() 
	return globals.get_float(262145 + 31118)
end, function(value)
	globals.set_float(262145 + 31118, value)
end)
 
CSYONS13:add_float_range("Pursuit Race Multiplier", 1.0, 1, 50, function() 
	return globals.get_float(262145 + 31119)
end, function(value)
	globals.set_float(262145 + 31119, value)
end)
 
CSYONS13:add_float_range("Scramble Multiplier", 1.0, 1, 50, function() 
	return globals.get_float(262145 + 31120)
end, function(value)
	globals.set_float(262145 + 31120, value)
end)
 
CSYONS13:add_float_range("Head2Head Multiplier", 1.0, 1, 50, function() 
	return globals.get_float(262145 + 31121)
end, function(value)
	globals.set_float(262145 + 31121, value)
end)
 
CSYONS12:add_action("Drop Fireworks", DropFireworks)

CSYONS8:add_action("Unlock Gunrunning Missions", function() stats.set_int("MP0_LFETIME_BIKER_BUY_COMPLET5", "MP1_LFETIME_BIKER_BUY_COMPLET5",14) end)
 
CSYONS12:add_action("👫 Allow Gender Change ◀◀", function()
	mpIndex = globals.get_int(1574918)
	if mpIndex == 0 then
		stats.set_int("MP0_ALLOW_GENDER_CHANGE", 52)
	else
		stats.set_int("MP1_ALLOW_GENDER_CHANGE", 52)
	end
end)

CSYONS10s = CSYON10:add_submenu("🗞Crew Rang Setter")

CSYONS10s:add_action("CREW Level change", function()
	STATS.STAT_SET_INT("MPPLY_CREW_LOCAL_XP_0", 1337)
	STATS.STAT_SET_INT("MPPLY_CREW_LOCAL_XP_1", 1337)
	STATS.STAT_SET_INT("MPPLY_CREW_LOCAL_XP_2", 1337)
	STATS.STAT_SET_INT("MPPLY_CREW_LOCAL_XP_3", 1337)
	STATS.STAT_SET_INT("MPPLY_CREW_LOCAL_XP_4", 1337)
end)
 
-- or
 
INI.CREWLEVEL = 0
CSYONS10s:add_array_item("CREW Level Select", {
	[0] = "0", 
	[2165850] = "120", 
	[75185850] = "1337", 
	[1787576850] = "8000"
}, function()
	return INI.CREWLEVEL
end, function(array)
	INI.CREWLEVEL = array
	STATS.STAT_SET_INT("MPPLY_CREW_LOCAL_XP_0", array)
	STATS.STAT_SET_INT("MPPLY_CREW_LOCAL_XP_1", array)
	STATS.STAT_SET_INT("MPPLY_CREW_LOCAL_XP_2", array)
	STATS.STAT_SET_INT("MPPLY_CREW_LOCAL_XP_3", array)
	STATS.STAT_SET_INT("MPPLY_CREW_LOCAL_XP_4", array)
end)

local CSYONS10i = CSYONS10:add_submenu("2022 Halloween UFOs Event") 
CSYONS10i:add_action("Instructions UFOs Event", function() end)
CSYONS10i:add_action("1-After you set the value, change session", function() end)
CSYONS10i:add_action("2-crew level do not decrease", function() end)
CSYONS10i:add_action("3-EXP is added, meaning whatever level", function() end)
CSYONS10i:add_action("   EXP you have will be summed with the", function() end)
CSYONS10i:add_action("   EXP level you are setting.", function() end)
CSYONS10i:add_action("--", function() end)



CSYONS4:add_action("🔫 Reload Speed ◀◀ ", reloadSpeed)
 
local Plates={ "Csyon", "ADMIN", "ROCKSTAR", "Kiddion", "L7NEG", "Csyons", "CSYON" }
local function Veh() if localplayer:is_in_vehicle() then return localplayer:get_current_vehicle() else return nil end end
CSYONS5:add_array_item("Set Number Plate 🚘", Plates, function()
if Veh() then for x=1, #Plates do if Plates[x]==Veh():get_number_plate_text() then return x end end return 1 end end, function(t)
  if Veh() then Veh():set_number_plate_text(Plates[t]) end
end)
 
CSYONS8:add_action("Unlock Arcade T-Shirts (m)", function()
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 38)  --  Unlock for Badlands Revenge II Retro Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 39)  --  Unlock for Badlands Revenge II Pixtro Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 40)  --  Unlock for Degenatron Glitch Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 41)  --  Unlock for Degenatron Logo Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 42)  --  Unlock for The Wizards Ruin Rescue Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 43)  --  Unlock for The Wizards Ruin Vow Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 44)  --  Unlock for Space Monkey Art Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 45)  --  Unlock for Crotch Rockets Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 46)  --  Unlock for Street Legal Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 47)  --  Unlock for Get Truckin Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 48)  --  Unlock for Arcade Trophy Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 49)  --  Unlock for Videogeddon Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 50)  --  Unlock for Insert Coin Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 51)  --  Unlock for Plushie Princess Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 52)  --  Unlock for Plushie Wasabi Kitty Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 53)  --  Unlock for Plushie Master Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 54)  --  Unlock for Plushie Muffy Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 55)  --  Unlock for Plushie Humpy Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 56)  --  Unlock for Plushie Saki Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 57)  --  Unlock for Plushie Grindy Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 58)  --  Unlock for Plushie Poopie Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 59)  --  Unlock for Plushie Smoker Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 60)  --  Unlock for Shiny Wasabi Kitty Claw Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 61)  --  Unlock for Nazar Speaks Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL1", true, 28)  --  Unlock for 11 11 Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL1", true, 29)  --  Unlock for King Of QUB3D Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL1", true, 30)  --  Unlock for Qubism Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL1", true, 31)  --  Unlock for God Of QUB3D Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL1", true, 32)  --  Unlock for QUB3D Boxart Tee
	stats.set_bool_masked(MPX .. "SU20TATTOOSTAT_BOOL0", true, 63)  --  Unlock for Faces of Death Tee
	stats.set_bool_masked(MPX .. "SU20TATTOOSTAT_BOOL1", true, 0)  --  Unlock for Straight to Video Tee
	stats.set_bool_masked(MPX .. "SU20TATTOOSTAT_BOOL1", true, 1)  --  Unlock for Monkey See Monkey Die Tee
	stats.set_bool_masked(MPX .. "SU20TATTOOSTAT_BOOL1", true, 2)  --  Unlock for Trained to Kill Tee
	stats.set_bool_masked(MPX .. "SU20TATTOOSTAT_BOOL1", true, 3)  --  Unlock for The Director Tee
end)
 
CSYONS8:add_action("Unlock Arcade T-Shirts (f)", function()
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 49)  --  Unlock for Badlands Revenge II Retro Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 50)  --  Unlock for Badlands Revenge II Pixtro Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 51)  --  Unlock for Degenatron Glitch Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 52)  --  Unlock for Degenatron Logo Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 53)  --  Unlock for The Wizards Ruin Rescue Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 54)  --  Unlock for The Wizards Ruin Vow Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 55)  --  Unlock for Space Monkey Art Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 56)  --  Unlock for Crotch Rockets Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 57)  --  Unlock for Street Legal Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 58)  --  Unlock for Get Truckin Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 59)  --  Unlock for Arcade Trophy Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 60)  --  Unlock for Videogeddon Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 61)  --  Unlock for Insert Coin Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 62)  --  Unlock for Plushie Princess Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL0", true, 63)  --  Unlock for Plushie Wasabi Kitty Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL1", true, 0)  --  Unlock for Plushie Master Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL1", true, 1)  --  Unlock for Plushie Muffy Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL1", true, 2)  --  Unlock for Plushie Humpy Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL1", true, 3)  --  Unlock for Plushie Saki Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL1", true, 4)  --  Unlock for Plushie Grindy Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL1", true, 5)  --  Unlock for Plushie Poopie Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL1", true, 6)  --  Unlock for Plushie Smoker Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL1", true, 7)  --  Unlock for Shiny Wasabi Kitty Claw Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL1", true, 8)  --  Unlock for Nazar Speaks Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL1", true, 39)  --  Unlock for 11 11 Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL1", true, 40)  --  Unlock for King Of QUB3D Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL1", true, 41)  --  Unlock for Qubism Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL1", true, 42)  --  Unlock for God Of QUB3D Tee
	stats.set_bool_masked(MPX .. "HEIST3TATTOOSTAT_BOOL1", true, 43)  --  Unlock for QUB3D Boxart Tee
	stats.set_bool_masked(MPX .. "SU20TATTOOSTAT_BOOL1", true, 10)  --  Unlock for Faces of Death Tee
	stats.set_bool_masked(MPX .. "SU20TATTOOSTAT_BOOL1", true, 11)  --  Unlock for Straight to Video Tee
	stats.set_bool_masked(MPX .. "SU20TATTOOSTAT_BOOL1", true, 12)  --  Unlock for Monkey See Monkey Die Tee
	stats.set_bool_masked(MPX .. "SU20TATTOOSTAT_BOOL1", true, 13)  --  Unlock for Trained to Kill Tee
	stats.set_bool_masked(MPX .. "SU20TATTOOSTAT_BOOL1", true, 14)  --  Unlock for The Director Tee
end)
 
local CSYONS8i = CSYONS8:add_submenu("2022 Halloween UFOs Event")

CSYONS8i:add_action("Instructions UFOs Event", function() end)
CSYONS8i:add_action("Start an invite only session", function() end)
CSYONS8i:add_action("Make sure the time is between 10 PM and 4 AM", function() end)
CSYONS8i:add_action("Enable the event", function() end)
CSYONS8i:add_action("Select which UFOs you want to spawn", function() end)
CSYONS8i:add_action("Wait a couple minutes", function() end)
CSYONS8i:add_action("Take photos or get abducted", function() end)
CSYONS8i:add_action("", function() end)

CSYONS8i:add_toggle("2022 Halloween UFOs Event", function()
    return globals.get_int(mainGlobal) == mainGlobalNewValue
end, function()
    if globals.get_int(mainGlobal) ~= mainGlobalNewValue then
        globals.set_int(mainGlobal, mainGlobalNewValue)
    else
        globals.set_int(mainGlobal, mainGlobalOriginalValue)
    end
end)

CSYONS8i:add_action("1 Paleto Bay", function()
    globals.set_int(ufoSelectorGlobal, 19278)
end)
 
CSYONS8i:add_action("2 Above sunken UFO near Paleto Bay", function()
    globals.set_int(ufoSelectorGlobal, 19279)
end)
 
CSYONS8i:add_action("3 Mount Chiliad", function()
    globals.set_int(ufoSelectorGlobal, 19280)
end)
 
CSYONS8i:add_action("4* El Gordo Lighthouse", function()
    globals.set_int(ufoSelectorGlobal, 19281)
end)
 
CSYONS8i:add_action("5 Altruist Camp", function()
    globals.set_int(ufoSelectorGlobal, 19282)
end)
 
CSYONS8i:add_action("6 Silent Probe Mountain in Sandy Shores", function()
    globals.set_int(ufoSelectorGlobal, 19283)
end)
 
CSYONS8i:add_action("7* Satellite Relay Station off Route 68", function()
    globals.set_int(ufoSelectorGlobal, 19284)
end)
 
CSYONS8i:add_action("8 Gunrunning UFO Crash Site south of Fort Zancudo", function()
    globals.set_int(ufoSelectorGlobal, 19285)
end)
 
CSYONS8i:add_action("8,9* Shack (Grand Senora Desert) and Gunrunning UFO Crash Sight", function()
    globals.set_int(ufoSelectorGlobal, 19286)
end)
 
CSYONS8i:add_action("10 Patriot House near Redwood Lights Track", function()
    globals.set_int(ufoSelectorGlobal, 19287)
end)
 
CSYONS8i:add_action("11 Farm off Baytree Canyon Road", function()
    globals.set_int(ufoSelectorGlobal, 19288)
end)
 
CSYONS8i:add_action("12 Palmer-Taylor Power Station", function()
    globals.set_int(ufoSelectorGlobal, 19289)
end)
 
CSYONS8i:add_action("1,2,3 Paleto area", function()
    globals.set_int(ufoSelectorGlobal, 19290)
end)
 
CSYONS8i:add_action("5,8,11 Altruist Camp, Fort Zancudo and Farm", function()
    globals.set_int(ufoSelectorGlobal, 19291)
end)
 
CSYONS8i:add_action("6,10,12 East Blaine County", function()
    globals.set_int(ufoSelectorGlobal, 19292)
end)
 
CSYONS8i:add_action("13-17 Kortz Center, Galileo Observatory, Vinewood Sign, Land Act Dam, and NOOSE Headquarters"
    , function()
    globals.set_int(ufoSelectorGlobal, 19293)
end)
 
CSYONS8i:add_action("13-26 Fourteen UFOs all across Los Santos", function()
    globals.set_int(ufoSelectorGlobal, 19294)
end)
 
CSYONS8:add_action("Unlock Rare Parachutes", function()
	stats.set_bool_masked(MPX .. "TUNERPSTAT_BOOL1", true, 20)  --  Unlock for Sprunk Chute Bag*
	stats.set_bool_masked(MPX .. "TUNERPSTAT_BOOL1", true, 21)  --  Unlock for eCola Chute Bag*
	stats.set_bool_masked(MPX .. "TUNERPSTAT_BOOL1", true, 22)  --  Unlock for Halloween Chute Bag*
	stats.set_bool_masked(MPX .. "TUNERPSTAT_BOOL1", true, 23)  --  Unlock for Sprunk Chute
	stats.set_bool_masked(MPX .. "TUNERPSTAT_BOOL1", true, 24)  --  Unlock for eCola Chute
	stats.set_bool_masked(MPX .. "TUNERPSTAT_BOOL1", true, 25)  --  Unlock for Halloween Chute
end)
 
CSYONS8:add_action("Unlock Rare Progress", function()
	stats.set_bool_masked(MPX .. "PSTAT_BOOL0", true, 31)  --  Unlock for Give cash to someone
end)

CSYONS4:add_action("Weapon Mod", weaponMod)
menu.register_hotkey(103, weaponMod)
--Press num7 to Weapon Mod

giverp()
local enn = false CSYONS2:add_toggle("Automatically Skip Cutscene", function() return enn end, function(value) enn = value end)
local function giverp()
    if enn then
      menu.end_cutscene()
    end
end
menu.register_hotkey(107, function() loop() end) -- Add key Nummeric +

CSYONS11:add_action("Get Partner", GetCopPartner)

CSYONS8:add_action("Unlock Double Action Revolver",function()
if (stats.get_masked_int(MPX.."GANGOPSPSTAT_INT102", 24, 8)<3) then
	stats.set_masked_int(MPX.."GANGOPSPSTAT_INT102", 3, 24, 8)
end
if (stats.get_masked_int(MPX.."GANGOPSPSTAT_INT102", 24, 8) > 3) then
	stats.set_masked_int(MPX.."GANGOPSPSTAT_INT102", 0, 24, 8)
end
end)
	
CSYONS8:add_action("Unlock Stone Hatchet",function()
if (stats.get_masked_int("MP_NGDLCPSTAT_INT0", 16, 8)<5)then
	stats.set_masked_int("MP_NGDLCPSTAT_INT0", 5, 16, 8)
end
if (stats.get_masked_int("MP_NGDLCPSTAT_INT0", 16, 8)>5)then
	stats.set_masked_int("MP_NGDLCPSTAT_INT0", 0, 16, 8)
end	
end)


CSYONS8:add_action("Unlock Guns liveris", function()
	stats.set_int(	MPX .. "CHAR_WEAP_UNLOCKED", -1)
	stats.set_int(MPX .. "CHAR_WEAP_UNLOCKED2", -1)
	stats.set_int(MPX .. "CHAR_WEAP_UNLOCKED3", -1)
	stats.set_int(MPX .. "CHAR_WEAP_UNLOCKED4", -1)
	stats.set_int(MPX .. "CHAR_WEAP_ADDON_1_UNLCK", -1)
	stats.set_int(MPX .. "CHAR_WEAP_ADDON_2_UNLCK", -1)
	stats.set_int(MPX .. "CHAR_WEAP_ADDON_3_UNLCK", -1)
	stats.set_int(MPX .. "CHAR_WEAP_ADDON_4_UNLCK", -1)
	stats.set_int(MPX .. "CHAR_WEAP_FREE", -1)
	stats.set_int(MPX .. "CHAR_WEAP_FREE2", -1)
	stats.set_int(MPX .. "CHAR_FM_WEAP_FREE", -1)
	stats.set_int(MPX .. "CHAR_FM_WEAP_FREE2", -1)
	stats.set_int(MPX .. "CHAR_FM_WEAP_FREE3", -1)
	stats.set_int(MPX .. "CHAR_FM_WEAP_FREE4", -1)
	stats.set_int(MPX .. "CHAR_WEAP_PURCHASED", -1)
	stats.set_int(MPX .. "CHAR_WEAP_PURCHASED2", -1)
	stats.set_int(MPX .. "WEAPON_PICKUP_BITSET", -1)
	stats.set_int(MPX .. "WEAPON_PICKUP_BITSET2", -1)
	stats.set_int(MPX .. "CHAR_FM_WEAP_UNLOCKED", -1)
	stats.set_int(MPX .. "NO_WEAPONS_UNLOCK", -1)
	stats.set_int(MPX .. "NO_WEAPON_MODS_UNLOCK", -1)
	stats.set_int(MPX .. "NO_WEAPON_CLR_MOD_UNLOCK", -1) 
	stats.set_int(MPX .. "CHAR_FM_WEAP_UNLOCKED2", -1)
	stats.set_int(MPX .. "CHAR_FM_WEAP_UNLOCKED3", -1)
	stats.set_int(MPX .. "CHAR_FM_WEAP_UNLOCKED4", -1)
	stats.set_int(MPX .. "CHAR_KIT_1_FM_UNLCK", -1)
	stats.set_int(MPX .. "CHAR_KIT_2_FM_UNLCK", -1)
	stats.set_int(MPX .. "CHAR_KIT_3_FM_UNLCK", -1)
	stats.set_int(MPX .. "CHAR_KIT_4_FM_UNLCK", -1)
	stats.set_int(MPX .. "CHAR_KIT_5_FM_UNLCK", -1)
	stats.set_int(MPX .. "CHAR_KIT_6_FM_UNLCK", -1)
	stats.set_int(MPX .. "CHAR_KIT_7_FM_UNLCK", -1)
	stats.set_int(MPX .. "CHAR_KIT_8_FM_UNLCK", -1)
	stats.set_int(MPX .. "CHAR_KIT_9_FM_UNLCK", -1)
	stats.set_int(MPX .. "CHAR_KIT_10_FM_UNLCK", -1)
	stats.set_int(MPX .. "CHAR_KIT_11_FM_UNLCK", -1)
	stats.set_int(MPX .. "CHAR_KIT_12_FM_UNLCK", -1)
	stats.set_int(MPX .. "CHAR_KIT_FM_PURCHASE", -1)
	stats.set_int(MPX .. "CHAR_WEAP_FM_PURCHASE", -1)
	stats.set_int(MPX .. "CHAR_WEAP_FM_PURCHASE2", -1)
	stats.set_int(MPX .. "CHAR_WEAP_FM_PURCHASE3", -1)
	stats.set_int(MPX .. "CHAR_WEAP_FM_PURCHASE4", -1)
	stats.set_int(MPX .. "FIREWORK_TYPE_1_WHITE", 1000)
	stats.set_int(MPX .. "FIREWORK_TYPE_1_RED", 1000)
	stats.set_int(MPX .. "FIREWORK_TYPE_1_BLUE", 1000)
	stats.set_int(MPX .. "FIREWORK_TYPE_2_WHITE", 1000)
	stats.set_int(MPX .. "FIREWORK_TYPE_2_RED", 1000)
	stats.set_int(MPX .. "FIREWORK_TYPE_2_BLUE", 1000)
	stats.set_int(MPX .. "FIREWORK_TYPE_3_WHITE", 1000)
	stats.set_int(MPX .. "FIREWORK_TYPE_3_RED", 1000)
	stats.set_int(MPX .. "FIREWORK_TYPE_3_BLUE", 1000)
	stats.set_int(MPX .. "FIREWORK_TYPE_4_WHITE", 1000)
	stats.set_int(MPX .. "FIREWORK_TYPE_4_RED", 1000)
	stats.set_int(MPX .. "FIREWORK_TYPE_4_BLUE", 1000)
	stats.set_int(MPX .. "WEAP_FM_ADDON_PURCH", -1)
   for i = 2, 19 do stats.set_int(MPX .. "WEAP_FM_ADDON_PURCH"..i, -1) end
   for j = 1, 19 do stats.set_int(MPX .. "CHAR_FM_WEAP_ADDON_"..j.."_UNLCK", -1) end
   for m = 1, 41 do stats.set_int(MPX .. "CHAR_KIT_"..m.."_FM_UNLCK", -1) end
   for l = 2, 41 do stats.set_int(MPX .. "CHAR_KIT_FM_PURCHASE"..l, -1) end
end)

CSYONS8:add_action("Get all Weapons n Upgrades (Temporary)", function()
 stats.set_int(MPX .. "CHAR_WEAP_ADDON_1_UNLCK", -1)
 stats.set_int(MPX .. "CHAR_WEAP_ADDON_2_UNLCK", -1)
 stats.set_int(MPX .. "CHAR_WEAP_ADDON_3_UNLCK", -1)
 stats.set_int(MPX .. "CHAR_WEAP_ADDON_4_UNLCK", -1)
 stats.set_int(MPX .. "CHAR_WEAP_FREE", -1)
 stats.set_int(MPX .. "CHAR_WEAP_FREE2", -1)
 stats.set_int(MPX .. "CHAR_FM_WEAP_FREE", -1)
 stats.set_int(MPX .. "CHAR_FM_WEAP_FREE2", -1)
 stats.set_int(MPX .. "CHAR_FM_WEAP_FREE3", -1)
 stats.set_int(MPX .. "CHAR_FM_WEAP_FREE4", -1)
 stats.set_int(MPX .. "CHAR_WEAP_PURCHASED", -1)
 stats.set_int(MPX .. "CHAR_WEAP_PURCHASED2", -1)
 stats.set_int(MPX .. "WEAPON_PICKUP_BITSET", -1)
 stats.set_int(MPX .. "WEAPON_PICKUP_BITSET2", -1)
 stats.set_int(MPX .. "CHAR_FM_WEAP_UNLOCKED", -1)
 stats.set_int(MPX .. "NO_WEAPONS_UNLOCK", -1)
 stats.set_int(MPX .. "NO_WEAPON_MODS_UNLOCK", -1)
 stats.set_int(MPX .. "NO_WEAPON_CLR_MOD_UNLOCK", -1)
 stats.set_int(MPX .. "CHAR_KIT_FM_PURCHASE", -1)
 stats.set_int(MPX .. "CHAR_WEAP_FM_PURCHASE", -1)
 stats.set_int(MPX .. "CHAR_WEAP_FM_PURCHASE2", -1)
 stats.set_int(MPX .. "CHAR_WEAP_FM_PURCHASE3", -1)
 stats.set_int(MPX .. "CHAR_WEAP_FM_PURCHASE4", -1)
 stats.set_int(MPX .. "WEAP_FM_ADDON_PURCH", -1)
 for i = 2, 19 do
 stats.set_int(MPX .. "WEAP_FM_ADDON_PURCH"..i, -1) end
 for l = 2, 41 do
 stats.set_int(MPX .. "CHAR_KIT_FM_PURCHASE"..l, -1) end
 globals.set_int(1575015, 1)
 globals.set_int(1575015, 1)
 globals.set_int(1574589, 1) sleep(0.2)
 globals.set_int(1574589, 0) 
end)

CSYONS8:add_action("Unlock All LSC", function()
			stats.set_int(MPX .. "CHAR_FM_CARMOD_1_UNLCK", -1)
			stats.set_int(MPX .. "CHAR_FM_CARMOD_2_UNLCK", -1)
			stats.set_int(MPX .. "CHAR_FM_CARMOD_3_UNLCK", -1)
			stats.set_int(MPX .. "CHAR_FM_CARMOD_4_UNLCK", -1)
			stats.set_int(MPX .. "CHAR_FM_CARMOD_5_UNLCK", -1)
			stats.set_int(MPX .. "CHAR_FM_CARMOD_6_UNLCK", -1)
			stats.set_int(MPX .. "CHAR_FM_CARMOD_7_UNLCK", -1)
			stats.set_int(MPX .. "AWD_WIN_CAPTURES", 50)
			stats.set_int(MPX .. "AWD_DROPOFF_CAP_PACKAGES", 100)
			stats.set_int(MPX .. "AWD_KILL_CARRIER_CAPTURE", 100)
			stats.set_int(MPX .. "AWD_FINISH_HEISTS", 50)
			stats.set_int(MPX .. "AWD_FINISH_HEIST_SETUP_JOB", 50)
			stats.set_int(MPX .. "AWD_NIGHTVISION_KILLS", 100)
			stats.set_int(MPX .. "AWD_WIN_LAST_TEAM_STANDINGS", 50)
			stats.set_int(MPX .. "AWD_ONLY_PLAYER_ALIVE_LTS", 50)
			stats.set_int(MPX .. "AWD_FMRALLYWONDRIVE", 25)
			stats.set_int(MPX .. "AWD_FMRALLYWONNAV", 25)
			stats.set_int(MPX .. "AWD_FMWINSEARACE", 25)
			stats.set_int(MPX .. "AWD_RACES_WON", 50)
			stats.set_int(MPX .. "MOST_FLIPS_IN_ONE_JUMP", 5)
			stats.set_int(MPX .. "MOST_SPINS_IN_ONE_JUMP", 5)
			stats.set_int(MPX .. "NUMBER_SLIPSTREAMS_IN_RACE", 100)
			stats.set_int(MPX .. "NUMBER_TURBO_STARTS_IN_RACE", 50)
			stats.set_int(MPX .. "RACES_WON", 50)
			stats.set_int(MPX .. "USJS_COMPLETED", 50)
			stats.set_int(MPX .. "USJS_FOUND", 50)
			stats.set_int(MPX .. "USJS_TOTAL_COMPLETED", 50)
			stats.set_int(MPX .. "AWD_FM_GTA_RACES_WON", 50)
			stats.set_int(MPX .. "AWD_FM_RACE_LAST_FIRST", 25)
			stats.set_int(MPX .. "AWD_FM_RACES_FASTEST_LAP", 50)
			stats.set_int(MPX .. "AWD_FMBASEJMP", 25)
			stats.set_int(MPX .. "AWD_FMWINAIRRACE", 25)
			stats.set_int(MPX .. "TOTAL_RACES_WON", 50) end)

CSYONS2:add_action("Unlock All Bunker(Tempo)", function()
		for j = 0, 63 do
			stats.set_bool_masked(MPX .. "DLCGUNPSTAT_BOOL0", true, j, MPX)
			stats.set_bool_masked(MPX .. "DLCGUNPSTAT_BOOL1", true, j, MPX)
			stats.set_bool_masked(MPX .. "DLCGUNPSTAT_BOOL2", true, j, MPX)
			stats.set_bool_masked(MPX .. "GUNTATPSTAT_BOOL0", true, j, MPX)
			stats.set_bool_masked(MPX .. "GUNTATPSTAT_BOOL1", true, j, MPX)
			stats.set_bool_masked(MPX .. "GUNTATPSTAT_BOOL2", true, j, MPX)
			stats.set_bool_masked(MPX .. "GUNTATPSTAT_BOOL3", true, j, MPX)
			stats.set_bool_masked(MPX .. "GUNTATPSTAT_BOOL4", true, j, MPX)
			stats.set_bool_masked(MPX .. "GUNTATPSTAT_BOOL5", true, j, MPX) end end)

	 CSYONS8:add_array_item("Bunker Research", {"Speed Up", "Reset Speed"}, function()
                               return xox_26 end, function(value)
                               if value == 1
                               then
                               globals.set_int(BRE1,  1)
                               globals.set_int(BRE2,  1)
                               globals.set_int(BRE3,  1)
                               globals.set_int(BRE4,  1)
                               globals.set_int(BRE5,  0)
                               globals.set_int(BRE6,  0)
                               menu.trigger_bunker_research()
                               elseif value == 2 then globals.set_int(BRE1, 60)
                               globals.set_int(BRE3,  45000)
                               globals.set_int(BRE2,  300000)
                               globals.set_int(BRE4,  45000)
                               globals.set_int(BRE5,  2)
                               globals.set_int(BRE6,  1)
                               end xox_26 = value
                               end)

CSYONS2:add_action("Unlock Denim Jackets Drug wars dlc",
    function()
        denim_jackets_CSYON()
    end
)

CSYONS2:add_action("Unlock Designer Jeans Drug wars dlc",
    function()
        designer_jeans_CSYON()
    end
)

CSYONS2:add_action("Unlock Designer Jean Drug wars dlc",
    function()
        designer_jeans2_CSYON()
    end
)

CSYONS2:add_action("Unlock 25 Ski mask Drug wars dlc",
    function()
        twentyfive_SkiMask_CSYON()
    end
)

CSYONS2:add_action("Unlock Own Worst Enemy 60",
    function()
        Own_Worst_Enemy_CSYON()
    end
)

CSYONS2:add_action("Unlock Stashes to Stashes 50",
    function()
        Stashes_to_Stashes_CSYON()
    end
)

CSYONS2:add_action("Unlock Here Comes the Drop 50",
    function()
        Here_Comes_the_Drop_CSYON()
    end
)

CSYONS2:add_action("Unlock Good Samarithan 5",
    function()
        Good_Samarithan_CSYON()
    end
)

CSYONS2:add_action("Unlock Last Dose Awards",
    function()
        Last_Dose_Awards_CSYON()
    end
)

CSYONS2:add_action("Unlock Taxi Awards 50 / 10",
    function()
        Taxi_Awards_CSYON()
    end
)

-- executes main protection set_bools on load-in of this script
protection()
 
-- executes main protection set_bools on player change
menu.register_callback('OnPlayerChanged', function() protection() end)
 
-- the following toggle adds additional protections though if active they can break some Missions + Heists
CSYONS6:add_toggle('ADDL PROTECTIONS - can break Missions + Heists', function()
	return protections_bool
	end, function()
	protections_bool = not protections_bool
	globals.set_bool(base_address + 544, protections_bool) -- clear wanted
	globals.set_bool(base_address + 546, protections_bool) -- off the radar
	globals.set_bool(base_address + 347, protections_bool) -- teleport
	globals.set_bool(base_address + 744, protections_bool) -- teleport 
 
end)

CSYONS8:add_action("Unlock Casino Heist|", function()
	stats.set_int(MPX.."CAS_HEIST_FLOW", -1610744257)
end)

CSYONS2:add_toggle("Remove AutoShop Cooldown", function()
        return isRemoved
    end,
    function()
        isRemoved = not isRemoved
        removeCooldown(isRemoved)
    end
)

CSYONS2:add_toggle("Fast Respawn", function()
    return isRunning
end, toggleFastRespawn)

local enabled = true
CSYONS10:add_action("--- reset level ---", function() end)
local first = true
local function resetmenu()
               CSYONS10:clear()
               CSYONS10:add_action("--- reset level ---", function() end)
               enabled = not enabled

               CSYONS10:add_toggle("Reset level to 5", function() return enabled end,function()local mpIndex = globals.get_int(1574915) 
                    if mpIndex ~= nil then
                        if mpIndex > 1 or mpIndex < 0 then
                            return
                        end
                        enabled = not enabled
                        local newRP = globals.get_int(294355 + 5) + 100
                        if mpIndex == 0 then
						    stats.set_int("MP1_CHAR_SET_RP_GIFT_ADMIN", newRP)
                            stats.set_int("MP0_CHAR_SET_RP_GIFT_ADMIN", newRP)
                        else
						    stats.set_int("MP1_CHAR_SET_RP_GIFT_ADMIN", newRP)
                            stats.set_int("MP0_CHAR_SET_RP_GIFT_ADMIN", newRP)
                        end
                        resetmenu()
                     end 
            end) 

            CSYONS10:add_toggle("Reset level to 32", function() return enabled end,function()local mpIndex = globals.get_int(1574915) 
                    if mpIndex ~= nil then
                        if mpIndex > 1 or mpIndex < 0 then
                            return
                        end
                        enabled = not enabled
                        local newRP = 200000
                        if mpIndex == 0 then
                            stats.set_int("MP1_CHAR_SET_RP_GIFT_ADMIN", newRP)
							stats.set_int("MP0_CHAR_SET_RP_GIFT_ADMIN", newRP)
                        else
                            stats.set_int("MP1_CHAR_SET_RP_GIFT_ADMIN", newRP)
							stats.set_int("MP0_CHAR_SET_RP_GIFT_ADMIN", newRP)
                        end
                        resetmenu()
                     end 
            end)
            
            CSYONS10:add_toggle("Reset level to 75", function() return enabled end,function()local mpIndex = globals.get_int(1574915) 
                    if mpIndex ~= nil then
                        if mpIndex > 1 or mpIndex < 0 then
                            return
                        end
                        enabled = not enabled
                        local newRP = 938715
                        if mpIndex == 0 then
                            stats.set_int("MP1_CHAR_SET_RP_GIFT_ADMIN", newRP)
							stats.set_int("MP0_CHAR_SET_RP_GIFT_ADMIN", newRP)
                        else
                            stats.set_int("MP1_CHAR_SET_RP_GIFT_ADMIN", newRP)
							stats.set_int("MP0_CHAR_SET_RP_GIFT_ADMIN", newRP)
                        end
                        resetmenu()
                     end 
            end) 
            
            CSYONS10:add_int_range("Set custom rp level ", 10000, 538715, 80000000, function() return 1 end, function(value)
            local mpIndex = globals.get_int(1574907) 
                    if mpIndex ~= nil then
                        if mpIndex > 1 or mpIndex < 0 then
                            return
                        end
                        enabled = not enabled
                        local newRP = value
                        if mpIndex == 0 then
                            stats.set_int("MP0_CHAR_SET_RP_GIFT_ADMIN", newRP)
							stats.set_int("MP1_CHAR_SET_RP_GIFT_ADMIN", newRP)
                        else
							stats.set_int("MP0_CHAR_SET_RP_GIFT_ADMIN", newRP)
                            stats.set_int("MP1_CHAR_SET_RP_GIFT_ADMIN", newRP)
                        end
                        resetmenu()
                     end 
            end)
            
            
            if first then
                first = false
            else
                CSYONS10:add_action("--- now join a new session! ---", function() end)
            end
end
resetmenu()

CSYONS10:add_action("Unlock all with 120 level", function()
	mpIndex = globals.get_int(1574907)
	if mpIndex == 0 then
		stats.set_int("MP0_CHAR_SET_RP_GIFT_ADMIN", 2165850 )
	else
		stats.set_int("MP1_CHAR_SET_RP_GIFT_ADMIN", 2165850 )
	end
end)

CSYONS10:add_action("444 level", function()
	mpIndex = globals.get_int(1574907)
	if mpIndex == 0 then
		stats.set_int("MP0_CHAR_SET_RP_GIFT_ADMIN", 14372550 )
		stats.set_int("MP1_CHAR_SET_RP_GIFT_ADMIN", 14372550 )
	else
		stats.set_int("MP1_CHAR_SET_RP_GIFT_ADMIN", 14372550 )
		stats.set_int("MP0_CHAR_SET_RP_GIFT_ADMIN", 14372550 )
	end
end)

CSYONS10:add_action("666 level", function()
	mpIndex = globals.get_int(1574907)
	if mpIndex == 0 then
		stats.set_int("MP0_CHAR_SET_RP_GIFT_ADMIN", 25766700 )
		stats.set_int("MP1_CHAR_SET_RP_GIFT_ADMIN", 25766700 )
	else
		stats.set_int("MP1_CHAR_SET_RP_GIFT_ADMIN", 25766700 )
		stats.set_int("MP0_CHAR_SET_RP_GIFT_ADMIN", 25766700 )
	end
end)

CSYONS10:add_action("7999 level", function()
	mpIndex = globals.get_int(1574907)
	if mpIndex == 0 then
		stats.set_int("MP0_CHAR_SET_RP_GIFT_ADMIN", 1787153300 )
		stats.set_int("MP1_CHAR_SET_RP_GIFT_ADMIN", 1787153300 )
	else
		stats.set_int("MP1_CHAR_SET_RP_GIFT_ADMIN", 1787153300 )
		stats.set_int("MP0_CHAR_SET_RP_GIFT_ADMIN", 1787153300 )
	end
end)

CSYONS10:add_action("8000 level", function()
	mpIndex = globals.get_int(1574907)
	if mpIndex == 0 then
		stats.set_int("MP0_CHAR_SET_RP_GIFT_ADMIN", 1787576850 )
		stats.set_int("MP1_CHAR_SET_RP_GIFT_ADMIN", 1787576850 )
	else
		stats.set_int("MP1_CHAR_SET_RP_GIFT_ADMIN", 1787576850 )
		stats.set_int("MP0_CHAR_SET_RP_GIFT_ADMIN", 1787576850 )
	end
end)

CSYONS8:add_action("Bunch of Clothing at Shops", function()
	globals.set_int(296190, 1)
	globals.set_int(296191, 1)
	globals.set_int(296192, 1)
	globals.set_int(296193, 1)
	globals.set_int(296194, 1)
	globals.set_int(296195, 1)
	globals.set_int(296196, 1)
	globals.set_int(296197, 1)
	globals.set_int(296198, 1)
	globals.set_int(296199, 1)
	globals.set_int(296200, 1)
	globals.set_int(296201, 1)
	globals.set_int(296203, 1)
	globals.set_int(296204, 1)
	globals.set_int(296206, 1)
	globals.set_int(296207, 1)
	globals.set_int(296211, 1)
	globals.set_int(296215, 1)
	globals.set_int(296223, 1)
	globals.set_int(296254, 1)
end)

CSYONS8:add_action("Biker DLC unlocks", function()
    for i = 0, 2 do
        for j = 0, 63 do
            stats.set_bool_masked(MPX .. "DLCBIKEPSTAT_BOOL" .. i, true, j)
            sleep(0.1)
        end
    end
end)

CSYONS8:add_action("Trigger TrickOrTreat", function()
    TrickOrTreat(5) -- Normal collect
end)
 
CSYONS8:add_action("Trigger TrickOrTreat 2", function()
    TrickOrTreat(11) -- No full screen text
end)
 
CSYONS8:add_action("Trigger Money", function()
    TrickOrTreat(10) -- 50k
end)
 
CSYONS8:add_action("Trigger Treat", function()
    TrickOrTreat(200) -- Only treat
end)
 
CSYONS8:add_action("Trigger Help", function()
    TrickOrTreat(0) -- Help text
end)
 
CSYONS8:add_action("Trigger Up-n-Atomizer Trick", function()
    globals.set_int(2764906 + 579, 0) -- Trick type (0-3)
    globals.set_int(2764906 + 581, 1000000) -- Time. Does nothing? afaik
    globals.set_int(2764906 + 581 + 1, 1) -- Trigger. Should be 1
end)
 
CSYONS8:add_action("Trigger Explosion Trick", function()
    globals.set_int(2764906 + 579, 1) -- Trick type (0-3)
    globals.set_int(2764906 + 581, 1000000) -- Time. Does nothing? afaik
    globals.set_int(2764906 + 581 + 1, 1) -- Trigger. Should be 1
end)
 
CSYONS8:add_action("Trigger Drugs Trick", function()
    globals.set_int(2764906 + 579, 2) -- Trick type (0-3)
    globals.set_int(2764906 + 581, 1000000) -- Time. Does nothing? afaik
    globals.set_int(2764906 + 581 + 1, 1) -- Trigger. Should be 1
end)
 
CSYONS8:add_action("Trigger Shocker Trick", function()
    globals.set_int(2764906 + 579, 3) -- Trick type (0-3)
    globals.set_int(2764906 + 581, 1000000) -- Time. Does nothing? afaik
    globals.set_int(2764906 + 581 + 1, 1) -- Trigger. Should be 1
end)

CSYONS8:add_action("Unlock Rare Tattoos Boy", function()
	stats.set_bool_masked(MPX.. "GUNTATPSTAT_BOOL2", true, 47)  --  Unlock for Alien Tattoo
	stats.set_bool_masked(MPX.. "GUNTATPSTAT_BOOL5", true, 5)  --  Unlock for Lucky 7s
	stats.set_bool_masked(MPX.. "GUNTATPSTAT_BOOL5", true, 12)  --  Unlock for The Royals
end)

CSYONS8:add_action("Unlock Rare Tattoos Girl", function()
	stats.set_bool_masked(MPX.. "GUNTATPSTAT_BOOL2", true, 58)  --  Unlock for Alien Tattoo
	stats.set_bool_masked(MPX.. "GUNTATPSTAT_BOOL5", true, 16)  --  Unlock for Lucky 7s
	stats.set_bool_masked(MPX.. "GUNTATPSTAT_BOOL5", true, 23)  --  Unlock for The Royals
end)

CSYONS8:add_action("Unlock Rare Aged T-Shirts Girl", function()
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 9)  --  Unlock for BCTR Aged Tee*
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 11)  --  Unlock for Cultstopeprs Aged Tee*
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 13)  --  Unlock for Daily Globe Aged Tee*
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 15)  --  Unlock for Eyefind Aged Tee*
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 17)  --  Unlock for Facade Aged Tee*
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 19)  --  Unlock for Fruit Aged Tee*
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 21)  --  Unlock for LSHH Aged Tee*
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 23)  --  Unlock for MyRoom Aged Tee*
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 25)  --  Unlock for Rebel Aged Tee*
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 27)  --  Unlock for Six Figure Aged Tee*
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 29)  --  Unlock for Trash Or Treasure Aged Tee*
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 31)  --  Unlock for TW@ Logo Aged Tee*
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 33)  --  Unlock for Vapers Den Aged Tee*
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 35)  --  Unlock for WingIt Aged Tee*
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 37)  --  Unlock for ZiT Aged Tee*
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 44)  --  Unlock for Channel X Aged Tee
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 45)  --  Unlock for Rebel Radio Aged Tee
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 46)  --  Unlock for LSUR Aged Tee
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 47)  --  Unlock for Steel Horse Solid Logo Aged Tee
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 48)  --  Unlock for Black Western Logo Aged Tee
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 49)  --  Unlock for White Nagasaki Aged Tee
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 50)  --  Unlock for Black Principe Aged Tee
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 51)  --  Unlock for Albany Vintage Aged Tee
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 52)  --  Unlock for Benefactor Aged Tee
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 53)  --  Unlock for Bravado Aged Tee
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 54)  --  Unlock for Declasse Aged Tee
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 55)  --  Unlock for Dinka Aged Tee
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 56)  --  Unlock for Grotti Aged Tee
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 57)  --  Unlock for Lampadati Aged Tee
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 58)  --  Unlock for Ocelot Aged Tee
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 59)  --  Unlock for Overflod Aged Tee
	stats.set_bool_masked(MPX.. "SU20TATTOOSTAT_BOOL0", true, 0)  --  Unlock for Pegassi Aged Tee
	stats.set_bool_masked(MPX.. "SU20TATTOOSTAT_BOOL0", true, 1)  --  Unlock for Pfister Aged Tee
	stats.set_bool_masked(MPX.. "SU20TATTOOSTAT_BOOL0", true, 2)  --  Unlock for Vapid Aged Tee
	stats.set_bool_masked(MPX.. "SU20TATTOOSTAT_BOOL0", true, 3)  --  Unlock for Weeny Aged Tee
	stats.set_bool_masked(MPX.. "SU20TATTOOSTAT_BOOL0", true, 4)  --  Unlock for ToeShoes Aged T-Shirt
	stats.set_bool_masked(MPX.. "SU20TATTOOSTAT_BOOL0", true, 5)  --  Unlock for Vanilla Unicorn Aged T-Shirt
	stats.set_bool_masked(MPX.. "SU20TATTOOSTAT_BOOL0", true, 6)  --  Unlock for Fake Vapid Aged T-Shirt
	stats.set_bool_masked(MPX.. "SU20TATTOOSTAT_BOOL0", true, 7)  --  Unlock for I Married My Dad Aged T-Shirt
	stats.set_bool_masked(MPX.. "SU20TATTOOSTAT_BOOL0", true, 8)  --  Unlock for White Rockstar Camo Aged Tee
	stats.set_bool_masked(MPX.. "SU20TATTOOSTAT_BOOL0", true, 9)  --  Unlock for Razor Aged T-Shirt
	stats.set_bool_masked(MPX.. "SU20TATTOOSTAT_BOOL0", true, 10)  --  Unlock for Noise Rockstar Logo Aged Tee
	stats.set_bool_masked(MPX.. "SU20TATTOOSTAT_BOOL0", true, 11)  --  Unlock for Noise Aged Tee
	stats.set_bool_masked(MPX.. "SU20TATTOOSTAT_BOOL0", true, 12)  --  Unlock for Emotion 98.3 Aged T-Shirt
	stats.set_bool_masked(MPX.. "SU20TATTOOSTAT_BOOL0", true, 13)  --  Unlock for KDST Aged T-Shirt
	stats.set_bool_masked(MPX.. "SU20TATTOOSTAT_BOOL0", true, 14)  --  Unlock for KJAH Radio Aged T-Shirt
	stats.set_bool_masked(MPX.. "SU20TATTOOSTAT_BOOL0", true, 15)  --  Unlock for Bounce FM Aged T-Shirt
	stats.set_bool_masked(MPX.. "SU20TATTOOSTAT_BOOL0", true, 16)  --  Unlock for K-Rose Aged T-Shirt
	stats.set_bool_masked(MPX.. "SU20TATTOOSTAT_BOOL0", true, 17)  --  Unlock for Blue The Diamond Resort LS Aged Tee
end)

CSYONS8:add_action("Unlock Rare Aged T-Shirts Boy", function()
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL0", true, 62)  --  Unlock for BCTR Aged Tee*
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 0)  --  Unlock for Cultstopeprs Aged Tee*
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 2)  --  Unlock for Daily Globe Aged Tee*
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 4)  --  Unlock for Eyefind Aged Tee*
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 6)  --  Unlock for Facade Aged Tee*
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 8)  --  Unlock for Fruit Aged Tee*
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 10)  --  Unlock for LSHH Aged Tee*
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 12)  --  Unlock for MyRoom Aged Tee*
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 14)  --  Unlock for Rebel Aged Tee*
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 16)  --  Unlock for Six Figure Aged Tee*
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 18)  --  Unlock for Trash Or Treasure Aged Tee*
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 20)  --  Unlock for TW@ Logo Aged Tee*
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 22)  --  Unlock for Vapers Den Aged Tee*
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 24)  --  Unlock for WingIt Aged Tee*
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 26)  --  Unlock for ZiT Aged Tee*
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 33)  --  Unlock for Channel X Aged Tee
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 34)  --  Unlock for Rebel Radio Aged Tee
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 35)  --  Unlock for LSUR Aged Tee
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 36)  --  Unlock for Steel Horse Solid Logo Aged Tee
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 37)  --  Unlock for Black Western Logo Aged Tee
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 38)  --  Unlock for White Nagasaki Aged Tee
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 39)  --  Unlock for Black Principe Aged Tee
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 40)  --  Unlock for Albany Vintage Aged Tee
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 41)  --  Unlock for Benefactor Aged Tee
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 42)  --  Unlock for Bravado Aged Tee
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 43)  --  Unlock for Declasse Aged Tee
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 44)  --  Unlock for Dinka Aged Tee
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 45)  --  Unlock for Grotti Aged Tee
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 46)  --  Unlock for Lampadati Aged Tee
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 47)  --  Unlock for Ocelot Aged Tee
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 48)  --  Unlock for Overflod Aged Tee
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 49)  --  Unlock for Pegassi Aged Tee
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 50)  --  Unlock for Pfister Aged Tee
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 51)  --  Unlock for Vapid Aged Tee
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 52)  --  Unlock for Weeny Aged Tee
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 53)  --  Unlock for ToeShoes Aged T-Shirt
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 54)  --  Unlock for Vanilla Unicorn Aged T-Shirt
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 55)  --  Unlock for Fake Vapid Aged T-Shirt
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 56)  --  Unlock for I Married My Dad Aged T-Shirt
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 57)  --  Unlock for White Rockstar Camo Aged Tee
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 58)  --  Unlock for Razor Aged T-Shirt
	stats.set_bool_masked(MPX.. "HEIST3TATTOOSTAT_BOOL1", true, 59)  --  Unlock for Noise Rockstar Logo Aged Tee
	stats.set_bool_masked(MPX.. "SU20TATTOOSTAT_BOOL0", true, 0)  --  Unlock for Noise Aged Tee
	stats.set_bool_masked(MPX.. "SU20TATTOOSTAT_BOOL0", true, 1)  --  Unlock for Emotion 98.3 Aged T-Shirt
	stats.set_bool_masked(MPX.. "SU20TATTOOSTAT_BOOL0", true, 2)  --  Unlock for KDST Aged T-Shirt
	stats.set_bool_masked(MPX.. "SU20TATTOOSTAT_BOOL0", true, 3)  --  Unlock for KJAH Radio Aged T-Shirt
	stats.set_bool_masked(MPX.. "SU20TATTOOSTAT_BOOL0", true, 4)  --  Unlock for Bounce FM Aged T-Shirt
	stats.set_bool_masked(MPX.. "SU20TATTOOSTAT_BOOL0", true, 5)  --  Unlock for K-Rose Aged T-Shirt
	stats.set_bool_masked(MPX.. "SU20TATTOOSTAT_BOOL0", true, 6)  --  Unlock for Blue The Diamond Resort LS Aged Tee
end)

CSYONS2:add_action("Thank to Shiny Wasabi Kitty Claw", function() ahc() end)
ahc() --will run function on scripts reload or menu launch

CSYONS2:add_action("Refill Inventory & Armour", function()	stats.set_int(MPX .. "NO_BOUGHT_YUM_SNACKS", 30) stats.set_int(MPX .. "NO_BOUGHT_HEALTH_SNACKS", 15) stats.set_int(MPX .. "NO_BOUGHT_EPIC_SNACKS", 5) stats.set_int(MPX .. "NUMBER_OF_CHAMP_BOUGHT", 5) stats.set_int(MPX .. "NUMBER_OF_ORANGE_BOUGHT", 11) stats.set_int(MPX .. "NUMBER_OF_BOURGE_BOUGHT", 10) stats.set_int(MPX .. "CIGARETTES_BOUGHT", 20) stats.set_int(MPX .. "MP_CHAR_ARMOUR_1_COUNT", 10) stats.set_int(MPX .. "MP_CHAR_ARMOUR_2_COUNT", 10) stats.set_int(MPX .. "MP_CHAR_ARMOUR_3_COUNT", 10) stats.set_int(MPX .. "MP_CHAR_ARMOUR_4_COUNT", 10) stats.set_int(MPX .. "MP_CHAR_ARMOUR_5_COUNT", 10) stats.set_int(MPX .. "BREATHING_APPAR_BOUGHT", 20) end) 

CSYONS8:add_action("Fast Run & Reload", function() stats.set_int(MPX .. "CHAR_ABILITY_1_UNLCK", -1) stats.set_int(MPX .. "CHAR_ABILITY_2_UNLCK", -1) stats.set_int(MPX .. "CHAR_ABILITY_3_UNLCK", -1) stats.set_int(MPX .. "CHAR_FM_ABILITY_1_UNLCK", -1) stats.set_int(MPX .. "CHAR_FM_ABILITY_2_UNLCK", -1) stats.set_int(MPX .. "CHAR_FM_ABILITY_3_UNLCK", -1) globals.set_int(1575015, 1) globals.set_int(1575015, 1) sleep(0.2) globals.set_int(1575015, 0) end) 
CSYONS8:add_action("Reset Fast Run & Reload", function() stats.set_int(MPX .. "CHAR_ABILITY_1_UNLCK", 0) stats.set_int(MPX .. "CHAR_ABILITY_2_UNLCK", 0) stats.set_int(MPX .. "CHAR_ABILITY_3_UNLCK", 0) stats.set_int(MPX .. "CHAR_FM_ABILITY_1_UNLCK", 0) stats.set_int(MPX .. "CHAR_FM_ABILITY_2_UNLCK", 0) stats.set_int(MPX .. "CHAR_FM_ABILITY_3_UNLCK", 0) globals.set_int(1575015, 1) globals.set_int(1575015, 1) sleep(0.2) globals.set_int(1575015, 0) end)

function fx() globals.set_bool(1669394 + 792, true) globals.set_bool(1669394 + 504, true) end
fx() menu.register_callback('OnPlayerChanged', fx)

--menu.register_callback('OnPlayerChanged', function()
  --  globals.set_bool(1669394 + 792, true)
    --globals.set_bool(1669394 + 504, true)
--end)

CSYONS8:add_action("Unlock stuff hidden behind packed bools", function()
	for i = 0, 63 do
		stats.set_bool_masked(MPX .. "DLC22022PSTAT_BOOL1", true, i)
		stats.set_bool_masked(MPX .. "DLC22022PSTAT_BOOL2", true, i)
		stats.set_bool_masked(MPX .."DLC22022PSTAT_BOOL", true, i)
		stats.set_bool_masked(36788,true, -1, MPX)
		stats.set_int(MPX .."DLC22022PSTAT_INT"..i, 1)
		
	end
end)

CSYONS2:add_action("Revive All Dead Cars", function()
    for v in replayinterface.get_vehicles() do
        if v ~= nil then
            v:set_health(1000)
        end
    end
end)

-----
Spawner= CSYONS5:add_submenu("Vehicles Spawner")

RS = Spawner:add_submenu("Request Services")

CSYONS5:add_action("Spawn Avenger", function() menu.deliver_avenger() end)
CSYONS5:add_action("Spawn Kosatska", function() menu.deliver_kosatka() end)
CSYONS5:add_action("Spawn Mobile Command Center", function() menu.deliver_moc() end)
CSYONS5:add_action("Spawn Terrorbyte", function() menu.deliver_terrorbyte() end)

RS3 = Spawner:add_submenu("Kosatka Vehicle")

CSYONS5:add_action("Deliver Kosatka Avisa Submarine", function() menu.deliver_avisa() end)
CSYONS5:add_action("Deliver Kosatka Dinghy", function() menu.deliver_dinghy() end)
CSYONS5:add_action("Deliver Kostaka Sea Sparrow", function() menu.deliver_seasparrow() end)

local a={}
a={}a[joaat("BOOR")]="Karin Boor"
a[joaat("BRICKADE2")]="MTL Brickade 6x6"
a[joaat("BROADWAY")]="Classique Broadway"
a[joaat("EUDORA")]="Willard Eudora"
a[joaat("EVERON2")]="Karin Hotring Everon"
a[joaat("ISSI8")]="Weeny Issi Rally"
a[joaat("PANTHERE")]="Toundra Panthere"
a[joaat("POWERSURGE")]="Western Powersurge"
a[joaat("TAHOMA")]="Declasse Tahoma Coupe"
a[joaat("VIRTUE")]="Ocelot Virtue" 
local b={}
b={}b[joaat("BOOR")]=33972;
b[joaat("BRICKADE2")]=33962;
b[joaat("BROADWAY")]=33967;
b[joaat("EUDORA")]=33971;
b[joaat("EVERON2")]=33969;
b[joaat("ISSI8")]=33966;
b[joaat("PANTHERE")]=33968;
b[joaat("POWERSURGE")]=33965;
b[joaat("TAHOMA")]=33964;
b[joaat("VIRTUE")]=33970;

function SpawnVehicles(c)local d=b[c]globals.set_int(2694562+d,1)
	local e=localplayer:get_position()local 
	f=localplayer:get_heading()e.x=e.x+f.x*5;e.y=e.y+f.y*5;globals.set_int(2639783+46,c)globals.set_float(2639783+42,e.x)globals.set_float(2639783+43,e.y)globals.set_float(2639783+44,e.z)globals.set_boolean(2639783+41,true)end;local g=Spawner:add_submenu("Los Santos Drug Wars")for h,i in pairs(a)do g:add_action(i,function()SpawnVehicle(h)end)end


CSYONS5 = CSYON5:add_submenu("Wheels Mod Section")

F1Mod = false
OldF1Hash = 0
CSYONS5:add_toggle("F1 - Covers", function()
	return F1Mod
end, function()
	F1Mod = not F1Mod
	if F1Mod then
		if localplayer ~= nil then
			if localplayer:is_in_vehicle() then
				OldF1Hash = localplayer:get_current_vehicle():get_model_hash()
				localplayer:get_current_vehicle():set_model_hash(1492612435)
			end
		end
	else
		if localplayer ~= nil then
			if localplayer:is_in_vehicle() then
				localplayer:get_current_vehicle():set_model_hash(OldF1Hash)
			end
		end
	end
end)

F1Mod = false
OldF1Hash = 0
CSYONS5:add_toggle("F1 - Covers v2", function()
return F1Mod
end, function()
F1Mod = not F1Mod
if F1Mod then
if localplayer ~= nil then
if localplayer:is_in_vehicle() then
OldF1Hash = localplayer:get_current_vehicle():get_model_hash()
localplayer:get_current_vehicle():set_model_hash(1492612435)
end
end
else
if localplayer ~= nil then
if localplayer:is_in_vehicle() then
localplayer:get_current_vehicle():set_model_hash(OldF1Hash)
end
end
end
end)

BennyMod = false
OldBennyHash = 0
CSYONS5:add_toggle("Bennys - Covers", function()
return BennyMod
end, function()
BennyMod = not BennyMod
if BennyMod then
if localplayer ~= nil then
if localplayer:is_in_vehicle() then
OldBennyHash = localplayer:get_current_vehicle():get_model_hash()
localplayer:get_current_vehicle():set_model_hash(196747873)
end
end
else
if localplayer ~= nil then
if localplayer:is_in_vehicle() then
localplayer:get_current_vehicle():set_model_hash(OldBennyHash)
end
end
end
end)

BennyMod = false
OldBennyHash = 0
CSYONS5:add_toggle("Bennys - Covers", function()
	return BennyMod
end, function()
	BennyMod = not BennyMod
	if BennyMod then
		if localplayer ~= nil then
			if localplayer:is_in_vehicle() then
				OldBennyHash = localplayer:get_current_vehicle():get_model_hash()
				localplayer:get_current_vehicle():set_model_hash(196747873)
			end
		end
	else
		if localplayer ~= nil then
			if localplayer:is_in_vehicle() then
				localplayer:get_current_vehicle():set_model_hash(OldBennyHash)
			end
		end
	end
end)

CSYONS5 = CSYON5:add_submenu("Custom Plate")

PlateChar = {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", ""}
PI1 = PlateChar[1]
PI1Current = 1
CSYONS5:add_array_item("Char #1", PlateChar, function()
	if localplayer ~= nil and localplayer:is_in_vehicle() then
		return PI1Current
	end
end, function(value)
	PI1 = PlateChar[value]
	PI1Current = value
end)


PI2 = PlateChar[1]
PI2Current = 1
CSYONS5:add_array_item("Char #2", PlateChar, function()
	if localplayer ~= nil and localplayer:is_in_vehicle() then
		return PI2Current
	end
end, function(value)
	PI2 = PlateChar[value]
	PI2Current = value
end)


PI3 = PlateChar[1]
PI3Current = 1
CSYONS5:add_array_item("Char #3", PlateChar, function()
	if localplayer ~= nil and localplayer:is_in_vehicle() then
		return PI3Current
	end
end, function(value)
	PI3 = PlateChar[value]
	PI3Current = value
end)


PI4 = PlateChar[1]
PI4Current = 1
CSYONS5:add_array_item("Char #4", PlateChar, function()
	if localplayer ~= nil and localplayer:is_in_vehicle() then
		return PI4Current
	end
end, function(value)
	PI4 = PlateChar[value]
	PI4Current = value
end)


PI5 = PlateChar[1]
PI5Current = 1
CSYONS5:add_array_item("Char #5", PlateChar, function()
	if localplayer ~= nil and localplayer:is_in_vehicle() then
		return PI5Current
	end
end, function(value)
	PI5 = PlateChar[value]
	PI5Current = value
end)


PI6 = PlateChar[1]
PI6Current = 1
CSYONS5:add_array_item("Char #6", PlateChar, function()
	if localplayer ~= nil and localplayer:is_in_vehicle() then
		return PI6Current
	end
end, function(value)
	PI6 = PlateChar[value]
	PI6Current = value
end)


PI7 = PlateChar[1]
PI7Current = 1
CSYONS5:add_array_item("Char #7", PlateChar, function()
	if localplayer ~= nil and localplayer:is_in_vehicle() then
		return PI7Current
	end
end, function(value)
	PI7 = PlateChar[value]
	PI7Current = value
end)


PI8 = PlateChar[1]
PI8Current = 1
CSYONS5:add_array_item("Char #8", PlateChar, function()
	if localplayer ~= nil and localplayer:is_in_vehicle() then
		return PI8Current
	end
end, function(value)
	PI8 = PlateChar[value]
	PI8Current = value
end)


CSYONS5:add_bare_item("", function()
	return "Apply plate: " .. PI1 .. PI2 .. PI3 .. PI4 .. PI5 .. PI6 .. PI7 .. PI8
end, function()
	if localplayer ~= nil and localplayer:is_in_vehicle() then
		localplayer:get_current_vehicle():set_number_plate_text(PI1 .. PI2 .. PI3 .. PI4 .. PI5 .. PI6 .. PI7 .. PI8)
	end
end, function()
end, function()
end)


CSYONS5 = CSYON5:add_submenu("Car Speed Menu")
local function superChargeVehicle()
	if localplayer == nil then
		return
	end
	
	current_vehicle = localplayer:get_current_vehicle()
		if current_vehicle ~= nil then
			current_vehicle:set_acceleration(1.59)
			current_vehicle:set_gravity(16.8)

		end
end
CSYONS5:add_action("Active Car Speed Hack", superChargeVehicle)
-----

fdGlobal = 262145+33902--First Dose Hard Mode
function mp() return "mp"..stats.get_int("MPPLY_LAST_MP_CHAR").."_" end
CSYONS2:add_array_item("Play ", {"1 - Welcome to the Troupe", "2 - Designated Driver", "3 - Fatal Incursion", "4 - Uncontrolled Substance", "5 - Make War not Love", "6 - Off the Rails"}, function() return stats.get_int(mp().."XM22_CURRENT")+1 end, function(m) stats.set_int(mp().."XM22_CURRENT",m-1) end)
CSYONS2:add_toggle("Hard Mode", function() return globals.get_boolean(fdGlobal) end, function(b) globals.set_boolean(fdGlobal,b) end)
CSYONS5:add_action("have fun By CSYON", function() end)

CSYONS9:add_toggle("Nightclub Safe Abuse $250k/10s (AFK)",
    function()
        return night
    end,
    function()
        night = not night
        clubs(night)
    end
)

CSYONS8:add_action("Unlock 1.64 Clothes",
    function()
        DrugWarsUnlockClothes_CSYON()
    end
)

CSYONS8:add_action("Unlock StreetDealer",
    function()
        StreetDealer_CSYON()
    end
)
	 
CSYONS2:add_action("Cayo Fingerprint Clone", function()
    if(script(script_name):is_active()) then
        script(script_name):set_int(cayo_fingerprint_clone, 5)
    end
end)

CSYONS2:add_action("Unlock 1.64 Baseball Bat & Knife Design",
    function()
        Baseball_Bat_and_Knife_liveries_CSYON()
    end
)
 
CSYONS2:add_action("Cayo Instant Heist Passed", function()
    if(script(script_name):is_active()) then
        script(script_name):set_int(cayo_instant_heist_passed_trigger, 9)
        script(script_name):set_int(cayo_instant_heist_passed_value, 50)
    end
end)
	 
	CSYONS8:add_int_range("XMAS Mugger Event(Gooch)", 171, 0, 171, function() 
    	return globals.get_int(2756259+3+1)
    end, function(value)
    	globals.set_int(2756259+3+1, value)
		globals.set_int(2756259+2, 6)
    end)
	
CSYONS2:add_int_range("Bank Shootout Event", 172, 0, 172, function()
return globals.get_int(2756259+3+1)
end, function(value)
globals.set_int(262145+34058, 1) -- ENABLE_MAZEBANKSHOOTOUT_DLC22022
globals.set_int(2756259+3+1, value)
globals.set_int(2756259+2, 6)
end)

CSYONS8:add_action("LSCM Prize Ride Unlock", function() stats.set_bool(MPX .. "CARMEET_PV_CHLLGE_CMPLT", true) end)

CSYONS8:add_action("Unlock LSCM Rep Lvl 1000", function() for i = 293761, 293788 do globals.set_float(i, 100000) end end)

CSYONS2:add_action("Set Agency security missions to 500", function()
    local PlayerIndex = stats.get_int("MPPLY_LAST_MP_CHAR")
    local mpx = PlayerIndex
    if PlayerIndex == 0 then mpx = "MP0_" else mpx = "MP1_" end
    stats.set_int(mpx .. "FIXER_COUNT", 500)
end)

CSYONS2:add_int_range("Remove Kosatka Missle Cooldown", 10000, 0, 2147483647, function()
	return globals.get_int(262145 + 30175) 
end, function(value)
	globals.set_int(262145 + 30175, value)
end)
 
CSYONS2:add_int_range("Increase Kosatka Missile Range", 1000, 0, 2147483647, function()
	return globals.get_int(262145 + 30176) 
end, function(value)
	globals.set_int(262145 + 30176, value)
end)

CSYONS2:add_action("New Sessanta Vehicle", function()
	local shop_controller = script("shop_controller")
	if shop_controller and shop_controller:is_active() then
		stats.set_int("MP" .. stats.get_int("MPPLY_LAST_MP_CHAR") .. "_TUNER_CLIENT_VEHICLE_POSSIX", 1)
		base_local = 297
		-- this base_local value is current as of v1.63, 2-Nov-22, per Underd0g. note that these offsets shift slightly every update
		shop_controller:set_int(base_local + 1, 0)
		shop_controller:set_int(base_local + 2, 0)
		shop_controller:set_int(base_local + 3, 1)
		shop_controller:set_int(base_local, 3)
	end
end, function()
	return script("shop_controller"):is_active()
end)

CSYONS5:add_toggle("Horn E",function()return Horn end,function(v)
	Horn=v if v then menu.send_key_down(69)else menu.send_key_up(69)end end)

CSYONS2:add_action("Royals, Lucky 7s and Alien Tattoo", function()
	for i = 0, 63 do
		for z = 0, 05 do
			stats.set_bool_masked("MP" .. MPX.. "_GUNTATPSTAT_BOOL" .. z, true, i, MPX)
		end
	end
end)

CSYONS4:add_action("Weapon Force Hotkeynum6", weaponForce)
menu.register_hotkey(102, weaponForce)

CSYONS4:add_action("Weapon Damage Hotkeynum7", weaponDamage)
menu.register_hotkey(103, weaponDamage)
--Press num7 to Weapon Damage

CSYONS4:add_action("Weapon Ped Damage Hotkeynum8", weaponPedForce)
menu.register_hotkey(104, weaponPedForce)

CSYONS4:add_action("Weapon Heli Damage Hotkeynum9", weaponHeliForce)
menu.register_hotkey(105, weaponHeliForce)

local cars_data = {}
local function waitForVehicleData()
	local tries = 0
	while tries <= 250 do
		-- try getting a vehicle and its handling data
		veh = localplayer:get_current_vehicle()
		local temp_data = {
					veh:get_acceleration(),			--1
					veh:get_brake_force(),			--2
					veh:get_gravity(),				--3
					veh:get_handbrake_force(),		--4
					veh:get_initial_drive_force(),	--5
					veh:get_traction_curve_min(),	--6
					veh:get_traction_curve_max(),	--7
					veh:get_traction_bias_front(),	--8
					veh:get_up_shift(),				--9
					veh:get_down_shift(),			--10
					veh:get_initial_drive_max_flat_velocity(),	--11
					veh:get_centre_of_mass_offset(),			--12
					veh:get_collision_damage_multiplier(),		--13
					veh:get_engine_damage_multiplier(),			--14
					veh:get_roll_centre_height_front(),			--15	
					veh:get_roll_centre_height_rear(),			--16
					veh:get_drive_bias_front(),					--17
					veh:get_traction_loss_multiplier(),			--18
					veh:get_initial_drag_coeff()				--19
					}
		
		--do a rough check if the vehicle data we got actually makes sense, else try getting the vehicle object again
		--this is to work around a bug in Kiddions LUA vehicle implementation where often
		--the vehicle handling data in a vehicle object will be broken, leaving to bs data when using get methods
		--and being unable to change the handling later with set methods
		--once we find a working veh object, it gets saved in the table and returned so it can be used to modify on later
		if (temp_data[8] >= 0 and temp_data[8] <= 1) and
		   (temp_data[11] >= 10 and temp_data[11] <= 500) and
		   (temp_data[17] >= 0 and temp_data[17] <= 1) then
		    -- save the working veh object with model hash as key in the table so we can use it later
			temp_data[veh:get_model_hash()] = veh
			return temp_data
		end
		--try again if the data we got looked weird
		sleep(0.02)
		tries = tries + 1
	end
end
 
--functions for carboost
local cars_data = {}
local multiplier_percent = 100
local function boostVehicle(vehicle_data, hash, vehicle, boost)
	if boost then --boost mode
		accel = vehicle_data[1] * (17 * (multiplier_percent / 100))
		brake_force = vehicle_data[2] * (23 * (multiplier_percent / 100))
		gravity = 19.7
		handbrake_force = vehicle_data[4] * (14 * (multiplier_percent / 100))
		initial_drive_force = vehicle_data[5] * (690 * (multiplier_percent / 100))   --nice
		traction_min = 6 + (2 * (multiplier_percent / 100))   --very high traction. Used without roll_centre modification, the car will constantly flip
		traction_max = vehicle_data[7] + (2 * (multiplier_percent / 100))
		traction_bias_front = 0.420
		up_shift = 10000  --huge shift values, causing cars to get stuck in gear and accelerate rapidly
		down_shift = 10000
		max_flat_vel = 10000
		--mass_offset = vector3(0,2,1)  --puts the centre of mass up and in front of the car, making it more stable EDIT: actually this option is quite buggy, only gets applied on reload like vehicle_mass and causes cars to flip uncontrollably. Just gonna ignore it.
		collision_dmg_multiplier = 0
		engine_dmg_multiplier = 0
		if multiplier_percent >= 100 then
			--Dont increase the following roll_centre variables more than 100%. Makes things flip.
			multiplier_percent = 100
		end
		roll_centre_front = vehicle_data[15] + (0.300 * (multiplier_percent / 100)) --these two stop the car from rolling even at high speeds, it rolls inwards instead
		roll_centre_rear = vehicle_data[16] + (0.300 * (multiplier_percent	/ 100))
		drive_bias = 0.5   --all wheel drive
		traction_loss_mult = 1
		initial_drag_coeff = 1  --no drag forces
	else --restore mode
		accel = vehicle_data[1]
		brake_force = vehicle_data[2]
		gravity = vehicle_data[3]
		handbrake_force = vehicle_data[4]
		initial_drive_force = vehicle_data[5]
		traction_min = vehicle_data[6]
		traction_max = vehicle_data[7]
		traction_bias_front = vehicle_data[8]
		up_shift = vehicle_data[9]
		down_shift = vehicle_data[10]
		max_flat_vel = vehicle_data[11]
		--mass_offset = vehicle_data[12]
		collision_dmg_multiplier = vehicle_data[13]
		engine_dmg_multiplier = vehicle_data[14]
		roll_centre_front = vehicle_data[15]
		roll_centre_rear = vehicle_data[16]
		drive_bias = vehicle_data[17]
		traction_loss_mult = vehicle_data[18]
		initial_drag_coeff = vehicle_data[19]
	end
	
	vehicle:set_acceleration(accel)
	vehicle:set_brake_force(brake_force)
	vehicle:set_gravity(gravity)
	vehicle:set_handbrake_force(handbrake_force)
	vehicle:set_initial_drive_force(initial_drive_force)
	vehicle:set_traction_curve_min(traction_min)
	vehicle:set_traction_curve_max(traction_max)
	vehicle:set_traction_bias_front(traction_bias_front)
	vehicle:set_up_shift(up_shift)
	vehicle:set_down_shift(down_shift)
	vehicle:set_initial_drive_max_flat_velocity(max_flat_vel)
	--vehicle:set_centre_of_mass_offset(mass_offset)
	vehicle:set_roll_centre_height_front(roll_centre_front)
	vehicle:set_roll_centre_height_rear(roll_centre_rear)
	vehicle:set_drive_bias_front(drive_bias)
	vehicle:set_collision_damage_multiplier(collision_dmg_multiplier)
	vehicle:set_engine_damage_multiplier(engine_dmg_multiplier)
	vehicle:set_traction_loss_multiplier(traction_loss_mult)
	vehicle:set_initial_drag_coeff(initial_drag_coeff)
	vehicle:set_max_speed(10000)
end
 
local function reloadVehicle(vehicle)
	--Check if car has been found in the table, then restore, otherwise exit
	restore = cars_data[vehicle:get_model_hash()]
	if restore then
		boostVehicle(restore, vehicle:get_model_hash(), vehicle, false)
	end
end
 
--------------------------------
--boosted car handling logic, insert key
--------------------------------
function carBoost()
	if localplayer ~= nil and localplayer:is_in_vehicle() then 
		current = localplayer:get_current_vehicle()
		if current == nil then return end
 
		--check if car has been modified already by the modified gravity value, if not, try to save and modify it
		if current:get_gravity() ~= 19.7 then
			
			::retry::
			--Save car data to map if its not in there already
			if not cars_data[current:get_model_hash()] then
				cars_data[current:get_model_hash()] = {
					current:get_acceleration(),			--1
					current:get_brake_force(),			--2
					current:get_gravity(),				--3
					current:get_handbrake_force(),		--4
					current:get_initial_drive_force(),	--5
					current:get_traction_curve_min(),	--6
					current:get_traction_curve_max(),	--7
					current:get_traction_bias_front(),	--8
					current:get_up_shift(),				--9
					current:get_down_shift(),			--10
					current:get_initial_drive_max_flat_velocity(),	--11
					current:get_centre_of_mass_offset(),			--12
					current:get_collision_damage_multiplier(),		--13
					current:get_engine_damage_multiplier(),			--14
					current:get_roll_centre_height_front(),			--15	
					current:get_roll_centre_height_rear(),			--16
					current:get_drive_bias_front(),					--17
					current:get_traction_loss_multiplier(),			--18
					current:get_initial_drag_coeff()				--19
					}
			end
			
			--boost car if data has been read successfully
			boostVehicle(cars_data[current:get_model_hash()], current:get_model_hash(), current, true)
			
			--Check if the boost worked, else reload the vehicle object again and try once more
			--This is usually necessary when changing to a new car of the same type, or when the old one gets destroyed and called back
			if current:get_gravity() ~= 19.7 then
				cars_data[current:get_model_hash()] = nil
				goto retry
			end
		else
			reloadVehicle(current)
		end
	end
end
 
menu.register_hotkey(45, carBoost) --Insrt key
CSYONS5:add_int_range("Car Boost strength |%", 5, 0, 690, function() return multiplier_percent end, function(value) multiplier_percent = value end)
CSYONS5:add_action("Reset all modified cars' handling", function()
	for hash, data in pairs(cars_data) do
		reloadVehicle(data[hash])
	end
end)
 
CSYONS2:add_action("Drop Ped", PedDrop)

local enable = false
local speed = 2
local function up()
	if not enable then return end
	local newpos = localplayer:get_position() + vector3(0,0,speed)
 
	if not localplayer:is_in_vehicle() then
		localplayer:set_position(newpos)
	else
		vehicle=localplayer:get_current_vehicle()
		vehicle:set_position(newpos)
	end
end
 
local function down()
	if not enable then return end
	local newpos = localplayer:get_position() + vector3(0,0,speed * -1)
 
	if not localplayer:is_in_vehicle() then
		localplayer:set_position(newpos)
	else
		vehicle=localplayer:get_current_vehicle()
		vehicle:set_position(newpos)
	end
end
 
local function forward()
	if not enable then return end
	local dir = localplayer:get_heading()
	local newpos = localplayer:get_position() + (dir * speed)
 
	if not localplayer:is_in_vehicle() then
		localplayer:set_position(newpos)
	else
		vehicle=localplayer:get_current_vehicle()
		vehicle:set_position(newpos)
	end
end
 
local function backward()
	if not enable then return end
	local dir = localplayer:get_heading()
	local newpos = localplayer:get_position() + (dir * speed * -1)
 
	if not localplayer:is_in_vehicle() then
		localplayer:set_position(newpos)
	else
		vehicle=localplayer:get_current_vehicle()
		vehicle:set_position(newpos)
	end
end
 
local function turnleft()
	if not enable then return end
	local dir = localplayer:get_rotation()
	
	if not localplayer:is_in_vehicle() then
		localplayer:set_rotation(dir + vector3(0.25,0,0))
	else
		vehicle=localplayer:get_current_vehicle()
		vehicle:set_rotation(dir + vector3(0.25,0,0))
	end
end
 
local function turnright()
	if not enable then return end
	local dir = localplayer:get_rotation()
	
	if not localplayer:is_in_vehicle() then
		localplayer:set_rotation(dir + vector3(0.25 * -1,0,0))
	else
		vehicle=localplayer:get_current_vehicle()
		vehicle:set_rotation(dir + vector3(0.25 * -1,0,0))
	end
end
 
local function increasespeed()
	if speed > 0 then 
		speed = speed + 1
	end
end
 
local function decreasespeed()
	if speed > 1 then 
		speed = speed - 1
	end
end
 
local up_hotkey ---Shift Key
local down_hotkey ---CTRL key
local forward_hotkey ---UP ARROW key
local backward_hotkey ---	DOWN ARROW key
local turnleft_hotkey ---	LEFT ARROW key
local turnright_hotkey ---RIGHT ARROW key
local increasespeed_hotkey ---Add key
local decreasespeed_hotkey ---Subtract key
 
local function NoClip(e)
	if not localplayer then return end
	if e then 
		localplayer:set_freeze_momentum(true) 
		localplayer:set_no_ragdoll(true)
		localplayer:set_config_flag(292,true)
		up_hotkey = menu.register_hotkey(16, up)
		down_hotkey = menu.register_hotkey(17, down)
		forward_hotkey = menu.register_hotkey(38, forward)
		backward_hotkey = menu.register_hotkey(40, backward)
		turnleft_hotkey = menu.register_hotkey(37, turnleft)
		turnright_hotkey = menu.register_hotkey(39, turnright)
		increasespeed_hotkey = menu.register_hotkey(107, increasespeed)
		decreasespeed_hotkey = menu.register_hotkey(109, decreasespeed)
	else
		localplayer:set_freeze_momentum(false)
		localplayer:set_no_ragdoll(false)
		localplayer:set_config_flag(292,false)
		menu.remove_hotkey(up_hotkey)
		menu.remove_hotkey(down_hotkey)
		menu.remove_hotkey(forward_hotkey)
		menu.remove_hotkey(backward_hotkey)
		menu.remove_hotkey(turnleft_hotkey)
		menu.remove_hotkey(turnright_hotkey)
		menu.remove_hotkey(increasespeed_hotkey)
		menu.remove_hotkey(decreasespeed_hotkey)
	end
end
 
menu.register_hotkey(111, function()
	enable = not enable 
	NoClip(enable)
end)
 
CSYONS7:add_action("Heal Player", function() menu.heal_all() end)
CSYONS7:add_toggle("God Mode", function() return Godmode end, function() Godmode = not Godmode localplayer:set_godmode(Godmode) end)
CSYONS7:add_action("Suicide", function() menu.suicide_player() end)
CSYONS7:add_toggle("Passive Mode", function() return PassiveMode end, function() PassiveMode = not PassiveMode menu.set_passive(PassiveMode) end)
CSYONS7:add_toggle("Off Radar", function() return Offradar end, function() Offradar = not Offradar menu.set_offradar(Offradar) end)
CSYONS7:add_toggle("Out Of Sight Area", function() return OutOfSight end, function() OutOfSight = not OutOfSight menu.set_out_of_sight(OutOfSight) end)
CSYONS7:add_toggle("Reveal All Players", function() return RevealPlayers end, function() RevealPlayers = not RevealPlayers menu.set_reveal_player(RevealPlayers) end)
CSYONS7:add_toggle("Big Map", function() return BigMap end, function() BigMap = not BigMap menu.set_big_map(BigMap) end)
CSYONS7:add_toggle("Mobile Radio", function() return MobileRadio end, function() MobileRadio = not MobileRadio menu.set_mobile_radio(MobileRadio) end)
 
CSYONS7:add_toggle("NoClip", function()
	return enable
end, function()
	enable = not enable 
	NoClip(enable)
end)
 
CSYONS7:add_int_range("NoClip Speed", 1, 1, 10, function()
	return speed
end, function(i) speed = i end)

settings = {
	protections = {
		block_socialclub_messages = true
	}
}
 
CSYONS6:add_toggle("Block Socialclub messages", function()
	return settings.protections.block_socialclub_messages
end, function(value)
	settings.protections.block_socialclub_messages = value
end)
 
function OnScriptsLoaded()
	local social_controller = script("social_controller")
	while true do
		if settings.protections.block_socialclub_messages then
			if social_controller:is_active() then
				social_controller:set_int(169, 0)
			end
		end
			
		sleep(1)
	end
end
 
menu.register_callback('OnScriptsLoaded', OnScriptsLoaded)

CSYONS2:add_action("Make Nightclub Popular", function()
	mpIndex = globals.get_int(1574907)
	if mpIndex == 0 then
		stats.set_int("mp0_club_popularity", 1000)
	else
		stats.set_int("mp1_club_popularity", 1000)
	end
end)

menu.register_hotkey(110, function()
	if localplayer ~= nil and localplayer:is_in_vehicle() then 
		vehicle = localplayer:get_current_vehicle()
		grav = vehicle:get_gravity()
		vehicle:set_gravity(-50)
		sleep(0.2)
		vehicle:set_gravity(grav)
	end
end)

CSYONS5:add_action("Heal Vehicle", function()
	if localplayer == nil then
		return
	end
	
	current_vehicle = localplayer:get_current_vehicle()
	if current_vehicle ~= nil then
		if current_vehicle:get_health() < 1000 then
			current_vehicle:set_health(1000)
		end
	end
end)

local heal_vehicle_on_change = false
CSYONS5:add_toggle("Heal Vehicle on Change", function() 
	return heal_vehicle_on_change 
end, function(value)
	heal_vehicle_on_change = value
end)
 
local function OnVehicleChanged(oldVehicle, newVehicle)
	if newVehicle ~= nil and heal_vehicle_on_change then
		if newVehicle:get_health() < 1000 then
			newVehicle:set_health(1000)
		end
	end
end
 
menu.register_callback('OnVehicleChanged', OnVehicleChanged)
 
CSYONS2:add_toggle("Snow HotkeyF12", function()
    return globals.get_boolean(snowAddress)
end, toggleSnow)
 
menu.register_hotkey(123, toggleSnow) -- F12

local casinoFinger=52962
CSYONS2:add_action("Crack Casino Fingerprint", function()
	local heist_script = script("fm_mission_controller")
	if heist_script and heist_script:is_active() then
		if heist_script:get_int(casinoFinger) == 3 or heist_script:get_int(casinoFinger) == 4 then
			heist_script:set_int(casinoFinger, 5)
		end
	end
end)

local cayoFinger=22032
CSYONS2:add_action("Crack Cayo FingerPrint Scan", function()
	local heist_script = script("fm_mission_controller_2020")
	if heist_script and heist_script:is_active() then
		if heist_script:get_int(cayoFinger) == 4 then
			heist_script:set_int(cayoFinger, 5)
		end
	end
end)

CSYONS2:add_action("Dax", function()
	        stats.set_int("MP"..MPX.."_XM22JUGGALOWORKCDTIMER", -1)
end)

CSYONS2:add_action("Summon The Grinch", function()
    globals.set_int(2756261, 171)
    globals.set_int(2756259, 6)
end)

CSYON1 = Online:add_submenu("⫸ Unlocker Cars")
local CSYONS1 = CSYON1:add_submenu("Drug Wars 1.64 DLC Vehicles")

CSYONS1:add_action("Activate San Andreas Mercenaries DLC Vehicles", function()
globals.set_int(262145+35462,1)--walton
globals.set_int(262145+35463,1)--vapid ratel
globals.set_int(262145+35464,1)--maibatsu
globals.set_int(262145+35465,1)--vapid vagon
globals.set_int(262145+35466,1)--stinger
globals.set_int(262145+35467,1)--streame216
globals.set_int(262145+35468,1)--f-160
globals.set_int(262145+35469,1)--buffalo5
globals.set_int(262145+35471,1)--penaud
globals.set_int(262145+35472,1)--conada
globals.set_int(262145+35473,1)--bravodo hotring
globals.set_int(262145+35474,1)--albany brigrham
end)

CSYONS1:add_action("Activate Drug Wars DLC Vehicles", function()
globals.set_int(262145+33957,1)--ENTITY3
globals.set_int(262145+33959,1)--JOURNEY2
globals.set_int(262145+33961,1)--annis 300r
globals.set_int(262145+33960,1)--SURFER3
globals.set_int(262145+33958,1)--TULIP2
globals.set_int(262145+33972,1)--boor
globals.set_int(262145+33962,1)--brickade2
globals.set_int(262145+33967,1)--broadway
globals.set_int(262145+33972,1)--eudora
globals.set_int(262145+33970,1)--everon2
globals.set_int(262145+33967,1)--issi8
globals.set_int(262145+33969,1)--panthere
globals.set_int(262145+33965,1)--powersurge
globals.set_int(262145+33964,1)--tahoma
globals.set_int(262145+33971,1)--virtue
globals.set_int(262145+33963,1)--taxi
globals.set_int(262145+34062,1)--Convoy
end)


CSYONS3N = CSYONS2:add_submenu("Instructions for LSCM LVL")
CSYONS3N:add_action("Buy A Membership, Activate, Sit in", function() end)

CSYONS3N:add_action("A Test Car And Go To The Track", function() end)

CSYONS3N:add_action("", function() end)

CSYONS3N:add_action("Then Activate", function() end)

CSYONS3N:add_action("And Buy Something In The LSCM Store", function() end)

CSYONS3N:add_action("", function() end)

CSYONS3N:add_action("Then Change Session To Apply Lvl 1000", function() end)

CSYONS3N:add_action("If You've Used LS Tuner Awards Unlock", function() end)

CSYONS3N:add_action("Before, All Unlocks Will Be Temporary Only", function() end)

CSYONS3N:add_action("Only", function() end)

CSYONS3N:add_action("LSCM Prize Ride Unlock", function() stats.set_bool(MPX .. "CARMEET_PV_CHLLGE_CMPLT", true) end)

CSYONS3N:add_action("Unlock LSCM Rep Lvl 1000", function() for i = 293761, 293788 do globals.set_float(i, 100000) end end)


Text("**************************************************************************")

Offlinex64 = mainMenu:add_submenu("                        **💬 Read Me 💬**                        ")
Text("**************************************************************************")

local function Text(text)
	Offlinex64:add_action(text,  function() end)
end

Offlinex6333t = Offlinex64:add_submenu("                        **🔽 Credits 🔼**                        ")

Text ("                        ** CSYON **                        ")
Text ("                        ** Thanks for Support my work**                        ")
Text ("                        ** Thanks to all for lua scripts sharing**                        ")
Text ("                        ** on Unknowncheats**                        ")


Text("**********************************************************")

Text("          🐨 UKC : CSYON")

Text("🐨 Warning : you are not allowed Copying and selling this script")

Text("**********************************************************")

Text("   🐨 Discord Server :")
Text("   🐨 https://discord.gg/JaCvtj6yQK")


Text("**********************************************************")

Text("   Download Vote in UKC A+  ")
Text("   thanks for Support  ")

Text("**********************************************************")

--────────────────────────────────────────────────────────────────────────────────────────
--─██████████████─██████████████─████████──████████─██████████████─██████──────────██████─
--─██░░░░░░░░░░██─██░░░░░░░░░░██─██░░░░██──██░░░░██─██░░░░░░░░░░██─██░░██████████──██░░██─
--─██░░██████████─██░░██████████─████░░██──██░░████─██░░██████░░██─██░░░░░░░░░░██──██░░██─
--─██░░██─────────██░░██───────────██░░░░██░░░░██───██░░██──██░░██─██░░██████░░██──██░░██─
--─██░░██─────────██░░██████████───████░░░░░░████───██░░██──██░░██─██░░██──██░░██──██░░██─
--─██░░██─────────██░░░░░░░░░░██─────████░░████─────██░░██──██░░██─██░░██──██░░██──██░░██─
--─██░░██─────────██████████░░██───────██░░██───────██░░██──██░░██─██░░██──██░░██──██░░██─
--─██░░██─────────────────██░░██───────██░░██───────██░░██──██░░██─██░░██──██░░██████░░██─
--─██░░██████████─██████████░░██───────██░░██───────██░░██████░░██─██░░██──██░░░░░░░░░░██─
--─██░░░░░░░░░░██─██░░░░░░░░░░██───────██░░██───────██░░░░░░░░░░██─██░░██──██████████░░██─
--─██████████████─██████████████───────██████───────██████████████─██████──────────██████─
--────────────────────────────────────────────────────────────────────────────────────────