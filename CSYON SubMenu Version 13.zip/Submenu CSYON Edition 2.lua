--░█████╗░░██████╗██╗░░░██╗░█████╗░███╗░░██╗
--██╔══██╗██╔════╝╚██╗░██╔╝██╔══██╗████╗░██║
--██║░░╚═╝╚█████╗░░╚████╔╝░██║░░██║██╔██╗██║
--██║░░██╗░╚═══██╗░░╚██╔╝░░██║░░██║██║╚████║
--╚█████╔╝██████╔╝░░░██║░░░╚█████╔╝██║░╚███║
--░╚════╝░╚═════╝░░░░╚═╝░░░░╚════╝░╚═╝░░╚══╝
function CheckOnlineVersion()
	major, minor, build, patch = menu.get_game_version()
	if build ~= 2944 then
		main = menu.add_submenu("⚠The game current version is: "..major.."."..minor.."."..build.."."..patch)
		main:add_submenu("Game updated!!!")
		main:add_submenu("The sctipt is outdated!!!")
	end
end
CheckOnlineVersion()
require_game_build(2944) -- GTA Online version 1.67

local function Texterrrsa(text)
	mainMenu3:add_action(text,  function() end)
end

local function Text(text)
	Online:add_action(text,  function() end)
end

local function Text(text)
	Offlinex64:add_action(text,  function() end)
end

local function Text(text)
	menu.add_action(text,  function() end)
end

-- Required Script Handles
local scrWarehouse = script("am_mp_warehouse")
local scrSellContraband = script("gb_contraband_sell")
local scrBuyContraband = script("gb_contraband_buy")
local scrSecuroServ = script("appsecuroserv")

-- get the right variable prefix
if stats.get_int("MPPLY_LAST_MP_CHAR") == 0 then
  MPX = "MP0_"
else
  MPX = "MP1_"
end

local function funcCeoBanger(isRunning)

  while isRunning == true do
    local numLifetimeSales = stats.get_int(MPX .. "LIFETIME_SELL_COMPLETE")
    if scrWarehouse:is_active() then
          globals.set_int(278108, 6000000)
          globals.set_int(277873, 0)
          globals.set_int(277874, 0)
        end
          globals.set_int(4536677,  0)
          globals.set_int(4536678,  0)
          globals.set_int(4536679,  0)


        if scrSecuroServ:is_active() then
          scrSecuroServ:set_int(737, 1)
          sleep(1)
          scrSecuroServ:set_int(738, 1)
          sleep(1)
          scrSecuroServ:set_int(556, 3012)
        end


-----------------------------------------------------------------------------------------------------------------

        if scrSellContraband:is_active() then
          scrSellContraband:set_int(1136, 1)
          scrSellContraband:set_int(596, 0)
          scrSellContraband:set_int(1125, 0)

          scrSellContraband:set_int(548, 7)
          sleep(1)
          scrSellContraband:set_int(542,  99999)
        end
      end
    end

-----------------------------------------------------------------------------------------------------------------

    if scrBuyContraband:is_active() then
        sleep(1)
        scrBuyContraband:set_int(604, 1)
        scrBuyContraband:set_int(600, 111)  
        scrBuyContraband:set_int(790, 6)
        scrBuyContraband:set_int(791, 4)
      end
-------
--local function Text(text)
--	csyons:add_action(text, function() end)
--end
-------
local autorepairvehicle = false
local function repaircar()
    if autorepairvehicle then
		current_vehicle = localplayer:get_current_vehicle()
		 current_vehicle:set_health(current_vehicle:get_max_health())
		 menu.repair_online_vehicle()
		current_vehicle:set_dirt_level(0.0)
    end 
end
---
----------
local boolall = false 
local blockSocialClubSpamState = false

local function Bounty(bool)
	globals.set_bool(1669471, bool) 
end
 
local function CeoKick(bool)
	globals.set_bool(1669984, bool) 
end
 
local function KickCrashes(bool)
	globals.set_bool(1670036, bool)
	globals.set_bool(1670051, bool)
	globals.set_bool(1669951, bool)
	globals.set_bool(1670028, bool)
	globals.set_bool(1670238, bool)
end
 
local function getKickCrashesState()
	return (globals.get_bool(1670036) and
	globals.get_bool(1670051) and
	globals.get_bool(1669951) and
	globals.get_bool(1670028) and
	globals.get_bool(1670238))
end
 
local function CeoBan(bool)
	globals.set_bool(1670006, bool) 
end
 
local function SoundSpam(bool)
	globals.set_bool(1669879, bool)
	globals.set_bool(1670243, bool)
	globals.set_bool(1669394, bool)
	globals.set_bool(1670529, bool)
	globals.set_bool(1670058, bool)
	globals.set_bool(1669421, bool)
end
 
local function getSoundSpamState()
	return (globals.get_bool(1669879) and
	globals.get_bool(1670243) and
	globals.get_bool(1669394) and
	globals.get_bool(1670529) and
	globals.get_bool(1670058) and
	globals.get_bool(1669421))
end
 
local function InfiniteLoad(bool)	
	globals.set_bool(1669947, bool) 
	globals.set_bool(1670076, bool)
end
 
local function getInfiniteLoadState()
	return (globals.get_bool(1669947) and
	globals.get_bool(1670076))
end
 
local function Collectibles(bool)
	globals.set_bool(1670208, bool) 
end
 
local function PassiveMode(bool)
	globals.set_bool(1669996, bool) 
end
 
local function TransactionError(bool) 
	globals.set_bool(1669797, bool) 
end
 
local function RemoveMoneyMessage(bool) 
	globals.set_bool(1669880, bool)
	globals.set_bool(1669426, bool)
	globals.set_bool(1670057, bool)
	globals.set_bool(1669428, bool)
end
 
local function getRemoveMoneyMessageState()
	return (globals.get_bool(1669880) and
	globals.get_bool(1669426) and
	globals.get_bool(1670057) and
	globals.get_bool(1669428))
end
 
local function ExtraTeleport(bool) 
	globals.set_bool(1669741, bool) 
	globals.set_bool(1670138, bool) 
    globals.set_bool(1670237, bool)
    globals.set_bool(1670238, bool)
    globals.set_bool(1670233, bool) 
end
 
local function getExtraTeleportState()
	return (globals.get_bool(1669741) and
	globals.get_bool(1670138) and globals.get_bool(1670237) and globals.get_bool(1670238) and globals.get_bool(1670233))
end
 
local function ClearWanted(bool) 
	globals.set_bool(1669938, bool)
end
 
local function OffTheRadar(bool) 
	globals.set_bool(1669940, bool) 
end
 
local function SendCutscene(bool) 
	globals.set_bool(1670198, bool)
end
 
local function Godmode(bool) 
	globals.set_bool(1669396, bool)
end
 
local function PersonalVehicleDestroy(bool) 
	globals.set_bool(1669480, bool)
	globals.set_bool(1670063, bool) 
	globals.set_bool(1669947, bool)
end
 
local function getPersonalVehicleDestroyState()
	return (globals.get_bool(1669480) and
	globals.get_bool(1670063) and
	globals.get_bool(1669947))
end
 
local function RemoteGlobalModification(bool)
	local setting = 0
	if bool then
		setting = 1
	end
	globals.set_int(1669394+792, setting)
	globals.set_int(1669394+504, setting)
end
 
local function getRemoteGlobalModificationState()
	return ((globals.get_int(1669394+792) == 1) and
	(globals.get_int(1669394+504) == 1))
end
 
local function BlockSocialclubSpam(bool)
	blockSocialClubSpamState = bool
end
 
local function getBlockSocialClubSpamState()
	return blockSocialClubSpamState
end
 
local function All(bool) 
	Bounty(bool)
	CeoKick(bool)
	CeoBan(bool)
	SoundSpam(bool)
	InfiniteLoad(bool)
	PassiveMode(bool)
	TransactionError(bool)
	RemoveMoneyMessage(bool)
	ClearWanted(bool)
	OffTheRadar(bool)
	PersonalVehicleDestroy(bool)
	SendCutscene(bool)
	Godmode(bool)
	Collectibles(bool)
	ExtraTeleport(bool)
	KickCrashes(bool)
	RemoteGlobalModification(bool)
	BlockSocialclubSpam(bool)
end
----------
function force_gun()
	local gun = localplayer:get_current_weapon()
	gun:set_heli_force(99900000.00)
    gun:set_ped_force(99900000.00)
    gun:set_vehicle_force(99900000.00)
end
----------
function boom_gun()
	local gun = localplayer:get_current_weapon()
	gun:set_explosion_type(1)
	gun:set_damage_type(5)
end
----------
function nuke_gun()
	local gun = localplayer:get_current_weapon()
	gun:set_explosion_type(82)
	gun:set_damage_type(5)
end
----------
function CarDrop()
	local position = localplayer:get_position()
	position.z = position.z + 5
	for c in replayinterface.get_vehicles() do
		print(c)
		print(replayinterface.get_vehicles())
		print(replayinterface)
		c:set_position(position)
		return
	end
end
----------
function MPX()
	return "MP"..stats.get_int("MPPLY_LAST_MP_CHAR").."_"
end

--local MPX() = function()
--	return "MP"..stats.get_int("MPPLY_LAST_MP_CHAR").."_"
--end
----------
fmC2020 = script("fm_mission_controller_2020") fmC = script("fm_mission_controller") PlayerIndex = stats.get_int("MPPLY_LAST_MP_CHAR") mpx = PlayerIndex if PlayerIndex == 0 then mpx = "MP0_" else mpx = "MP1_" end xox_00 = 1 xox_01 = 1 xox_0 = 1 xox_1 = 1 xox_2 = 1 xox_3 = 1 xox_4 = 1 xox_5 = 1 xox_6 = 1 xox_7 = 1 xox_8 = 1 xox_9 = 1 xox_10 = 1 xox_11 = 1 xox_12 = 1 xox_13 = 1 xox_14 = 1 xox_15 = 1 xox_16 = 1 xox_17 = 1 xox_18 = 1 xox_19 = 1 xox_20 = 1 xox_21 = 1 xox_22 = 1 xox_23 = 1 xox_24 = 1 xox_25 = 1 xox_26 = 1 xox_27 = 1 xox_28 = 1 xox_29 = 1 xox_30 = 1 xox_31 = 1 xox_32 = 1 xox_33 = 1 xox_34 = 1 xox_35 = 1 xox_36 = 1 xox_37 = 1 e0 = false e1 = false e2 = false e3 = false e4 = false e5 = false e6 = false e7 = false e8 = false e9 = false e10 = false e11 = false e12 = false e13 = false e14 = false e15 = false e16 = false e17 = false e18 = false e19 = false e20 = false e21 = false e22 = false e23 = false e24 = false e25 = false e26 = false e27 = false e28 = false e29 = false e30 = false e31 = false e32 = false e33 = false e34 = false e35 = false e36 = false e37 = false e38 = false e39 = false e40 = false e41 = false e42 = false e43 = false e44 = false e45 = false e46 = false e47 = false e48 = false e49 = false e50 = false e51 = false e52 = false e53 = false
function TP(x, y, z, yaw, roll, pitch) if localplayer:is_in_vehicle() then localplayer:get_current_vehicle():set_position(x, y, z) localplayer:get_current_vehicle():set_rotation(yaw, roll, pitch) else localplayer:set_position(x, y, z) localplayer:set_rotation(yaw, roll, pitch) end end 
--Globals ---
CsyonsACL1=262145+17425
CsyonsACL2=262145+17396
CsyonsACL3=262145+18949
CsyonsACL4=262145+21869
CsyonsACL5=262145+21870
CsyonsACL6=262145+21866
TEB1=262145+32702

TEB2=262145+32688

DWU1=262145+33975

DWU2=262145+34113

PEY1=262145+27133

PEY2=262145+27894

RPN1=262145+29991

RPN2=262145+29992

TEQ1=262145+29982

RUN1=262145+29983

BEB1=262145+29984

PID1=262145+29985

PAS1=262145+29987

BAS1=262145+29939

RLC1=262145+28817

RLC2=262145+28831

RE1=262145+24608

RE2=262145+24612

RE3=262145+24609								

RLC3=262145+28467

RLC4=262145+28818

RLC5=262145+28819

RLC6=262145+28820

RLC7=262145+28821

RLC8=262145+28822

RLC9=262145+28823

RLC10=262145+28824

RLC11=262145+28825

RLC12=262145+28826

RLC13=262145+28827

RLC14=262145+28828

RLC15=262145+28829

RLC16=262145+28830

CDP1=262145+28808

CGP1=262145+28807

CAP1=262145+28806

CCP1=262145+28805

RCP1=262145+31701

RCP2=262145+31765

PAP1=262145+31727

PAH1=262145+31728

DRD1=262145+34062

GUV1=262145+33799

GUV2=262145+33877

TJC1=262145+33770

BSM1=262145+21509

BSM2=262145+21510

EBD1=262145+21621

EBD2=262145+21645

EBD3=262145+21647

EBD4=262145+21650

EBD5=262145+21654

EBD6=262145+21656

EBD7=262145+21658

EBD8=262145+21660

EBD9=262145+21666

EBD10=262145+21668

EBD11=262145+21671

EBD12=262145+21673

EBD13=262145+21675

EBD14=262145+21678

EBD15=262145+21689

EBD16=262145+21691

EBD17=262145+21695

EBD18=262145+21697

EBD19=262145+21699

EBD20=262145+21702

RBD1=262145+21557

RBS1=262145+21555

RBS2=262145+21556

BSU1=262145+21532

BSU2=262145+21531

CSP1=262145+15788

CSP2=262145+15789

CSP3=262145+15790

CSP4=262145+15791

CSP5=262145+15792

CSP6=262145+15793

CSP7=262145+15794

CSP8=262145+15795

CSP9=262145+15796

CSP10=262145+15797

CSP11=262145+15798

CSP12=262145+15799

CSP13=262145+15800

CSP14=262145+15801

CSP15=262145+15802

CSP16=262145+15803

CSP17=262145+15804

CSP18=262145+15805

CSP19=262145+15806

CSP20=262145+15807

CSP21=262145+15808

CRC1=262145+15553

CRC2=262145+15554

NRC1=262145+24447

NRC2=262145+24489

NCR3=262145+24490

PSU1=262145+24107

PSU2=262145+24113

PSU3=262145+24108

PSU4=262145+24109

PSU5=262145+24110

PSU6=262145+24111

PSU7=262145+24112

SGV1=262145+24381

SAV1=262145+24382

PHV1=262145+24383

OPV1=262145+24384

PCV1=262145+24385

CCV1=262145+24386

CSV1=262145+24387

RTC1=262145+24496

ALV1=262145+22811

AMV1=262145+22812

AAV1=262145+22813

CHV1=262145+22814

COV1=262145+22815

JEV1=262145+22816

MSV1=262145+22817

NAV1=262145+22818

TAV1=262145+22819

RRC1=262145+22793

SUP1=262145+17391

SUP2=262145+17395

SUP3=262145+17394

SUP4=262145+17393

SUP5=262145+17392

EMD1=262145+15567

EMD2=262145+18510

EMD3=262145+18514

EMD4=262145+18516

EMD5=262145+18520

EMD6=262145+18523

EMD7=262145+18547

EMD8=262145+18550

EMD9=262145+18552

EMD10=262145+18557

EMD11=262145+18561

EMD12=262145+18565

EMD13=262145+18570

EMD14=262145+18575

RSC1=262145+18953

RSD1=262145+18954

GSM1=262145+18247

MSM1=262145+19066

MSM2=262145+19067

ACC1=262145+31126

CHA1=262145+31127

LOM1=262145+31128

EXT1=262145+31132

MHT1=262145+31136

MMT1=262145+31137

MLT1=262145+31138

TOR1=262145+19412

MIR1=262145+19413

STR1=262145+19414

UCR1=262145+19416

UCS1=262145+19417

VHR1=262145+19682

VHR2=262145+19685

VHR3=262145+19314

VHR4=262145+19683

VHR5=262145+19684

RRC1=262145+19661

RRC2=262145+19662

RRC3=262145+19663

SAH1=262145+19418

SPD1=262145+19419

REM1=262145+20288

RMU1=262145+1

APU1=262145+25926

SRM1=262145+31649

PRM1=262145+31650

SCM1=262145+31651

HH1=262145+31652

LCM1=262145+31653

LMT1=262145+31654

AWA1=262145+24058

AWA2=262145+24060

AWA3=262145+24067

AWA4=262145+24069

AWO1=262145+24052

AWO2=262145+24054

AWO3=262145+24061

AWO4=262145+24063

AWR1=262145+24055

AWR2=262145+24057

AWR3=262145+24064

AWR4=262145+24066

EG1=262145+13149

EB1=262145+13150

CC1=262145+15891

CC2=262145+18025

RF7=262145+12843

RB1=262145+12843

RB2=262145+12851

RB3=262145+15890

RB4=262145+12848

RB5=262145+12849

RB6=262145+12850

RB7=262145+12853

RB8=262145+12854			

RF1=262145+12842

RF2=262145+12846

RF3=262145+15968

RF4=262145+15973

RF5=262145+19302

RF6=262145+19304

RF8=262145+12845

RF9=262145+15969

RF10=262145+15970

RF11=262145+15971

RF12=262145+15980

IS1=262145+25302

IS2=262145+25303

IS3=262145+25304

RV1=262145+12832

RM1=262145+28408

RSU1=262145+30187

RSU2=262145+30188

RC1=262145+13081

NM1=262145+8352

NM2=262145+8353

NM3=262145+8354

NM4=262145+8355

NM5=262145+8356

NM6=262145+8357

NM7=262145+8358

NM8=262145+8359

NM9=262145+8360

DR1=262145+33957

DR2=262145+33972

MU1=262145+32865

CG1=262145+24219

CG2=262145+24220

UA1=262145+31859

UA2=262145+31870

CD1=262145+31871

CD2=262145+31872

CD3=262145+31873

AC1=262145+27530

AC2=262145+27531

AC3=262145+27532

AC4=262145+27533

PC1=262145+28200

PC2=262145+28205

PC3=262145+27945

PC4=262145+28011

VU1=262145+7059

VU2=262145+12030

VU3=262145+12031

VU4=262145+12032

VU5=262145+12033

VU5=262145+12034

VU6=262145+13396

VU7=262145+13397

ID1=262145+8259

ID2=262145+8268

ID3=262145+8274

ID4=262145+8297

ID5=262145+8303

HA1=262145+11996

HA2=262145+12036

HA3=262145+12041

HA4=262145+12042

HA5=262145+12043

HA7=262145+12045

HA8=262145+12046

HA9=262145+12047

HA10=262145+12048

HA11=262145+12059

HA12=262145+12702

HA13=262145+17488

XM1=262145+4763

XM2=262145+30902

XM3=262145+25834

XM4=262145+25835

XM5=262145+25836

XM6=262145+19139

XM6=262145+19139

XM7=262145+9395

XM8=262145+9396

XM8=262145+9397

XM9=262145+9398

XM10=262145+12710

XM11=262145+23412

XM12=262145+23413

XM13=262145+23414

XM44=262145+23415

XM15=262145+24203

XM16=262145+12711

XM17=262145+12713

XM18=262145+19256

XM19=262145+23056

XM20=262145+12816

XM21=262145+12817

XM22=262145+12818

XM23=262145+12819

XM24=262145+19115

XM25=262145+19116

XM26=262145+19117

XM27=262145+19118

XM28=262145+23434

XM27=262145+23435

XM29=262145+23436

XM30=262145+23437

XM31=262145+25838

XM32=262145+25841

XM33=262145+25839

XM34=262145+25840

XM35=262145+28690

XM36=262145+28691

XM37=262145+28692

XM38=262145+28693

XM39=262145+31410

XM40=262145+31411

XM41=262145+31756

XM42=262145+31757

XM43=262145+23407

XM45=262145+9449

XM46=262145+9451

XM47=262145+33915

XM48=262145+33916

SN1=262145+4752

CA1=262145+21109

CA2=262145+21112

CA3=262145+21118

CA4=262145+21121

CA5=262145+21122

CA6=262145+21129

CA7=262145+21132

CA8=262145+21134

HAS1=262145+12591

HAS2=262145+12600

MS5=262145+12613

BS1=262145+15222

BS2=262145+15224

BS3=262145+15226

BS4=262145+15228

BS5=262145+15230

BS6=262145+15236

BS7=262145+24205

BS8=262145+24208

BS9=262145+23951

BS10=262145+24210

RS4=262145+24212

BS11=262145+24214

BS12=262145+24215

BS13=262145+18255

KT1=262145+24221

KT2=262145+24230

MC1=262145+15225

MC2=262145+17532

MC2=262145+17532

MC3=262145+17553

MC3=262145+17553

MS1=262145+11955

MS2=262145+15229

MS3=262145+11964

MS4=262145+12601

RS1=262145+24204

RS2=262145+24209

RS3=262145+24211

RS5=262145+24214

RS6=262145+24216

RS7=262145+24217

RS8=262145+24744

RS9=262145+24763

CT1=262145+24704

CT2=262145+24712

DT1=262145+24918

DT2=262145+24941

HO1=262145+21110

HO2=262145+21114

HO3=262145+21117

HO4=262145+21119

HO5=262145+21124

HO6=262145+21126

HO7=262145+21130

HO8=262145+21133

SH1=262145+25826

SH2=262145+21111

SH3=262145+21113

SH4=262145+21115

SH5=262145+21116

SH6=262145+21120

SH7=262145+21125

SH8=262145+21131

SH9=262145+21135

SH10=262145+21136

SH11=262145+21147

WB1=262145+16783

WB2=262145+16790

SS1=262145+23407

SS2=262145+23411

AC1=262145+25842

AC2=262145+25919

AR1=262145+27027

AR2=262145+27033

AR3=262145+28316

AR4=262145+28335

LS1=262145+29685

LS2=262145+29720

LT1=262145+31187

LT2=262145+31208

LT3=262145+31019

LT4=262145+31025

CP1=262145+30209

CP2=262145+30277

CP3=262145+30282

CP4=262145+30301

CP5=262145+30866

CP6=262145+30901

TTM1=262145+24345

BRE1=262145+21295

BRE2=262145+21547

BRE3=262145+21548

BRE4=262145+21549

BRE5=262145+21551

BRE6=262145+21552

--Skin Changer  

NORS1=2639783+61

NORS2=2639783+48

--Request Services

REQS1=2793046 --Offset

--Lobby Switch

LOBS1=1575017

LOBS2=1574589
----------
local fmC2020 = script("fm_csyon_script_2023") local fmC = script("fm_csyon_script") local PlayerIndex = stats.get_int("MPPLY_LAST_MP_CHAR") local mpx = PlayerIndex if PlayerIndex == 0 then mpx = "MP0_" else mpx = "MP1_" end local xox_00 = 1 local xox_01 = 1 local xox_0 = 1 local xox_1 = 1 local xox_2 = 1 local xox_3 = 1 local xox_4 = 1 local xox_5 = 1 local xox_6 = 1 local xox_7 = 1 local xox_8 = 1 local xox_9 = 1 local xox_10 = 1 local xox_11 = 1 local xox_12 = 1 local xox_13 = 1 local xox_14 = 1 local xox_15 = 1 local xox_16 = 1 local xox_17 = 1 local xox_18 = 1 local xox_19 = 1 local xox_20 = 1 local xox_21 = 1 local xox_22 = 1 local xox_23 = 1 local xox_24 = 1 local xox_25 = 1 local xox_26 = 1 local xox_27 = 1 local xox_28 = 1 local xox_29 = 1 local xox_30 = 1 local xox_31 = 1 local xox_32 = 1 local xox_33 = 1 local xox_34 = 1 local xox_35 = 1 local e0 = false local e1 = false local e2 = false local e3 = false local e4 = false local e5 = false local e6 = false local e7 = false local e8 = false local e9 = false local e10 = false local e11 = false local e12 = false local e13 = false local e14 = false local e15 = false local e16 = false local e17 = false local e18 = false local e19 = false local e20 = false local e21 = false local e22 = false local e23 = false local e24 = false local e25 = false local e26 = false local e27 = false local e28 = false local e29 = false local e30 = false local e31 = false local e32 = false local e33 = false local e34 = false local e35 = false local e36 = false local e37 = false local e38 = false local e39 = false local e40 = false local function TP(x, y, z, yaw, roll, pitch) if localplayer:is_in_vehicle() then localplayer:get_current_vehicle():set_position(x, y, z) localplayer:get_current_vehicle():set_rotation(yaw, roll, pitch) else localplayer:set_position(x, y, z) localplayer:set_rotation(yaw, roll, pitch) end end
----------
----------

----------

----------

----------

----------

----------

----------

----------

----------

mainMenu3 = menu.add_submenu("【 CSYON 】 SubMenu E2")

Texterrrsa("**************************************************************************")
Texterrrsa("            ** CSYON SubMenu 1.67 **                  ")
Texterrrsa("                               **✅ v13 **                   ")
Texterrrsa("            ** ⚠️Game Build Version 2845⚠️ **                  ")
Texterrrsa("**************************************************************************")
	
Online= mainMenu3:add_submenu("🚨 Csyon Submenu")

CSYON29 = Online:add_submenu("🙎‍Player Features")

CSYON22 = Online:add_submenu("💵 Money Options")

CSYON23 = Online:add_submenu("🚗Vehicles Features")

CSYON35 = Online:add_submenu("🎴Events")

CSYON24 = Online:add_submenu("✨ Misc things activater")

CSYON27 = Online:add_submenu("🚩flags options")

CSYON28 = Online:add_submenu("🔫Weapons Options")

CSYON26 = Online:add_submenu("🛡️ Protections")

CSYON25 = Online:add_submenu("🎮Unlock Alls")

CSYON21 = Online:add_submenu("⚠info for help")

--------------------------------------------------------------------------------------------------------

CSYONS22 = CSYON22:add_submenu("---> Press here the Pay Respect")

CSYONS23 = CSYON23:add_submenu("🚗 Vehicles Modifications? ")

CSYONS24 = CSYON24:add_submenu("✨ Misc things activater? ")

CSYONS26 = CSYON26:add_submenu("🛡️ Give your self Protection? ")

CSYONS25 = CSYON25:add_submenu("🎮Unlock All? ")

CSYONS35 = CSYON35:add_submenu("🎴do you wanna Play a Event?")

CSYONS27 = CSYON27:add_submenu("🚩flags? ")

CSYONS29 = CSYON29:add_submenu("🙎‍Player Options? ")

CSYONS28 = CSYON28:add_submenu("🔫Weapon Features ")

CSYONS21 = CSYON21:add_submenu("⚠ReadMe")
--------------------------------------------------------------------------------------------------------

CSYONS21:add_action("***********************************************************", function() end)
CSYONS21:add_action("for Help join my Discord Server", function() end)
CSYONS21:add_action("https://discord.gg/JaCvtj6yQK", function() end)
CSYONS21:add_action("***********************************************************", function() end)

--------------------------------------------------------------------------------------------------------
--CSYONS9:add_action("------------------------------------------------------", function() end)



local VehicleSpawnGlobal2 = 2694613
local VehicleSpawnGlobal = 2639889
 
local function createVehicle(modelHash, pos)
	if not localplayer:is_in_vehicle() then
		globals.set_int(VehicleSpawnGlobal + 46, modelHash)
		globals.set_float(VehicleSpawnGlobal + 42, pos.x)
		globals.set_float(VehicleSpawnGlobal + 43, pos.y)
		globals.set_float(VehicleSpawnGlobal + 44, pos.z)
		local vector = localplayer:get_heading()
		local angle = math.deg(math.atan(vector.y, vector.x))
		if angle < 0 then angle = angle + 360 end
		globals.set_float(VehicleSpawnGlobal + 45, angle)
		globals.set_boolean(VehicleSpawnGlobal + 41, true)
	else
		globals.set_boolean(VehicleSpawnGlobal2 + 5, false) -- SpawnVehicles
		globals.set_boolean(VehicleSpawnGlobal2 + 2, false) -- SpawnVehicles
		globals.set_float(VehicleSpawnGlobal2 + 7 + 0, pos.x) -- pos.x
		globals.set_float(VehicleSpawnGlobal2 + 7 + 1, pos.y) -- pos.y
		globals.set_float(VehicleSpawnGlobal2 + 7 + 2, pos.z) -- pos.z
		globals.set_int(VehicleSpawnGlobal2 + 27 + 66, modelHash) -- modelHash
		globals.set_boolean(VehicleSpawnGlobal2 + 5, true) -- SpawnVehicles
		globals.set_boolean(VehicleSpawnGlobal2 + 2, true) -- SpawnVehicles
	end
end
 
local weapon_data = {}
local enabled = false
local isActive = false
local function spawnCarWhereAiming()
	if not enabled then return end
	isActive = true
	local weapon = localplayer:get_current_weapon()
	local pos
	if weapon ~= nil then 
		local force = weapon:get_vehicle_force()
		if force ~= nil and force < 100000 then
			weapon_data[weapon:get_name_hash()] = force
			weapon:set_vehicle_force(99900000)
		end
	end
	local pos = (localplayer:get_position() + localplayer:get_heading()*2.2)
	if localplayer:is_in_vehicle() then
		pos = (localplayer:get_position() + localplayer:get_heading()*11)
	end
	createVehicle(joaat("Youga4"), pos + vector3(0,0,1))
	sleep(0.2)
	isActive = false
end
 
local weapon_data = {}
local enabled = false
local isActive = false
local function spawnCarWhereAiming()
	if not enabled then return end
	isActive = true
	--check weapon hit force and put in table
	local weapon = localplayer:get_current_weapon()
	if weapon ~= nil then
		local force = weapon:get_vehicle_force()
		if force ~= nil and force < 100000 then
			weapon_data[weapon:get_name_hash()] = force
			weapon:set_vehicle_force(99900000)
		end
	end
	local pos = (localplayer:get_position() + localplayer:get_heading()*2.2)
	if localplayer:is_in_vehicle() then
		pos = (localplayer:get_position() + localplayer:get_heading()*11)
	end
	createVehicle(joaat("Youga4"), pos + vector3(0,0,1))
	sleep(0.2)
	isActive = false
end
 
local hotkey
local function carAPult()
	if not localplayer or localplayer == nil then return end
	
	enabled = not enabled
	if enabled then
		--register hotkey to left click for continually spawning cars
		hotkey = menu.register_hotkey(1, function() if not isActive then spawnCarWhereAiming() end end)
	else
		--reset weapon hit force from table
		local weapon = localplayer:get_current_weapon()
		if weapon ~= nil and weapon:get_vehicle_force() == 99900000 then
			local force = weapon_data[weapon:get_name_hash()]
			if force ~= nil then
				weapon:set_vehicle_force(force)
			end
		end
		
		--unregister hotkey
		menu.remove_hotkey(hotkey)
	end
end
 
CSYONS28:add_toggle("Enable Car-A-Pult", function() return enabled end, carAPult)
 
--multiply key on numpad
menu.register_hotkey(106, carAPult)

acid_lab_production = false
CSYONS22:add_toggle("auto acid lab production", function()
    return acid_lab_production
end, function(bool)
    acid_lab_production = bool
    while (acid_lab_production == true) do
        menu.trigger_acid_lab_production()
        sleep(1)
    end
end)

CSYONS22:add_action("--------------Acid Labs Editior--------------", function() end)
CSYONS22:add_action("--------------Dont Exceed More than 2 Million --------------", function() end)
CSYONS22:add_int_range("Acid Labs Inrease Prodution Speed", 1.0, 1, 10, function()
	return globals.get_int(262145 + 32700)
end, function(value)
	globals.set_int(262145 + 32700, 0)
end)

function AL(e) if not localplayer then return end if e then globals.set_int(262145+17576, 0) else globals.set_int(262145+17576, 135000) end end 
function AC(e) if not localplayer then return end if e then globals.set_int(262145+22813, 0) else globals.set_int(262145+22813, 300000) end end 
function ACL(e) if not localplayer then return end if e then globals.set_int(262145+23412, 0) globals.set_int(262145+15797, 0) else globals.set_int(262145+23412, 12000) globals.set_int(262145+15797, 12000) end end
CSYONS22:add_int_range("Set $$", 50000, 10000, 2000000, function() return globals.get_int(262145+28200) end, function(Val) globals.set_int(262145+28200, Val) end) 
CSYONS22:add_toggle("Remove Production Delay", function() return e52 end, function() e52 = not e52 AL(e52) end)
CSYONS22:add_toggle("Remove Supply Delay", function() return e53 end, function() e53 = not e53 AC(e53) end)
CSYONS22:add_toggle("Remove Supply Cost", function() return e51 end, function() e51 = not e51 ACL(e51) end)

CSYONS22:add_int_range("Set Acid Value 2Mil", 10000.0, 10000, 99999, function()
return globals.get_int(262145 + 17425)
end, function(value)
globals.set_int(262145 + 17425, value)
end)

CSYONS22:add_int_range("Decrease Production Time", 1.0, 0, 100, function() 
	return globals.get_int(262145 + 17396)
end, function(value)
	globals.set_int(262145 + 17396, value)
end)

CSYONS22:add_int_range("Product Capacity", 1, 0, 100, function() 
	return globals.get_int(262145+18949)
end, function(value)
	globals.set_int(262145+18949, value)
end)


CSYONS22:add_int_range("Change Supplies Cost", 1, 0, 10, function() 
	return globals.get_int(262145+21869)
end, function(value)
	globals.set_int(262145+21869, value)
end)

CSYONS22:add_action("------------------------------------------------------", function() end)

CSYONS24:add_toggle('Activate new Vehicles',
function()
    return globals.get_bool(262145 + 35462)
end,
function(toggle)
    local loop = {{35462, 35469}, {35471, 35474}}
 
    for k = 1, #loop do
        for i = loop[k][1], loop[k][2] do
            globals.set_bool(262145 + i, toggle)
        end
    end
end)
 
CSYONS24:add_toggle('Activate old Vehicles',
function()
    return globals.get_bool(262145 + 35167)
end,
function(toggle)
    local loop = {{14908, 14916, 1}, {17482, 17500, 1}, {17654, 17675, 1}, {19311, 19335, 1}, {20392, 20395, 1}, {21274, 21279, 1}, {22073, 22092, 1}, {23041, 23068, 1}, {24262, 24277, 1}, {24353, 24375, 1}, {25969, 25975, 1}, {25980, 26000, 1}, {26956, 26957, 1}, {28820, 28840, 1}, {28863, 28866, 3}, {29534, 29541, 1}, {29883, 29889, 1}, {30348, 30364, 1}, {31216, 31232, 1}, {32099, 32113, 1}, {33341, 33357, 1}, {33359, 33359, 1}, {34212, 34227, 1}, {35167, 35443, 2}}
 
    for k = 1, #loop do
        for i = loop[k][1], loop[k][2], loop[k][3] do
            globals.set_bool(262145 + i, toggle)
        end
    end
end)

CSYONS25:add_action("Unlocking the Gun Van Weapons", function()
globals.set_int(262145 + 34094 + 3, -22923932) ----- The RailGun
globals.set_int(262145 + 34094 + 4, -1238556825) ----- The WidoMaker
globals.set_int(262145 + 34094 + 5, -1355376991) ----- The RayPistol
globals.set_int(262145 + 34094 + 6, 1198256469) ----- The HellBringer
globals.set_int(262145 + 34094 + 7, -1786099057) ----- The BaseBall Bat
end)

CSYONS24:add_toggle("Enable Removed Vehicles", function() 
return globals.get_int(262145+35167) end, 
function(value) local EnableNumb = 35167 
local StopNumb = 20394 for i = EnableNumb, StopNumb, 2 do globals.set_int(262145 + i, 1) 
   end 
end)

CSYONS35:add_action("Enable Random Spawn Ghost Hunt 8PM & 6AM", function()
		globals.set_int(262145 + 35064, 0)
		globals.set_int(262145 + 35158, 50000)
end)	

CSYONS35:add_action("Enable Original Freemode Events", function()
		globals.set_int(262145 + 12046, 1)
end)

CSYONS35:add_action("Create Drop ", function()
		globals.set_int(262145 + 7203, 0)
end)

CSYONS35:add_action("Armoured Truck", function()
		globals.set_int(262145 + 7204, 0)
end)

CSYONS35:add_action("Destroy Vehicle", function()
		globals.set_int(262145 + 8742, 0)
end)

CSYONS35:add_action("Distract Cops", function()
		globals.set_int(262145 + 8737, 0)
end)

CSYONS35:add_action("Plane Takedown", function()
		globals.set_int(262145 + 8732, 0)
end)

CSYONS25:add_action("Unlock exclusive Outfits", function() 
			stats.set_int(262145, 16964) --White Jock Cranley Suit
			stats.set_int(262145, 16966) --Red Jock Cranley Suit
			stats.set_int(262145, 16965) --Blue Jock Cranley Suit
			stats.set_int(262145, 16967) --Gold Jock Cranley Suit
			stats.set_int(262145, 16968) --Black Jock Cranley Suit
			stats.set_int(262145, 16969) --Pink Jock Cranley Suit
			stats.set_int(262145, 16970) --Silver Jock Cranley Suit
			stats.set_int(262145, 23588) --Green Wireframe Bodysuit
			stats.set_int(262145, 23589) --Orange Wireframe Bodysuit
			stats.set_int(262145, 23590) --Blue Wireframe Bodysuit
			stats.set_int(262145, 23591) --Pink Wireframe Bodysuit
			stats.set_int(262145, 23592) --Yellow Wireframe Bodysuit
			stats.set_int(262145, 27315) --High Roller Outfit
			stats.set_int(262145, 31415) --Penitentiary Coveralls
			stats.set_int(262145, 31398) --LS Customs Coveralls
			stats.set_int(262145, 31405) --eCola Bodysuit
			stats.set_int(262145, 31406) --Sprunk Bodysuit
			stats.set_int(262145, 35510) --The Retired Criminal
			stats.set_int(262145, 35511) --The Groupie
			stats.set_int(262145, 35509) --The Homie
end)

CSYONS25:add_action("Unlock Junk Energy", function()
globals.set_int(262145+35056,0)--Junk Energy Time Trial
globals.set_int(262145+35156,-1)--Junk Energy Time Trial location
end)

CSYONS25:add_action("Unlock Ace Mask Diamond Restore Store", function()
		globals.set_int(262145 + 27533, 1) --Ace of Diamonds
		globals.set_int(262145 + 27532, 1) --Ace of Clubs
		globals.set_int(262145 + 27531, 1) --Ace of Hearts
		globals.set_int(262145 + 27530, 1) --Ace of Spades
end)

local Plates={ "Csyon", "ADMIN", "ROCKSTAR", "Kiddion", "L7NEG", "Csyons", "CSYON", "Joker", "JOKER", "J0K3R", "joker" }
local function Veh() if localplayer:is_in_vehicle() then return localplayer:get_current_vehicle() else return nil end end
CSYONS23:add_array_item("Set Number Plate 🚘", Plates, function()
if Veh() then for x=1, #Plates do if Plates[x]==Veh():get_number_plate_text() then return x end end return 1 end end, function(t)
  if Veh() then Veh():set_number_plate_text(Plates[t]) end
end)

CSYONS25:add_action('Unlock Vanilla Unicorn', function()
        stats.set_int(MPX() .. 'LAP_DANCED_BOUGHT', 0)
        stats.set_int(MPX() .. 'LAP_DANCED_BOUGHT', 5)
        stats.set_int(MPX() .. 'LAP_DANCED_BOUGHT', 10)
        stats.set_int(MPX() .. 'LAP_DANCED_BOUGHT', 15)
        stats.set_int(MPX() .. 'LAP_DANCED_BOUGHT', 25)
        stats.set_int(MPX() .. 'PROSTITUTES_FREQUENTED', 1000)
    end
)

CSYONS28:add_action("Get all Weapons Upgrades (Temporary)", function() stats.set_int(MPX() .. "CHAR_WEAP_ADDON_1_UNLCK", -1) stats.set_int(MPX() .. "CHAR_WEAP_ADDON_2_UNLCK", -1) stats.set_int(MPX() .. "CHAR_WEAP_ADDON_3_UNLCK", -1) stats.set_int(MPX() .. "CHAR_WEAP_ADDON_4_UNLCK", -1) stats.set_int(MPX() .. "CHAR_WEAP_FREE", -1) stats.set_int(MPX() .. "CHAR_WEAP_FREE2", -1) stats.set_int(MPX() .. "CHAR_FM_WEAP_FREE", -1) stats.set_int(MPX() .. "CHAR_FM_WEAP_FREE2", -1) stats.set_int(MPX() .. "CHAR_FM_WEAP_FREE3", -1) stats.set_int(MPX() .. "CHAR_FM_WEAP_FREE4", -1) stats.set_int(MPX() .. "CHAR_WEAP_PURCHASED", -1) stats.set_int(MPX() .. "CHAR_WEAP_PURCHASED2", -1) stats.set_int(MPX() .. "WEAPON_PICKUP_BITSET", -1) stats.set_int(MPX() .. "WEAPON_PICKUP_BITSET2", -1) stats.set_int(MPX() .. "CHAR_FM_WEAP_UNLOCKED", -1) stats.set_int(MPX() .. "NO_WEAPONS_UNLOCK", -1) stats.set_int(MPX() .. "NO_WEAPON_MODS_UNLOCK", -1) stats.set_int(MPX() .. "NO_WEAPON_CLR_MOD_UNLOCK", -1) stats.set_int(MPX() .. "CHAR_KIT_FM_PURCHASE", -1) stats.set_int(MPX() .. "CHAR_WEAP_FM_PURCHASE", -1) stats.set_int(MPX() .. "CHAR_WEAP_FM_PURCHASE2", -1) stats.set_int(MPX() .. "CHAR_WEAP_FM_PURCHASE3", -1) stats.set_int(MPX() .. "CHAR_WEAP_FM_PURCHASE4", -1) stats.set_int(MPX() .. "WEAP_FM_ADDON_PURCH", -1) for i = 2, 19 do stats.set_int(MPX() .. "WEAP_FM_ADDON_PURCH"..i, -1) end for l = 2, 41 do stats.set_int(MPX() .. "CHAR_KIT_FM_PURCHASE"..l, -1) end globals.set_int(1575015, 1) globals.set_int(1575015, 1) globals.set_int(LOBS2, 1) sleep(0.2) globals.set_int(LOBS2, 0) end)

CSYONS24:add_action("reset LSC vehicle sell limit", function() 
			stats.set_int("MPPLY_VEHICLE_SELL_TIME", 0)
			stats.set_int("MPPLY_NUM_CARS_SOLD_TODAY", 0)
end)

CSYONS22:add_action("Bunker $$$ Methode", function() end)
CSYONS22:add_float_range("Sale Multiplier", 0.5, 1, 1000, function() return globals.get_float(BSM1) end, function(value) globals.set_float(BSM1, value) globals.set_float(BSM2, value) end) 
local function EBdt(e) if not localplayer then return end if e then globals.set_int(EBD1, 14400000) globals.set_int(EBD2, 15000000) globals.set_int(EBD3, 15600000) globals.set_int(EBD4, 16200000) globals.set_int(EBD5, 16800000) globals.set_int(EBD6, 17400000) globals.set_int(EBD7, 18000000) globals.set_int(EBD8, 18600000) globals.set_int(EBD9, 19200000) globals.set_int(EBD10, 19800000) globals.set_int(EBD11, 20400000) globals.set_int(EBD12, 21000000) globals.set_int(EBD13, 21600000) globals.set_int(EBD14, 22200000) globals.set_int(EBD15, 22800000) globals.set_int(EBD16, 23400000) globals.set_int(EBD17, 24000000) globals.set_int(EBD18, 24600000) globals.set_int(EBD19, 25200000) globals.set_int(EBD20, 25800000) else  globals.set_int(EBD1, 1800000) globals.set_int(EBD2, 1800000) globals.set_int(EBD3, 1800000) globals.set_int(EBD4, 1800000) globals.set_int(EBD5, 1800000) globals.set_int(EBD6, 1800000) globals.set_int(EBD7, 1800000) globals.set_int(EBD8, 1800000) globals.set_int(EBD9, 1800000) globals.set_int(EBD10, 1800000) globals.set_int(EBD11, 1800000) globals.set_int(EBD12, 1800000) globals.set_int(EBD13, 1800000) globals.set_int(EBD14, 1800000) globals.set_int(EBD15, 900000) globals.set_int(EBD16, 900000) globals.set_int(EBD17, 1800000) globals.set_int(EBD18, 900000) globals.set_int(EBD19, 900000) globals.set_int(EBD20, 900000) end end 
CSYONS22:add_toggle("Extend Bunker Delivery Timer", function() return e45 end, function() e45 = not e45 EBdt(e45) end)
local function BRd(e) if not localplayer then return end if e then globals.set_int(RBD1, 10) else globals.set_int(RBD1, 600) end end 
CSYONS22:add_toggle("Remove Bunker Resupply Delay", function() return e47 end, function() e47 = not e47 BRd(e47) end)
local function BRC(e) if not localplayer then return end if e then globals.set_int(RBS1, 1000) globals.set_int(RBS2, 1000) else globals.set_int(RBS1, 15000) globals.set_int(RBS2, 15000) end end 
CSYONS22:add_toggle("Reduce Bunker Resupply Cost", function() return e23 end, function() e23 = not e23 BRC(e23) end)
local function Brr(e) if not localplayer then return end if e then stats.set_int(MPX().."PAYRESUPPLYTIMER5", 1) sleep(0.1)  else stats.set_int(MPX().."PAYRESUPPLYTIMER5", 0) end end 
CSYONS22:add_toggle("Refill Bunker Supplies(experimental)", function() return e27 end, function() e27 = not e27 Brr(e27) end)
local function SbP(e) if not localplayer then return end if e then globals.set_int(BSU1, 0) menu.trigger_bunker_production() else globals.set_int(BSU1, 600000) end end 
CSYONS22:add_toggle("Speed Up Production", function() return e49 end, function() e49 = not e49 SbP(e49) end)
CSYONS22:add_action("----------------Cargo Sell Methode-------------------", function() end) 
CSYONS22:add_action("Reset Stats 20M/1000 sales", function() stats.set_int(MPX() .. "LFETIME_BIKER_SELL_COMPLET5", 500) stats.set_int(MPX() .. "LIFETIME_BKR_SEL_COMPLETBC5", 500) stats.set_int(MPX() .. "LIFETIME_BKR_SELL_EARNINGS5", 20000000) globals.set_int(SCG1, 1) globals.set_int(SCG2, 1) sleep(0.2) globals.set_int(SCG2, 0) end) 
CSYONS22:add_action("-------~Max=8M------------", function() end)
CSYONS22:add_int_range("Set Ceo Crate $$", 200000, 10000, 6000000, function() return globals.get_int(CSP1) end, function(Val) local a = Val local b = math.floor(Val / 2) local c = math.floor(Val / 3) local d = math.floor(Val / 5) local e = math.floor(Val / 7) local f = math.floor(Val / 9) local g = math.floor(Val / 14) local h = math.floor(Val / 19) local i = math.floor(Val / 24) local j = math.floor(Val / 29) local k = math.floor(Val / 34) local l = math.floor(Val / 39) local m = math.floor(Val / 44) local n = math.floor(Val / 49) local o = math.floor(Val / 59) local p = math.floor(Val / 69) local q = math.floor(Val / 79) local r = math.floor(Val / 89) local s = math.floor(Val / 99) local t = math.floor(Val / 110) local u = math.floor(Val / 111) globals.set_int(CSP1, a) globals.set_int(CSP2, b) globals.set_int(CSP3, c) globals.set_int(CSP4, d) globals.set_int(CSP5, e) globals.set_int(CSP6, f) globals.set_int(CSP7, g) globals.set_int(CSP8, h) globals.set_int(CSP9, i) globals.set_int(CSP10, j) globals.set_int(CSP11, k) globals.set_int(CSP12, l) globals.set_int(CSP13, m) globals.set_int(CSP14, n) globals.set_int(CSP15, o) globals.set_int(CSP16, p) globals.set_int(CSP17, q) globals.set_int(CSP18, r) globals.set_int(CSP19, s) globals.set_int(CSP20, t) globals.set_int(CSP21, u) end) 
CSYONS22:add_action("Get Crates", function() for i = 12, 16 do stats.set_bool_masked(MPX().."FIXERPSTAT_BOOL1", true, i, MPX()) end end)
local function CCooldown(e) if not localplayer then return end if e then globals.set_int(CRC1, 0) globals.set_int(CRC2, 0) else globals.set_int(CRC1, 300000) globals.set_int(CRC2, 1800000) end end 
CSYONS22:add_toggle("Remove Cooldowns", function() return e13 end, function() e13 = not e13 CCooldown(e13) end)
CSYONS22:add_toggle("Random Unique Cargo Toggle", function() return globals.get_boolean(1949968) end, function(value) globals.set_boolean(1949968, value) end) 
CSYONS22:add_array_item("Select Unique Cargo", {"Ornamental Egg", "Gold Minigun", "Large Diamond", "Rage Hide", "Film Reel", "Rare Pocket Watch"}, function() return xox_33 end, function(value) xox_33 = value if value == 1 then globals.set_int(1949968, 1) globals.set_int(1949814, 2) elseif value == 2 then globals.set_int(1949968, 1) globals.set_int(1949814, 4) elseif value == 3 then globals.set_int(1949968, 1) globals.set_int(1949814, 6) elseif value == 4 then globals.set_int(1949968, 1) globals.set_int(1949814, 7) elseif value == 5 then globals.set_int(1949968, 1) globals.set_int(1949814, 8) else globals.set_int(1949968, 1) globals.set_int(1949814, 9) end end) 
CSYONS22:add_action("-------~Max=6M------------", function() end)
CSYONS22:add_action("Auto-Reset stats-20M/1000Sales", function() stats.set_int(MPX() .. "LIFETIME_BUY_COMPLETE", 1000) stats.set_int(MPX() .. "LIFETIME_BUY_UNDERTAKEN", 1000) stats.set_int(MPX() .. "LIFETIME_SELL_COMPLETE", 1000) stats.set_int(MPX() .. "LIFETIME_SELL_UNDERTAKEN", 1000) stats.set_int(MPX() .. "LIFETIME_CONTRA_EARNINGS", 20000000) globals.set_int(SCG1, 1) globals.set_int(SCG2, 1) sleep(0.2) globals.set_int(SCG2, 0) end)
CSYONS22:add_int_range("Manually Reset stats-No. of Sales", 1, 0, 1000, function() return stats.get_int(MPX() .. "LIFETIME_SELL_COMPLETE") end, function(value) stats.set_int(MPX() .. "LIFETIME_BUY_COMPLETE", value) stats.set_int(MPX() .. "LIFETIME_BUY_UNDERTAKEN", value) stats.set_int(MPX() .. "LIFETIME_SELL_COMPLETE", value) stats.set_int(MPX() .. "LIFETIME_SELL_UNDERTAKEN", value) stats.set_int(MPX() .. "LIFETIME_CONTRA_EARNINGS", value * 20000) globals.set_int(SCG1, 1) globals.set_int(SCG2, 1) sleep(0.2) globals.set_int(SCG2, 0) end)
CSYONS22 = CSYON22:add_submenu("Nightclub $$$ Methode") local function NCooldown(e) if not localplayer then return end if e then globals.set_int(NRC1, 0) globals.set_int(NRC2, 0) globals.set_int(NRC3, 0) else globals.set_int(NRC1, 300000) globals.set_int(NRC2, 300000) globals.set_int(NRC3, 300000) end end 
CSYONS22:add_toggle("Remove Cooldowns", function() return e14 end, function() e14 = not e14 NCooldown(e14) end)
CSYONS22:add_action("-----------------NC Money Methode--------------------------", function() end)
CSYONS22:add_float_range("TTP Multiplier", 0.5, 0.5, 1000, function() return globals.get_float(TTM1) end, function(value) globals.set_float(TTM1, value) end)
CSYONS22:add_array_item("Production", {"Speed Up", "Reset Speed"}, function() return xox_17 end, function(v) if v == 1 then for i = PSU1, PSU2 do globals.set_int(i, 1) end menu.trigger_nightclub_production() else globals.set_int(PSU1, 4800000) globals.set_int(PSU3, 14400000) globals.set_int(PSU4, 7200000) globals.set_int(PSU5, 2400000) globals.set_int(PSU6, 1800000) globals.set_int(PSU7, 3600000) globals.set_int(PSU2, 8400000) end xox_17 = v end) 
CSYONS22:add_action("---", function() end)
CSYONS22:add_int_range("Sporting Goods Value", 5000, 5000, 4000000, function() return globals.get_int(SGV1) end, function(value) globals.set_int(SGV1, value) end)
CSYONS22:add_int_range("S.A. Imports Value", 10000, 27000, 4000000, function() return globals.get_int(SAV1) end, function(value) globals.set_int(SAV1, value) end)
CSYONS22:add_int_range("Pharmaceutical Value", 10000, 11475, 4000000, function() return globals.get_int(PHV1) end, function(value) globals.set_int(PHV1, value) end)
CSYONS22:add_int_range("Organic Produce Value", 10000, 2025, 4000000, function() return globals.get_int(OPV1) end, function(value) globals.set_int(OPV1, value) end)
CSYONS22:add_int_range("Printing and Copying Value", 10000, 1350, 4000000, function() return globals.get_int(PCV1) end, function(value) globals.set_int(PCV1, value) end)
CSYONS22:add_int_range("Cash Creation Value", 10000, 4725, 4000000, function() return globals.get_int(CCV1) end, function(value) globals.set_int(CCV1, value) end)
CSYONS22:add_int_range("Cargo Shipments Value", 10000, 10000, 4000000, function() return globals.get_int(CSV1) end, function(value) globals.set_int(CSV1, value) end)
local function tonyC(e) if not localplayer then return end if e then globals.set_float(RTC1, 0) else globals.set_float(RTC1, 0.1) end end 
CSYONS22:add_toggle("Remove Tony's cut", function() return e29 end, function() e29 = not e29 tonyC(e29) end) 
CSYONS22:add_action("-------~Max=8M------------", function() end)
CSYONS22:add_int_range("Reset Sales", 1, 0, 1000, function() return stats.get_int(MPX() .. "HUB_SALES_COMPLETED") end, function(value) stats.set_int(MPX() .. "HUB_S93271ALES_COMPLETED", value) end) 
CSYONS22:add_int_range("Reset Earnings", 500000, 0, 30000000, function() return stats.get_int(MPX() .. "HUB_EARNINGS") end, function(value) stats.set_int(MPX() .. "HUB_EARNINGS", value) globals.set_int(SCG1, 1) globals.set_int(SCG2, 1) sleep(0.2) globals.set_int(SCG2, 0) end)
CSYONS22 = CSYON22:add_submenu("Hanger Cargo $$$") local function Cooldown(e) if not localplayer then return end if e then for i = 284924, 284900 do globals.set_int(i, 0) globals.set_int(i, 1) end else globals.set_int(284868, 120000) globals.set_int(284897, 180000) globals.set_int(284898, 240000) globals.set_int(284927, 60000) globals.set_int(284900, 2000) end end 
CSYONS22:add_toggle("Remove Cooldowns", function() return e15 end, function() e15 = not e15 Cooldown(e15) end)
CSYONS22:add_action("-----------------Cargos Money Methode--------------------------", function() end)
CSYONS22:add_int_range("All/Mixed Value", 50000, 10000, 3100000, function() return globals.get_int(ALV1) end, function(value) globals.set_int(ALV1, value) end)
CSYONS22:add_int_range("Animal Material Value", 50000, 10000, 3100000, function() return globals.get_int(AMV1) end, function(value) globals.set_int(AMV1, value) end)
CSYONS22:add_int_range("Art n Antiques Value", 50000, 10000, 3100000, function() return globals.get_int(AAV1) end, function(value) globals.set_int(AAV1, value) end)
CSYONS22:add_int_range("Chemicals Value", 50000, 10000, 3100000, function() return globals.get_int(CHV1) end, function(value) globals.set_int(CHV1, value) end)
CSYONS22:add_int_range("Counterfeit Value", 50000, 10000, 3100000, function() return globals.get_int(COV1) end, function(value) globals.set_int(COV1, value) end)
CSYONS22:add_int_range("Jewelry Value", 50000, 10000, 3100000, function() return globals.get_int(JEV1) end, function(value) globals.set_int(JEV1, value) end)
CSYONS22:add_int_range("Medical Sup Value", 50000, 10000, 3100000, function() return globals.get_int(MSV1) end, function(value) globals.set_int(MSV1, value) end)
CSYONS22:add_int_range("Narcotics Value", 50000, 10000, 3100000, function() return globals.get_int(NAV1) end, function(value) globals.set_int(NAV1, value) end)
CSYONS22:add_int_range("Tabacco Value", 50000, 10000, 3100000, function() return globals.get_int(TAV1) end, function(value) globals.set_int(TAV1, value) end)
local function ronC(e) if not localplayer then return end if e then globals.set_float(RRC1, 0) else globals.set_float(RRC1, 0.025) end end 
CSYONS22:add_toggle("Remove Rons's cut", function() return e30 end, function() e30 = not e30 ronC(e30) end)
CSYONS22:add_int_range("Reset stats-No. of Sales", 1, 0, 500, function() return stats.get_int(MPX() .. "LFETIME_HANGAR_SEL_COMPLET") end, function(value) stats.set_int(MPX() .. "LFETIME_HANGAR_BUY_UNDETAK", value) stats.set_int(MPX() .. "LFETIME_HANGAR_BUY_COMPLET", value) stats.set_int(MPX() .. "LFETIME_HANGAR_SEL_UNDETAK", value) stats.set_int(MPX() .. "LFETIME_HANGAR_SEL_COMPLET", value) stats.set_int(MPX() .. "LFETIME_HANGAR_EARNINGS", value * 40000) globals.set_int(SCG1, 1) globals.set_int(SCG2, 1) sleep(0.2) globals.set_int(SCG2, 0) end)
CSYONS22 = CSYON22:add_submenu("MC $$$") local function Speed(e) if not localplayer then return end if e then for i = SUP1, SUP2 do globals.set_int(i, 0) globals.set_int(i, 1) end else globals.set_int(SUP3, 300000) globals.set_int(SUP2, 720000) globals.set_int(SUP4, 3000000) globals.set_int(SUP5, 1800000) globals.set_int(SUP1, 360000) end end 
CSYONS22:add_toggle("Speed Up Production", function() return e16 end, function() e16 = not e16 Speed(e16) end)
CSYONS22:add_action("-----------------MC Money Methode--------------------------", function() end)
local function EMCdt(e) if not localplayer then return end if e then globals.set_int(EMD1, 14400000) globals.set_int(EMD2, 6600000) globals.set_int(EMD3, 7200000) globals.set_int(EMD4, 7800000) globals.set_int(EMD5, 8400000) globals.set_int(EMD6, 9000000) globals.set_int(EMD7, 9600000) globals.set_int(EMD8, 10200000) globals.set_int(EMD9, 10800000) globals.set_int(EMD10, 11400000) globals.set_int(EMD11, 12000000) globals.set_int(EMD12, 12600000) globals.set_int(EMD13, 13200000) globals.set_int(EMD14, 13800000) else globals.set_int(EMD1, 1800000) globals.set_int(EMD2, 1800000) globals.set_int(EMD3, 1800000) globals.set_int(EMD4, 1800000) globals.set_int(EMD5, 1800000) globals.set_int(EMD6, 1800000) globals.set_int(EMD7, 1800000) globals.set_int(EMD8, 1800000) globals.set_int(EMD9, 900000) globals.set_int(EMD10, 900000) globals.set_int(EMD11, 1800000) globals.set_int(EMD12, 900000) globals.set_int(EMD13, 900000) globals.set_int(EMD14, 900000) end end 
CSYONS22:add_toggle("Extend MC Delivery Timer", function() return e46 end, function() e46 = not e46 EMCdt(e46) end)
local function VRC(e) if not localplayer then return end if e then globals.set_int(RSC1, 1000) else globals.set_int(RSC1, 1000) end end 
CSYONS22:add_toggle("Remove Resupply Cost", function() return e22 end, function() e22 = not e22 VRC(e22) end) 
local function VRD(e) if not localplayer then return end if e then globals.set_int(RSD1, 10) else globals.set_int(RSD1, 600) end end 
CSYONS22:add_toggle("Remove Resupply Delay", function() return e42 end, function() e42 = not e42 VRD(e42) end)
local function MCrr(e) if not localplayer then return end if e then for i = 0, 4 do stats.set_int(MPX().."PAYRESUPPLYTIMER"..i, 1) sleep(0.1) end else for i = 0, 4 do stats.set_int(MPX().."PAYRESUPPLYTIMER"..i, 0) end end end 
CSYONS22:add_toggle("Refill Supplies(experimental)", function() return e25 end, function() e25 = not e25 MCrr(e25) end)
local function MCgs(e) if not localplayer then return end if e then globals.set_int(GSM1, 0) else globals.set_int(GSM1, 40000) end end 
CSYONS22:add_toggle("Remove Global Signal", function() return e24 end, function() e24 = not e24 MCgs(e24) end)
CSYONS22:add_float_range("Sale Multiplier", 0.5, 1, 1000, function() return globals.get_float(MSM1) end, function(value) globals.set_float(MSM1, value) globals.set_float(MSM2, value) end) 
CSYONS22:add_action(" ~Use the multiplier to get max 8 mil~ ", function() end)
CSYONS22 = CSYON22:add_submenu("Autoshop Client Cars $$$ Methode") local function ACCC(e) if not localplayer then return end if e then globals.set_int(ACC1, 0) else globals.set_int(ACC1, 2880) end end 
CSYONS22:add_toggle("Remove Cooldown", function() return e35 end, function() e35 = not e35 ACCC(e35) end)
CSYONS22:add_int_range("% Chance", 5, 0, 100, function() return globals.get_int(CHA1) end, function(value) globals.set_int(CHA1, value) end)
CSYONS22:add_float_range("2 Lifts Cooldown Multiplier", 0.5, 0.0, 100, function() return globals.get_float(LOM1) end, function(value) globals.set_float(LOM1, value) end)
local function etCC(e) if not localplayer then return end if e then globals.set_int(EXT1, 99999) else globals.set_int(EXT1, 600) end end 
CSYONS22:add_toggle("Extend Timer", function() return e36 end, function() e36 = not e36 etCC(e36) end)
CSYONS22:add_int_range("Low Tier", 5000, 20000, 100000, function() return globals.get_int(MHT1) end, function(value) globals.set_int(MHT1, value) end)
CSYONS22:add_int_range("Mid Tier", 5000, 25000, 125000, function() return globals.get_int(MMT1) end, function(value) globals.set_int(MMT1, value) end)
CSYONS22:add_int_range("High Tier", 5000, 30000, 150000, function() return globals.get_int(MLT1) end, function(value) globals.set_int(MLT1, value) end)
CSYONS22 = CSYON22:add_submenu("Vehicle Cargo $$$ Methode") local function Max(e) if not localplayer then return end if e then globals.set_int(MAR1, 155000) globals.set_int(MAR2, 155000) globals.set_int(MAR3, 155000) globals.set_float(MAR4, 0) globals.set_float(MAR5, 0) else globals.set_int(MAR1, 40000) globals.set_int(MAR2, 25000) globals.set_int(MAR3, 15000) globals.set_float(MAR4, 0.25) globals.set_float(MAR5, 0.5) end end 
CSYONS22:add_toggle("Max all Ranges", function() return e17 end, function() e17 = not e17 Max(e17) end)
local function VCD(e) if not localplayer then return end if e then for i = VHR1, VHR2 do globals.set_int(i, 0) sleep(1) globals.set_int(i, 1) end globals.set_int(VHR3, 1) else globals.set_int(VHR3, 180000) globals.set_int(VHR1, 1200000) globals.set_int(VHR4, 1680000) globals.set_int(VHR5, 2340000) globals.set_int(VHR2, 2880000) end end 
CSYONS22:add_toggle("Remove Cooldown", function() return e18 end, function() e18 = not e18 VCD(e18) end)
local function VRC(e) if not localplayer then return end if e then for i = RRC1, RRC3 do globals.set_int(i, 0) end else globals.set_int(RRC1, 34000) globals.set_int(RRC2, 21250) globals.set_int(RRC3, 12750) end end 
CSYONS22:add_toggle("Remove Repair Cost", function() return e21 end, function() e21 = not e21 VRC(e21) end) 
CSYONS22:add_action("---", function() end)
CSYONS22:add_int_range("Top Range", 1000, 40000, 4000000, function() return globals.get_int(TOR1) end, function(value) globals.set_int(TOR1, value) end)
CSYONS22:add_int_range("Mid Range", 1000, 25000, 4000000, function() return globals.get_int(MIR1) end, function(value) globals.set_int(MIR1, value) end)
CSYONS22:add_int_range("Stanard Range", 1000, 15000, 4000000, function() return globals.get_int(STR1) end, function(value) globals.set_int(STR1, value) end)
CSYONS22:add_float_range("Sale Showroom", 0.5, 1.5, 1000, function() return globals.get_float(SAH1) end, function(value) globals.set_float(SAH1, value) end)
CSYONS22:add_float_range("Sale Specialist Dealer", 0.5, 2, 1000, function() return globals.get_float(SPD1) end, function(value) globals.set_float(SPD1, value) end)
CSYONS22:add_float_range("Upgrade Cost Showroom", 0.25, 0, 1000, function() return globals.get_float(UCR1) end, function(value) globals.set_float(UCR1, value) end)
CSYONS22:add_float_range("Upgrade Cost Specialist Dealer", 0.25, 0, 1000, function() return globals.get_float(UCS1) end, function(value) globals.set_float(UCS1, value) end)
CSYONS22:add_action("-----------------Supply Money Methode--------------------------", function() end)
CSYONS22:add_int_range("Set Sell price", 50000, 10000, 2000000, function() return globals.get_int(CsyonsACL1) end, function(Val) globals.set_int(CsyonsACL1, Val) end) 
CSYONS22:add_int_range("Product-Capacity", 1, 1, 2000000, function() return globals.get_int(CsyonsACL3) end, function(Val) globals.set_int(CsyonsACL3, Val) end) 
local function ACL(e) if not localplayer then return end if e then globals.set_int(CsyonsACL4, 0) globals.set_int(CsyonsACL5, 0) else globals.set_int(CsyonsACL4, 12000) globals.set_int(CsyonsACL5, 12000) end end 
CSYONS22:add_toggle("Reduce Resupply Cost", function() return e51 end, function() e51 = not e51 ACL(e51) end)
local function AC(e) if not localplayer then return end if e then globals.set_int(CsyonsACL6, 0) else globals.set_int(CsyonsACL6, 300000) end end 
CSYONS22:add_toggle("Remove Resupply Delay", function() return e53 end, function() e53 = not e53 AC(e53) end)
local function AL(e) if not localplayer then return end if e then globals.set_int(CsyonsACL2, 0) else globals.set_int(CsyonsACL2, 135000) end end 
CSYONS22:add_toggle("Remove Production Delay", function() return e52 end, function() e52 = not e52 AL(e52) end)
CSYONS22:add_action("--------------------------limit Max=2M--------------------------------", function() end)
CSYONS22:add_action("~~~~~~~~~~~Every Thing Tested in:solo public Lobby~~~~~~~~~~~~~~~~~~~~~~~", function() end)

local function reloadSpeed()
	if localplayer == number then
		return
	end
	current_weapon = localplayer:get_current_weapon()
		if current_weapon ~= number then
			current_weapon:set_reload_time_multiplier(0.1)
		end
    end
    
	CSYONS28:add_action("Reload Speed", reloadSpeed)
CSYONS28:add_action("                 _________Weapons modifyer_________", function() end)
local function wEp()if localplayer:get_current_weapon()then return true end return false end
 
local bT,WR,LR=0,0,0
local function OnWeaponChanged(oldWeapon, newWeapon)
	if newWeapon~=nil then NAME=localplayer:get_current_weapon():get_name_hash()
		if NAME==joaat("weapon_hominglauncher") then newWeapon:set_range(1500) elseif NAME==joaat("weapon_raypistol") then
			newWeapon:set_heli_force(1075) newWeapon:set_ped_force(63) newWeapon:set_vehicle_force(1075) end
		if bT==0 then if NAME==joaat("weapon_stungun_mp") or NAME==joaat("weapon_stungun") then newWeapon:set_time_between_shots(1)
			elseif NAME==joaat("weapon_raypistol") then newWeapon:set_time_between_shots(0.5) end
			else newWeapon:set_time_between_shots(bT) end
		if WR~=0 then newWeapon:set_range(WR) else if NAME==joaat("weapon_raypistol") then newWeapon:set_range(1200)
			elseif NAME==joaat("weapon_stungun_mp") or NAME==joaat("weapon_stungun") then newWeapon:set_range(1000) end end
		if LR==0 then if NAME==joaat("weapon_hominglauncher") then newWeapon:set_lock_on_range(1500) end
			else newWeapon:set_lock_on_range(LR) end end
end
------
if WCD then menu.remove_callback(WCD) end local WCD=nil
if enable then local WCD = menu.register_callback('OnWeaponChanged', OnWeaponChanged) end
 
local function mxwep()
	localplayer:get_current_weapon():set_heli_force(60000) localplayer:get_current_weapon():set_ped_force(60000)
	localplayer:get_current_weapon():set_vehicle_force(60000) localplayer:get_current_weapon():set_time_between_shots(0.1)
	localplayer:get_current_weapon():set_range(2000) localplayer:get_current_weapon():set_lock_on_range(2000)
	localplayer:get_current_weapon():set_spread(0.2)
end
if WepTw~=nil then menu.register_hotkey(WepTw, mxwep) end
 
CSYONS28:add_toggle("QuickFire-Atmzer,StnGun/Auto", function() return enable end, function()
	enable=not enable if enable then WCD=menu.register_callback('OnCSYONS28onChanged', OnWeaponChanged)else menu.remove_callback(WCD) bT,WR,LR=0,0,0 end
end)
 
CSYONS28:add_float_range("Time Between Shots for all", 0.1, 0, 4, function()if wEp()then return localplayer:get_current_weapon():get_time_between_shots()end end, function(BtSh)
	bT=BtSh localplayer:get_current_weapon():set_time_between_shots(BtSh)
end)
CSYONS28:add_float_range("Weapon Range for all", 10, 0, 1500, function()if wEp()then return localplayer:get_current_weapon():get_range()end end, function(range)
	WR=range localplayer:get_current_weapon():set_range(range)
end)
CSYONS28:add_float_range("Lock-On Range", 10, 0, 1500, function()if wEp()then return localplayer:get_current_weapon():get_lock_on_range()end end, function(Lock)
	LR=Lock localplayer:get_current_weapon():set_lock_on_range(Lock)
end)
CSYONS28:add_action("Max All weaponstats", function() mxwep() end)
WepTw=nil
CSYONS28:add_action("____________________________________", function() end)

CSYONS24:add_action("Share Cash from Last Job", function() 
			stats.set_int(2793046, 283) 
			stats.set_int(2793046, 284) -- Share Cash from Last Job (Total Earned)
end)

CSYONS25:add_action("Unlock Rare Outfits", function() 
			stats.set_int(262145, 16784) 
			stats.set_int(262145, 16785)
			stats.set_int(262145, 16786)
			stats.set_int(262145, 16787)
			stats.set_int(262145, 16788)
			stats.set_int(262145, 16789)
			stats.set_int(262145, 16790)
			stats.set_int(262145, 23407)
			stats.set_int(262145, 23408)
			stats.set_int(262145, 23409)
			stats.set_int(262145, 23410)
			stats.set_int(262145, 23411)
			stats.set_int(262145, 28690)
			stats.set_int(262145, 28691)
			stats.set_int(262145, 28692)
			stats.set_int(262145, 28693)
			stats.set_int(262145, 31208)
			stats.set_int(262145, 31191) 
			stats.set_int(262145, 31198)
			stats.set_int(262145, 31199)
			stats.set_int(262145, 32938)
			stats.set_int(262145, 34043)
			stats.set_int(262145, 34044)
			stats.set_int(262145, 34045)
			stats.set_int(262145, 33794)
end)

CSYONS25:add_action("Unlock Junk Energy Drink Chute Bag", function() 
			stats.set_boolean(34378, true) 
end)

CSYONS25:add_action("Unlock Rare Masks", function() 
			stats.set_boolean(27087, true) 
			stats.set_boolean(34372, true) 
			stats.set_boolean(27088, true)  
end)

CSYONS24:add_action(" Drop Car ", function() CarDrop() end)

CSYONS28:add_action(" Full Ammo ", function() menu.max_all_ammo() end)
local function reloadSpeed()
	if localplayer == number then
		return
	end
	current_weapon = localplayer:get_current_weapon()
		if current_weapon ~= number then
			current_weapon:set_time_between_shots(0.05)
		end
end
CSYONS28:add_action(" Reload ( stun Gun ) Speed ", reloadSpeed)

CSYONS28:add_action("Extreme Bullets", function() EXPLO() end)
function EXPLO()
    if localplayer ~= nil then
     localplayer:get_current_weapon():set_bullet_damage(1000000)
     localplayer:get_current_weapon():set_vehicle_force(1000000)
end end

CSYONS28:add_action(" Force Gun ", function() force_gun() end)
CSYONS28:add_action(" Boom Gun ", function() boom_gun() end)
CSYONS28:add_action(" Nuke Gun ", function() nuke_gun() end)

 CSYONS29:add_action(" Remove Cops ", function() menu.clear_wanted_level() end)

 CSYONS29:add_action(" Set 1* ", function() localplayer:set_wanted_level(1) end)
 CSYONS29:add_action(" Set 2** ", function() localplayer:set_wanted_level(2) end)
 CSYONS29:add_action(" Set 3*** ", function() localplayer:set_wanted_level(3) end)
 CSYONS29:add_action(" Set 4**** ", function() localplayer:set_wanted_level(4) end)
 CSYONS29:add_action(" Set 5***** ", function() localplayer:set_wanted_level(5) end)
 CSYONS29:add_action(" Set 6****** ", function() localplayer:set_wanted_level(6) end)

CSYONS24:add_action("name your Acids", function() 
globals.set_int(2792112, 0)
end)

function hsvToRgb(h, s, v)
    local r, g, b
  
    local i = math.floor(h * 6);
    local f = h * 6 - i;
    local p = v * (1 - s);
    local q = v * (1 - f * s);
    local t = v * (1 - (1 - f) * s);
  
    i = i % 6
    if i == 0 then r, g, b = v, t, p
    elseif i == 1 then r, g, b = q, v, p
    elseif i == 2 then r, g, b = p, v, t
    elseif i == 3 then r, g, b = p, q, v
    elseif i == 4 then r, g, b = t, p, v
    elseif i == 5 then r, g, b = v, p, q
    end
  
    return math.floor(r * 255), math.floor(g * 255), math.floor(b * 255)
end
 
b = false
s = 0.5
CSYONS23:add_toggle("Smooth Rainbow Car",function() return b end,function() b = not b menu.emit_event("Rainbow_Vehicle_Start") end)
CSYONS23:add_float_range("Rainbow Speed", 0.1, 0.1, 2.0,function() return s end,function(v) s = v end)
menu.register_callback("Rainbow_Vehicle_Start", function()
    t = 0
    while b == true do
        t=t+1
        p = localplayer
        v = p and p:get_current_vehicle() or nil
        if v then
            c_r,c_g,c_b = hsvToRgb(t/100 * s, 1, 1)
            v:set_custom_primary_colour(c_r,c_g,c_b)
            v:set_custom_secondary_colour(c_r,c_g,c_b)
        end
        sleep(0.01)
    end
end)

CSYONS24:add_action(" Kill Current Vehicle", function() menu.kill_current_vehicle() end)
CSYONS24:add_action(" Kill All Vehicles", function() menu.kill_all_vehicles() end)

CSYONS23:add_action(" Return car garage", function() menu.deliver_personal_vehicle() end)
CSYONS23:add_action(" Get in your car", function() menu.enter_personal_vehicle() end)
CSYONS28:add_action(" Full All Ammo ", function() menu.max_all_ammo() end)
CSYONS24:add_toggle(" Big Map", function() return BigMap end, function() BigMap = not BigMap menu.set_big_map(BigMap) end)
CSYONS24:add_toggle(" Open Radio", function() return MobileRadio end, function() MobileRadio = not MobileRadio menu.set_mobile_radio(MobileRadio) end)

config = {
	use_metric = true
}
 
function display_online_vehicle_speed()
	if localplayer == nil then
		return
	end 
	
	local current_vehicle = localplayer:get_current_vehicle()
	if current_vehicle == nil or not localplayer:is_in_vehicle() then
		return
	end
	
	local velocity = current_vehicle:get_velocity()
	local mps = math.sqrt(velocity.x * velocity.x + velocity.y * velocity.y + velocity.z * velocity.z)
	
	if config['use_metric'] == true then 
		globals.set_string(2703735 + 2400 + 1 + 8, "AMCH_KMHN", 32)
		globals.set_int(2703735 + 2400 + 1 + 3, math.floor(mps * 3.6 + 0.5))
	else
		globals.set_string(2703735 + 2400 + 1 + 8, "AMCH_MPHN", 32)
		globals.set_int(2703735 + 2400 + 1 + 3, math.floor(mps * 0.6214 + 0.5))
	end
 
	globals.set_string(2703735 + 2400 + 1 + 21, "FM_AE_SORT_3", 16)
	globals.set_int(2703735 + 2400 + 1 + 1, 11)
	globals.set_int(2703735 + 2400 + 1 + 2, 1)
end
 
CSYONS23:add_action("Show current speed", display_online_vehicle_speed)

CSYONS29:add_action("Max Stats", function() 
			stats.set_int(MPX() .. "SCRIPT_INCREASE_DRIV", 100) 
			stats.set_int(MPX() .. "SCRIPT_INCREASE_FLY", 100) 
			stats.set_int(MPX() .. "SCRIPT_INCREASE_LUNG", 100) 
			stats.set_int(MPX() .. "SCRIPT_INCREASE_SHO", 100) 
			stats.set_int(MPX() .. "SCRIPT_INCREASE_STAM", 100) 
			stats.set_int(MPX() .. "SCRIPT_INCREASE_STL", 100) 
			stats.set_int(MPX() .. "SCRIPT_INCREASE_STRN", 100) end)
		
	CSYONS29:add_int_range("Stamina", 2, 0, 100, function() return stats.get_int(MPX() .. "STAMINA") end, function(Stam) stats.set_int(MPX() .. "SCRIPT_INCREASE_STAM", 0) sleep(5) stats.set_int(MPX() .. "SCRIPT_INCREASE_STAM", Stam - stats.get_int(MPX() .. "STAMINA")) end)
	CSYONS29:add_int_range("Shooting", 2, 0, 100, function() return stats.get_int(MPX() .. "SHOOTING_ABILITY") end, function(Sho) stats.set_int(MPX() .. "SCRIPT_INCREASE_SHO", 0) sleep(5) stats.set_int(MPX() .. "SCRIPT_INCREASE_SHO", Sho - stats.get_int(MPX() .. "SHOOTING_ABILITY")) end)
	CSYONS29:add_int_range("Strength", 2, 0, 100, function() return stats.get_int(MPX() .. "STRENGTH") end, function(Strn) stats.set_int(MPX() .. "SCRIPT_INCREASE_STRN", 0) sleep(5) stats.set_int(MPX() .. "SCRIPT_INCREASE_STRN", Strn - stats.get_int(MPX() .. "STRENGTH")) end)
	CSYONS29:add_int_range("Stealth", 2, 0, 100, function() return stats.get_int(MPX() .. "STEALTH_ABILITY") end, function(Stl) stats.set_int(MPX() .. "SCRIPT_INCREASE_STL", 0) sleep(5) stats.set_int(MPX() .. "SCRIPT_INCREASE_STL", Stl - stats.get_int(MPX() .. "STEALTH_ABILITY")) end)
	CSYONS29:add_int_range("Flying", 2, 0, 100, function() return stats.get_int(MPX() .. "FLYING_ABILITY") end, function(Fly) stats.set_int(MPX() .. "SCRIPT_INCREASE_FLY", 0) sleep(5) stats.set_int(MPX() .. "SCRIPT_INCREASE_FLY", Fly - stats.get_int(MPX() .. "FLYING_ABILITY")) end)
	CSYONS29:add_int_range("Driving", 2, 0, 100, function() return stats.get_int(MPX() .. "WHEELIE_ABILITY") end, function(Driv) stats.set_int(MPX() .. "SCRIPT_INCREASE_DRIV", 0) sleep(5) stats.set_int(MPX() .. "SCRIPT_INCREASE_DRIV", Driv - stats.get_int(MPX() .. "WHEELIE_ABILITY")) end)
	CSYONS29:add_int_range("Swimming", 2, 0, 100, function() return stats.get_int(MPX() .. "LUNG_CAPACITY") end, function(Lung) stats.set_int(MPX() .. "SCRIPT_INCREASE_LUNG", 0) sleep(5) stats.set_int(MPX() .. "SCRIPT_INCREASE_LUNG", stats.get_int(MPX() .. "LUNG_CAPACITY")) end)
	CSYONS29:add_float_range("Psychics", 2, 0, 100, function() return stats.get_float(MPX() .. "PLAYER_MENTAL_STATE") end, function(Ment) stats.set_float(MPX() .. "PLAYER_MENTAL_STATE", Ment) end)

CSYONS28:add_action("WEAPON_LOADOUT_1", function()
	MPX = stats.get_int("mpply_last_mp_char")
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 2) -- Index: 7387 // Pistol
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 3) -- Index: 7388 // Combat Pistol
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", false, 4) -- Index: 7389 // AP Pistol
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 5) -- Index: 7390 // SMG
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 6) -- Index: 7391 // Assault Rifle
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 7) -- Index: 7392 // Carbine Rifle
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 8) -- Index: 7393 // Advanced Rifle
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 9) -- Index: 7394 // MG
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 10) -- Index: 7395 // Combat MG
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 11) -- Index: 7396 // Pump Shotgun
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 12) -- Index: 7397 // Sawed-Off Shotgun
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 13) -- Index: 7398 // Assault Shotgun
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 14) -- Index: 7399 // Sniper Rifle
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 15) -- Index: 7400 // Grenade Launcher
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 16) -- Index: 7401 // RPG
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 17) -- Index: 7402 // Minigun
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", false, 18) -- Index: 7403 // Grenade
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 19) -- Index: 7404 // Tear Gas
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 20) -- Index: 7405 // Sticky Bomb
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 21) -- Index: 7406 // Molotov
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 23) -- Index: 7408 // Knife
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 24) -- Index: 7409 // Nightstick
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 25) -- Index: 7410 // Hammer
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 26) -- Index: 7411 // Pistol .50
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 27) -- Index: 7412 // Assault SMG
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 28) -- Index: 7413 // Heavy Rifle
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 29) -- Index: 7414 // Bullpup Shotgun
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 32) -- Index: 7417 // Special Carbine
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 33) -- Index: 7418 // Bottle
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 34) -- Index: 7419 // Bullpup Rifle
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 35) -- Index: 7420 // Heavy Pistol
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 36) -- Index: 7421 // SNS Pistol
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 37) -- Index: 7422 // Antique Cavalry Dagger
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 38) -- Index: 7423 // Vintage Pistol
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 39) -- Index: 7424 // Gusenberg Sweeper
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", false, 40) -- Index: 7425 // Flare Gun
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 41) -- Index: 7426 // Firework Launcher
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 42) -- Index: 7427 // Musket
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 44) -- Index: 7429 // Heavy Shotgun
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 45) -- Index: 7430 // Marksman Rifle
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 46) -- Index: 7431 // Homing Launcher
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 47) -- Index: 7432 // Proximity Mine
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", false, 49) -- Index: 7434 // Combat PDW
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 50) -- Index: 7435 // Knuckle Duster
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 51) -- Index: 7436 // Marksman Pistol
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 52) -- Index: 7437 // Hatchet
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", false, 53) -- Index: 7438 // Compact Rifle
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 54) -- Index: 7439 // Double Barrel Shotgun
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 55) -- Index: 7440 // Machete
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 56) -- Index: 7441 // Machine Pistol
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 57) -- Index: 7442 // Flashlight
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 58) -- Index: 7443 // Heavy Revolver
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 59) -- Index: 7444 // Switchblade
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 60) -- Index: 7445 // Micro SMG
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 61) -- Index: 7446 // Heavy Sniper
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 62) -- Index: 7447 // Jerry Can
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 63) -- Index: 7448 // Golf Club
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", true, 0) -- Index: 7449 // Baseball Bat
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", false, 1) -- Index: 7450 // All Melee Weapons 
    stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", false, 2) -- Index: 7451 // All Pistols
    stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", false, 3) -- Index: 7452 // All Machine Guns
    stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", false, 4) -- Index: 7453 // All Rifles
    stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", false, 5) -- Index: 7454 // All Shotguns
    stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", false, 6) -- Index: 7455 // All Snipers
    stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", false, 7) -- Index: 7456 // All Heavy Weapons
    stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", false, 8) -- Index: 7457 // All Explosives
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", false, 17) -- Index: 7466 // Crowbar
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL3", false, 44) -- Index: 7621 // Sweeper Shotgun
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL3", true, 45) -- Index: 7622 // Battle Axe
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL3", false, 46) -- Index: 7623 // Compact Grenade Launcher
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL3", true, 47) -- Index: 7624 // Mini SMG
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL3", true, 48) -- Index: 7625 // Pipe Bomb
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL3", true, 49) -- Index: 7626 // Pool Cue
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL3", true, 50) -- Index: 7627 // Pipe Wrench
	stats.set_bool_masked("MP"..MPX().."_DLCGUNPSTAT_BOOL2", true, 51) -- Index: 15548 // Stone Hatchet
	stats.set_bool_masked("MP"..MPX().."_DLCSMUGCHARPSTAT_BOOL0", true, 49) -- Index: 15995 // Double-Action Revolver
	stats.set_bool_masked("MP"..MPX().."_ARENAWARSPSTAT_BOOL4", false, 23) -- Index: 25241 // Up-n-Atomizer
	stats.set_bool_masked("MP"..MPX().."_ARENAWARSPSTAT_BOOL4", true, 24) -- Index: 25242 // Unholy Hellbringer
	stats.set_bool_masked("MP"..MPX().."_ARENAWARSPSTAT_BOOL4", true, 25) -- Index: 25243 // Widowmaker
	stats.set_bool_masked("MP"..MPX().."_ARENAWARSPSTAT_BOOL8", true, 44) -- Index: 25518 // Ceramic Pistol
	stats.set_bool_masked("MP"..MPX().."_ARENAWARSPSTAT_BOOL8", true, 45) -- Index: 25519 // Navy Revolver
	stats.set_bool_masked("MP"..MPX().."_CASINOHSTPSTAT_BOOL2", false, 33) -- Index: 28259 // Compact EMP Launcher
	stats.set_bool_masked("MP"..MPX().."_CASINOHSTPSTAT_BOOL2", true, 35) -- Index: 28261 // Stun Gun
	stats.set_bool_masked("MP"..MPX().."_DLCGUNPSTAT_BOOL1", true, 8) -- Index: 15441 // Pistol Mk II
	stats.set_bool_masked("MP"..MPX().."_DLCGUNPSTAT_BOOL1", true, 9) -- Index: 15442 // SMG Mk II
	stats.set_bool_masked("MP"..MPX().."_DLCGUNPSTAT_BOOL1", false, 10) -- Index: 15443 // Heavy Sniper Mk II
	stats.set_bool_masked("MP"..MPX().."_DLCGUNPSTAT_BOOL1", true, 11) -- Index: 15444 // Combat MG Mk II
	stats.set_bool_masked("MP"..MPX().."_DLCGUNPSTAT_BOOL1", true, 12) -- Index: 15445 // Assault Rifle Mk II
	stats.set_bool_masked("MP"..MPX().."_DLCGUNPSTAT_BOOL1", true, 13) -- Index: 15446 // Carbine Rifle Mk II
	stats.set_bool_masked("MP"..MPX().."_GANGOPSPSTAT_BOOL0", true, 2) -- Index: 18100 // Bullpup Rifle Mk II
	stats.set_bool_masked("MP"..MPX().."_GANGOPSPSTAT_BOOL0", false, 3) -- Index: 18101 // Marksman Rifle Mk II
	stats.set_bool_masked("MP"..MPX().."_GANGOPSPSTAT_BOOL0", true, 4) -- Index: 18102 // Pump Shotgun Mk II
	stats.set_bool_masked("MP"..MPX().."_GANGOPSPSTAT_BOOL0", true, 5) -- Index: 18103 // Heavy Revolver Mk II
	stats.set_bool_masked("MP"..MPX().."_GANGOPSPSTAT_BOOL0", true, 6) -- Index: 18104 // SNS Pistol Mk II
	stats.set_bool_masked("MP"..MPX().."_GANGOPSPSTAT_BOOL0", true, 7) -- Index: 18105 // Special Carbine Mk II
	stats.set_bool_masked("MP"..MPX().."_SU20PSTAT_BOOL1", true, 30) -- Index: 30321 // Military Rifle
	stats.set_bool_masked("MP"..MPX().."_SU20PSTAT_BOOL1", true, 31) -- Index: 30322 // Perico Pistol
	stats.set_bool_masked("MP"..MPX().."_SU20PSTAT_BOOL1", true, 32) -- Index: 30323 // Combat Shotgun
	stats.set_bool_masked("MP"..MPX().."_DLC12022PSTAT_BOOL1", true, 61) -- Index: 34376 // Service Carbine
	stats.set_bool_masked("MP"..MPX().."_DLC12022PSTAT_BOOL1", true, 62) -- Index: 34377 // Precision Rifle
	stats.set_bool_masked("MP"..MPX().."_DLC22022PSTAT_BOOL0", true, 43) -- Index: 36670 // WM 29 Pistol
	stats.set_bool_masked("MP"..MPX().."_DLC22022PSTAT_BOOL0", true, 44) -- Index: 36671 // Candy Cane
	stats.set_bool_masked("MP"..MPX().."_DLC22022PSTAT_BOOL0", false, 45) -- Index: 36672 // Railgun
end)
 
CSYONS28:add_action("WEAPON_LOADOUT_2", function()
	MPX = stats.get_int("mpply_last_mp_char")
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 2) -- Index: 7387 // Pistol
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 3) -- Index: 7388 // Combat Pistol
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", false, 4) -- Index: 7389 // AP Pistol
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 5) -- Index: 7390 // SMG
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 6) -- Index: 7391 // Assault Rifle
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 7) -- Index: 7392 // Carbine Rifle
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 8) -- Index: 7393 // Advanced Rifle
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 9) -- Index: 7394 // MG
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 10) -- Index: 7395 // Combat MG
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 11) -- Index: 7396 // Pump Shotgun
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 12) -- Index: 7397 // Sawed-Off Shotgun
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 13) -- Index: 7398 // Assault Shotgun
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 14) -- Index: 7399 // Sniper Rifle
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 15) -- Index: 7400 // Grenade Launcher
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 16) -- Index: 7401 // RPG
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 17) -- Index: 7402 // Minigun
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", false, 18) -- Index: 7403 // Grenade
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 19) -- Index: 7404 // Tear Gas
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 20) -- Index: 7405 // Sticky Bomb
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 21) -- Index: 7406 // Molotov
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 23) -- Index: 7408 // Knife
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 24) -- Index: 7409 // Nightstick
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 25) -- Index: 7410 // Hammer
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 26) -- Index: 7411 // Pistol .50
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 27) -- Index: 7412 // Assault SMG
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 28) -- Index: 7413 // Heavy Rifle
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 29) -- Index: 7414 // Bullpup Shotgun
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 32) -- Index: 7417 // Special Carbine
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 33) -- Index: 7418 // Bottle
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 34) -- Index: 7419 // Bullpup Rifle
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 35) -- Index: 7420 // Heavy Pistol
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 36) -- Index: 7421 // SNS Pistol
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 37) -- Index: 7422 // Antique Cavalry Dagger
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 38) -- Index: 7423 // Vintage Pistol
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 39) -- Index: 7424 // Gusenberg Sweeper
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 40) -- Index: 7425 // Flare Gun
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 41) -- Index: 7426 // Firework Launcher
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 42) -- Index: 7427 // Musket
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 44) -- Index: 7429 // Heavy Shotgun
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 45) -- Index: 7430 // Marksman Rifle
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 46) -- Index: 7431 // Homing Launcher
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 47) -- Index: 7432 // Proximity Mine
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 49) -- Index: 7434 // Combat PDW
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 50) -- Index: 7435 // Knuckle Duster
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 51) -- Index: 7436 // Marksman Pistol
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 52) -- Index: 7437 // Hatchet
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", false, 53) -- Index: 7438 // Compact Rifle
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 54) -- Index: 7439 // Double Barrel Shotgun
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 55) -- Index: 7440 // Machete
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 56) -- Index: 7441 // Machine Pistol
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 57) -- Index: 7442 // Flashlight
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 58) -- Index: 7443 // Heavy Revolver
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 59) -- Index: 7444 // Switchblade
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 60) -- Index: 7445 // Micro SMG
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 61) -- Index: 7446 // Heavy Sniper
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 62) -- Index: 7447 // Jerry Can
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL0", true, 63) -- Index: 7448 // Golf Club
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", true, 0) -- Index: 7449 // Baseball Bat
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", false, 1) -- Index: 7450 // All Melee Weapons 
    stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", false, 2) -- Index: 7451 // All Pistols
    stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", false, 3) -- Index: 7452 // All Machine Guns
    stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", false, 4) -- Index: 7453 // All Rifles
    stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", false, 5) -- Index: 7454 // All Shotguns
    stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", false, 6) -- Index: 7455 // All Snipers
    stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", false, 7) -- Index: 7456 // All Heavy Weapons
    stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", false, 8) -- Index: 7457 // All Explosives
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL1", true, 17) -- Index: 7466 // Crowbar
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL3", false, 44) -- Index: 7621 // Sweeper Shotgun
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL3", true, 45) -- Index: 7622 // Battle Axe
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL3", true, 46) -- Index: 7623 // Compact Grenade Launcher
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL3", true, 47) -- Index: 7624 // Mini SMG
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL3", true, 48) -- Index: 7625 // Pipe Bomb
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL3", true, 49) -- Index: 7626 // Pool Cue
	stats.set_bool_masked("MP"..MPX().."_NGDLCPSTAT_BOOL3", true, 50) -- Index: 7627 // Pipe Wrench
	stats.set_bool_masked("MP"..MPX().."_DLCGUNPSTAT_BOOL2", true, 51) -- Index: 15548 // Stone Hatchet
	stats.set_bool_masked("MP"..MPX().."_DLCSMUGCHARPSTAT_BOOL0", true, 49) -- Index: 15995 // Double-Action Revolver
	stats.set_bool_masked("MP"..MPX().."_ARENAWARSPSTAT_BOOL4", true, 23) -- Index: 25241 // Up-n-Atomizer
	stats.set_bool_masked("MP"..MPX().."_ARENAWARSPSTAT_BOOL4", true, 24) -- Index: 25242 // Unholy Hellbringer
	stats.set_bool_masked("MP"..MPX().."_ARENAWARSPSTAT_BOOL4", true, 25) -- Index: 25243 // Widowmaker
	stats.set_bool_masked("MP"..MPX().."_ARENAWARSPSTAT_BOOL8", true, 44) -- Index: 25518 // Ceramic Pistol
	stats.set_bool_masked("MP"..MPX().."_ARENAWARSPSTAT_BOOL8", true, 45) -- Index: 25519 // Navy Revolver
	stats.set_bool_masked("MP"..MPX().."_CASINOHSTPSTAT_BOOL2", true, 33) -- Index: 28259 // Compact EMP Launcher
	stats.set_bool_masked("MP"..MPX().."_CASINOHSTPSTAT_BOOL2", true, 35) -- Index: 28261 // Stun Gun
	stats.set_bool_masked("MP"..MPX().."_DLCGUNPSTAT_BOOL1", true, 8) -- Index: 15441 // Pistol Mk II
	stats.set_bool_masked("MP"..MPX().."_DLCGUNPSTAT_BOOL1", true, 9) -- Index: 15442 // SMG Mk II
	stats.set_bool_masked("MP"..MPX().."_DLCGUNPSTAT_BOOL1", true, 10) -- Index: 15443 // Heavy Sniper Mk II
	stats.set_bool_masked("MP"..MPX().."_DLCGUNPSTAT_BOOL1", true, 11) -- Index: 15444 // Combat MG Mk II
	stats.set_bool_masked("MP"..MPX().."_DLCGUNPSTAT_BOOL1", true, 12) -- Index: 15445 // Assault Rifle Mk II
	stats.set_bool_masked("MP"..MPX().."_DLCGUNPSTAT_BOOL1", true, 13) -- Index: 15446 // Carbine Rifle Mk II
	stats.set_bool_masked("MP"..MPX().."_GANGOPSPSTAT_BOOL0", true, 2) -- Index: 18100 // Bullpup Rifle Mk II
	stats.set_bool_masked("MP"..MPX().."_GANGOPSPSTAT_BOOL0", true, 3) -- Index: 18101 // Marksman Rifle Mk II
	stats.set_bool_masked("MP"..MPX().."_GANGOPSPSTAT_BOOL0", true, 4) -- Index: 18102 // Pump Shotgun Mk II
	stats.set_bool_masked("MP"..MPX().."_GANGOPSPSTAT_BOOL0", true, 5) -- Index: 18103 // Heavy Revolver Mk II
	stats.set_bool_masked("MP"..MPX().."_GANGOPSPSTAT_BOOL0", true, 6) -- Index: 18104 // SNS Pistol Mk II
	stats.set_bool_masked("MP"..MPX().."_GANGOPSPSTAT_BOOL0", true, 7) -- Index: 18105 // Special Carbine Mk II
	stats.set_bool_masked("MP"..MPX().."_SU20PSTAT_BOOL1", true, 30) -- Index: 30321 // Military Rifle
	stats.set_bool_masked("MP"..MPX().."_SU20PSTAT_BOOL1", true, 31) -- Index: 30322 // Perico Pistol
	stats.set_bool_masked("MP"..MPX().."_SU20PSTAT_BOOL1", true, 32) -- Index: 30323 // Combat Shotgun
	stats.set_bool_masked("MP"..MPX().."_DLC12022PSTAT_BOOL1", true, 61) -- Index: 34376 // Service Carbine
	stats.set_bool_masked("MP"..MPX().."_DLC12022PSTAT_BOOL1", true, 62) -- Index: 34377 // Precision Rifle
	stats.set_bool_masked("MP"..MPX().."_DLC22022PSTAT_BOOL0", true, 43) -- Index: 36670 // WM 29 Pistol
	stats.set_bool_masked("MP"..MPX().."_DLC22022PSTAT_BOOL0", true, 44) -- Index: 36671 // Candy Cane
	stats.set_bool_masked("MP"..MPX().."_DLC22022PSTAT_BOOL0", false, 45) -- Index: 36672 // Railgun
end)

CSYONS27:add_toggle("limp", function()
	if localplayer == nil then
		return nil
	end
	return localplayer:get_config_flag(166)
end, function(value)
	localplayer:set_config_flag(166, value)
end)
 
CSYONS27:add_toggle("limp with weapon", function()
	if localplayer == nil then
		return nil
	end
 
	return localplayer:get_config_flag(187)
end, function(value)
	localplayer:set_config_flag(187, value)
end)
 
CSYONS27:add_toggle("disable engine auto stop", function()
	if localplayer == nil then
		return nil
	end
 
	return localplayer:get_config_flag(241)
end, function(value)
	localplayer:set_config_flag(241, value)
end)
 
CSYONS27:add_toggle("freeze player", function()
	if localplayer == nil then
		return nil
	end
 
	return localplayer:get_config_flag(292)
end, function(value)
	localplayer:set_config_flag(292, value)
end)
 
CSYONS27:add_toggle("attack friendlies", function()
	if localplayer == nil then
		return nil
	end
 
	return localplayer:get_config_flag(140)
end, function(value)
	localplayer:set_config_flag(140, value)
end)

CSYONS24:add_toggle("Freeze Momentum", function()	
	if localplayer == nil then
		return nil
	end
 
	return localplayer:get_freeze_momentum()
end, function(value)
	localplayer:set_freeze_momentum(value)
end)
 
CSYONS24:add_toggle("Passive/Pussymode", function()	
	if localplayer == nil then
		return nil
	end
 
	return menu.get_passive()
end, function(value)
	menu.set_passive(value)
end)
 
 
CSYONS24:add_toggle("No Ragdoll lool", function()	
	if localplayer == nil then
		return nil
	end
 
	return localplayer:get_no_ragdoll()
end, function(value)
	localplayer:set_no_ragdoll(value)
end)

--Protect him
CSYONS26:add_toggle("Activate All", function()
	return boolall
end, function()
	boolall = not boolall
	All(boolall)
end)
--Text("<Protections>")
CSYONS26:add_toggle("Block Bounty", function()
	return globals.get_bool(1669471)
end, function()
	Bounty(not globals.get_bool(1669471))
end)
 
 
CSYONS26:add_toggle("Block Socialclub Spam", function()
	return getBlockSocialClubSpamState()
end, function(value)
	BlockSocialclubSpam(value)
end)
 
CSYONS26:add_toggle("Block Remote Global Modification", function()
	return getRemoteGlobalModificationState()
end, function()
	RemoteGlobalModification(not getRemoteGlobalModificationState())
end)
 
CSYONS26:add_toggle("Block Some Kicks&&Crashes", function()
	return getKickCrashesState()
end, function()
	KickCrashes(not getKickCrashesState())
end)
 
CSYONS26:add_toggle("Block Ceo Kick", function()
	return globals.get_bool(1669984)
end, function()
	CeoKick(not globals.get_bool(1669984))
end)
 
CSYONS26:add_toggle("Block Ceo Ban", function()
	return globals.get_bool(1670006) 
end, function()
	CeoBan(not globals.get_bool(1670006))
end)
 
CSYONS26:add_toggle("Block Sound Spam", function()
	return getSoundSpamState()
end, function()
	SoundSpam(not getSoundSpamState())
end)
 
CSYONS26:add_toggle("Block Infinite Loadingscreen", function()
	return getInfiniteLoadState()
end, function()
	InfiniteLoad(not getInfiniteLoadState())
end)
 
CSYONS26:add_toggle("Block Passive Mode", function()
	return globals.get_bool(1669996) 
end, function()
	PassiveMode(not globals.get_bool(1669996))
end)
 
CSYONS26:add_toggle("Block Transaction Error", function()
	return globals.get_bool(1669797)
end, function()
	TransactionError(not globals.get_bool(1669797))
end)
 
CSYONS26:add_toggle("Block Modded Notifys/SMS", function()
	return getRemoveMoneyMessageState()
end, function()
	RemoveMoneyMessage(not getRemoveMoneyMessageState())
end)
 
CSYONS26:add_toggle("Block Clear Wanted", function()
	return globals.get_bool(1669938)
end, function()
	ClearWanted(not globals.get_bool(1669938))
end)
 
CSYONS26:add_toggle("Block Off The Radar", function()
	return globals.get_bool(1669940)
end, function()
	OffTheRadar(not globals.get_bool(1669940))
end)
 
CSYONS26:add_toggle("Block Personal Vehicle Destroy", function()
	return getPersonalVehicleDestroyState()
end, function()
	PersonalVehicleDestroy(not getPersonalVehicleDestroyState())
end)
 
CSYONS26:add_toggle("Block Send to Cutscene", function()
	return globals.get_bool(1670198)
end, function()
	SendCutscene(not globals.get_bool(1670198))
end)
 
CSYONS26:add_toggle("Block Remove Godmode", function()
	return globals.get_bool(1669396)
end, function()
	Godmode(not globals.get_bool(1669396))
end)
 
CSYONS26:add_toggle("Block Give Collectibles", function()
	return globals.get_bool(1670208)
end, function()
	Collectibles(not globals.get_bool(1670208))
end)
 
CSYONS26:add_toggle("Block Cayo && Beach Teleport", function()
	return getExtraTeleportState()
end, function()
	ExtraTeleport(not getExtraTeleportState())
end)
 
function OnScriptsLoaded()
	local social_controller = script("social_controller")
	while true do
		if blockSocialClubSpamState then
			if social_controller:is_active() then
				social_controller:set_int(169, 0)
			end
		end
		sleep(1)
	end
end
 
menu.register_callback('OnScriptsLoaded', OnScriptsLoaded)
--Protections

CSYONS26:add_action("Remove Transaction Error", function()
	globals.set_int(4536679, 20)
	globals.set_int(4536679, 4)
	globals.set_int(4536679, 0)
end)

	--menu.register_hotkey(35, function()	--END key
	--if localplayer:is_in_vehicle() then
		--current_vehicle = localplayer:get_current_vehicle()
		 --current_vehicle:set_health(current_vehicle:get_max_health())
		 --menu.repair_online_vehicle()
		--current_vehicle:set_dirt_level(0.0)
	--end
--end)

CSYONS23:add_toggle("Automatically Repair Vehicle", function() return autorepairvehicle end, function(value) autorepairvehicle = value end) 

CSYONS23:add_action("Vehicle No Collision", function()
if localplayer:is_in_vehicle() then
   current_vehicle = localplayer:get_current_vehicle()
   end
end)

CSYONS23:add_action("Vehicle Max Speed", function()
if localplayer:is_in_vehicle() then
   current_vehicle = localplayer:get_current_vehicle()
   current_vehicle:set_max_speed(1000.00)
   end
end)

CSYONS22:add_toggle("Start Ceo Banager",
  function()
    return boolCeoBanager
  end,
  function()
    boolCeoBanager = not boolCeoBanager;
    funcCeoBanger(boolCeoBanager)
  end)

			NoRP = false
	CSYONS22:add_toggle("Disable RP Earning", function() return NoRP end, function() NoRP = not NoRP end)
            if NoRP == true then globals.set_float(262146, 1)
		else globals.set_float(262146, 0) end

CSYONS22:add_action("1-10 per Press", function() for i = 12, 16 do stats.set_bool_masked(MPX() .. "FIXERPSTAT_BOOL1", true, i, MPX()) end end)
	
			GCv0 = false
		local function GCv1()
		while GCv0 == true do for i = 12, 16 do stats.set_bool_masked(MPX() .. "FIXERPSTAT_BOOL1", true, i, MPX()) end end end
CSYONS22:add_toggle("Crates Loop", function() return GCv0 end, function() GCv0 = not GCv0 GCv1(GCv0) end)
	
			GCv2 = 1
CSYONS22:add_int_range("Instant Buy", 1, 1, 111, function() return GCv2 end, 
		function(CV) if GCB:is_active() then
					    GCB:set_int(598 + 5, 1)
					    GCB:set_int(598 + 1, CV)
					    GCB:set_int(598 + 191, 6)
					    GCB:set_int(598 + 192, 4)
					    GCv2 = CV end end)

local WH = script("am_mp_warehouse")
local function Cloop(bool)
	while bool do
		if WH:is_active() then
			menu.send_key_up(83)
			menu.send_key_press(69)
			sleep(1)
			if not WH:is_active() then
				menu.send_key_press(13)
				menu.send_key_down(83)
			end
		end
	end
end

CSYONS22:add_toggle("Automatic Sell Crate AFK Female & Male", function()
	return boolcl
end, function()
	boolcl = not boolcl
	Cloop(boolcl)
	
end)

CSYONS22r=CSYON22:add_submenu("Special Cargo Money methode") 
	 
	CSYONS22r:add_int_range("Price per Crate", 4995000, 10000, 9990000, function() 
    	return globals.get_int(262145 + 15788)
    end, function(value)
    	globals.set_int(262145 + 15788, value)
    end)
	
	CSYONS22r:add_int_range("Price per Crate(1,5x)", 4995000, 10000, 6660000, function() 
    	return globals.get_int(262145 + 15788)
    end, function(value)
    	globals.set_int(262145 + 15788, value)
    end)
     
    CSYONS22r:add_int_range("Price per 2 Crate", 4995000, 11000, 4995000, function() 
    	return globals.get_int(262145 + 15789)
    end, function(value)
    	globals.set_int(262145 + 15789, value)
    end)
     
    CSYONS22r:add_int_range("Price per 3 Crate", 3330000, 12000, 3330000, function() 
    	return globals.get_int(262145 + 15790)
    end, function(value)
    	globals.set_int(262145 + 15790, value)
    end)
	
	CSYONS22r:add_int_range("Price per 111 Crate", 90000, 20000, 90000, function() 
    	return globals.get_int(262145 + 15808)
    end, function(value)
    	globals.set_int(262145 + 15808, value)
    end)
     
    CSYONS22r:add_int_range("Special Cargo CD Buy", 300000, 0, 300000, function() 
    	return globals.get_int(262145 + 15553)
    end, function(value)
    	globals.set_int(262145 + 15553, value)
    end)
     
    CSYONS22r:add_int_range("Special Cargo CD Sell", 1800000, 0, 1800000, function() 
    	return globals.get_int(262145 + 15554)
    end, function(value)
    	globals.set_int(262145 + 15554, value)
    end)
 
CSYONS22r:add_action("Insta Finish Sell Mission", function()
	sale_mission = script("gb_contraband_sell")
	if sale_mission:is_active()
		then
			base_address = 540
			sale_mission:set_int(base_address+1,99999)
		end
end)

CSYONS22r:add_action("Insta Finish Buy/Steal Mission", function()
	buy_mission = script("gb_contraband_buy")
	if buy_mission:is_active()
		then
			base_address = 598
			buy_mission:set_int(base_address+5, 1)
			buy_mission:set_int(base_address+191, 6)
			buy_mission:set_int(base_address+192, 4)
		end
end)

CSYONS22r:add_action("No Sell Cooldown", function()
    globals.set_int(262145+15554, 0) 
end)
	
	CSYONS22r:add_action("Set Price(5M)", function()
    sale_price = 5000000
	base_address = 15788
    globals.set_int(262145+base_address, sale_price//1)
    globals.set_int(262145+base_address+1, sale_price//2)
    globals.set_int(262145+base_address+2, sale_price//3)
    globals.set_int(262145+base_address+3, sale_price//5)
    globals.set_int(262145+base_address+4, sale_price//7)
    globals.set_int(262145+base_address+5, sale_price//9)
    globals.set_int(262145+base_address+6, sale_price//14)
    globals.set_int(262145+base_address+7, sale_price//19)
    globals.set_int(262145+base_address+8, sale_price//24)
    globals.set_int(262145+base_address+9, sale_price//29)
    globals.set_int(262145+base_address+10, sale_price//34)
    globals.set_int(262145+base_address+11, sale_price//39)
    globals.set_int(262145+base_address+12, sale_price//44)
    globals.set_int(262145+base_address+13, sale_price//49)
    globals.set_int(262145+base_address+14, sale_price//59)
    globals.set_int(262145+base_address+15, sale_price//69)
    globals.set_int(262145+base_address+16, sale_price//79)
    globals.set_int(262145+base_address+17, sale_price//89)
    globals.set_int(262145+base_address+18, sale_price//99)
    globals.set_int(262145+base_address+19, sale_price//110)
    globals.set_int(262145+base_address+20, sale_price//111)
end)
	
	    local speccargo_script = script("gb_contraband_sell")
 
	CSYONS22r:add_toggle("Special Cargo Instant Sell", function() 
    	return speccargo_script:get_int(541) 
    end, function()
    if speccargo_script and speccargo_script:is_active() then
    	speccargo_script:set_int(541, 99999)
    end
    end)
	
	local function Text(text)
    	CSYONS22r:add_action(text, function() end)
    end
	
	Text("Instant Sell Mission Selector:") 
	CSYONS22r:add_int_range("0 to 6 Truck|7 to 11 Plane|12 = Boat", 1, 0, 12, function()
    	return speccargo_script:get_int(547) 
    end, function(value)
    if speccargo_script and speccargo_script:is_active() then
    	speccargo_script:set_int(547, value)
    end
    end)
	
	local speccargo_script = script("gb_contraband_buy")
	
	CSYONS22r:add_toggle("Special Cargo Instant Buy", function() 
    	return speccargo_script:get_int(790) 
    end, function()
    if speccargo_script and speccargo_script:is_active() then
    	speccargo_script:set_int(790, 4)
    end
    end)
	
	CSYONS22r:add_int_range("Special Cargo Crate Count", 1, 1, 111, function() 
    	return speccargo_script:get_int(599) 
    end, function(value)
    if speccargo_script and speccargo_script:is_active() then
    	speccargo_script:set_int(599, value)
    end
    end)
	
	local function Text(text)
    	CSYONS22r:add_action(text, function() end)
    end
 
    CSYONS22r:add_toggle("Unique Cargo Toggle", function()	
    	return globals.get_boolean(1949968) 
    end, function(value)
    	globals.set_boolean(1949968, value)
    end)
	
	local cargotype, ctype=2, {} ctype[2]="Ornamental Egg($25000)" ctype[4]="Golden Minigun($23000)" ctype[6]="Large Diamond($27000)" 
	ctype[7]="Rare Hide($21000)" ctype[8]="Film Reel($19000)" ctype[9]="Rare Pocket Watch($30000)"
	
	CSYONS22r:add_array_item("U.Cargo Type:", ctype, function()
		return cargotype
	end, function(CT)
		globals.get_int(1949814)
		cargotype=CT		
	if CT==2 then 
		globals.set_int(1949814, 2)
	elseif CT==4 then
		globals.set_int(1949814, 4)
	elseif CT==6 then
		globals.set_int(1949814, 6)
	elseif CT==7 then
		globals.set_int(1949814, 7)
	elseif CT==8 then
		globals.set_int(1949814, 8)
	elseif CT==9 then
		globals.set_int(1949814, 9)
		end
	end)

CSYONS25:add_action("Unlock Alls Full", function()
	PlayerIndex = globals.get_int(1574918) --Crazy global number :D
	if PlayerIndex == 0 then
		MPX = "MP0_" --Player 1
	else
		MPX = "MP1_" --Player 2
	end
		stats.set_int(MPX() .. "GANGOPS_FLOW_MISSION_CSYONS26G", 240)
		stats.set_int(MPX() .. "GANGOPS_HEIST_STATUS", 229378)
		stats.set_int(MPX() .. "GANGOPS_FLOW_NOTIFICATIONS", 1557)
		stats.set_int(MPX() .. "GANGOPS_FLOW_MISSION_CSYONS26G", 240)
		stats.set_int(MPX() .. "GANGOPS_HEIST_STATUS", 229378)
		stats.set_int(MPX() .. "GANGOPS_FLOW_NOTIFICATIONS", 1557)
		stats.set_int(MPX() .. "GANGOPS_FLOW_MISSION_CSYONS26G", 16368)
		stats.set_int(MPX() .. "GANGOPS_HEIST_STATUS", 229380)
		stats.set_int(MPX() .. "GANGOPS_FLOW_NOTIFICATIONS", 1557)
		stats.set_int(MPX() .. "FIXER_GENERAL_BS", -1)
		stats.set_int(MPX() .. "FIXER_COMPLETED_BS", -1)
		stats.set_int(MPX() .. "FIXER_STORY_BS", -1)
		stats.set_int(MPX() .. "FIXER_STORY_STRAND", -1)
		stats.set_int(MPX() .. "FIXER_STORY_COOLDOWN", -1)
		stats.set_int(MPX() .. "FIXER_COUNT", 500)
		stats.set_int(MPX() .. "PAYPHONE_BONUS_KILL_METHOD", -1)
		stats.set_int(MPX() .. "XMASLIVERIES0", -1)
		stats.set_int(MPX() .. "XMASLIVERIES1", -1)
		stats.set_int(MPX() .. "XMASLIVERIES2", -1)
		stats.set_int(MPX() .. "XMASLIVERIES3", -1)
		stats.set_int(MPX() .. "XMASLIVERIES5", -1)
		stats.set_int(MPX() .. "XMASLIVERIES6", -1)
		stats.set_int(MPX() .. "XMASLIVERIES7", -1)
		stats.set_int(MPX() .. "XMASLIVERIES8", -1)
		stats.set_int(MPX() .. "XMASLIVERIES9", -1)
		stats.set_int(MPX() .. "XMASLIVERIES10", -1)
		stats.set_int(MPX() .. "XMASLIVERIES11", -1)
		stats.set_int(MPX() .. "XMASLIVERIES12", -1)
		stats.set_int(MPX() .. "XMASLIVERIES13", -1)
		stats.set_int(MPX() .. "XMASLIVERIES14", -1)
		stats.set_int(MPX() .. "XMASLIVERIES15", -1)
		stats.set_int(MPX() .. "XMASLIVERIES16", -1)
		stats.set_int(MPX() .. "XMASLIVERIES17", -1)
		stats.set_int(MPX() .. "XMASLIVERIES18", -1)
		stats.set_int(MPX() .. "XMASLIVERIES19", -1)
		stats.set_int(MPX() .. "XMASLIVERIES20", -1)
		stats.set_int(MPX() .. "AWD_WATCH_YOUR_STEP", 15)
		stats.set_int(MPX() .. "AWD_TOWER_OFFENSE", 15)
		stats.set_int(MPX() .. "AWD_READY_FOR_WAR", 60)
		stats.set_int(MPX() .. "AWD_THROUGH_A_LENS", 60)
		stats.set_int(MPX() .. "AWD_SPINNER", 60)
		stats.set_int(MPX() .. "AWD_YOUMEANBOOBYTRAPS", 15)
		stats.set_int(MPX() .. "AWD_MASTER_BANDITO", 12)
		stats.set_int(MPX() .. "AWD_SITTING_DUCK", 60)
		stats.set_int(MPX() .. "AWD_CROWDPARTICIPATION", 60)
		stats.set_int(MPX() .. "AWD_KILL_OR_BE_KILLED", 60)
		stats.set_int(MPX() .. "AWD_MASSIVE_SHUNT", 60)
		stats.set_int(MPX() .. "AWD_YOURE_OUTTA_HERE", 110)
		stats.set_int(MPX() .. "AWD_WEVE_GOT_ONE", 52)
		stats.set_int(MPX() .. "AWD_TIME_SERVED", 110)
		stats.set_int(MPX() .. "AWD_CAREER_WINNER", 110)
		stats.set_int(MPX() .. "AWD_ARENA_WAGEWORKER", 1100000)
		stats.set_int(MPX() .. "CH_ARC_CAB_CLAW_TROPHY", -1)
		stats.set_int(MPX() .. "CH_ARC_CAB_LOVE_TROPHY", -1)
		stats.set_int(MPX() .. "AWD_PREPARATION", 40)
		stats.set_int(MPX() .. "AWD_ASLEEPONJOB", 20)
		stats.set_int(MPX() .. "AWD_DAICASHCRAB", 100000)
		stats.set_int(MPX() .. "AWD_BIGBRO", 40)
		stats.set_int(MPX() .. "AWD_SHARPSHOOTER", 40)
		stats.set_int(MPX() .. "AWD_RACECHAMP", 40)
		stats.set_int(MPX() .. "AWD_BATSWORD", 1000000)
		stats.set_int(MPX() .. "AWD_COINPURSE", 950000)
		stats.set_int(MPX() .. "AWD_ASTROCHIMP", 3000000)
		stats.set_int(MPX() .. "AWD_MASTERFUL", 40000)
		stats.set_int(MPX() .. "SCGW_NUM_WINS_GANG_0", 50)
		stats.set_int(MPX() .. "SCGW_NUM_WINS_GANG_1", 50)
		stats.set_int(MPX() .. "SCGW_NUM_WINS_GANG_2", 50)
		stats.set_int(MPX() .. "SCGW_NUM_WINS_GANG_3", 50)
		stats.set_int(MPX() .. "IAP_MA0_MOON_DIST", 2147483647)
		stats.set_int(MPX() .. "AWD_FACES_OF_DEATH", 50)
		stats.set_int(MPX() .. "HEIST_PLANNING_STAGE", -1)
		stats.set_int(MPX() .. "CHAR_ABILITY_1_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_ABILITY_2_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_ABILITY_3_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_FM_ABILITY_1_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_FM_ABILITY_2_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_FM_ABILITY_3_UNLCK", -1)
		stats.set_int(MPX() .. "LIFETIME_BKR_SELL_EARNINGS5", 50000000)
		stats.set_int(MPX() .. "VCM_FLOW_CSYONS26GRESS", -1)
		stats.set_int(MPX() .. "VCM_STORY_CSYONS26GRESS", -1)
		stats.set_int(MPX() .. "MKRIFLE_MK2_KILLS", 500)
		stats.set_int(MPX() .. "MKRIFLE_MK2_DEATHS", 100)
		stats.set_int(MPX() .. "MKRIFLE_MK2_SHOTS", 500)
		stats.set_int(MPX() .. "MKRIFLE_MK2_HITS", 500)
		stats.set_int(MPX() .. "MKRIFLE_MK2_HEADSHOTS", 500)
		stats.set_int(MPX() .. "MKRIFLE_MK2_HELDTIME", 5963259)
		stats.set_int(MPX() .. "MKRIFLE_MK2_DB_HELDTIME", 5963259)
		stats.set_int(MPX() .. "MKRIFLE_MK2_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "AWD_ODD_JOBS", 52)
		stats.set_int(MPX() .. "AWD_PREPARATION", 50)
		stats.set_int(MPX() .. "AWD_ASLEEPONJOB", 20)
		stats.set_int(MPX() .. "AWD_DAICASHCRAB", 100000)
		stats.set_int(MPX() .. "AWD_BIGBRO", 40)
		stats.set_int(MPX() .. "AWD_SHARPSHOOTER", 40)
		stats.set_int(MPX() .. "AWD_RACECHAMP", 40)
		stats.set_int(MPX() .. "AWD_BATSWORD", 1000000)
		stats.set_int(MPX() .. "AWD_COINPURSE", 950000)
		stats.set_int(MPX() .. "AWD_ASTROCHIMP", 3000000)
		stats.set_int(MPX() .. "AWD_MASTERFUL", 40000)
		stats.set_int(MPX() .. "DM_CURRENT_KILLS", 10000)
		stats.set_int(MPX() .. "DM_CURRENT_ASSISTS", 500)
		stats.set_int(MPX() .. "DM_CURRENT_DEATHS", 600)
		stats.set_int(MPX() .. "DM_HIGHEST_KILLSTREAK", 900)
		stats.set_int(MPX() .. "HIGHEST_SKITTLES", 900)
		stats.set_int(MPX() .. "NUMBER_NEAR_MISS", 1000)
		stats.set_int(MPX() .. "LAP_DANCED_BOUGHT", 100)
		stats.set_int(MPX() .. "CARS_EXPLODED", 500)
		stats.set_int(MPX() .. "CARS_COPS_EXPLODED", 300)
		stats.set_int(MPX() .. "BIKES_EXPLODED", 100)
		stats.set_int(MPX() .. "BOATS_EXPLODED", 168)
		stats.set_int(MPX() .. "HELIS_EXPLODED", 98)
		stats.set_int(MPX() .. "PLANES_EXPLODED", 138)
		stats.set_int(MPX() .. "QUADBIKE_EXPLODED", 50)
		stats.set_int(MPX() .. "BICYCLE_EXPLODED", 48)
		stats.set_int(MPX() .. "SUBMARINE_EXPLODED", 28)
		stats.set_int(MPX() .. "DEATHS", 499)
		stats.set_int(MPX() .. "DIED_IN_DROWNING", 833)
		stats.set_int(MPX() .. "DIED_IN_DROWNINGINVEHICLE", 833)
		stats.set_int(MPX() .. "DIED_IN_EXPLOSION", 833)
		stats.set_int(MPX() .. "DIED_IN_FALL", 833)
		stats.set_int(MPX() .. "DIED_IN_FIRE", 833)
		stats.set_int(MPX() .. "DIED_IN_ROAD", 833)
		stats.set_int(MPX() .. "NO_PHOTOS_TAKEN", 100)
		stats.set_int(MPX() .. "CSYONS26STITUTES_FREQUENTED", 100)
		stats.set_int(MPX() .. "BOUNTSONU", 200)
		stats.set_int(MPX() .. "BOUNTPLACED", 500)
		stats.set_int(MPX() .. "PASS_DB_KILLS", 300)
		stats.set_int(MPX() .. "PASS_DB_PLAYER_KILLS", 300)
		stats.set_int(MPX() .. "PASS_DB_SHOTS", 300)
		stats.set_int(MPX() .. "PASS_DB_HITS", 300)
		stats.set_int(MPX() .. "PASS_DB_HITS_PEDS_VEHICLES", 300)
		stats.set_int(MPX() .. "PASS_DB_HEADSHOTS", 300)
		stats.set_int(MPX() .. "TIRES_POPPED_BY_GUNSHOT", 500)
		stats.set_int(MPX() .. "NUMBER_CRASHES_CARS", 300)
		stats.set_int(MPX() .. "NUMBER_CRASHES_BIKES", 300)
		stats.set_int(MPX() .. "BAILED_FROM_VEHICLE", 300)
		stats.set_int(MPX() .. "NUMBER_CRASHES_QUADBIKES", 300)
		stats.set_int(MPX() .. "NUMBER_STOLEN_COP_VEHICLE", 300)
		stats.set_int(MPX() .. "NUMBER_STOLEN_CARS", 300)
		stats.set_int(MPX() .. "NUMBER_STOLEN_BIKES", 300)
		stats.set_int(MPX() .. "NUMBER_STOLEN_BOATS", 300)
		stats.set_int(MPX() .. "NUMBER_STOLEN_HELIS", 300)
		stats.set_int(MPX() .. "NUMBER_STOLEN_PLANES", 300)
		stats.set_int(MPX() .. "NUMBER_STOLEN_QUADBIKES", 300)
		stats.set_int(MPX() .. "NUMBER_STOLEN_BICYCLES", 300)
		stats.set_int(MPX() .. "FAVOUTFITBIKETIMECURRENT", 884483972)
		stats.set_int(MPX() .. "FAVOUTFITBIKETIME1ALLTIME", 884483972)
		stats.set_int(MPX() .. "FAVOUTFITBIKETYPECURRENT", 884483972)
		stats.set_int(MPX() .. "FAVOUTFITBIKETYPEALLTIME", 884483972)
		stats.set_int(MPX() .. "MC_CONTRIBUTION_POINTS", 1000)
		stats.set_int(MPX() .. "MEMBERSMARKEDFORDEATH", 700)
		stats.set_int(MPX() .. "MCKILLS", 500)
		stats.set_int(MPX() .. "MCDEATHS", 700)
		stats.set_int(MPX() .. "RIVALPRESIDENTKILLS", 700)
		stats.set_int(MPX() .. "RIVALCEOANDVIPKILLS", 700)
		stats.set_int(MPX() .. "MELEEKILLS", 700)
		stats.set_int(MPX() .. "CLUBHOUSECONTRACTSCOMPLETE", 700)
		stats.set_int(MPX() .. "CLUBHOUSECONTRACTEARNINGS", 32698547)
		stats.set_int(MPX() .. "CLUBCHALLENGESCOMPLETED", 700)
		stats.set_int(MPX() .. "MEMBERCHALLENGESCOMPLETED", 700)
		stats.set_int(MPX() .. "HITS", 100000)
		stats.set_int(MPX() .. "MKRIFLE_KILLS", 500)
		stats.set_int(MPX() .. "MKRIFLE_DEATHS", 100)
		stats.set_int(MPX() .. "MKRIFLE_SHOTS", 500)
		stats.set_int(MPX() .. "MKRIFLE_HITS", 500)
		stats.set_int(MPX() .. "MKRIFLE_HEADSHOTS", 500)
		stats.set_int(MPX() .. "MKRIFLE_HELDTIME", 5963259)
		stats.set_int(MPX() .. "MKRIFLE_DB_HELDTIME", 5963259)
		stats.set_int(MPX() .. "MKRIFLE_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "BETAMOUNT", 500)
		stats.set_int(MPX() .. "GHKILLS", 500)
		stats.set_int(MPX() .. "HORDELVL", 10)
		stats.set_int(MPX() .. "HORDKILLS", 500)
		stats.set_int(MPX() .. "UNIQUECRATES", 500)
		stats.set_int(MPX() .. "BJWINS", 500)
		stats.set_int(MPX() .. "HORDEWINS", 500)
		stats.set_int(MPX() .. "MCMWINS", 500)
		stats.set_int(MPX() .. "GANGHIDWINS", 500)
		stats.set_int(MPX() .. "KILLS", 800)
		stats.set_int(MPX() .. "HITS_PEDS_VEHICLES", 100)
		stats.set_int(MPX() .. "SHOTS", 1000)
		stats.set_int(MPX() .. "HEADSHOTS", 100)
		stats.set_int(MPX() .. "KILLS_ARMED", 650)
		stats.set_int(MPX() .. "SUCCESSFUL_COUNTERS", 100)
		stats.set_int(MPX() .. "KILLS_PLAYERS", 3593)
		stats.set_int(MPX() .. "DEATHS_PLAYER", 1002)
		stats.set_int(MPX() .. "KILLS_STEALTH", 100)
		stats.set_int(MPX() .. "KILLS_INNOCENTS", 500)
		stats.set_int(MPX() .. "KILLS_ENEMY_GANG_MEMBERS", 100)
		stats.set_int(MPX() .. "KILLS_FRIENDLY_GANG_MEMBERS", 100)
		stats.set_int(MPX() .. "KILLS_BY_OTHERS", 100)
		stats.set_int(MPX() .. "HITS", 600)
		stats.set_int(MPX() .. "BIGGEST_VICTIM_KILLS", 500)
		stats.set_int(MPX() .. "ARCHENEMY_KILLS", 500)
		stats.set_int(MPX() .. "CRARMWREST", 500)
		stats.set_int(MPX() .. "CRBASEJUMP", 500)
		stats.set_int(MPX() .. "CRDARTS", 500)
		stats.set_int(MPX() .. "CRDM", 500)
		stats.set_int(MPX() .. "CRGANGHIDE", 500)
		stats.set_int(MPX() .. "CRGOLF", 500)
		stats.set_int(MPX() .. "CRHORDE", 500)
		stats.set_int(MPX() .. "CRMISSION", 500)
		stats.set_int(MPX() .. "CRSHOOTRNG", 500)
		stats.set_int(MPX() .. "CRTENNIS", 500)
		stats.set_int(MPX() .. "TOTAL_TIME_CINEMA", 2147483647)
		stats.set_int(MPX() .. "NO_TIMES_CINEMA", 500)
		stats.set_int(MPX() .. "TIME_AS_A_PASSENGER", 2147483647)
		stats.set_int(MPX() .. "TIME_AS_A_DRIVER", 2147483647)
		stats.set_int(MPX() .. "TIME_SPENT_FLYING", 2147483647)
		stats.set_int(MPX() .. "TIME_IN_CAR", 2147483647)
		stats.set_int(MPX() .. "LIFETIME_BKR_SELL_UNDERTABC", 500)
		stats.set_int(MPX() .. "LIFETIME_BKR_SELL_COMPLETBC", 500)
		stats.set_int(MPX() .. "BKR_CSYONS26D_STOP_COUT_S1_0", 500)
		stats.set_int(MPX() .. "BKR_CSYONS26D_STOP_COUT_S2_0", 500)
		stats.set_int(MPX() .. "BKR_CSYONS26D_STOP_COUT_S3_0", 500)
		stats.set_int(MPX() .. "LFETIME_BIKER_BUY_UNDERTA1", 500)
		stats.set_int(MPX() .. "LFETIME_BIKER_BUY_COMPLET1", 500)
		stats.set_int(MPX() .. "LFETIME_BIKER_SELL_UNDERTA1", 500)
		stats.set_int(MPX() .. "LFETIME_BIKER_SELL_COMPLET1", 500)
		stats.set_int(MPX() .. "LIFETIME_BKR_SEL_UNDERTABC1", 500)
		stats.set_int(MPX() .. "LIFETIME_BKR_SEL_COMPLETBC1", 500)
		stats.set_int(MPX() .. "BKR_CSYONS26D_STOP_COUT_S1_1", 500)
		stats.set_int(MPX() .. "BKR_CSYONS26D_STOP_COUT_S2_1", 500)
		stats.set_int(MPX() .. "BKR_CSYONS26D_STOP_COUT_S3_1", 500)
		stats.set_int(MPX() .. "LFETIME_BIKER_BUY_UNDERTA2", 500)
		stats.set_int(MPX() .. "LFETIME_BIKER_BUY_COMPLET2", 500)
		stats.set_int(MPX() .. "LFETIME_BIKER_SELL_UNDERTA2", 500)
		stats.set_int(MPX() .. "LFETIME_BIKER_SELL_COMPLET2", 500)
		stats.set_int(MPX() .. "LIFETIME_BKR_SEL_UNDERTABC2", 500)
		stats.set_int(MPX() .. "LIFETIME_BKR_SEL_COMPLETBC2", 500)
		stats.set_int(MPX() .. "BKR_CSYONS26D_STOP_COUT_S1_2", 500)
		stats.set_int(MPX() .. "BKR_CSYONS26D_STOP_COUT_S2_2", 500)
		stats.set_int(MPX() .. "BKR_CSYONS26D_STOP_COUT_S3_2", 500)
		stats.set_int(MPX() .. "LFETIME_BIKER_BUY_UNDERTA3", 500)
		stats.set_int(MPX() .. "LFETIME_BIKER_BUY_COMPLET3", 500)
		stats.set_int(MPX() .. "LFETIME_BIKER_SELL_UNDERTA3", 500)
		stats.set_int(MPX() .. "LFETIME_BIKER_SELL_COMPLET3", 500)
		stats.set_int(MPX() .. "LIFETIME_BKR_SEL_UNDERTABC3", 500)
		stats.set_int(MPX() .. "LIFETIME_BKR_SEL_COMPLETBC3", 500)
		stats.set_int(MPX() .. "BKR_CSYONS26D_STOP_COUT_S1_3", 500)
		stats.set_int(MPX() .. "BKR_CSYONS26D_STOP_COUT_S2_3", 500)
		stats.set_int(MPX() .. "BKR_CSYONS26D_STOP_COUT_S3_3", 500)
		stats.set_int(MPX() .. "LFETIME_BIKER_BUY_UNDERTA4", 500)
		stats.set_int(MPX() .. "LFETIME_BIKER_BUY_COMPLET4", 500)
		stats.set_int(MPX() .. "LFETIME_BIKER_SELL_UNDERTA4", 500)
		stats.set_int(MPX() .. "LFETIME_BIKER_SELL_COMPLET4", 500)
		stats.set_int(MPX() .. "LIFETIME_BKR_SEL_UNDERTABC4", 500)
		stats.set_int(MPX() .. "LIFETIME_BKR_SEL_COMPLETBC4", 500)
		stats.set_int(MPX() .. "BKR_CSYONS26D_STOP_COUT_S1_4", 500)
		stats.set_int(MPX() .. "BKR_CSYONS26D_STOP_COUT_S2_4", 500)
		stats.set_int(MPX() .. "BKR_CSYONS26D_STOP_COUT_S3_4", 500)
		stats.set_int(MPX() .. "LFETIME_BIKER_BUY_UNDERTA5", 500)
		stats.set_int(MPX() .. "LFETIME_BIKER_BUY_COMPLET5", 500)
		stats.set_int(MPX() .. "LIFETIME_BKR_SEL_UNDERTABC5", 500)
		stats.set_int(MPX() .. "LIFETIME_BKR_SEL_COMPLETBC5", 500)
		stats.set_int(MPX() .. "LFETIME_BIKER_SELL_UNDERTA5", 500)
		stats.set_int(MPX() .. "LFETIME_BIKER_SELL_COMPLET5", 500)
		stats.set_int(MPX() .. "BUNKER_UNITS_MANUFAC", 500)
		stats.set_int(MPX() .. "CHAR_ABILITY_1_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_ABILITY_2_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_ABILITY_3_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_FM_ABILITY_1_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_FM_ABILITY_2_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_FM_ABILITY_3_UNLCK", -1)
		stats.set_int(MPX() .. "LFETIME_HANGAR_BUY_UNDETAK", 500)
		stats.set_int(MPX() .. "LFETIME_HANGAR_BUY_COMPLET", 500)
		stats.set_int(MPX() .. "LFETIME_HANGAR_SEL_UNDETAK", 500)
		stats.set_int(MPX() .. "LFETIME_HANGAR_SEL_COMPLET", 500)
		stats.set_int(MPX() .. "LFETIME_HANGAR_EARNINGS", 29654123)
		stats.set_int(MPX() .. "LFETIME_HANGAR_EARN_BONUS", 15987456)
		stats.set_int(MPX() .. "RIVAL_HANGAR_CRATES_STOLEN", 500)
		stats.set_int(MPX() .. "LFETIME_IE_STEAL_STARTED", 500)
		stats.set_int(MPX() .. "LFETIME_IE_EXPORT_STARTED", 500)
		stats.set_int(MPX() .. "LFETIME_IE_EXPORT_COMPLETED", 500)
		stats.set_int(MPX() .. "LFETIME_IE_MISSION_EARNINGS", 59654897)
		stats.set_int(MPX() .. "AT_FLOW_IMPEXP_NUM", 500)
		stats.set_int(MPX() .. "CLUB_POPULARITY", 1000)
		stats.set_int(MPX() .. "NIGHTCLUB_VIP_APPEAR", 300)
		stats.set_int(MPX() .. "NIGHTCLUB_JOBS_DONE", 500)
		stats.set_int(MPX() .. "NIGHTCLUB_EARNINGS", 39856412)
		stats.set_int(MPX() .. "HUB_SALES_COMPLETED", 500)
		stats.set_int(MPX() .. "HUB_EARNINGS", 29865423)
		stats.set_int(MPX() .. "DANCE_COMBO_DURATION_MINS", 86400000)
		stats.set_int(MPX() .. "NIGHTCLUB_PLAYER_APPEAR", 500)
		stats.set_int(MPX() .. "LIFETIME_HUB_GOODS_SOLD", 500)
		stats.set_int(MPX() .. "LIFETIME_HUB_GOODS_MADE", 500)
		stats.set_int(MPX() .. "ADMIN_CLOTHES_GV_BS_1", -1)
		stats.set_int(MPX() .. "ADMIN_CLOTHES_GV_BS_10", -1)
		stats.set_int(MPX() .. "ADMIN_CLOTHES_GV_BS_11", -1)
		stats.set_int(MPX() .. "ADMIN_CLOTHES_GV_BS_12", -1)
		stats.set_int(MPX() .. "ADMIN_CLOTHES_GV_BS_2", -1)
		stats.set_int(MPX() .. "ADMIN_CLOTHES_GV_BS_3", -1)
		stats.set_int(MPX() .. "ADMIN_CLOTHES_GV_BS_4", -1)
		stats.set_int(MPX() .. "ADMIN_CLOTHES_GV_BS_5", -1)
		stats.set_int(MPX() .. "ADMIN_CLOTHES_GV_BS_6", -1)
		stats.set_int(MPX() .. "ADMIN_CLOTHES_GV_BS_7", -1)
		stats.set_int(MPX() .. "ADMIN_CLOTHES_GV_BS_8", -1)
		stats.set_int(MPX() .. "ADMIN_CLOTHES_GV_BS_9", -1)
		stats.set_int(MPX() .. "ADMIN_WEAPON_GV_BS_1", -1)
		stats.set_int(MPX() .. "AIR_LAUNCHES_OVER_40M", 25)
		stats.set_int(MPX() .. "AWD_5STAR_WANTED_AVOIDANCE", 50)
		stats.set_int(MPX() .. "AWD_CAR_BOMBS_ENEMY_KILLS", 25)
		stats.set_int(MPX() .. "AWD_CARS_EXPORTED", 50)
		stats.set_int(MPX() .. "AWD_CONTROL_CROWDS", 25)
		stats.set_int(MPX() .. "AWD_DAILYOBJCOMPLETED", 100)
		stats.set_int(MPX() .. "AWD_DO_HEIST_AS_MEMBER", 25)
		stats.set_int(MPX() .. "AWD_DO_HEIST_AS_THE_LEADER", 25)
		stats.set_int(MPX() .. "AWD_DROPOFF_CAP_PACKAGES", 100)
		stats.set_int(MPX() .. "AWD_FINISH_HEIST_SETUP_JOB", 50)
		stats.set_int(MPX() .. "AWD_FINISH_HEISTS", 50)
		stats.set_int(MPX() .. "AWD_FM_DM_3KILLSAMEGUY", 50)
		stats.set_int(MPX() .. "AWD_FM_DM_KILLSTREAK", 100)
		stats.set_int(MPX() .. "AWD_FM_DM_STOLENKILL", 50)
		stats.set_int(MPX() .. "AWD_FM_DM_TOTALKILLS", 500)
		stats.set_int(MPX() .. "AWD_FM_DM_WINS", 50)
		stats.set_int(MPX() .. "AWD_FM_GOLF_HOLE_IN_1", 300)
		stats.set_int(MPX() .. "AWD_FM_GOLF_BIRDIES", 25)
		stats.set_int(MPX() .. "AWD_FM_GOLF_WON", 25)
		stats.set_int(MPX() .. "AWD_FM_GTA_RACES_WON", 50)
		stats.set_int(MPX() .. "AWD_FM_RACE_LAST_FIRST", 25)
		stats.set_int(MPX() .. "AWD_FM_RACES_FASTEST_LAP", 50)
		stats.set_int(MPX() .. "AWD_FM_SHOOTRANG_CT_WON", 25)
		stats.set_int(MPX() .. "AWD_FM_SHOOTRANG_RT_WON", 25)
		stats.set_int(MPX() .. "AWD_FM_SHOOTRANG_TG_WON", 25)
		stats.set_int(MPX() .. "AWD_FM_TDM_MVP", 50)
		stats.set_int(MPX() .. "AWD_FM_TDM_WINS", 50)
		stats.set_int(MPX() .. "AWD_FM_TENNIS_ACE", 25)
		stats.set_int(MPX() .. "AWD_FM_TENNIS_WON", 25)
		stats.set_int(MPX() .. "AWD_FMBASEJMP", 25)
		stats.set_int(MPX() .. "AWD_FMBBETWIN", 50000)
		stats.set_int(MPX() .. "AWD_FMCRATEDROPS", 25)
		stats.set_int(MPX() .. "AWD_FMDRIVEWITHOUTCRASH", 30)
		stats.set_int(MPX() .. "AWD_FMHORDWAVESSURVIVE", 10)
		stats.set_int(MPX() .. "AWD_FMKILLBOUNTY", 25)
		stats.set_int(MPX() .. "AWD_FMRALLYWONDRIVE", 25)
		stats.set_int(MPX() .. "AWD_FMRALLYWONNAV", 25)
		stats.set_int(MPX() .. "AWD_FMREVENGEKILLSD", 50)
		stats.set_int(MPX() .. "AWD_FMSHOOTDOWNCOPHELI", 25)
		stats.set_int(MPX() .. "AWD_FMWINAIRRACE", 25)
		stats.set_int(MPX() .. "AWD_FMWINRACETOPOINTS", 25)
		stats.set_int(MPX() .. "AWD_FMWINSEARACE", 25)
		stats.set_int(MPX() .. "AWD_HOLD_UP_SHOPS", 20)
		stats.set_int(MPX() .. "AWD_KILL_CARRIER_CAPTURE", 100)
		stats.set_int(MPX() .. "AWD_KILL_PSYCHOPATHS", 100)
		stats.set_int(MPX() .. "AWD_KILL_TEAM_YOURSELF_LTS", 25)
		stats.set_int(MPX() .. "AWD_LAPDANCES", 25)
		stats.set_int(MPX() .. "AWD_LESTERDELIVERVEHICLES", 25)
		stats.set_int(MPX() .. "AWD_MENTALSTATE_TO_NORMAL", 50)
		stats.set_int(MPX() .. "AWD_NIGHTVISION_KILLS", 100)
		stats.set_int(MPX() .. "AWD_NO_HAIRCUTS", 25)
		stats.set_int(MPX() .. "AWD_ODISTRACTCOPSNOEATH", 25)
		stats.set_int(MPX() .. "AWD_ONLY_PLAYER_ALIVE_LTS", 50)
		stats.set_int(MPX() .. "AWD_PARACHUTE_JUMPS_20M", 25)
		stats.set_int(MPX() .. "AWD_PARACHUTE_JUMPS_50M", 25)
		stats.set_int(MPX() .. "AWD_PASSENGERTIME", 4)
		stats.set_int(MPX() .. "AWD_PICKUP_CAP_PACKAGES", 100)
		stats.set_int(MPX() .. "AWD_RACES_WON", 50)
		stats.set_int(MPX() .. "AWD_SECURITY_CARS_ROBBED", 25)
		stats.set_int(MPX() .. "AWD_TAKEDOWNSMUGPLANE", 50)
		stats.set_int(MPX() .. "AWD_TIME_IN_HELICOPTER", 4)
		stats.set_int(MPX() .. "AWD_TRADE_IN_YOUR_CSYONS26PERTY", 25)
		stats.set_int(MPX() .. "AWD_VEHICLES_JACKEDR", 500)
		stats.set_int(MPX() .. "AWD_WIN_AT_DARTS", 25)
		stats.set_int(MPX() .. "AWD_WIN_CAPTURE_DONT_DYING", 25)
		stats.set_int(MPX() .. "AWD_WIN_CAPTURES", 50)
		stats.set_int(MPX() .. "AWD_WIN_GOLD_MEDAL_HEISTS", 25)
		stats.set_int(MPX() .. "AWD_WIN_LAST_TEAM_STANDINGS", 50)
		stats.set_int(MPX() .. "BOTTLE_IN_POSSESSION", -1)
		stats.set_int(MPX() .. "CHAR_FM_CARMOD_1_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_FM_CARMOD_2_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_FM_CARMOD_3_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_FM_CARMOD_4_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_FM_CARMOD_5_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_FM_CARMOD_6_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_FM_CARMOD_7_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_FM_VEHICLE_1_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_FM_VEHICLE_2_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_FM_WEAP_ADDON_1_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_FM_WEAP_ADDON_2_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_FM_WEAP_ADDON_3_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_FM_WEAP_ADDON_4_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_FM_WEAP_ADDON_5_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_FM_WEAP_UNLOCKED", -1)
		stats.set_int(MPX() .. "CHAR_FM_WEAP_UNLOCKED2", -1)
		stats.set_int(MPX() .. "CHAR_KIT_10_FM_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_KIT_11_FM_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_KIT_12_FM_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_KIT_1_FM_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_KIT_2_FM_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_KIT_3_FM_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_KIT_4_FM_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_KIT_5_FM_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_KIT_6_FM_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_KIT_7_FM_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_KIT_8_FM_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_KIT_9_FM_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_KIT_FM_PURCHASE", -1)
		stats.set_int(MPX() .. "CHAR_KIT_FM_PURCHASE10", -1)
		stats.set_int(MPX() .. "CHAR_KIT_FM_PURCHASE11", -1)
		stats.set_int(MPX() .. "CHAR_KIT_FM_PURCHASE12", -1)
		stats.set_int(MPX() .. "CHAR_KIT_FM_PURCHASE2", -1)
		stats.set_int(MPX() .. "CHAR_KIT_FM_PURCHASE3", -1)
		stats.set_int(MPX() .. "CHAR_KIT_FM_PURCHASE4", -1)
		stats.set_int(MPX() .. "CHAR_KIT_FM_PURCHASE5", -1)
		stats.set_int(MPX() .. "CHAR_KIT_FM_PURCHASE6", -1)
		stats.set_int(MPX() .. "CHAR_KIT_FM_PURCHASE7", -1)
		stats.set_int(MPX() .. "CHAR_KIT_FM_PURCHASE8", -1)
		stats.set_int(MPX() .. "CHAR_KIT_FM_PURCHASE9", -1)
		stats.set_int(MPX() .. "CHAR_WANTED_LEVEL_TIME5STAR", -1)
		stats.set_int(MPX() .. "CHAR_WEAP_FM_PURCHASE", -1)
		stats.set_int(MPX() .. "CHAR_WEAP_FM_PURCHASE2", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_BERD", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_BERD_1", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_BERD_2", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_BERD_3", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_BERD_4", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_BERD_5", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_BERD_6", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_DECL", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_FEET", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_FEET_1", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_FEET_2", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_FEET_3", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_FEET_4", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_FEET_5", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_FEET_6", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_FEET_7", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_JBIB", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_JBIB_1", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_JBIB_2", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_JBIB_3", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_JBIB_4", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_JBIB_5", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_JBIB_6", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_JBIB_7", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_LEGS", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_LEGS_1", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_LEGS_2", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_LEGS_3", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_LEGS_4", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_LEGS_5", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_LEGS_6", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_LEGS_7", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_OUTFIT", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_CSYONS26PS", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_CSYONS26PS_1", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_CSYONS26PS_10", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_CSYONS26PS_2", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_CSYONS26PS_3", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_CSYONS26PS_4", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_CSYONS26PS_5", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_CSYONS26PS_6", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_CSYONS26PS_7", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_CSYONS26PS_8", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_CSYONS26PS_9", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_SPECIAL", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_SPECIAL2", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_SPECIAL2_1", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_SPECIAL_1", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_SPECIAL_2", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_SPECIAL_3", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_SPECIAL_4", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_SPECIAL_5", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_SPECIAL_6", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_SPECIAL_7", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_TEETH", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_TEETH_1", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_TEETH_2", -1)
		stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_TORSO", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_BERD", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_BERD_1", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_BERD_2", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_BERD_3", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_BERD_4", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_BERD_5", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_BERD_6", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_BERD_7", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_DECL", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_FEET", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_FEET_1", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_FEET_2", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_FEET_3", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_FEET_4", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_FEET_5", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_FEET_6", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_FEET_7", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_HAIR", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_HAIR_1", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_HAIR_2", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_HAIR_3", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_HAIR_4", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_HAIR_5", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_HAIR_6", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_HAIR_7", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_JBIB", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_JBIB_1", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_JBIB_2", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_JBIB_3", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_JBIB_4", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_JBIB_5", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_JBIB_6", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_JBIB_7", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_LEGS", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_LEGS_1", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_LEGS_2", -1)
		stats.set_int(MPX() .. "SAVESTRA_MG_HELDTIME", 5963259)
		stats.set_int(MPX() .. "SAVESTRA_MG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "STROMBERG_MG_KILLS", 500)
		stats.set_int(MPX() .. "STROMBERG_MG_DEATHS", 100)
		stats.set_int(MPX() .. "STROMBERG_MG_SHOTS", 500)
		stats.set_int(MPX() .. "STROMBERG_MG_HITS", 500)
		stats.set_int(MPX() .. "STROMBERG_MG_HEADSHOTS", 500)
		stats.set_int(MPX() .. "STROMBERG_MG_HELDTIME", 5963259)
		stats.set_int(MPX() .. "STROMBERG_MG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "STROMBERG_MISS_KILLS", 500)
		stats.set_int(MPX() .. "STROMBERG_MISS_DEATHS", 100)
		stats.set_int(MPX() .. "STROMBERG_MISS_SHOTS", 500)
		stats.set_int(MPX() .. "STROMBERG_MISS_HITS", 500)
		stats.set_int(MPX() .. "STROMBERG_MISS_HELDTIME", 5963259)
		stats.set_int(MPX() .. "STROMBERG_MISS_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "STROMBERG_TORP_KILLS", 500)
		stats.set_int(MPX() .. "STROMBERG_TORP_DEATHS", 100)
		stats.set_int(MPX() .. "STROMBERG_TORP_SHOTS", 500)
		stats.set_int(MPX() .. "STROMBERG_TORP_HITS", 500)
		stats.set_int(MPX() .. "STROMBERG_TORP_HELDTIME", 5963259)
		stats.set_int(MPX() .. "STROMBERG_TORP_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "THRUSTER_MG_KILLS", 500)
		stats.set_int(MPX() .. "THRUSTER_MG_DEATHS", 100)
		stats.set_int(MPX() .. "THRUSTER_MG_SHOTS", 500)
		stats.set_int(MPX() .. "THRUSTER_MG_HITS", 500)
		stats.set_int(MPX() .. "THRUSTER_MG_HEADSHOTS", 500)
		stats.set_int(MPX() .. "THRUSTER_MG_HELDTIME", 5963259)
		stats.set_int(MPX() .. "THRUSTER_MG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "THRUSTER_MISS_KILLS", 500)
		stats.set_int(MPX() .. "THRUSTER_MISS_DEATHS", 100)
		stats.set_int(MPX() .. "THRUSTER_MISS_SHOTS", 500)
		stats.set_int(MPX() .. "THRUSTER_MISS_HITS", 500)
		stats.set_int(MPX() .. "THRUSTER_MISS_HELDTIME", 5963259)
		stats.set_int(MPX() .. "THRUSTER_MISS_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "VISERIS_MG_KILLS", 500)
		stats.set_int(MPX() .. "VISERIS_MG_DEATHS", 100)
		stats.set_int(MPX() .. "VISERIS_MG_SHOTS", 500)
		stats.set_int(MPX() .. "VISERIS_MG_HITS", 500)
		stats.set_int(MPX() .. "VISERIS_MG_HEADSHOTS", 500)
		stats.set_int(MPX() .. "VISERIS_MG_HELDTIME", 5963259)
		stats.set_int(MPX() .. "VISERIS_MG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "VOLATOL_MG_KILLS", 500)
		stats.set_int(MPX() .. "VOLATOL_MG_DEATHS", 100)
		stats.set_int(MPX() .. "VOLATOL_MG_SHOTS", 500)
		stats.set_int(MPX() .. "VOLATOL_MG_HITS", 500)
		stats.set_int(MPX() .. "VOLATOL_MG_HEADSHOTS", 500)
		stats.set_int(MPX() .. "VOLATOL_MG_HELDTIME", 5963259)
		stats.set_int(MPX() .. "VOLATOL_MG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "MULE4_MG_KILLS", 500)
		stats.set_int(MPX() .. "MULE4_MG_DEATHS", 100)
		stats.set_int(MPX() .. "MULE4_MG_SHOTS", 500)
		stats.set_int(MPX() .. "MULE4_MG_HITS", 500)
		stats.set_int(MPX() .. "MULE4_MG_HEADSHOTS", 500)
		stats.set_int(MPX() .. "MULE4_MG_HELDTIME", 5963259)
		stats.set_int(MPX() .. "MULE4_MG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "MULE4_MISS_KILLS", 500)
		stats.set_int(MPX() .. "MULE4_MISS_DEATHS", 100)
		stats.set_int(MPX() .. "MULE4_MISS_SHOTS", 500)
		stats.set_int(MPX() .. "MULE4_MISS_HITS", 500)
		stats.set_int(MPX() .. "MULE4_MISS_HELDTIME", 5963259)
		stats.set_int(MPX() .. "MULE4_MISS_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "MULE4_GL_KILLS", 500)
		stats.set_int(MPX() .. "MULE4_GL_DEATHS", 100)
		stats.set_int(MPX() .. "MULE4_GL_SHOTS", 500)
		stats.set_int(MPX() .. "MULE4_GL_HITS", 500)
		stats.set_int(MPX() .. "MULE4_GL_HELDTIME", 5963259)
		stats.set_int(MPX() .. "MULE4_GL_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "MENACER_MG_KILLS", 500)
		stats.set_int(MPX() .. "MENACER_MG_DEATHS", 100)
		stats.set_int(MPX() .. "MENACER_MG_SHOTS", 500)
		stats.set_int(MPX() .. "MENACER_MG_HITS", 500)
		stats.set_int(MPX() .. "MENACER_MG_HEADSHOTS", 500)
		stats.set_int(MPX() .. "MENACER_MG_HELDTIME", 5963259)
		stats.set_int(MPX() .. "MENACER_MG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "MENACER_TURR_KILLS", 500)
		stats.set_int(MPX() .. "MENACER_TURR_DEATHS", 100)
		stats.set_int(MPX() .. "MENACER_TURR_SHOTS", 500)
		stats.set_int(MPX() .. "MENACER_TURR_HITS", 500)
		stats.set_int(MPX() .. "MENACER_TURR_HEADSHOTS", 500)
		stats.set_int(MPX() .. "MENACER_TURR_HELDTIME", 5963259)
		stats.set_int(MPX() .. "MENACER_TURR_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "MENACER_MINI_KILLS", 500)
		stats.set_int(MPX() .. "MENACER_MINI_DEATHS", 100)
		stats.set_int(MPX() .. "MENACER_MINI_SHOTS", 500)
		stats.set_int(MPX() .. "MENACER_MINI_HITS", 500)
		stats.set_int(MPX() .. "MENACER_MINI_HEADSHOTS", 500)
		stats.set_int(MPX() .. "MENACER_MINI_HELDTIME", 5963259)
		stats.set_int(MPX() .. "MENACER_MINI_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "OPPRESSOR2_MG_KILLS", 500)
		stats.set_int(MPX() .. "OPPRESSOR2_MG_DEATHS", 100)
		stats.set_int(MPX() .. "OPPRESSOR2_MG_SHOTS", 500)
		stats.set_int(MPX() .. "OPPRESSOR2_MG_HITS", 500)
		stats.set_int(MPX() .. "OPPRESSOR2_MG_HEADSHOTS", 500)
		stats.set_int(MPX() .. "OPPRESSOR2_MG_HELDTIME", 5963259)
		stats.set_int(MPX() .. "OPPRESSOR2_MG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "OPPRESSOR2_CANN_KILLS", 500)
		stats.set_int(MPX() .. "OPPRESSOR2_CANN_DEATHS", 100)
		stats.set_int(MPX() .. "OPPRESSOR2_CANN_SHOTS", 500)
		stats.set_int(MPX() .. "OPPRESSOR2_CANN_HITS", 500)
		stats.set_int(MPX() .. "OPPRESSOR2_CANN_HELDTIME", 5963259)
		stats.set_int(MPX() .. "OPPRESSOR2_CANN_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "OPPRESSOR2_MISS_KILLS", 500)
		stats.set_int(MPX() .. "OPPRESSOR2_MISS_DEATHS", 100)
		stats.set_int(MPX() .. "OPPRESSOR2_MISS_SHOTS", 500)
		stats.set_int(MPX() .. "OPPRESSOR2_MISS_HITS", 500)
		stats.set_int(MPX() .. "OPPRESSOR2_MISS_HELDTIME", 5963259)
		stats.set_int(MPX() .. "OPPRESSOR2_MISS_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "BRUISER_MG50_KILLS", 500)
		stats.set_int(MPX() .. "BRUISER_MG50_DEATHS", 100)
		stats.set_int(MPX() .. "BRUISER_MG50_SHOTS", 500)
		stats.set_int(MPX() .. "BRUISER_MG50_HITS", 500)
		stats.set_int(MPX() .. "BRUISER_MG50_HEADSHOTS", 500)
		stats.set_int(MPX() .. "BRUISER_MG50_HELDTIME", 5963259)
		stats.set_int(MPX() .. "BRUISER_MG50_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "BRUISER2_MG50_KILLS", 500)
		stats.set_int(MPX() .. "BRUISER2_MG50_DEATHS", 100)
		stats.set_int(MPX() .. "BRUISER2_MG50_SHOTS", 500)
		stats.set_int(MPX() .. "BRUISER2_MG50_HITS", 500)
		stats.set_int(MPX() .. "BRUISER2_MG50_HEADSHOTS", 500)
		stats.set_int(MPX() .. "BRUISER2_MG50_HELDTIME", 5963259)
		stats.set_int(MPX() .. "BRUISER2_MG50_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "BRUISER2_LAS_KILLS", 500)
		stats.set_int(MPX() .. "BRUISER2_LAS_DEATHS", 100)
		stats.set_int(MPX() .. "BRUISER2_LAS_SHOTS", 500)
		stats.set_int(MPX() .. "BRUISER2_LAS_HITS", 500)
		stats.set_int(MPX() .. "BRUISER2_LAS_HEADSHOTS", 500)
		stats.set_int(MPX() .. "BRUISER2_LAS_HELDTIME", 5963259)
		stats.set_int(MPX() .. "BRUISER2_LAS_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "BRUISER3_MG50_KILLS", 500)
		stats.set_int(MPX() .. "BRUISER3_MG50_DEATHS", 100)
		stats.set_int(MPX() .. "BRUISER3_MG50_SHOTS", 500)
		stats.set_int(MPX() .. "BRUISER3_MG50_HITS", 500)
		stats.set_int(MPX() .. "BRUISER3_MG50_HEADSHOTS", 500)
		stats.set_int(MPX() .. "BRUISER3_MG50_HELDTIME", 5963259)
		stats.set_int(MPX() .. "BRUISER3_MG50_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "BRUTUS_MG50_KILLS", 500)
		stats.set_int(MPX() .. "BRUTUS_MG50_DEATHS", 100)
		stats.set_int(MPX() .. "BRUTUS_MG50_SHOTS", 500)
		stats.set_int(MPX() .. "BRUTUS_MG50_HITS", 500)
		stats.set_int(MPX() .. "BRUTUS_MG50_HEADSHOTS", 500)
		stats.set_int(MPX() .. "BRUTUS_MG50_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "BRUTUS2_MG50_KILLS", 500)
		stats.set_int(MPX() .. "BRUTUS2_MG50_DEATHS", 100)
		stats.set_int(MPX() .. "BRUTUS2_MG50_SHOTS", 500)
		stats.set_int(MPX() .. "BRUTUS2_MG50_HITS", 500)
		stats.set_int(MPX() .. "BRUTUS2_MG50_HEADSHOTS", 500)
		stats.set_int(MPX() .. "BRUTUS2_MG50_HELDTIME", 5963259)
		stats.set_int(MPX() .. "BRUTUS2_MG50_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "BRUTUS2_LAS_KILLS", 500)
		stats.set_int(MPX() .. "BRUTUS2_LAS_DEATHS", 100)
		stats.set_int(MPX() .. "BRUTUS2_LAS_SHOTS", 500)
		stats.set_int(MPX() .. "BRUTUS2_LAS_HITS", 500)
		stats.set_int(MPX() .. "BRUTUS2_LAS_HEADSHOTS", 500)
		stats.set_int(MPX() .. "BRUTUS2_LAS_HELDTIME", 5963259)
		stats.set_int(MPX() .. "BRUTUS2_LAS_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "BRUTUS3_MG50_KILLS", 500)
		stats.set_int(MPX() .. "BRUTUS3_MG50_DEATHS", 100)
		stats.set_int(MPX() .. "BRUTUS3_MG50_SHOTS", 500)
		stats.set_int(MPX() .. "BRUTUS3_MG50_HITS", 500)
		stats.set_int(MPX() .. "BRUTUS3_MG50_HEADSHOTS", 500)
		stats.set_int(MPX() .. "BRUTUS3_MG50_HELDTIME", 5963259)
		stats.set_int(MPX() .. "BRUTUS3_MG50_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "CERBERUS_FLAME_KILLS", 500)
		stats.set_int(MPX() .. "CERBERUS_FLAME_DEATHS", 100)
		stats.set_int(MPX() .. "CERBERUS_FLAME_SHOTS", 500)
		stats.set_int(MPX() .. "CERBERUS_FLAME_HITS", 500)
		stats.set_int(MPX() .. "CERBERUS_FLAME_HEADSHOTS", 500)
		stats.set_int(MPX() .. "CERBERUS_FLAME_HELDTIME", 5963259)
		stats.set_int(MPX() .. "CERBERUS_FLAME_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "CERBERUS2_FLAME_KILLS", 500)
		stats.set_int(MPX() .. "CERBERUS2_FLAME_DEATHS", 100)
		stats.set_int(MPX() .. "CERBERUS2_FLAME_SHOTS", 500)
		stats.set_int(MPX() .. "CERBERUS2_FLAME_HITS", 500)
		stats.set_int(MPX() .. "CERBERUS2_FLAME_HEADSHOTS", 500)
		stats.set_int(MPX() .. "CERBERUS2_FLAME_HELDTIME", 5963259)
		stats.set_int(MPX() .. "CERBERUS2_FLAME_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "CERBERUS3_FLAME_KILLS", 500)
		stats.set_int(MPX() .. "CERBERUS3_FLAME_DEATHS", 100)
		stats.set_int(MPX() .. "CERBERUS3_FLAME_SHOTS", 500)
		stats.set_int(MPX() .. "CERBERUS3_FLAME_HITS", 500)
		stats.set_int(MPX() .. "CERBERUS3_FLAME_HEADSHOTS", 500)
		stats.set_int(MPX() .. "CERBERUS3_FLAME_HELDTIME", 5963259)
		stats.set_int(MPX() .. "CERBERUS3_FLAME_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "DEATHBIKE_MINI_KILLS", 500)
		stats.set_int(MPX() .. "DEATHBIKE_MINI_DEATHS", 100)
		stats.set_int(MPX() .. "DEATHBIKE_MINI_SHOTS", 500)
		stats.set_int(MPX() .. "DEATHBIKE_MINI_HITS", 500)
		stats.set_int(MPX() .. "DEATHBIKE_MINI_HEADSHOTS", 500)
		stats.set_int(MPX() .. "DEATHBIKE_MINI_HELDTIME", 5963259)
		stats.set_int(MPX() .. "DEATHBIKE_MINI_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "DEATHBIKE2_LAS_KILLS", 500)
		stats.set_int(MPX() .. "DEATHBIKE2_LAS_DEATHS", 100)
		stats.set_int(MPX() .. "DEATHBIKE2_LAS_SHOTS", 500)
		stats.set_int(MPX() .. "DEATHBIKE2_LAS_HITS", 500)
		stats.set_int(MPX() .. "DEATHBIKE2_LAS_HEADSHOTS", 500)
		stats.set_int(MPX() .. "DEATHBIKE2_LAS_HELDTIME", 5963259)
		stats.set_int(MPX() .. "DEATHBIKE2_LAS_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "DEATHBIKE3_MINI_KILLS", 500)
		stats.set_int(MPX() .. "DEATHBIKE3_MINI_DEATHS", 100)
		stats.set_int(MPX() .. "DEATHBIKE3_MINI_SHOTS", 500)
		stats.set_int(MPX() .. "DEATHBIKE3_MINI_HITS", 500)
		stats.set_int(MPX() .. "DEATHBIKE3_MINI_HEADSHOTS", 500)
		stats.set_int(MPX() .. "DEATHBIKE3_MINI_HELDTIME", 5963259)
		stats.set_int(MPX() .. "DEATHBIKE3_MINI_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "DOMINATOR4_MG50_KILLS", 500)
		stats.set_int(MPX() .. "DOMINATOR4_MG50_DEATHS", 100)
		stats.set_int(MPX() .. "DOMINATOR4_MG50_SHOTS", 500)
		stats.set_int(MPX() .. "DOMINATOR4_MG50_HITS", 500)
		stats.set_int(MPX() .. "DOMINATOR4_MG50_HEADSHOTS", 500)
		stats.set_int(MPX() .. "DOMINATOR4_MG50_HELDTIME", 5963259)
		stats.set_int(MPX() .. "DOMINATOR4_MG50_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "DOMINATOR5_MG50_KILLS", 500)
		stats.set_int(MPX() .. "DOMINATOR5_MG50_DEATHS", 100)
		stats.set_int(MPX() .. "DOMINATOR5_MG50_SHOTS", 500)
		stats.set_int(MPX() .. "DOMINATOR5_MG50_HITS", 500)
		stats.set_int(MPX() .. "DOMINATOR5_MG50_HEADSHOTS", 500)
		stats.set_int(MPX() .. "DOMINATOR5_MG50_HELDTIME", 5963259)
		stats.set_int(MPX() .. "DOMINATOR5_MG50_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "DOMINATOR5_LAS_KILLS", 500)
		stats.set_int(MPX() .. "DOMINATOR5_LAS_DEATHS", 100)
		stats.set_int(MPX() .. "DOMINATOR5_LAS_SHOTS", 500)
		stats.set_int(MPX() .. "DOMINATOR5_LAS_HITS", 500)
		stats.set_int(MPX() .. "DOMINATOR5_LAS_HEADSHOTS", 500)
		stats.set_int(MPX() .. "DOMINATOR5_LAS_HELDTIME", 5963259)
		stats.set_int(MPX() .. "DOMINATOR5_LAS_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "DOMINATOR6_MG50_KILLS", 500)
		stats.set_int(MPX() .. "DOMINATOR6_MG50_DEATHS", 100)
		stats.set_int(MPX() .. "DOMINATOR6_MG50_SHOTS", 500)
		stats.set_int(MPX() .. "DOMINATOR6_MG50_HITS", 500)
		stats.set_int(MPX() .. "DOMINATOR6_MG50_HEADSHOTS", 500)
		stats.set_int(MPX() .. "DOMINATOR6_MG50_HELDTIME", 5963259)
		stats.set_int(MPX() .. "DOMINATOR6_MG50_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "IMPALER2_MG50_KILLS", 500)
		stats.set_int(MPX() .. "IMPALER2_MG50_DEATHS", 100)
		stats.set_int(MPX() .. "IMPALER2_MG50_SHOTS", 500)
		stats.set_int(MPX() .. "IMPALER2_MG50_HITS", 500)
		stats.set_int(MPX() .. "IMPALER2_MG50_HEADSHOTS", 500)
		stats.set_int(MPX() .. "IMPALER2_MG50_HELDTIME", 5963259)
		stats.set_int(MPX() .. "IMPALER2_MG50_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "IMPALER3_MG50_KILLS", 500)
		stats.set_int(MPX() .. "IMPALER3_MG50_DEATHS", 100)
		stats.set_int(MPX() .. "IMPALER3_MG50_SHOTS", 500)
		stats.set_int(MPX() .. "IMPALER3_MG50_HITS", 500)
		stats.set_int(MPX() .. "IMPALER3_MG50_HEADSHOTS", 500)
		stats.set_int(MPX() .. "IMPALER3_MG50_HELDTIME", 5963259)
		stats.set_int(MPX() .. "IMPALER3_MG50_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "IMPALER3_LAS_KILLS", 500)
		stats.set_int(MPX() .. "IMPALER3_LAS_DEATHS", 100)
		stats.set_int(MPX() .. "IMPALER3_LAS_SHOTS", 500)
		stats.set_int(MPX() .. "IMPALER3_LAS_HITS", 500)
		stats.set_int(MPX() .. "IMPALER3_LAS_HEADSHOTS", 500)
		stats.set_int(MPX() .. "IMPALER3_LAS_HELDTIME", 5963259)
		stats.set_int(MPX() .. "IMPALER3_LAS_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "IMPALER4_MG50_KILLS", 500)
		stats.set_int(MPX() .. "IMPALER4_MG50_DEATHS", 100)
		stats.set_int(MPX() .. "IMPALER4_MG50_SHOTS", 500)
		stats.set_int(MPX() .. "IMPALER4_MG50_HITS", 500)
		stats.set_int(MPX() .. "IMPALER4_MG50_HEADSHOTS", 500)
		stats.set_int(MPX() .. "IMPALER4_MG50_HELDTIME", 5963259)
		stats.set_int(MPX() .. "IMPALER4_MG50_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "IMPERATOR_MG50_KILLS", 500)
		stats.set_int(MPX() .. "IMPERATOR_MG50_DEATHS", 100)
		stats.set_int(MPX() .. "IMPERATOR_MG50_SHOTS", 500)
		stats.set_int(MPX() .. "IMPERATOR_MG50_HITS", 500)
		stats.set_int(MPX() .. "IMPERATOR_MG50_HEADSHOTS", 500)
		stats.set_int(MPX() .. "IMPERATOR_MG50_HELDTIME", 5963259)
		stats.set_int(MPX() .. "IMPERATOR_MG50_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "IMPERATOR_KIN_KILLS", 500)
		stats.set_int(MPX() .. "IMPERATOR_KIN_DEATHS", 100)
		stats.set_int(MPX() .. "IMPERATOR_KIN_SHOTS", 500)
		stats.set_int(MPX() .. "IMPERATOR_KIN_HITS", 500)
		stats.set_int(MPX() .. "IMPERATOR_KIN_HELDTIME", 5963259)
		stats.set_int(MPX() .. "IMPERATOR_KIN_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "IMPERATOR2_MG50_KILLS", 500)
		stats.set_int(MPX() .. "IMPERATOR2_MG50_DEATHS", 100)
		stats.set_int(MPX() .. "IMPERATOR2_MG50_SHOTS", 500)
		stats.set_int(MPX() .. "IMPERATOR2_MG50_HITS", 500)
		stats.set_int(MPX() .. "IMPERATOR2_MG50_HEADSHOTS", 500)
		stats.set_int(MPX() .. "IMPERATOR2_MG50_HELDTIME", 5963259)
		stats.set_int(MPX() .. "IMPERATOR2_MG50_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "IMPERATOR2_KIN_KILLS", 500)
		stats.set_int(MPX() .. "IMPERATOR2_KIN_DEATHS", 100)
		stats.set_int(MPX() .. "IMPERATOR2_KIN_SHOTS", 500)
		stats.set_int(MPX() .. "IMPERATOR2_KIN_HITS", 500)
		stats.set_int(MPX() .. "IMPERATOR2_KIN_HELDTIME", 5963259)
		stats.set_int(MPX() .. "IMPERATOR2_KIN_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "IMPERATOR2_LAS_KILLS", 500)
		stats.set_int(MPX() .. "IMPERATOR2_LAS_DEATHS", 100)
		stats.set_int(MPX() .. "IMPERATOR2_LAS_SHOTS", 500)
		stats.set_int(MPX() .. "IMPERATOR2_LAS_HITS", 500)
		stats.set_int(MPX() .. "IMPERATOR2_LAS_HEADSHOTS", 500)
		stats.set_int(MPX() .. "IMPERATOR2_LAS_HELDTIME", 5963259)
		stats.set_int(MPX() .. "IMPERATOR2_LAS_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "IMPERATOR3_MG50_KILLS", 500)
		stats.set_int(MPX() .. "IMPERATOR3_MG50_DEATHS", 100)
		stats.set_int(MPX() .. "IMPERATOR3_MG50_SHOTS", 500)
		stats.set_int(MPX() .. "IMPERATOR3_MG50_HITS", 500)
		stats.set_int(MPX() .. "IMPERATOR3_MG50_HEADSHOTS", 500)
		stats.set_int(MPX() .. "IMPERATOR3_MG50_HELDTIME", 5963259)
		stats.set_int(MPX() .. "IMPERATOR3_MG50_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "IMPERATOR3_KIN_KILLS", 500)
		stats.set_int(MPX() .. "IMPERATOR3_KIN_DEATHS", 100)
		stats.set_int(MPX() .. "IMPERATOR3_KIN_SHOTS", 500)
		stats.set_int(MPX() .. "IMPERATOR3_KIN_HITS", 500)
		stats.set_int(MPX() .. "IMPERATOR3_KIN_HELDTIME", 5963259)
		stats.set_int(MPX() .. "IMPERATOR3_KIN_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "VALKYRIE_CANNON_KILLS", 500)
		stats.set_int(MPX() .. "VALKYRIE_CANNON_DEATHS", 100)
		stats.set_int(MPX() .. "VALKYRIE_CANNON_SHOTS", 500)
		stats.set_int(MPX() .. "VALKYRIE_CANNON_HITS", 500)
		stats.set_int(MPX() .. "VALKYRIE_CANNON_HEADSHOTS", 500)
		stats.set_int(MPX() .. "VALKYRIE_CANNON_HELDTIME", 5963259)
		stats.set_int(MPX() .. "VALKYRIE_CANNON_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "VALKYRIE_TURR_KILLS", 500)
		stats.set_int(MPX() .. "VALKYRIE_TURR_DEATHS", 100)
		stats.set_int(MPX() .. "VALKYRIE_TURR_SHOTS", 500)
		stats.set_int(MPX() .. "VALKYRIE_TURR_HITS", 500)
		stats.set_int(MPX() .. "VALKYRIE_TURR_HEADSHOTS", 500)
		stats.set_int(MPX() .. "VALKYRIE_TURR_HELDTIME", 5963259)
		stats.set_int(MPX() .. "VALKYRIE_TURR_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "JB7002_MG_KILLS", 500)
		stats.set_int(MPX() .. "JB7002_MG_DEATHS", 100)
		stats.set_int(MPX() .. "JB7002_MG_SHOTS", 500)
		stats.set_int(MPX() .. "JB7002_MG_HITS", 500)
		stats.set_int(MPX() .. "JB7002_MG_HEADSHOTS", 500)
		stats.set_int(MPX() .. "JB7002_MG_HELDTIME", 5963259)
		stats.set_int(MPX() .. "JB7002_MG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "MINITANK_MG_KILLS", 500)
		stats.set_int(MPX() .. "MINITANK_MG_DEATHS", 100)
		stats.set_int(MPX() .. "MINITANK_MG_SHOTS", 500)
		stats.set_int(MPX() .. "MINITANK_MG_HITS", 500)
		stats.set_int(MPX() .. "MINITANK_MG_HEADSHOTS", 500)
		stats.set_int(MPX() .. "MINITANK_MG_HELDTIME", 5963259)
		stats.set_int(MPX() .. "MINITANK_MG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "MINITANK_FL_KILLS", 500)
		stats.set_int(MPX() .. "MINITANK_FL_DEATHS", 100)
		stats.set_int(MPX() .. "MINITANK_FL_SHOTS", 500)
		stats.set_int(MPX() .. "MINITANK_FL_HITS", 500)
		stats.set_int(MPX() .. "MINITANK_FL_HELDTIME", 5963259)
		stats.set_int(MPX() .. "MINITANK_FL_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "MINITANK_RK_KILLS", 500)
		stats.set_int(MPX() .. "MINITANK_RK_DEATHS", 100)
		stats.set_int(MPX() .. "MINITANK_RK_SHOTS", 500)
		stats.set_int(MPX() .. "MINITANK_RK_HITS", 500)
		stats.set_int(MPX() .. "MINITANK_RK_HELDTIME", 5963259)
		stats.set_int(MPX() .. "MINITANK_RK_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "MINITANK_LZ_KILLS", 500)
		stats.set_int(MPX() .. "MINITANK_LZ_DEATHS", 100)
		stats.set_int(MPX() .. "MINITANK_LZ_SHOTS", 500)
		stats.set_int(MPX() .. "MINITANK_LZ_HITS", 500)
		stats.set_int(MPX() .. "MINITANK_LZ_HEADSHOTS", 500)
		stats.set_int(MPX() .. "MINITANK_LZ_HELDTIME", 5963259)
		stats.set_int(MPX() .. "MINITANK_LZ_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "FLAREGUN_KILLS", 500)
		stats.set_int(MPX() .. "FLAREGUN_DEATHS", 100)
		stats.set_int(MPX() .. "FLAREGUN_SHOTS", 500)
		stats.set_int(MPX() .. "FLAREGUN_HITS", 500)
		stats.set_int(MPX() .. "FLAREGUN_HEADSHOTS", 500)
		stats.set_int(MPX() .. "FLAREGUN_HELDTIME", 5963259)
		stats.set_int(MPX() .. "FLAREGUN_DB_HELDTIME", 5963259)
		stats.set_int(MPX() .. "FLAREGUN_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "INSURGENT_TURR_KILLS", 500)
		stats.set_int(MPX() .. "INSURGENT_TURR_DEATHS", 100)
		stats.set_int(MPX() .. "INSURGENT_TURR_SHOTS", 500)
		stats.set_int(MPX() .. "INSURGENT_TURR_HITS", 500)
		stats.set_int(MPX() .. "INSURGENT_TURR_HEADSHOTS", 500)
		stats.set_int(MPX() .. "INSURGENT_TURR_HELDTIME", 5963259)
		stats.set_int(MPX() .. "INSURGENT_TURR_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "SAVAGE_ROCKET_KILLS", 500)
		stats.set_int(MPX() .. "SAVAGE_ROCKET_DEATHS", 100)
		stats.set_int(MPX() .. "SAVAGE_ROCKET_SHOTS", 500)
		stats.set_int(MPX() .. "SAVAGE_ROCKET_HITS", 500)
		stats.set_int(MPX() .. "SAVAGE_ROCKET_HELDTIME", 5963259)
		stats.set_int(MPX() .. "SAVAGE_ROCKET_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "SAVAGE_BULLET_KILLS", 500)
		stats.set_int(MPX() .. "SAVAGE_BULLET_DEATHS", 100)
		stats.set_int(MPX() .. "SAVAGE_BULLET_SHOTS", 500)
		stats.set_int(MPX() .. "SAVAGE_BULLET_HITS", 500)
		stats.set_int(MPX() .. "SAVAGE_BULLET_HEADSHOTS", 500)
		stats.set_int(MPX() .. "SAVAGE_BULLET_HELDTIME", 5963259)
		stats.set_int(MPX() .. "SAVAGE_BULLET_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "TECHNICAL_TURR_KILLS", 500)
		stats.set_int(MPX() .. "TECHNICAL_TURR_DEATHS", 100)
		stats.set_int(MPX() .. "TECHNICAL_TURR_SHOTS", 500)
		stats.set_int(MPX() .. "TECHNICAL_TURR_HITS", 500)
		stats.set_int(MPX() .. "TECHNICAL_TURR_HEADSHOTS", 500)
		stats.set_int(MPX() .. "TECHNICAL_TURR_HELDTIME", 5963259)
		stats.set_int(MPX() .. "TECHNICAL_TURR_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "VEHBOMB_KILLS", 500)
		stats.set_int(MPX() .. "VEHBOMB_DEATHS", 100)
		stats.set_int(MPX() .. "VEHBOMB_SHOTS", 500)
		stats.set_int(MPX() .. "VEHBOMB_HITS", 500)
		stats.set_int(MPX() .. "VEHBOMB_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "VEHBOMB_C_KILLS", 500)
		stats.set_int(MPX() .. "VEHBOMB_C_DEATHS", 100)
		stats.set_int(MPX() .. "VEHBOMB_C_SHOTS", 500)
		stats.set_int(MPX() .. "VEHBOMB_C_HITS", 500)
		stats.set_int(MPX() .. "VEHBOMB_C_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "VEHBOMB_G_KILLS", 500)
		stats.set_int(MPX() .. "VEHBOMB_G_DEATHS", 100)
		stats.set_int(MPX() .. "VEHBOMB_G_SHOTS", 500)
		stats.set_int(MPX() .. "VEHBOMB_G_HITS", 500)
		stats.set_int(MPX() .. "VEHBOMB_G_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "VEHBOMB_I_KILLS", 500)
		stats.set_int(MPX() .. "VEHBOMB_I_DEATHS", 100)
		stats.set_int(MPX() .. "VEHBOMB_I_SHOTS", 500)
		stats.set_int(MPX() .. "VEHBOMB_I_HITS", 500)
		stats.set_int(MPX() .. "VEHBOMB_I_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "BOMBUSHKA_CANN_KILLS", 500)
		stats.set_int(MPX() .. "BOMBUSHKA_CANN_DEATHS", 100)
		stats.set_int(MPX() .. "BOMBUSHKA_CANN_SHOTS", 500)
		stats.set_int(MPX() .. "BOMBUSHKA_CANN_HITS", 500)
		stats.set_int(MPX() .. "BOMBUSHKA_CANN_HELDTIME", 5963259)
		stats.set_int(MPX() .. "BOMBUSHKA_CANN_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "BOMBUSHKA_DUAL_KILLS", 500)
		stats.set_int(MPX() .. "BOMBUSHKA_DUAL_DEATHS", 100)
		stats.set_int(MPX() .. "BOMBUSHKA_DUAL_SHOTS", 500)
		stats.set_int(MPX() .. "BOMBUSHKA_DUAL_HITS", 500)
		stats.set_int(MPX() .. "BOMBUSHKA_DUAL_HEADSHOTS", 500)
		stats.set_int(MPX() .. "BOMBUSHKA_DUAL_HELDTIME", 5963259)
		stats.set_int(MPX() .. "BOMBUSHKA_DUAL_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "HAVOK_MINI_KILLS", 500)
		stats.set_int(MPX() .. "HAVOK_MINI_DEATHS", 100)
		stats.set_int(MPX() .. "HAVOK_MINI_SHOTS", 500)
		stats.set_int(MPX() .. "HAVOK_MINI_HITS", 500)
		stats.set_int(MPX() .. "HAVOK_MINI_HEADSHOTS", 500)
		stats.set_int(MPX() .. "HAVOK_MINI_HELDTIME", 5963259)
		stats.set_int(MPX() .. "HAVOK_MINI_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "HUNTER_BARR_KILLS", 500)
		stats.set_int(MPX() .. "HUNTER_BARR_DEATHS", 100)
		stats.set_int(MPX() .. "HUNTER_BARR_SHOTS", 500)
		stats.set_int(MPX() .. "HUNTER_BARR_HITS", 500)
		stats.set_int(MPX() .. "HUNTER_BARR_HELDTIME", 5963259)
		stats.set_int(MPX() .. "HUNTER_BARR_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "HUNTER_CANNON_KILLS", 500)
		stats.set_int(MPX() .. "HUNTER_CANNON_DEATHS", 100)
		stats.set_int(MPX() .. "HUNTER_CANNON_SHOTS", 500)
		stats.set_int(MPX() .. "HUNTER_CANNON_HITS", 500)
		stats.set_int(MPX() .. "HUNTER_CANNON_HELDTIME", 5963259)
		stats.set_int(MPX() .. "HUNTER_CANNON_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "MICROLIGHT_MG_KILLS", 500)
		stats.set_int(MPX() .. "MICROLIGHT_MG_DEATHS", 100)
		stats.set_int(MPX() .. "MICROLIGHT_MG_SHOTS", 500)
		stats.set_int(MPX() .. "MICROLIGHT_MG_HITS", 500)
		stats.set_int(MPX() .. "MICROLIGHT_MG_HEADSHOTS", 500)
		stats.set_int(MPX() .. "MICROLIGHT_MG_HELDTIME", 5963259)
		stats.set_int(MPX() .. "MICROLIGHT_MG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "MOGUL_NOSE_KILLS", 500)
		stats.set_int(MPX() .. "MOGUL_NOSE_DEATHS", 100)
		stats.set_int(MPX() .. "MOGUL_NOSE_SHOTS", 500)
		stats.set_int(MPX() .. "MOGUL_NOSE_HITS", 500)
		stats.set_int(MPX() .. "MOGUL_NOSE_HEADSHOTS", 500)
		stats.set_int(MPX() .. "MOGUL_NOSE_HELDTIME", 5963259)
		stats.set_int(MPX() .. "MOGUL_NOSE_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "MOGUL_DNOSE_KILLS", 500)
		stats.set_int(MPX() .. "MOGUL_DNOSE_DEATHS", 100)
		stats.set_int(MPX() .. "MOGUL_DNOSE_SHOTS", 500)
		stats.set_int(MPX() .. "MOGUL_DNOSE_HITS", 500)
		stats.set_int(MPX() .. "MOGUL_DNOSE_HEADSHOTS", 500)
		stats.set_int(MPX() .. "MOGUL_DNOSE_HELDTIME", 5963259)
		stats.set_int(MPX() .. "MOGUL_DNOSE_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "MOGUL_TURR_KILLS", 500)
		stats.set_int(MPX() .. "MOGUL_TURR_DEATHS", 100)
		stats.set_int(MPX() .. "MOGUL_TURR_SHOTS", 500)
		stats.set_int(MPX() .. "MOGUL_TURR_HITS", 500)
		stats.set_int(MPX() .. "MOGUL_TURR_HEADSHOTS", 500)
		stats.set_int(MPX() .. "MOGUL_TURR_HELDTIME", 5963259)
		stats.set_int(MPX() .. "MOGUL_TURR_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "MOGUL_DTURR_KILLS", 500)
		stats.set_int(MPX() .. "MOGUL_DTURR_DEATHS", 100)
		stats.set_int(MPX() .. "MOGUL_DTURR_SHOTS", 500)
		stats.set_int(MPX() .. "MOGUL_DTURR_HITS", 500)
		stats.set_int(MPX() .. "MOGUL_DTURR_HEADSHOTS", 500)
		stats.set_int(MPX() .. "MOGUL_DTURR_HELDTIME", 5963259)
		stats.set_int(MPX() .. "MOGUL_DTURR_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "MOLOTOK_MG_KILLS", 500)
		stats.set_int(MPX() .. "MOLOTOK_MG_DEATHS", 100)
		stats.set_int(MPX() .. "MOLOTOK_MG_SHOTS", 500)
		stats.set_int(MPX() .. "MOLOTOK_MG_HITS", 500)
		stats.set_int(MPX() .. "MOLOTOK_MG_HEADSHOTS", 500)
		stats.set_int(MPX() .. "MOLOTOK_MG_HELDTIME", 5963259)
		stats.set_int(MPX() .. "MOLOTOK_MG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "MOLOTOK_MISS_KILLS", 500)
		stats.set_int(MPX() .. "MOLOTOK_MISS_DEATHS", 100)
		stats.set_int(MPX() .. "MOLOTOK_MISS_SHOTS", 500)
		stats.set_int(MPX() .. "MOLOTOK_MISS_HITS", 500)
		stats.set_int(MPX() .. "MOLOTOK_MISS_HELDTIME", 5963259)
		stats.set_int(MPX() .. "MOLOTOK_MISS_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "NOKOTA_MG_KILLS", 500)
		stats.set_int(MPX() .. "NOKOTA_MG_DEATHS", 100)
		stats.set_int(MPX() .. "NOKOTA_MG_SHOTS", 500)
		stats.set_int(MPX() .. "NOKOTA_MG_HITS", 500)
		stats.set_int(MPX() .. "NOKOTA_MG_HEADSHOTS", 500)
		stats.set_int(MPX() .. "NOKOTA_MG_HELDTIME", 5963259)
		stats.set_int(MPX() .. "NOKOTA_MG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "NOKOTA_MISS_KILLS", 500)
		stats.set_int(MPX() .. "NOKOTA_MISS_DEATHS", 100)
		stats.set_int(MPX() .. "NOKOTA_MISS_SHOTS", 500)
		stats.set_int(MPX() .. "NOKOTA_MISS_HITS", 500)
		stats.set_int(MPX() .. "NOKOTA_MISS_HELDTIME", 5963259)
		stats.set_int(MPX() .. "NOKOTA_MISS_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "PYRO_MG_KILLS", 500)
		stats.set_int(MPX() .. "PYRO_MG_DEATHS", 100)
		stats.set_int(MPX() .. "PYRO_MG_SHOTS", 500)
		stats.set_int(MPX() .. "PYRO_MG_HITS", 500)
		stats.set_int(MPX() .. "PYRO_MG_HEADSHOTS", 500)
		stats.set_int(MPX() .. "PYRO_MG_HELDTIME", 5963259)
		stats.set_int(MPX() .. "PYRO_MG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "PYRO_MISS_KILLS", 500)
		stats.set_int(MPX() .. "PYRO_MISS_DEATHS", 100)
		stats.set_int(MPX() .. "PYRO_MISS_SHOTS", 500)
		stats.set_int(MPX() .. "PYRO_MISS_HITS", 500)
		stats.set_int(MPX() .. "PYRO_MISS_HELDTIME", 5963259)
		stats.set_int(MPX() .. "PYRO_MISS_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "ROGUE_MG_KILLS", 500)
		stats.set_int(MPX() .. "ROGUE_MG_DEATHS", 100)
		stats.set_int(MPX() .. "ROGUE_MG_SHOTS", 500)
		stats.set_int(MPX() .. "ROGUE_MG_HITS", 500)
		stats.set_int(MPX() .. "ROGUE_MG_HEADSHOTS", 500)
		stats.set_int(MPX() .. "ROGUE_MG_HELDTIME", 5963259)
		stats.set_int(MPX() .. "ROGUE_MG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "ROGUE_CANN_KILLS", 500)
		stats.set_int(MPX() .. "ROGUE_CANN_DEATHS", 100)
		stats.set_int(MPX() .. "ROGUE_CANN_SHOTS", 500)
		stats.set_int(MPX() .. "ROGUE_CANN_HITS", 500)
		stats.set_int(MPX() .. "ROGUE_CANN_HELDTIME", 5963259)
		stats.set_int(MPX() .. "ROGUE_CANN_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "ROGUE_MISS_KILLS", 500)
		stats.set_int(MPX() .. "ROGUE_MISS_DEATHS", 100)
		stats.set_int(MPX() .. "ROGUE_MISS_SHOTS", 500)
		stats.set_int(MPX() .. "ROGUE_MISS_HITS", 500)
		stats.set_int(MPX() .. "ROGUE_MISS_HELDTIME", 5963259)
		stats.set_int(MPX() .. "ROGUE_MISS_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "STARLING_MG_KILLS", 500)
		stats.set_int(MPX() .. "STARLING_MG_DEATHS", 100)
		stats.set_int(MPX() .. "STARLING_MG_SHOTS", 500)
		stats.set_int(MPX() .. "STARLING_MG_HITS", 500)
		stats.set_int(MPX() .. "STARLING_MG_HEADSHOTS", 500)
		stats.set_int(MPX() .. "STARLING_MG_HELDTIME", 5963259)
		stats.set_int(MPX() .. "STARLING_MG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "STARLING_MISS_KILLS", 500)
		stats.set_int(MPX() .. "STARLING_MISS_DEATHS", 100)
		stats.set_int(MPX() .. "STARLING_MISS_SHOTS", 500)
		stats.set_int(MPX() .. "STARLING_MISS_HITS", 500)
		stats.set_int(MPX() .. "STARLING_MISS_HELDTIME", 5963259)
		stats.set_int(MPX() .. "STARLING_MISS_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "SEABREEZE_MG_KILLS", 500)
		stats.set_int(MPX() .. "SEABREEZE_MG_DEATHS", 100)
		stats.set_int(MPX() .. "SEABREEZE_MG_SHOTS", 500)
		stats.set_int(MPX() .. "SEABREEZE_MG_HITS", 500)
		stats.set_int(MPX() .. "SEABREEZE_MG_HEADSHOTS", 500)
		stats.set_int(MPX() .. "SEABREEZE_MG_HELDTIME", 5963259)
		stats.set_int(MPX() .. "SEABREEZE_MG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "TULA_MG_KILLS", 500)
		stats.set_int(MPX() .. "TULA_MG_DEATHS", 100)
		stats.set_int(MPX() .. "TULA_MG_SHOTS", 500)
		stats.set_int(MPX() .. "TULA_MG_HITS", 500)
		stats.set_int(MPX() .. "TULA_MG_HEADSHOTS", 500)
		stats.set_int(MPX() .. "TULA_MG_HELDTIME", 5963259)
		stats.set_int(MPX() .. "TULA_MG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "TULA_SINGLEMG_KILLS", 500)
		stats.set_int(MPX() .. "TULA_SINGLEMG_DEATHS", 100)
		stats.set_int(MPX() .. "TULA_SINGLEMG_SHOTS", 500)
		stats.set_int(MPX() .. "TULA_SINGLEMG_HITS", 500)
		stats.set_int(MPX() .. "TULA_SINGLEMG_HEADSHOTS", 500)
		stats.set_int(MPX() .. "TULA_SINGLEMG_HELDTIME", 5963259)
		stats.set_int(MPX() .. "TULA_SINGLEMG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "TULA_DUALMG_KILLS", 500)
		stats.set_int(MPX() .. "TULA_DUALMG_DEATHS", 100)
		stats.set_int(MPX() .. "TULA_DUALMG_SHOTS", 500)
		stats.set_int(MPX() .. "TULA_DUALMG_HITS", 500)
		stats.set_int(MPX() .. "TULA_DUALMG_HEADSHOTS", 500)
		stats.set_int(MPX() .. "TULA_DUALMG_HELDTIME", 5963259)
		stats.set_int(MPX() .. "TULA_DUALMG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "TULA_MINI_KILLS", 500)
		stats.set_int(MPX() .. "TULA_MINI_DEATHS", 100)
		stats.set_int(MPX() .. "TULA_MINI_SHOTS", 500)
		stats.set_int(MPX() .. "TULA_MINI_HITS", 500)
		stats.set_int(MPX() .. "TULA_MINI_HEADSHOTS", 500)
		stats.set_int(MPX() .. "TULA_MINI_HELDTIME", 5963259)
		stats.set_int(MPX() .. "TULA_MINI_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "VIGILANTE_MG_KILLS", 500)
		stats.set_int(MPX() .. "VIGILANTE_MG_DEATHS", 100)
		stats.set_int(MPX() .. "VIGILANTE_MG_SHOTS", 500)
		stats.set_int(MPX() .. "VIGILANTE_MG_HITS", 500)
		stats.set_int(MPX() .. "VIGILANTE_MG_HEADSHOTS", 500)
		stats.set_int(MPX() .. "VIGILANTE_MG_HELDTIME", 5963259)
		stats.set_int(MPX() .. "VIGILANTE_MG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "VIGILANTE_MISS_KILLS", 500)
		stats.set_int(MPX() .. "VIGILANTE_MISS_DEATHS", 100)
		stats.set_int(MPX() .. "VIGILANTE_MISS_SHOTS", 500)
		stats.set_int(MPX() .. "VIGILANTE_MISS_HITS", 500)
		stats.set_int(MPX() .. "VIGILANTE_MISS_HELDTIME", 5963259)
		stats.set_int(MPX() .. "VIGILANTE_MISS_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "BOXVILLE5_TURR_KILLS", 500)
		stats.set_int(MPX() .. "BOXVILLE5_TURR_DEATHS", 100)
		stats.set_int(MPX() .. "BOXVILLE5_TURR_SHOTS", 500)
		stats.set_int(MPX() .. "BOXVILLE5_TURR_HITS", 500)
		stats.set_int(MPX() .. "BOXVILLE5_TURR_HEADSHOTS", 500)
		stats.set_int(MPX() .. "BOXVILLE5_TURR_HELDTIME", 5963259)
		stats.set_int(MPX() .. "BOXVILLE5_TURR_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "BLAZER5_CANNON_KILLS", 500)
		stats.set_int(MPX() .. "BLAZER5_CANNON_DEATHS", 100)
		stats.set_int(MPX() .. "BLAZER5_CANNON_SHOTS", 500)
		stats.set_int(MPX() .. "BLAZER5_CANNON_HITS", 500)
		stats.set_int(MPX() .. "BLAZER5_CANNON_HEADSHOTS", 500)
		stats.set_int(MPX() .. "BLAZER5_CANNON_HELDTIME", 5963259)
		stats.set_int(MPX() .. "BLAZER5_CANNON_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "RUINER2_BULLET_KILLS", 500)
		stats.set_int(MPX() .. "RUINER2_BULLET_DEATHS", 100)
		stats.set_int(MPX() .. "RUINER2_BULLET_SHOTS", 500)
		stats.set_int(MPX() .. "RUINER2_BULLET_HITS", 500)
		stats.set_int(MPX() .. "RUINER2_BULLET_HEADSHOTS", 500)
		stats.set_int(MPX() .. "RUINER2_BULLET_HELDTIME", 5963259)
		stats.set_int(MPX() .. "RUINER2_BULLET_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "RUINER2_ROCKET_KILLS", 500)
		stats.set_int(MPX() .. "RUINER2_ROCKET_DEATHS", 100)
		stats.set_int(MPX() .. "RUINER2_ROCKET_SHOTS", 500)
		stats.set_int(MPX() .. "RUINER2_ROCKET_HITS", 500)
		stats.set_int(MPX() .. "RUINER2_ROCKET_HEADSHOTS", 500)
		stats.set_int(MPX() .. "RUINER2_ROCKET_HELDTIME", 5963259)
		stats.set_int(MPX() .. "RUINER2_ROCKET_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "TECHNICAL2_TURR_KILLS", 500)
		stats.set_int(MPX() .. "TECHNICAL2_TURR_DEATHS", 100)
		stats.set_int(MPX() .. "TECHNICAL2_TURR_SHOTS", 500)
		stats.set_int(MPX() .. "TECHNICAL2_TURR_HITS", 500)
		stats.set_int(MPX() .. "TECHNICAL2_TURR_HEADSHOTS", 500)
		stats.set_int(MPX() .. "TECHNICAL2_TURR_HELDTIME", 5963259)
		stats.set_int(MPX() .. "TECHNICAL2_TURR_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "CRARMWREST", 500)
		stats.set_int(MPX() .. "CRBASEJUMP", 500)
		stats.set_int(MPX() .. "CRDARTS", 500)
		stats.set_int(MPX() .. "CRDM", 500)
		stats.set_int(MPX() .. "CRGANGHIDE", 500)
		stats.set_int(MPX() .. "CRGOLF", 500)
		stats.set_int(MPX() .. "CRHORDE", 500)
		stats.set_int(MPX() .. "CRMISSION", 500)
		stats.set_int(MPX() .. "CRSHOOTRNG", 500)
		stats.set_int(MPX() .. "CRTENNIS", 500)
		stats.set_int(MPX() .. "NO_TIMES_CINEMA", 500)
		stats.set_int(MPX() .. "AWD_CONTRACTOR", 50)
		stats.set_int(MPX() .. "AWD_COLD_CALLER", 50)
		stats.set_int(MPX() .. "AWD_CSYONS26DUCER", 60)
		stats.set_int(MPX() .. "FIXERTELEPHONEHITSCOMPL", 10)
		stats.set_int(MPX() .. "PAYPHONE_BONUS_KILL_METHOD", -1)
		stats.set_int(MPX() .. "TWR_INITIALS_0", 69644)
		stats.set_int(MPX() .. "TWR_INITIALS_1", 69644)
		stats.set_int(MPX() .. "TWR_INITIALS_2", 69644)
		stats.set_int(MPX() .. "TWR_INITIALS_3", 69644)
		stats.set_int(MPX() .. "TWR_INITIALS_4", 69644)
		stats.set_int(MPX() .. "TWR_INITIALS_5", 69644)
		stats.set_int(MPX() .. "TWR_INITIALS_6", 69644)
		stats.set_int(MPX() .. "TWR_INITIALS_7", 69644)
		stats.set_int(MPX() .. "TWR_INITIALS_8", 69644)
		stats.set_int(MPX() .. "TWR_INITIALS_9", 69644)
		stats.set_int(MPX() .. "TWR_SCORE_0", 50)
		stats.set_int(MPX() .. "TWR_SCORE_1", 50)
		stats.set_int(MPX() .. "TWR_SCORE_2", 50)
		stats.set_int(MPX() .. "TWR_SCORE_3", 50)
		stats.set_int(MPX() .. "TWR_SCORE_4", 50)
		stats.set_int(MPX() .. "TWR_SCORE_5", 50)
		stats.set_int(MPX() .. "TWR_SCORE_6", 50)
		stats.set_int(MPX() .. "TWR_SCORE_7", 50)
		stats.set_int(MPX() .. "TWR_SCORE_8", 50)
		stats.set_int(MPX() .. "TWR_SCORE_9", 50)
		stats.set_int(MPX() .. "GGSM_INITIALS_0", 69644)
		stats.set_int(MPX() .. "GGSM_INITIALS_1", 69644)
		stats.set_int(MPX() .. "GGSM_INITIALS_2", 69644)
		stats.set_int(MPX() .. "GGSM_INITIALS_3", 69644)
		stats.set_int(MPX() .. "GGSM_INITIALS_4", 69644)
		stats.set_int(MPX() .. "GGSM_INITIALS_5", 69644)
		stats.set_int(MPX() .. "GGSM_INITIALS_6", 69644)
		stats.set_int(MPX() .. "GGSM_INITIALS_7", 69644)
		stats.set_int(MPX() .. "GGSM_INITIALS_8", 69644)
		stats.set_int(MPX() .. "GGSM_INITIALS_9", 69644)
		stats.set_int(MPX() .. "GGSM_SCORE_0", 50)
		stats.set_int(MPX() .. "GGSM_SCORE_1", 50)
		stats.set_int(MPX() .. "GGSM_SCORE_2", 50)
		stats.set_int(MPX() .. "GGSM_SCORE_3", 50)
		stats.set_int(MPX() .. "GGSM_SCORE_4", 50)
		stats.set_int(MPX() .. "GGSM_SCORE_5", 50)
		stats.set_int(MPX() .. "GGSM_SCORE_6", 50)
		stats.set_int(MPX() .. "GGSM_SCORE_7", 50)
		stats.set_int(MPX() .. "GGSM_SCORE_8", 50)
		stats.set_int(MPX() .. "GGSM_SCORE_9", 50)
		stats.set_int(MPX() .. "DG_PENETRATOR_INITIALS_0", 69644)
		stats.set_int(MPX() .. "DG_PENETRATOR_INITIALS_1", 69644)
		stats.set_int(MPX() .. "DG_PENETRATOR_INITIALS_2", 69644)
		stats.set_int(MPX() .. "DG_PENETRATOR_INITIALS_3", 69644)
		stats.set_int(MPX() .. "DG_PENETRATOR_INITIALS_4", 69644)
		stats.set_int(MPX() .. "DG_PENETRATOR_INITIALS_5", 69644)
		stats.set_int(MPX() .. "DG_PENETRATOR_INITIALS_6", 69644)
		stats.set_int(MPX() .. "DG_PENETRATOR_INITIALS_7", 69644)
		stats.set_int(MPX() .. "DG_PENETRATOR_INITIALS_8", 69644)
		stats.set_int(MPX() .. "DG_PENETRATOR_INITIALS_9", 69644)
		stats.set_int(MPX() .. "DG_PENETRATOR_SCORE_0", 50)
		stats.set_int(MPX() .. "DG_PENETRATOR_SCORE_1", 50)
		stats.set_int(MPX() .. "DG_PENETRATOR_SCORE_2", 50)
		stats.set_int(MPX() .. "DG_PENETRATOR_SCORE_3", 50)
		stats.set_int(MPX() .. "DG_PENETRATOR_SCORE_4", 50)
		stats.set_int(MPX() .. "DG_PENETRATOR_SCORE_5", 50)
		stats.set_int(MPX() .. "DG_PENETRATOR_SCORE_6", 50)
		stats.set_int(MPX() .. "DG_PENETRATOR_SCORE_7", 50)
		stats.set_int(MPX() .. "DG_PENETRATOR_SCORE_8", 50)
		stats.set_int(MPX() .. "DG_PENETRATOR_SCORE_9", 50)
		stats.set_int(MPX() .. "DG_MONKEY_INITIALS_0", 69644)
		stats.set_int(MPX() .. "DG_MONKEY_INITIALS_1", 69644)
		stats.set_int(MPX() .. "DG_MONKEY_INITIALS_2", 69644)
		stats.set_int(MPX() .. "DG_MONKEY_INITIALS_3", 69644)
		stats.set_int(MPX() .. "DG_MONKEY_INITIALS_4", 69644)
		stats.set_int(MPX() .. "DG_MONKEY_INITIALS_5", 69644)
		stats.set_int(MPX() .. "DG_MONKEY_INITIALS_6", 69644)
		stats.set_int(MPX() .. "DG_MONKEY_INITIALS_7", 69644)
		stats.set_int(MPX() .. "DG_MONKEY_INITIALS_8", 69644)
		stats.set_int(MPX() .. "DG_MONKEY_INITIALS_9", 69644)
		stats.set_int(MPX() .. "DG_MONKEY_SCORE_0", 50)
		stats.set_int(MPX() .. "DG_MONKEY_SCORE_1", 50)
		stats.set_int(MPX() .. "DG_MONKEY_SCORE_2", 50)
		stats.set_int(MPX() .. "DG_MONKEY_SCORE_3", 50)
		stats.set_int(MPX() .. "DG_MONKEY_SCORE_4", 50)
		stats.set_int(MPX() .. "DG_MONKEY_SCORE_5", 50)
		stats.set_int(MPX() .. "DG_MONKEY_SCORE_6", 50)
		stats.set_int(MPX() .. "DG_MONKEY_SCORE_7", 50)
		stats.set_int(MPX() .. "DG_MONKEY_SCORE_8", 50)
		stats.set_int(MPX() .. "DG_MONKEY_SCORE_9", 50)
		stats.set_int(MPX() .. "CH_ARC_CAB_CLAW_TROPHY", -1)
		stats.set_int(MPX() .. "CH_ARC_CAB_LOVE_TROPHY", -1)
		stats.set_int(MPX() .. "AWD_PREPARATION", 40)
		stats.set_int(MPX() .. "AWD_ASLEEPONJOB", 20)
		stats.set_int(MPX() .. "AWD_DAICASHCRAB", 100000)
		stats.set_int(MPX() .. "AWD_BIGBRO", 40)
		stats.set_int(MPX() .. "AWD_SHARPSHOOTER", 40)
		stats.set_int(MPX() .. "AWD_RACECHAMP", 40)
		stats.set_int(MPX() .. "AWD_BATSWORD", 1000000)
		stats.set_int(MPX() .. "AWD_COINPURSE", 950000)
		stats.set_int(MPX() .. "AWD_ASTROCHIMP", 3000000)
		stats.set_int(MPX() .. "AWD_MASTERFUL", 40000)
		stats.set_int(MPX() .. "SCGW_NUM_WINS_GANG_0", 50)
		stats.set_int(MPX() .. "SCGW_NUM_WINS_GANG_1", 50)
		stats.set_int(MPX() .. "SCGW_NUM_WINS_GANG_2", 501)
		stats.set_int(MPX() .. "SCGW_NUM_WINS_GANG_3", 50)
		stats.set_int(MPX() .. "IAP_MA0_MOON_DIST", 2147483647)
		stats.set_int(MPX() .. "AWD_FACES_OF_DEATH", 47)
		stats.set_int(MPX() .. "IAP_INITIALS_0", 50)
		stats.set_int(MPX() .. "IAP_INITIALS_1", 50)
		stats.set_int(MPX() .. "IAP_INITIALS_2", 50)
		stats.set_int(MPX() .. "IAP_INITIALS_3", 50)
		stats.set_int(MPX() .. "IAP_INITIALS_4", 50)
		stats.set_int(MPX() .. "IAP_INITIALS_5", 50)
		stats.set_int(MPX() .. "IAP_INITIALS_6", 50)
		stats.set_int(MPX() .. "IAP_INITIALS_7", 50)
		stats.set_int(MPX() .. "IAP_INITIALS_8", 50)
		stats.set_int(MPX() .. "IAP_INITIALS_9", 50)
		stats.set_int(MPX() .. "IAP_SCORE_0", 69644)
		stats.set_int(MPX() .. "IAP_SCORE_1", 50333)
		stats.set_int(MPX() .. "IAP_SCORE_2", 63512)
		stats.set_int(MPX() .. "IAP_SCORE_3", 46136)
		stats.set_int(MPX() .. "IAP_SCORE_4", 21638)
		stats.set_int(MPX() .. "IAP_SCORE_5", 2133)
		stats.set_int(MPX() .. "IAP_SCORE_6", 1215)
		stats.set_int(MPX() .. "IAP_SCORE_7", 2444)
		stats.set_int(MPX() .. "IAP_SCORE_8", 38023)
		stats.set_int(MPX() .. "IAP_SCORE_9", 2233)
		stats.set_int(MPX() .. "SCGW_SCORE_1", 50)
		stats.set_int(MPX() .. "SCGW_SCORE_2", 50)
		stats.set_int(MPX() .. "SCGW_SCORE_3", 50)
		stats.set_int(MPX() .. "SCGW_SCORE_4", 50)
		stats.set_int(MPX() .. "SCGW_SCORE_5", 50)
		stats.set_int(MPX() .. "SCGW_SCORE_6", 50)
		stats.set_int(MPX() .. "SCGW_SCORE_7", 50)
		stats.set_int(MPX() .. "SCGW_SCORE_8", 50)
		stats.set_int(MPX() .. "SCGW_SCORE_9", 50)
		stats.set_int(MPX() .. "DG_DEFENDER_INITIALS_0", 69644)
		stats.set_int(MPX() .. "DG_DEFENDER_INITIALS_1", 69644)
		stats.set_int(MPX() .. "DG_DEFENDER_INITIALS_2", 69644)
		stats.set_int(MPX() .. "DG_DEFENDER_INITIALS_3", 69644)
		stats.set_int(MPX() .. "DG_DEFENDER_INITIALS_4", 69644)
		stats.set_int(MPX() .. "DG_DEFENDER_INITIALS_5", 69644)
		stats.set_int(MPX() .. "DG_DEFENDER_INITIALS_6", 69644)
		stats.set_int(MPX() .. "DG_DEFENDER_INITIALS_7", 69644)
		stats.set_int(MPX() .. "DG_DEFENDER_INITIALS_8", 69644)
		stats.set_int(MPX() .. "DG_DEFENDER_INITIALS_9", 69644)
		stats.set_int(MPX() .. "DG_DEFENDER_SCORE_0", 50)
		stats.set_int(MPX() .. "DG_DEFENDER_SCORE_1", 50)
		stats.set_int(MPX() .. "DG_DEFENDER_SCORE_2", 50)
		stats.set_int(MPX() .. "DG_DEFENDER_SCORE_3", 50)
		stats.set_int(MPX() .. "DG_DEFENDER_SCORE_4", 50)
		stats.set_int(MPX() .. "DG_DEFENDER_SCORE_5", 50)
		stats.set_int(MPX() .. "DG_DEFENDER_SCORE_6", 50)
		stats.set_int(MPX() .. "DG_DEFENDER_SCORE_7", 50)
		stats.set_int(MPX() .. "DG_DEFENDER_SCORE_8", 50)
		stats.set_int(MPX() .. "DG_DEFENDER_SCORE_9", 50)
		stats.set_int(MPX() .. "AWD_CAR_CLUB_MEM", 100)
		stats.set_int(MPX() .. "AWD_SPRINTRACER", 50)
		stats.set_int(MPX() .. "AWD_STREETRACER", 50)
		stats.set_int(MPX() .. "AWD_PURSUITRACER", 50)
		stats.set_int(MPX() .. "AWD_TEST_CAR", 240)
		stats.set_int(MPX() .. "AWD_AUTO_SHOP", 50)
		stats.set_int(MPX() .. "AWD_CAR_EXPORT", 100)
		stats.set_int(MPX() .. "AWD_GROUNDWORK", 40)
		stats.set_int(MPX() .. "AWD_ROBBERY_CONTRACT", 100)
		stats.set_int(MPX() .. "AWD_FACES_OF_DEATH", 100)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_LEGS_3", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_LEGS_4", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_LEGS_5", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_LEGS_6", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_LEGS_7", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_OUTFIT", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_CSYONS26PS", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_CSYONS26PS_1", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_CSYONS26PS_10", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_CSYONS26PS_2", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_CSYONS26PS_3", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_CSYONS26PS_4", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_CSYONS26PS_5", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_CSYONS26PS_6", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_CSYONS26PS_7", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_CSYONS26PS_8", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_CSYONS26PS_9", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_SPECIAL", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_SPECIAL2", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_SPECIAL2_1", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_SPECIAL_1", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_SPECIAL_2", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_SPECIAL_3", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_SPECIAL_4", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_SPECIAL_5", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_SPECIAL_6", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_SPECIAL_7", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_TEETH", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_TEETH_1", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_TEETH_2", -1)
		stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_TORSO", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_0", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_1", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_10", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_11", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_12", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_13", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_14", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_15", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_16", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_17", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_18", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_19", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_2", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_20", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_21", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_22", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_23", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_24", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_25", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_26", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_27", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_28", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_29", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_3", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_30", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_31", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_32", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_33", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_34", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_35", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_36", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_37", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_38", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_39", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_4", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_40", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_5", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_6", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_7", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_8", -1)
		stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_9", -1)
		stats.set_int(MPX() .. "GRENADE_ENEMY_KILLS", 50)
		stats.set_int(MPX() .. "MICROSMG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "SMG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "ASLTSMG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "ASLTRIFLE_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "CRBNRIFLE_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "ADVRIFLE_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "MG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "CMBTMG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "ASLTMG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "RPG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "LONGEST_WHEELIE_DIST", 1000)
		stats.set_int(MPX() .. "MOST_ARM_WRESTLING_WINS", 25)
		stats.set_int(MPX() .. "NO_CARS_REPAIR", 1000)
		stats.set_int(MPX() .. "VEHICLES_SPRAYED", 500)
		stats.set_int(MPX() .. "NUMBER_NEAR_MISS_NOCRASH", 500)
		stats.set_int(MPX() .. "USJS_FOUND", 50)
		stats.set_int(MPX() .. "USJS_FOUND_MASK", 50)
		stats.set_int(MPX() .. "USJS_COMPLETED", 50)
		stats.set_int(MPX() .. "USJS_TOTAL_COMPLETED", 50)
		stats.set_int(MPX() .. "USJS_COMPLETED_MASK", 50)
		stats.set_int(MPX() .. "MOST_FLIPS_IN_ONE_JUMP", 5)
		stats.set_int(MPX() .. "MOST_SPINS_IN_ONE_JUMP", 5)
		stats.set_int(MPX() .. "NUMBER_SLIPSTREAMS_IN_RACE", 100)
		stats.set_int(MPX() .. "NUMBER_TURBO_STARTS_IN_RACE", 50)
		stats.set_int(MPX() .. "PASS_DB_PLAYER_KILLS", 100)
		stats.set_int(MPX() .. "PISTOL_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "PLAYER_HEADSHOTS", 500)
		stats.set_int(MPX() .. "RACES_WON", 50)
		stats.set_int(MPX() .. "SAWNOFF_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "SCRIPT_INCREASE_DRIV", 100)
		stats.set_int(MPX() .. "SCRIPT_INCREASE_FLY", 100)
		stats.set_int(MPX() .. "SCRIPT_INCREASE_LUNG", 100)
		stats.set_int(MPX() .. "SCRIPT_INCREASE_MECH", 100)
		stats.set_int(MPX() .. "SCRIPT_INCREASE_SHO", 100)
		stats.set_int(MPX() .. "SCRIPT_INCREASE_STAM", 100)
		stats.set_int(MPX() .. "SCRIPT_INCREASE_STL", 100)
		stats.set_int(MPX() .. "SCRIPT_INCREASE_STRN", 100)
		stats.set_int(MPX() .. "STKYBMB_ENEMY_KILLS", 50)
		stats.set_int(MPX() .. "UNARMED_ENEMY_KILLS", 50)
		stats.set_int(MPX() .. "USJS_COMPLETED", 50)
		stats.set_int(MPX() .. "WEAP_FM_ADDON_PURCH", -1)
		stats.set_int(MPX() .. "WEAP_FM_ADDON_PURCH2", -1)
		stats.set_int(MPX() .. "WEAP_FM_ADDON_PURCH3", -1)
		stats.set_int(MPX() .. "WEAP_FM_ADDON_PURCH4", -1)
		stats.set_int(MPX() .. "WEAP_FM_ADDON_PURCH5", -1)
		for i = 2, 19 do stats.set_int(MPX() .. "WEAP_FM_ADDON_PURCH"..i, -1) end
		for j = 1, 19 do stats.set_int(MPX() .. "CHAR_FM_WEAP_ADDON_"..j.."_UNLCK", -1) end
		for m = 1, 41 do stats.set_int(MPX() .. "CHAR_KIT_"..m.."_FM_UNLCK", -1) end
		for l = 2, 41 do stats.set_int(MPX() .. "CHAR_KIT_FM_PURCHASE"..l, -1) end
		stats.set_int(MPX() .. "CRDEADLINE", 5)
		stats.set_int(MPX() .. "CHAR_FM_ABILITY_1_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_FM_ABILITY_2_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_FM_ABILITY_3_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_ABILITY_1_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_ABILITY_2_UNLCK", -1)
		stats.set_int(MPX() .. "CHAR_ABILITY_3_UNLCK", -1)
		stats.set_int(MPX() .. "LIFETIME_BIKER_BUY_COMPLET", 1000)
		stats.set_int(MPX() .. "LIFETIME_BIKER_BUY_UNDERTA", 1000)
		stats.set_int(MPX() .. "LIFETIME_BIKER_SELL_COMPLET", 1000)
		stats.set_int(MPX() .. "LIFETIME_BIKER_SELL_UNDERTA", 1000)
		stats.set_int(MPX() .. "LIFETIME_BIKER_BUY_COMPLET1", 1000)
		stats.set_int(MPX() .. "LIFETIME_BIKER_BUY_UNDERTA1", 1000)
		stats.set_int(MPX() .. "LIFETIME_BIKER_SELL_COMPLET1", 1000)
		stats.set_int(MPX() .. "LIFETIME_BIKER_SELL_UNDERTA1", 1000)
		stats.set_int(MPX() .. "LIFETIME_BIKER_BUY_COMPLET2", 1000)
		stats.set_int(MPX() .. "LIFETIME_BIKER_BUY_UNDERTA2", 1000)
		stats.set_int(MPX() .. "LIFETIME_BIKER_SELL_COMPLET2", 1000)
		stats.set_int(MPX() .. "LIFETIME_BIKER_SELL_UNDERTA2", 1000)
		stats.set_int(MPX() .. "LIFETIME_BIKER_BUY_COMPLET3", 1000)
		stats.set_int(MPX() .. "LIFETIME_BIKER_BUY_UNDERTA3", 1000)
		stats.set_int(MPX() .. "LIFETIME_BIKER_SELL_COMPLET3", 1000)
		stats.set_int(MPX() .. "LIFETIME_BIKER_SELL_UNDERTA3", 1000)
		stats.set_int(MPX() .. "LIFETIME_BIKER_BUY_COMPLET4", 1000)
		stats.set_int(MPX() .. "LIFETIME_BIKER_BUY_UNDERTA4", 1000)
		stats.set_int(MPX() .. "LIFETIME_BIKER_SELL_COMPLET4", 1000)
		stats.set_int(MPX() .. "LIFETIME_BIKER_SELL_UNDERTA4", 1000)
		stats.set_int(MPX() .. "LIFETIME_BIKER_BUY_COMPLET5", 1000)
		stats.set_int(MPX() .. "LIFETIME_BIKER_BUY_UNDERTA5", 1000)
		stats.set_int(MPX() .. "LIFETIME_BIKER_SELL_COMPLET5", 1000)
		stats.set_int(MPX() .. "LIFETIME_BIKER_SELL_UNDERTA5", 1000)
		stats.set_int(MPX() .. "LIFETIME_BKR_SELL_EARNINGS0", 20000000)
		stats.set_int(MPX() .. "LIFETIME_BKR_SELL_EARNINGS1", 20000000)
		stats.set_int(MPX() .. "LIFETIME_BKR_SELL_EARNINGS2", 20000000)
		stats.set_int(MPX() .. "LIFETIME_BKR_SELL_EARNINGS3", 20000000)
		stats.set_int(MPX() .. "LIFETIME_BKR_SELL_EARNINGS4", 20000000)
		stats.set_int(MPX() .. "LFETIME_IE_EXPORT_COMPLETED", 1000)
		stats.set_int(MPX() .. "LFETIME_IE_MISSION_EARNINGS", 20000000)
		stats.set_int(MPX() .. "LFETIME_HANGAR_SEL_UNDETAK", 1000)
		stats.set_int(MPX() .. "LFETIME_HANGAR_SEL_COMPLET", 1000)
		stats.set_int(MPX() .. "LFETIME_HANGAR_EARNINGS", 20000000)
		stats.set_int(MPX() .. "SR_HIGHSCORE_1", 690)
		stats.set_int(MPX() .. "SR_HIGHSCORE_2", 1860)
		stats.set_int(MPX() .. "SR_HIGHSCORE_3", 2690)
		stats.set_int(MPX() .. "SR_HIGHSCORE_4", 2660)
		stats.set_int(MPX() .. "SR_HIGHSCORE_5", 2650)
		stats.set_int(MPX() .. "SR_HIGHSCORE_6", 450)
		stats.set_int(MPX() .. "SR_TARGETS_HIT", 269)
		stats.set_int(MPX() .. "SR_WEAPON_BIT_SET", -1)
		stats.set_int(MPX() .. "GANGOPS_HEIST_STATUS", 9999)
		stats.set_int(MPX() .. "NO_BOUGHT_YUM_SNACKS", 1000)
		stats.set_int(MPX() .. "AWD_DANCE_TO_SOLOMUN", 100)
		stats.set_int(MPX() .. "AWD_DANCE_TO_TALEOFUS", 100)
		stats.set_int(MPX() .. "AWD_DANCE_TO_DIXON", 100)
		stats.set_int(MPX() .. "AWD_DANCE_TO_BLKMAD", 100)
		stats.set_int(MPX() .. "AWD_CLUB_DRUNK", 200)
		stats.set_int(MPX() .. "NUMUNIQUEPLYSINCLUB", 100)
		stats.set_int(MPX() .. "DANCETODIFFDJS", 4)
		stats.set_int(MPX() .. "DANCEPERFECTOWNCLUB", 100)
		stats.set_int(MPX() .. "NIGHTCLUB_HOTSPOT_TIME_MS", 3600000)
		stats.set_int(MPX() .. "AWD_WATCH_YOUR_STEP", 50)
		stats.set_int(MPX() .. "AWD_TOWER_OFFENSE", 50)
		stats.set_int(MPX() .. "AWD_READY_FOR_WAR", 60)
		stats.set_int(MPX() .. "AWD_THROUGH_A_LENS", 60)
		stats.set_int(MPX() .. "AWD_SPINNER", 60)
		stats.set_int(MPX() .. "AWD_YOUMEANBOOBYTRAPS", 50)
		stats.set_int(MPX() .. "AWD_MASTER_BANDITO", 50)
		stats.set_int(MPX() .. "AWD_SITTING_DUCK", 60)
		stats.set_int(MPX() .. "AWD_CROWDPARTICIPATION", 60)
		stats.set_int(MPX() .. "AWD_KILL_OR_BE_KILLED", 60)
		stats.set_int(MPX() .. "AWD_MASSIVE_SHUNT", 60)
		stats.set_int(MPX() .. "AWD_YOURE_OUTTA_HERE", 200)
		stats.set_int(MPX() .. "AWD_WEVE_GOT_ONE", 52)
		stats.set_int(MPX() .. "AWD_ARENA_WAGEWORKER", 20000000)
		stats.set_int(MPX() .. "AWD_TIME_SERVED", 1000)
		stats.set_int(MPX() .. "AWD_TOP_SCORE", 500000)
		stats.set_int(MPX() .. "AWD_CAREER_WINNER", 1000)
		stats.set_int(MPX() .. "ARENAWARS_SKILL_LEVEL", 20)
		stats.set_int(MPX() .. "ARENAWARS_AP_TIER", 1000)
		stats.set_int(MPX() .. "ARENAWARS_AP_LIFETIME", 47551850)
		stats.set_int(MPX() .. "ARN_W_THEME_SCIFI", 1000)
		stats.set_int(MPX() .. "ARN_W_THEME_APOC", 1000)
		stats.set_int(MPX() .. "ARN_W_THEME_CONS", 1000)
		stats.set_int(MPX() .. "ARN_W_PASS_THE_BOMB", 1000)
		stats.set_int(MPX() .. "ARN_W_DETONATION", 1000)
		stats.set_int(MPX() .. "ARN_W_ARCADE_RACE", 1000)
		stats.set_int(MPX() .. "ARN_W_CTF", 1000)
		stats.set_int(MPX() .. "ARN_W_TAG_TEAM", 1000)
		stats.set_int(MPX() .. "ARN_W_DESTR_DERBY", 1000)
		stats.set_int(MPX() .. "ARN_W_CARNAGE", 1000)
		stats.set_int(MPX() .. "ARN_W_MONSTER_JAM", 1000)
		stats.set_int(MPX() .. "ARN_W_GAMES_MASTERS", 1000)
		stats.set_int(MPX() .. "ARN_L_PASS_THE_BOMB", 500)
		stats.set_int(MPX() .. "ARN_L_DETONATION", 500)
		stats.set_int(MPX() .. "ARN_L_ARCADE_RACE", 500)
		stats.set_int(MPX() .. "ARN_L_CTF", 500)
		stats.set_int(MPX() .. "ARN_L_TAG_TEAM", 500)
		stats.set_int(MPX() .. "ARN_L_DESTR_DERBY", 500)
		stats.set_int(MPX() .. "ARN_L_CARNAGE", 500)
		stats.set_int(MPX() .. "ARN_L_MONSTER_JAM", 500)
		stats.set_int(MPX() .. "ARN_L_GAMES_MASTERS", 500)
		stats.set_int(MPX() .. "NUMBER_OF_CHAMP_BOUGHT", 1000)
		stats.set_int(MPX() .. "ARN_SPECTATOR_KILLS", 1000)
		stats.set_int(MPX() .. "ARN_LIFETIME_KILLS", 1000)
		stats.set_int(MPX() .. "ARN_LIFETIME_DEATHS", 500)
		stats.set_int(MPX() .. "ARENAWARS_CARRER_WINS", 1000)
		stats.set_int(MPX() .. "ARENAWARS_CARRER_WINT", 1000)
		stats.set_int(MPX() .. "ARENAWARS_MATCHES_PLYD", 1000)
		stats.set_int(MPX() .. "ARENAWARS_MATCHES_PLYDT", 1000)
		stats.set_int(MPX() .. "ARN_SPECTATOR_DRONE", 1000)
		stats.set_int(MPX() .. "ARN_SPECTATOR_CAMS", 1000)
		stats.set_int(MPX() .. "ARN_SMOKE", 1000)
		stats.set_int(MPX() .. "ARN_DRINK", 1000)
		stats.set_int(MPX() .. "ARN_VEH_MONSTER3", 1000)
		stats.set_int(MPX() .. "ARN_VEH_MONSTER4", 1000)
		stats.set_int(MPX() .. "ARN_VEH_MONSTER5", 1000)
		stats.set_int(MPX() .. "ARN_VEH_CERBERUS", 1000)
		stats.set_int(MPX() .. "ARN_VEH_CERBERUS2", 1000)
		stats.set_int(MPX() .. "ARN_VEH_CERBERUS3", 1000)
		stats.set_int(MPX() .. "ARN_VEH_BRUISER", 1000)
		stats.set_int(MPX() .. "ARN_VEH_BRUISER2", 1000)
		stats.set_int(MPX() .. "ARN_VEH_BRUISER3", 1000)
		stats.set_int(MPX() .. "ARN_VEH_SLAMVAN4", 1000)
		stats.set_int(MPX() .. "ARN_VEH_SLAMVAN5", 1000)
		stats.set_int(MPX() .. "ARN_VEH_SLAMVAN6", 1000)
		stats.set_int(MPX() .. "ARN_VEH_BRUTUS", 1000)
		stats.set_int(MPX() .. "ARN_VEH_BRUTUS2", 1000)
		stats.set_int(MPX() .. "ARN_VEH_BRUTUS3", 1000)
		stats.set_int(MPX() .. "ARN_VEH_SCARAB", 1000)
		stats.set_int(MPX() .. "ARN_VEH_SCARAB2", 1000)
		stats.set_int(MPX() .. "ARN_VEH_SCARAB3", 1000)
		stats.set_int(MPX() .. "ARN_VEH_DOMINATOR4", 1000)
		stats.set_int(MPX() .. "ARN_VEH_DOMINATOR5", 1000)
		stats.set_int(MPX() .. "ARN_VEH_DOMINATOR6", 1000)
		stats.set_int(MPX() .. "ARN_VEH_IMPALER2", 1000)
		stats.set_int(MPX() .. "ARN_VEH_IMPALER3", 1000)
		stats.set_int(MPX() .. "ARN_VEH_IMPALER4", 1000)
		stats.set_int(MPX() .. "ARN_VEH_ISSI4", 1000)
		stats.set_int(MPX() .. "ARN_VEH_ISSI5", 1000)
		stats.set_int(MPX() .. "ARN_VEH_ISSI6", 1000)
		stats.set_int(MPX() .. "ARN_VEH_IMPERATOR", 1000)
		stats.set_int(MPX() .. "ARN_VEH_IMPERATOR2", 1000)
		stats.set_int(MPX() .. "ARN_VEH_IMPERATOR3", 1000)
		stats.set_int(MPX() .. "ARN_VEH_ZR380", 1000)
		stats.set_int(MPX() .. "ARN_VEH_ZR3802", 1000)
		stats.set_int(MPX() .. "ARN_VEH_ZR3803", 1000)
		stats.set_int(MPX() .. "ARN_VEH_DEATHBIKE", 1000)
		stats.set_int(MPX() .. "ARN_VEH_DEATHBIKE2", 1000)
		stats.set_int(MPX() .. "ARN_VEH_DEATHBIKE3", 1000)
		stats.set_int(MPX() .. "NO_BOUGHT_HEALTH_SNACKS", 1000)
		stats.set_int(MPX() .. "NO_BOUGHT_EPIC_SNACKS", 1000)
		stats.set_int(MPX() .. "NUMBER_OF_ORANGE_BOUGHT", 1000)
		stats.set_int(MPX() .. "MP_CHAR_ARMOUR_1_COUNT", 1000)
		stats.set_int(MPX() .. "MP_CHAR_ARMOUR_2_COUNT", 1000)
		stats.set_int(MPX() .. "MP_CHAR_ARMOUR_3_COUNT", 1000)
		stats.set_int(MPX() .. "MP_CHAR_ARMOUR_4_COUNT", 1000)
		stats.set_int(MPX() .. "MP_CHAR_ARMOUR_5_COUNT", 1000)
		stats.set_int(MPX() .. "NUMBER_OF_BOURGE_BOUGHT", 1000)
		stats.set_int(MPX() .. "CIGARETTES_BOUGHT", 1000)
		stats.set_int(MPX() .. "FIREWORK_TYPE_1_WHITE", 1000)
		stats.set_int(MPX() .. "FIREWORK_TYPE_1_RED", 1000)
		stats.set_int(MPX() .. "FIREWORK_TYPE_1_BLUE", 1000)
		stats.set_int(MPX() .. "FIREWORK_TYPE_2_WHITE", 1000)
		stats.set_int(MPX() .. "FIREWORK_TYPE_2_RED", 1000)
		stats.set_int(MPX() .. "FIREWORK_TYPE_2_BLUE", 1000)
		stats.set_int(MPX() .. "FIREWORK_TYPE_3_WHITE", 1000)
		stats.set_int(MPX() .. "FIREWORK_TYPE_3_RED", 1000)
		stats.set_int(MPX() .. "FIREWORK_TYPE_3_BLUE", 1000)
		stats.set_int(MPX() .. "FIREWORK_TYPE_4_WHITE", 1000)
		stats.set_int(MPX() .. "FIREWORK_TYPE_4_RED", 1000)
		stats.set_int(MPX() .. "FIREWORK_TYPE_4_BLUE", 1000)
		stats.set_int(MPX() .. "FM_ACT_PHN", -1)
		stats.set_int(MPX() .. "FM_ACT_PH2", -1)
		stats.set_int(MPX() .. "FM_ACT_PH3", -1)
		stats.set_int(MPX() .. "FM_ACT_PH4", -1)
		stats.set_int(MPX() .. "FM_ACT_PH5", -1)
		stats.set_int(MPX() .. "FM_VEH_TX1", -1)
		stats.set_int(MPX() .. "FM_ACT_PH6", -1)
		stats.set_int(MPX() .. "FM_ACT_PH7", -1)
		stats.set_int(MPX() .. "FM_ACT_PH8", -1)
		stats.set_int(MPX() .. "FM_ACT_PH9", -1)
		stats.set_int(MPX() .. "LOWRIDER_FLOW_COMPLETE", 3)
		stats.set_int(MPX() .. "LOW_FLOW_CURRENT_CSYONS26G", 9)
		stats.set_int(MPX() .. "LOW_FLOW_CURRENT_CALL", 9)
		stats.set_int(MPX() .. "CR_GANGOP_MORGUE", 10)
		stats.set_int(MPX() .. "CR_GANGOP_DELUXO", 10)
		stats.set_int(MPX() .. "CR_GANGOP_SERVERFARM", 10)
		stats.set_int(MPX() .. "CR_GANGOP_IAABASE_FIN", 10)
		stats.set_int(MPX() .. "CR_GANGOP_STEALOSPREY", 10)
		stats.set_int(MPX() .. "CR_GANGOP_FOUNDRY", 10)
		stats.set_int(MPX() .. "CR_GANGOP_RIOTVAN", 10)
		stats.set_int(MPX() .. "CR_GANGOP_SUBMARINECAR", 10)
		stats.set_int(MPX() .. "CR_GANGOP_SUBMARINE_FIN", 10)
		stats.set_int(MPX() .. "CR_GANGOP_PREDATOR", 10)
		stats.set_int(MPX() .. "CR_GANGOP_BMLAUNCHER", 10)
		stats.set_int(MPX() .. "CR_GANGOP_BCCUSTOM", 10)
		stats.set_int(MPX() .. "CR_GANGOP_STEALTHTANKS", 10)
		stats.set_int(MPX() .. "CR_GANGOP_SPYPLANE", 10)
		stats.set_int(MPX() .. "CR_GANGOP_FINALE", 10)
		stats.set_int(MPX() .. "CR_GANGOP_FINALE_P2", 10)
		stats.set_int(MPX() .. "CR_GANGOP_FINALE_P3", 10)
		stats.set_int(MPX() .. "SNIPERRFL_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "HVYSNIPER_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "KILLS_COP", 4500)
		stats.set_int(MPX() .. "KILLS_SWAT", 500)
		stats.set_int(MPX() .. "CHAR_WANTED_LEVEL_TIME", 5000)
		stats.set_int(MPX() .. "NUMBER_STOLEN_COP_VEHICLE", 200)
		stats.set_int(MPX() .. "NUMBER_STOLEN_CARS", 200)
		stats.set_int(MPX() .. "NUMBER_STOLEN_BIKES", 200)
		stats.set_int(MPX() .. "NUMBER_STOLEN_BOATS", 200)
		stats.set_int(MPX() .. "NUMBER_STOLEN_HELIS", 200)
		stats.set_int(MPX() .. "NUMBER_STOLEN_PLANES", 200)
		stats.set_int(MPX() .. "NUMBER_STOLEN_QUADBIKES", 200)
		stats.set_int(MPX() .. "NUMBER_STOLEN_BICYCLES", 200)
		stats.set_int(MPX() .. "STARS_ATTAINED", 5000)
		stats.set_int(MPX() .. "STARS_EVADED", 4000)
		stats.set_int(MPX() .. "VEHEXPORTED", 500)
		stats.set_int(MPX() .. "TOTAL_NO_SHOPS_HELD_UP", 100)
		stats.set_int(MPX() .. "KILLS_ENEMY_GANG_MEMBERS", 500)
		stats.set_int(MPX() .. "KILLS_FRIENDLY_GANG_MEMBERS", 500)
		stats.set_int(MPX() .. "CR_GANGATTACK_CITY", 500)
		stats.set_int(MPX() .. "CR_GANGATTACK_COUNTRY", 500)
		stats.set_int(MPX() .. "CR_GANGATTACK_LOST", 500)
		stats.set_int(MPX() .. "CR_GANGATTACK_VAGOS", 500)
		stats.set_int(MPX() .. "HORDKILLS", 500)
		stats.set_int(MPX() .. "GHKILLS", 500)
		stats.set_int(MPX() .. "NO_NON_CONTRACT_RACE_WIN", 500)
		stats.set_int(MPX() .. "DB_SHOTTIME", 596)
		stats.set_int(MPX() .. "DB_KILLS", 500)
		stats.set_int(MPX() .. "DB_PLAYER_KILLS", 500)
		stats.set_int(MPX() .. "DB_SHOTS", 500)
		stats.set_int(MPX() .. "DB_HITS", 500)
		stats.set_int(MPX() .. "DB_HITS_PEDS_VEHICLES", 500)
		stats.set_int(MPX() .. "DB_HEADSHOTS", 500)
		stats.set_int(MPX() .. "LFETIME_BIKER_BUY_COMPLET5", 14)
		stats.set_int(MPX() .. "USJS_COMPLETED", 25)
		stats.set_int(MPX() .. "AWD_FM_RACES_FASTEST_LAP", 50)
		stats.set_int(MPX() .. "NUMBER_SLIPSTREAMS_IN_RACE", 1000)
		stats.set_int(MPX() .. "AWD_WIN_CAPTURES", 500)
		stats.set_int(MPX() .. "AWD_DROPOFF_CAP_PACKAGES", 100)
		stats.set_int(MPX() .. "AWD_KILL_CARRIER_CAPTURE", 100)
		stats.set_int(MPX() .. "AWD_FINISH_HEISTS", 50)
		stats.set_int(MPX() .. "AWD_FINISH_HEIST_SETUP_JOB", 50)
		stats.set_int(MPX() .. "AWD_NIGHTVISION_KILLS", 100)
		stats.set_int(MPX() .. "AWD_WIN_LAST_TEAM_STANDINGS", 50)
		stats.set_int(MPX() .. "AWD_ONLY_PLAYER_ALIVE_LTS", 50)
		stats.set_int(MPX() .. "AWD_FMRALLYWONDRIVE", 25)
		stats.set_int(MPX() .. "AWD_FMRALLYWONNAV", 25)
		stats.set_int(MPX() .. "AWD_FMWINAIRRACE", 25)
		stats.set_int(MPX() .. "AWD_FMWINSEARACE", 25)
		stats.set_int(MPX() .. "RACES_WON", 50)
		stats.set_int(MPX() .. "FAVOUTFITBIKETIMECURRENT", 884483972)
		stats.set_int(MPX() .. "FAVOUTFITBIKETIME1ALLTIME", 884483972)
		stats.set_int(MPX() .. "FAVOUTFITBIKETYPECURRENT", 884483972)
		stats.set_int(MPX() .. "FAVOUTFITBIKETYPEALLTIME", 884483972)
		stats.set_int(MPX() .. "LIFETIME_BUY_COMPLETE", 1000)
		stats.set_int(MPX() .. "LIFETIME_BUY_UNDERTAKEN", 1000)
		stats.set_int(MPX() .. "LIFETIME_SELL_COMPLETE", 1000)
		stats.set_int(MPX() .. "LIFETIME_SELL_UNDERTAKEN", 1000)
		stats.set_int(MPX() .. "LIFETIME_CONTRA_EARNINGS", 30000000)
		stats.set_int(MPX() .. "TATTOO_FM_CURRENT_32", 32768)
		stats.set_int(MPX() .. "TATTOO_FM_CURRENT_32", 67108864)
		stats.set_int(MPX() .. "DELUXO_BULLET_HITS", 500)
		stats.set_int(MPX() .. "DELUXO_BULLET_HEADSHOTS", 500)
		stats.set_int(MPX() .. "DELUXO_BULLET_HELDTIME", 5963259)
		stats.set_int(MPX() .. "DELUXO_BULLET_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "DELUXO_ROCKET_KILLS", 500)
		stats.set_int(MPX() .. "DELUXO_ROCKET_DEATHS", 100)
		stats.set_int(MPX() .. "DELUXO_ROCKET_SHOTS", 500)
		stats.set_int(MPX() .. "DELUXO_ROCKET_HITS", 500)
		stats.set_int(MPX() .. "DELUXO_ROCKET_HELDTIME", 5963259)
		stats.set_int(MPX() .. "DELUXO_ROCKET_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "DELUXO_BULLET_KILLS", 500)
		stats.set_int(MPX() .. "DELUXO_BULLET_DEATHS", 100)
		stats.set_int(MPX() .. "DELUXO_BULLET_SHOTS", 500)
		stats.set_int(MPX() .. "COMET4_MG_KILLS", 500)
		stats.set_int(MPX() .. "COMET4_MG_DEATHS", 100)
		stats.set_int(MPX() .. "COMET4_MG_SHOTS", 500)
		stats.set_int(MPX() .. "COMET4_MG_HITS", 500)
		stats.set_int(MPX() .. "COMET4_MG_HEADSHOTS", 500)
		stats.set_int(MPX() .. "COMET4_MG_HELDTIME", 5963259)
		stats.set_int(MPX() .. "COMET4_MG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "CHERNOBOG_MISS_KILLS", 500)
		stats.set_int(MPX() .. "CHERNOBOG_MISS_DEATHS", 100)
		stats.set_int(MPX() .. "CHERNOBOG_MISS_SHOTS", 500)
		stats.set_int(MPX() .. "CHERNOBOG_MISS_HITS", 500)
		stats.set_int(MPX() .. "CHERNOBOG_MISS_HELDTIME", 5963259)
		stats.set_int(MPX() .. "CHERNOBOG_MISS_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "BARRAGE_R_MG_KILLS", 500)
		stats.set_int(MPX() .. "BARRAGE_R_MG_DEATHS", 100)
		stats.set_int(MPX() .. "BARRAGE_R_MG_SHOTS", 500)
		stats.set_int(MPX() .. "BARRAGE_R_MG_HITS", 500)
		stats.set_int(MPX() .. "BARRAGE_R_MG_HEADSHOTS", 500)
		stats.set_int(MPX() .. "BARRAGE_R_MG_HELDTIME", 5963259)
		stats.set_int(MPX() .. "BARRAGE_R_MG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "BARRAGE_R_MINI_KILLS", 500)
		stats.set_int(MPX() .. "BARRAGE_R_MINI_DEATHS", 100)
		stats.set_int(MPX() .. "BARRAGE_R_MINI_SHOTS", 500)
		stats.set_int(MPX() .. "BARRAGE_R_MINI_HITS", 500)
		stats.set_int(MPX() .. "BARRAGE_R_MINI_HEADSHOTS", 500)
		stats.set_int(MPX() .. "BARRAGE_R_MINI_HELDTIME", 5963259)
		stats.set_int(MPX() .. "BARRAGE_R_MINI_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "BARRAGE_R_GL_KILLS", 500)
		stats.set_int(MPX() .. "BARRAGE_R_GL_DEATHS", 100)
		stats.set_int(MPX() .. "BARRAGE_R_GL_SHOTS", 500)
		stats.set_int(MPX() .. "BARRAGE_R_GL_HITS", 500)
		stats.set_int(MPX() .. "BARRAGE_R_GL_HELDTIME", 5963259)
		stats.set_int(MPX() .. "BARRAGE_R_GL_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "BARRAGE_T_MG_KILLS", 500)
		stats.set_int(MPX() .. "BARRAGE_T_MG_DEATHS", 100)
		stats.set_int(MPX() .. "BARRAGE_T_MG_SHOTS", 500)
		stats.set_int(MPX() .. "BARRAGE_T_MG_HITS", 500)
		stats.set_int(MPX() .. "BARRAGE_T_MG_HEADSHOTS", 500)
		stats.set_int(MPX() .. "BARRAGE_T_MG_HELDTIME", 5963259)
		stats.set_int(MPX() .. "BARRAGE_T_MG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "BARRAGE_T_MINI_KILLS", 500)
		stats.set_int(MPX() .. "BARRAGE_T_MINI_DEATHS", 100)
		stats.set_int(MPX() .. "BARRAGE_T_MINI_SHOTS", 500)
		stats.set_int(MPX() .. "BARRAGE_T_MINI_HITS", 500)
		stats.set_int(MPX() .. "BARRAGE_T_MINI_HEADSHOTS", 500)
		stats.set_int(MPX() .. "BARRAGE_T_MINI_HELDTIME", 5963259)
		stats.set_int(MPX() .. "BARRAGE_T_MINI_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "AVENGER_CANNON_KILLS", 500)
		stats.set_int(MPX() .. "AVENGER_CANNON_DEATHS", 100)
		stats.set_int(MPX() .. "AVENGER_CANNON_SHOTS", 500)
		stats.set_int(MPX() .. "AVENGER_CANNON_HITS", 500)
		stats.set_int(MPX() .. "AVENGER_CANNON_HELDTIME", 5963259)
		stats.set_int(MPX() .. "AVENGER_CANNON_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "AKULA_TURR_KILLS", 500)
		stats.set_int(MPX() .. "AKULA_TURR_DEATHS", 100)
		stats.set_int(MPX() .. "AKULA_TURR_SHOTS", 500)
		stats.set_int(MPX() .. "AKULA_TURR_HITS", 500)
		stats.set_int(MPX() .. "AKULA_TURR_HEADSHOTS", 500)
		stats.set_int(MPX() .. "AKULA_TURR_HELDTIME", 5963259)
		stats.set_int(MPX() .. "AKULA_TURR_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "AKULA_DTURR_KILLS", 500)
		stats.set_int(MPX() .. "AKULA_DTURR_DEATHS", 100)
		stats.set_int(MPX() .. "AKULA_DTURR_SHOTS", 500)
		stats.set_int(MPX() .. "AKULA_DTURR_HITS", 500)
		stats.set_int(MPX() .. "AKULA_DTURR_HEADSHOTS", 500)
		stats.set_int(MPX() .. "AKULA_DTURR_HELDTIME", 5963259)
		stats.set_int(MPX() .. "AKULA_DTURR_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "AKULA_MINI_KILLS", 500)
		stats.set_int(MPX() .. "AKULA_MINI_DEATHS", 100)
		stats.set_int(MPX() .. "AKULA_MINI_SHOTS", 500)
		stats.set_int(MPX() .. "AKULA_MINI_HITS", 500)
		stats.set_int(MPX() .. "AKULA_MINI_HEADSHOTS", 500)
		stats.set_int(MPX() .. "AKULA_MINI_HELDTIME", 5963259)
		stats.set_int(MPX() .. "AKULA_MINI_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "AKULA_BARR_KILLS", 500)
		stats.set_int(MPX() .. "AKULA_BARR_DEATHS", 100)
		stats.set_int(MPX() .. "AKULA_BARR_SHOTS", 500)
		stats.set_int(MPX() .. "AKULA_BARR_HITS", 500)
		stats.set_int(MPX() .. "AKULA_BARR_HELDTIME", 5963259)
		stats.set_int(MPX() .. "AKULA_BARR_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "AKULA_ROCKET_KILLS", 500)
		stats.set_int(MPX() .. "AKULA_ROCKET_DEATHS", 100)
		stats.set_int(MPX() .. "AKULA_ROCKET_SHOTS", 500)
		stats.set_int(MPX() .. "AKULA_ROCKET_HITS", 500)
		stats.set_int(MPX() .. "AKULA_ROCKET_HELDTIME", 5963259)
		stats.set_int(MPX() .. "AKULA_ROCKET_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "ARENA_MG_KILLS", 500)
		stats.set_int(MPX() .. "ARENA_MG_DEATHS", 100)
		stats.set_int(MPX() .. "ARENA_MG_SHOTS", 500)
		stats.set_int(MPX() .. "ARENA_MG_HITS", 500)
		stats.set_int(MPX() .. "ARENA_MG_HEADSHOTS", 500)
		stats.set_int(MPX() .. "ARENA_MG_HELDTIME", 5963259)
		stats.set_int(MPX() .. "ARENA_MG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "ARENA_HM_KILLS", 500)
		stats.set_int(MPX() .. "ARENA_HM_DEATHS", 100)
		stats.set_int(MPX() .. "ARENA_HM_SHOTS", 500)
		stats.set_int(MPX() .. "ARENA_HM_HITS", 500)
		stats.set_int(MPX() .. "ARENA_HM_HELDTIME", 5963259)
		stats.set_int(MPX() .. "RCMINE_KIN_KILLS", 500)
		stats.set_int(MPX() .. "RCMINE_KIN_DEATHS", 100)
		stats.set_int(MPX() .. "RCMINE_KIN_SHOTS", 500)
		stats.set_int(MPX() .. "RCMINE_KIN_HITS", 500)
		stats.set_int(MPX() .. "RCMINE_KIN_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "RCMINE_EMP_KILLS", 500)
		stats.set_int(MPX() .. "RCMINE_EMP_DEATHS", 100)
		stats.set_int(MPX() .. "RCMINE_EMP_SHOTS", 500)
		stats.set_int(MPX() .. "RCMINE_EMP_HITS", 500)
		stats.set_int(MPX() .. "RCMINE_EMP_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "RCMINE_SPI_KILLS", 500)
		stats.set_int(MPX() .. "RCMINE_SPI_DEATHS", 100)
		stats.set_int(MPX() .. "RCMINE_SPI_SHOTS", 500)
		stats.set_int(MPX() .. "RCMINE_SPI_HITS", 500)
		stats.set_int(MPX() .. "RCMINE_SPI_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "RCMINE_SLI_KILLS", 500)
		stats.set_int(MPX() .. "RCMINE_SLI_DEATHS", 100)
		stats.set_int(MPX() .. "RCMINE_SLI_SHOTS", 500)
		stats.set_int(MPX() .. "RCMINE_SLI_HITS", 500)
		stats.set_int(MPX() .. "RCMINE_SLI_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "RCMINE_TAR_KILLS", 500)
		stats.set_int(MPX() .. "RCMINE_TAR_DEATHS", 100)
		stats.set_int(MPX() .. "RCMINE_TAR_SHOTS", 500)
		stats.set_int(MPX() .. "RCMINE_TAR_HITS", 500)
		stats.set_int(MPX() .. "RCMINE_TAR_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "VEHMINE_KILLS", 500)
		stats.set_int(MPX() .. "VEHMINE_DEATHS", 100)
		stats.set_int(MPX() .. "VEHMINE_SHOTS", 500)
		stats.set_int(MPX() .. "VEHMINE_HITS", 500)
		stats.set_int(MPX() .. "VEHMINE_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "VEHMINE_KIN_KILLS", 500)
		stats.set_int(MPX() .. "VEHMINE_KIN_DEATHS", 100)
		stats.set_int(MPX() .. "VEHMINE_KIN_SHOTS", 500)
		stats.set_int(MPX() .. "VEHMINE_KIN_HITS", 500)
		stats.set_int(MPX() .. "VEHMINE_KIN_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "VEHMINE_EMP_KILLS", 500)
		stats.set_int(MPX() .. "VEHMINE_EMP_DEATHS", 100)
		stats.set_int(MPX() .. "VEHMINE_EMP_SHOTS", 500)
		stats.set_int(MPX() .. "VEHMINE_EMP_HITS", 500)
		stats.set_int(MPX() .. "VEHMINE_EMP_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "VEHMINE_SPI_KILLS", 500)
		stats.set_int(MPX() .. "VEHMINE_SPI_DEATHS", 100)
		stats.set_int(MPX() .. "VEHMINE_SPI_SHOTS", 500)
		stats.set_int(MPX() .. "VEHMINE_SPI_HITS", 500)
		stats.set_int(MPX() .. "VEHMINE_SPI_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "VEHMINE_SLI_KILLS", 500)
		stats.set_int(MPX() .. "VEHMINE_SLI_DEATHS", 100)
		stats.set_int(MPX() .. "VEHMINE_SLI_SHOTS", 500)
		stats.set_int(MPX() .. "VEHMINE_SLI_HITS", 500)
		stats.set_int(MPX() .. "VEHMINE_SLI_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "VEHMINE_TAR_KILLS", 500)
		stats.set_int(MPX() .. "VEHMINE_TAR_DEATHS", 100)
		stats.set_int(MPX() .. "VEHMINE_TAR_SHOTS", 500)
		stats.set_int(MPX() .. "VEHMINE_TAR_HITS", 500)
		stats.set_int(MPX() .. "VEHMINE_TAR_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "ZR3803_MG50_KILLS", 500)
		stats.set_int(MPX() .. "ZR3803_MG50_DEATHS", 100)
		stats.set_int(MPX() .. "ZR3803_MG50_SHOTS", 500)
		stats.set_int(MPX() .. "ZR3803_MG50_HITS", 500)
		stats.set_int(MPX() .. "ZR3803_MG50_HEADSHOTS", 500)
		stats.set_int(MPX() .. "ZR3803_MG50_HELDTIME", 5963259)
		stats.set_int(MPX() .. "ZR3803_MG50_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "ZR3802_MG50_KILLS", 500)
		stats.set_int(MPX() .. "ZR3802_MG50_DEATHS", 100)
		stats.set_int(MPX() .. "ZR3802_MG50_SHOTS", 500)
		stats.set_int(MPX() .. "ZR3802_MG50_HITS", 500)
		stats.set_int(MPX() .. "ZR3802_MG50_HEADSHOTS", 500)
		stats.set_int(MPX() .. "ZR3802_MG50_HELDTIME", 5963259)
		stats.set_int(MPX() .. "ZR3802_MG50_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "ZR3802_LAS_KILLS", 500)
		stats.set_int(MPX() .. "ZR3802_LAS_DEATHS", 100)
		stats.set_int(MPX() .. "ZR3802_LAS_SHOTS", 500)
		stats.set_int(MPX() .. "ZR3802_LAS_HITS", 500)
		stats.set_int(MPX() .. "ZR3802_LAS_HEADSHOTS", 500)
		stats.set_int(MPX() .. "ZR3802_LAS_HELDTIME", 5963259)
		stats.set_int(MPX() .. "ZR3802_LAS_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "ZR380_MG50_KILLS", 500)
		stats.set_int(MPX() .. "ZR380_MG50_DEATHS", 100)
		stats.set_int(MPX() .. "ZR380_MG50_SHOTS", 500)
		stats.set_int(MPX() .. "ZR380_MG50_HITS", 500)
		stats.set_int(MPX() .. "ZR380_MG50_HEADSHOTS", 500)
		stats.set_int(MPX() .. "ZR380_MG50_HELDTIME", 5963259)
		stats.set_int(MPX() .. "ZR380_MG50_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "SLAMVAN4_MG50_KILLS", 500)
		stats.set_int(MPX() .. "SLAMVAN4_MG50_DEATHS", 100)
		stats.set_int(MPX() .. "SLAMVAN4_MG50_SHOTS", 500)
		stats.set_int(MPX() .. "SLAMVAN4_MG50_HITS", 500)
		stats.set_int(MPX() .. "SLAMVAN4_MG50_HEADSHOTS", 500)
		stats.set_int(MPX() .. "SLAMVAN4_MG50_HELDTIME", 5963259)
		stats.set_int(MPX() .. "SLAMVAN4_MG50_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "SLAMVAN5_MG50_KILLS", 500)
		stats.set_int(MPX() .. "SLAMVAN5_MG50_DEATHS", 100)
		stats.set_int(MPX() .. "SLAMVAN5_MG50_SHOTS", 500)
		stats.set_int(MPX() .. "SLAMVAN5_MG50_HITS", 500)
		stats.set_int(MPX() .. "SLAMVAN5_MG50_HEADSHOTS", 500)
		stats.set_int(MPX() .. "SLAMVAN5_MG50_HELDTIME", 5963259)
		stats.set_int(MPX() .. "SLAMVAN5_MG50_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "SLAMVAN5_LAS_KILLS", 500)
		stats.set_int(MPX() .. "SLAMVAN5_LAS_DEATHS", 100)
		stats.set_int(MPX() .. "SLAMVAN5_LAS_SHOTS", 500)
		stats.set_int(MPX() .. "SLAMVAN5_LAS_HITS", 500)
		stats.set_int(MPX() .. "SLAMVAN5_LAS_HEADSHOTS", 500)
		stats.set_int(MPX() .. "SLAMVAN5_LAS_HELDTIME", 5963259)
		stats.set_int(MPX() .. "SLAMVAN5_LAS_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "SLAMVAN6_MG50_KILLS", 500)
		stats.set_int(MPX() .. "SLAMVAN6_MG50_DEATHS", 100)
		stats.set_int(MPX() .. "SLAMVAN6_MG50_SHOTS", 500)
		stats.set_int(MPX() .. "SLAMVAN6_MG50_HITS", 500)
		stats.set_int(MPX() .. "SLAMVAN6_MG50_HEADSHOTS", 500)
		stats.set_int(MPX() .. "SLAMVAN6_MG50_HELDTIME", 5963259)
		stats.set_int(MPX() .. "SLAMVAN6_MG50_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "SCARAB_MG50_KILLS", 500)
		stats.set_int(MPX() .. "SCARAB_MG50_DEATHS", 100)
		stats.set_int(MPX() .. "SCARAB_MG50_SHOTS", 500)
		stats.set_int(MPX() .. "SCARAB_MG50_HITS", 500)
		stats.set_int(MPX() .. "SCARAB_MG50_HEADSHOTS", 500)
		stats.set_int(MPX() .. "SCARAB_MG50_HELDTIME", 5963259)
		stats.set_int(MPX() .. "SCARAB_MG50_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "SCARAB2_MG50_KILLS", 500)
		stats.set_int(MPX() .. "SCARAB2_MG50_DEATHS", 100)
		stats.set_int(MPX() .. "SCARAB2_MG50_SHOTS", 500)
		stats.set_int(MPX() .. "SCARAB2_MG50_HITS", 500)
		stats.set_int(MPX() .. "SCARAB2_MG50_HEADSHOTS", 500)
		stats.set_int(MPX() .. "SCARAB2_MG50_HELDTIME", 5963259)
		stats.set_int(MPX() .. "SCARAB2_MG50_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "SCARAB2_LAS_KILLS", 500)
		stats.set_int(MPX() .. "SCARAB2_LAS_DEATHS", 100)
		stats.set_int(MPX() .. "SCARAB2_LAS_SHOTS", 500)
		stats.set_int(MPX() .. "SCARAB2_LAS_HITS", 500)
		stats.set_int(MPX() .. "SCARAB2_LAS_HEADSHOTS", 500)
		stats.set_int(MPX() .. "SCARAB2_LAS_HELDTIME", 5963259)
		stats.set_int(MPX() .. "SCARAB2_LAS_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "SCARAB3_MG50_KILLS", 500)
		stats.set_int(MPX() .. "SCARAB3_MG50_DEATHS", 100)
		stats.set_int(MPX() .. "SCARAB3_MG50_SHOTS", 500)
		stats.set_int(MPX() .. "SCARAB3_MG50_HITS", 500)
		stats.set_int(MPX() .. "SCARAB3_MG50_HEADSHOTS", 500)
		stats.set_int(MPX() .. "SCARAB3_MG50_HELDTIME", 5963259)
		stats.set_int(MPX() .. "SCARAB3_MG50_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "MONSTER3_KIN_KILLS", 500)
		stats.set_int(MPX() .. "MONSTER3_KIN_DEATHS", 100)
		stats.set_int(MPX() .. "MONSTER3_KIN_SHOTS", 500)
		stats.set_int(MPX() .. "MONSTER3_KIN_HITS", 500)
		stats.set_int(MPX() .. "MONSTER3_KIN_HELDTIME", 5963259)
		stats.set_int(MPX() .. "MONSTER3_KIN_ENEMY_KILL", 500)
		stats.set_int(MPX() .. "MONSTER4_KIN_KILLS", 500)
		stats.set_int(MPX() .. "MONSTER4_KIN_DEATHS", 100)
		stats.set_int(MPX() .. "MONSTER4_KIN_SHOTS", 500)
		stats.set_int(MPX() .. "MONSTER4_KIN_HITS", 500)
		stats.set_int(MPX() .. "MONSTER4_KIN_HELDTIME", 5963259)
		stats.set_int(MPX() .. "MONSTER4_KIN_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "MONSTER5_KIN_KILLS", 500)
		stats.set_int(MPX() .. "MONSTER5_KIN_DEATHS", 100)
		stats.set_int(MPX() .. "MONSTER5_KIN_SHOTS", 500)
		stats.set_int(MPX() .. "MONSTER5_KIN_HITS", 500)
		stats.set_int(MPX() .. "MONSTER5_KIN_HELDTIME", 5963259)
		stats.set_int(MPX() .. "MONSTER5_KIN_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "ISSI4_MG50_KILLS", 500)
		stats.set_int(MPX() .. "ISSI4_MG50_DEATHS", 100)
		stats.set_int(MPX() .. "ISSI4_MG50_SHOTS", 500)
		stats.set_int(MPX() .. "ISSI4_MG50_HITS", 500)
		stats.set_int(MPX() .. "ISSI4_MG50_HEADSHOTS", 500)
		stats.set_int(MPX() .. "ISSI4_MG50_HELDTIME", 5963259)
		stats.set_int(MPX() .. "ISSI4_MG50_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "ISSI4_KIN_KILLS", 500)
		stats.set_int(MPX() .. "ISSI4_KIN_DEATHS", 100)
		stats.set_int(MPX() .. "ISSI4_KIN_SHOTS", 500)
		stats.set_int(MPX() .. "ISSI4_KIN_HITS", 500)
		stats.set_int(MPX() .. "ISSI4_KIN_HELDTIME", 5963259)
		stats.set_int(MPX() .. "ISSI4_KIN_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "ISSI5_MG50_KILLS", 500)
		stats.set_int(MPX() .. "ISSI5_MG50_DEATHS", 100)
		stats.set_int(MPX() .. "ISSI5_MG50_SHOTS", 500)
		stats.set_int(MPX() .. "ISSI5_MG50_HITS", 500)
		stats.set_int(MPX() .. "ISSI5_MG50_HEADSHOTS", 500)
		stats.set_int(MPX() .. "ISSI5_MG50_HELDTIME", 5963259)
		stats.set_int(MPX() .. "ISSI5_MG50_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "ISSI5_LAS_KILLS", 500)
		stats.set_int(MPX() .. "ISSI5_LAS_DEATHS", 100)
		stats.set_int(MPX() .. "ISSI5_LAS_SHOTS", 500)
		stats.set_int(MPX() .. "ISSI5_LAS_HITS", 500)
		stats.set_int(MPX() .. "ISSI5_LAS_HEADSHOTS", 500)
		stats.set_int(MPX() .. "ISSI5_LAS_HELDTIME", 5963259)
		stats.set_int(MPX() .. "ISSI5_LAS_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "ISSI5_KIN_KILLS", 500)
		stats.set_int(MPX() .. "ISSI5_KIN_DEATHS", 100)
		stats.set_int(MPX() .. "ISSI5_KIN_SHOTS", 500)
		stats.set_int(MPX() .. "ISSI5_KIN_HITS", 500)
		stats.set_int(MPX() .. "ISSI5_KIN_HELDTIME", 5963259)
		stats.set_int(MPX() .. "ISSI5_KIN_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "ISSI6_MG50_KILLS", 500)
		stats.set_int(MPX() .. "ISSI6_MG50_DEATHS", 100)
		stats.set_int(MPX() .. "ISSI6_MG50_SHOTS", 500)
		stats.set_int(MPX() .. "ISSI6_MG50_HITS", 500)
		stats.set_int(MPX() .. "ISSI6_MG50_HEADSHOTS", 500)
		stats.set_int(MPX() .. "ISSI6_MG50_HELDTIME", 5963259)
		stats.set_int(MPX() .. "ISSI6_MG50_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "ISSI6_KIN_KILLS", 500)
		stats.set_int(MPX() .. "ISSI6_KIN_DEATHS", 100)
		stats.set_int(MPX() .. "ISSI6_KIN_SHOTS", 500)
		stats.set_int(MPX() .. "ISSI6_KIN_HITS", 500)
		stats.set_int(MPX() .. "ISSI6_KIN_HELDTIME", 5963259)
		stats.set_int(MPX() .. "ISSI6_KIN_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "ARN_SPECTATOR_KILLS", 500)
		stats.set_int(MPX() .. "ARN_LIFETIME_KILLS", 500)
		stats.set_int(MPX() .. "ARN_LIFETIME_DEATHS", 100)
		stats.set_int(MPX() .. "TRSMALL2_QUAD_KILLS", 500)
		stats.set_int(MPX() .. "TRSMALL2_QUAD_DEATHS", 100)
		stats.set_int(MPX() .. "TRSMALL2_QUAD_SHOTS", 500)
		stats.set_int(MPX() .. "TRSMALL2_QUAD_HITS", 500)
		stats.set_int(MPX() .. "TRSMALL2_QUAD_HEADSHOTS", 500)
		stats.set_int(MPX() .. "TRSMALL2_QUAD_HELDTIME", 5963259)
		stats.set_int(MPX() .. "TRSMALL2_QUAD_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "TRSMALL2_DUAL_KILLS", 500)
		stats.set_int(MPX() .. "TRSMALL2_DUAL_DEATHS", 100)
		stats.set_int(MPX() .. "TRSMALL2_DUAL_SHOTS", 500)
		stats.set_int(MPX() .. "TRSMALL2_DUAL_HITS", 500)
		stats.set_int(MPX() .. "TRSMALL2_DUAL_HELDTIME", 5963259)
		stats.set_int(MPX() .. "TRSMALL2_DUAL_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "TRSMALL2_MISS_KILLS", 500)
		stats.set_int(MPX() .. "TRSMALL2_MISS_DEATHS", 100)
		stats.set_int(MPX() .. "TRSMALL2_MISS_SHOTS", 500)
		stats.set_int(MPX() .. "TRSMALL2_MISS_HITS", 500)
		stats.set_int(MPX() .. "TRSMALL2_MISS_HELDTIME", 5963259)
		stats.set_int(MPX() .. "TRSMALL2_MISS_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "TRLARGE_CANNON_KILLS", 500)
		stats.set_int(MPX() .. "TRLARGE_CANNON_DEATHS", 100)
		stats.set_int(MPX() .. "TRLARGE_CANNON_SHOTS", 500)
		stats.set_int(MPX() .. "TRLARGE_CANNON_HITS", 500)
		stats.set_int(MPX() .. "TRLARGE_CANNON_HELDTIME", 5963259)
		stats.set_int(MPX() .. "TRLARGE_CANNON_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "POUNDER2_MINI_KILLS", 500)
		stats.set_int(MPX() .. "POUNDER2_MINI_DEATHS", 100)
		stats.set_int(MPX() .. "POUNDER2_MINI_SHOTS", 500)
		stats.set_int(MPX() .. "POUNDER2_MINI_HITS", 500)
		stats.set_int(MPX() .. "POUNDER2_MINI_HEADSHOTS", 500)
		stats.set_int(MPX() .. "POUNDER2_MINI_HELDTIME", 5963259)
		stats.set_int(MPX() .. "POUNDER2_MINI_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "POUNDER2_MISS_KILLS", 500)
		stats.set_int(MPX() .. "POUNDER2_MISS_DEATHS", 100)
		stats.set_int(MPX() .. "POUNDER2_MISS_SHOTS", 500)
		stats.set_int(MPX() .. "POUNDER2_MISS_HITS", 500)
		stats.set_int(MPX() .. "POUNDER2_MISS_HEADSHOTS", 500)
		stats.set_int(MPX() .. "POUNDER2_MISS_HELDTIME", 5963259)
		stats.set_int(MPX() .. "POUNDER2_MISS_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "POUNDER2_BARR_KILLS", 500)
		stats.set_int(MPX() .. "POUNDER2_BARR_DEATHS", 100)
		stats.set_int(MPX() .. "POUNDER2_BARR_SHOTS", 500)
		stats.set_int(MPX() .. "POUNDER2_BARR_HITS", 500)
		stats.set_int(MPX() .. "POUNDER2_BARR_HELDTIME", 5963259)
		stats.set_int(MPX() .. "POUNDER2_BARR_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "POUNDER2_GL_KILLS", 500)
		stats.set_int(MPX() .. "POUNDER2_GL_DEATHS", 100)
		stats.set_int(MPX() .. "POUNDER2_GL_SHOTS", 500)
		stats.set_int(MPX() .. "POUNDER2_GL_HITS", 500)
		stats.set_int(MPX() .. "POUNDER2_GL_HELDTIME", 5963259)
		stats.set_int(MPX() .. "POUNDER2_GL_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "SCRAMJET_MG_KILLS", 500)
		stats.set_int(MPX() .. "SCRAMJET_MG_DEATHS", 100)
		stats.set_int(MPX() .. "SCRAMJET_MG_SHOTS", 500)
		stats.set_int(MPX() .. "SCRAMJET_MG_HITS", 500)
		stats.set_int(MPX() .. "SCRAMJET_MG_HEADSHOTS", 500)
		stats.set_int(MPX() .. "SCRAMJET_MG_HELDTIME", 5963259)
		stats.set_int(MPX() .. "SCRAMJET_MG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "SCRAMJET_MISS_KILLS", 500)
		stats.set_int(MPX() .. "SCRAMJET_MISS_DEATHS", 100)
		stats.set_int(MPX() .. "SCRAMJET_MISS_SHOTS", 500)
		stats.set_int(MPX() .. "SCRAMJET_MISS_HITS", 500)
		stats.set_int(MPX() .. "SCRAMJET_MISS_HELDTIME", 5963259)
		stats.set_int(MPX() .. "SCRAMJET_MISS_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "SPEEDO4_MG_KILLS", 500)
		stats.set_int(MPX() .. "SPEEDO4_MG_DEATHS", 100)
		stats.set_int(MPX() .. "SPEEDO4_MG_SHOTS", 500)
		stats.set_int(MPX() .. "SPEEDO4_MG_HITS", 500)
		stats.set_int(MPX() .. "SPEEDO4_MG_HEADSHOTS", 500)
		stats.set_int(MPX() .. "SPEEDO4_MG_HELDTIME", 5963259)
		stats.set_int(MPX() .. "SPEEDO4_MG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "SPEEDO4_TURR_KILLS", 500)
		stats.set_int(MPX() .. "SPEEDO4_TURR_DEATHS", 100)
		stats.set_int(MPX() .. "SPEEDO4_TURR_SHOTS", 500)
		stats.set_int(MPX() .. "SPEEDO4_TURR_HITS", 500)
		stats.set_int(MPX() .. "SPEEDO4_TURR_HEADSHOTS", 500)
		stats.set_int(MPX() .. "SPEEDO4_TURR_HELDTIME", 5963259)
		stats.set_int(MPX() .. "SPEEDO4_TURR_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "SPEEDO4_MINI_KILLS", 500)
		stats.set_int(MPX() .. "SPEEDO4_MINI_DEATHS", 100)
		stats.set_int(MPX() .. "SPEEDO4_MINI_SHOTS", 500)
		stats.set_int(MPX() .. "SPEEDO4_MINI_HITS", 500)
		stats.set_int(MPX() .. "SPEEDO4_MINI_HEADSHOTS", 500)
		stats.set_int(MPX() .. "SPEEDO4_MINI_HELDTIME", 5963259)
		stats.set_int(MPX() .. "SPEEDO4_MINI_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "STRIKEFORCE_BAR_KILLS", 500)
		stats.set_int(MPX() .. "STRIKEFORCE_BAR_DEATHS", 100)
		stats.set_int(MPX() .. "STRIKEFORCE_BAR_SHOTS", 500)
		stats.set_int(MPX() .. "STRIKEFORCE_BAR_HITS", 500)
		stats.set_int(MPX() .. "STRIKEFORCE_BAR_HELDTIME", 5963259)
		stats.set_int(MPX() .. "STRIKEFORCE_BAR_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "STRIKEFORCE_CAN_KILLS", 500)
		stats.set_int(MPX() .. "STRIKEFORCE_CAN_DEATHS", 100)
		stats.set_int(MPX() .. "STRIKEFORCE_CAN_SHOTS", 500)
		stats.set_int(MPX() .. "STRIKEFORCE_CAN_HITS", 500)
		stats.set_int(MPX() .. "STRIKEFORCE_CAN_HELDTIME", 5963259)
		stats.set_int(MPX() .. "STRIKEFORCE_CAN_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "STRIKEFORCE_MIS_KILLS", 500)
		stats.set_int(MPX() .. "STRIKEFORCE_MIS_DEATHS", 100)
		stats.set_int(MPX() .. "STRIKEFORCE_MIS_SHOTS", 500)
		stats.set_int(MPX() .. "STRIKEFORCE_MIS_HITS", 500)
		stats.set_int(MPX() .. "STRIKEFORCE_MIS_HELDTIME", 5963259)
		stats.set_int(MPX() .. "STRIKEFORCE_MIS_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "TERBYTE_MISS_KILLS", 500)
		stats.set_int(MPX() .. "TERBYTE_MISS_DEATHS", 100)
		stats.set_int(MPX() .. "TERBYTE_MISS_SHOTS", 500)
		stats.set_int(MPX() .. "TERBYTE_MISS_HITS", 500)
		stats.set_int(MPX() .. "TERBYTE_MISS_HELDTIME", 5963259)
		stats.set_int(MPX() .. "TERBYTE_MISS_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "TERBYTE_HMISS_KILLS", 500)
		stats.set_int(MPX() .. "TERBYTE_HMISS_DEATHS", 100)
		stats.set_int(MPX() .. "TERBYTE_HMISS_SHOTS", 500)
		stats.set_int(MPX() .. "TERBYTE_HMISS_HITS", 500)
		stats.set_int(MPX() .. "TERBYTE_HMISS_HELDTIME", 5963259)
		stats.set_int(MPX() .. "TERBYTE_HMISS_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "CARACARA_MINI_KILLS", 500)
		stats.set_int(MPX() .. "CARACARA_MINI_DEATHS", 100)
		stats.set_int(MPX() .. "CARACARA_MINI_SHOTS", 500)
		stats.set_int(MPX() .. "CARACARA_MINI_HITS", 500)
		stats.set_int(MPX() .. "CARACARA_MINI_HEADSHOTS", 500)
		stats.set_int(MPX() .. "CARACARA_MINI_HELDTIME", 5963259)
		stats.set_int(MPX() .. "CARACARA_MINI_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "CARACARA_TURR_KILLS", 500)
		stats.set_int(MPX() .. "CARACARA_TURR_DEATHS", 100)
		stats.set_int(MPX() .. "CARACARA_TURR_SHOTS", 500)
		stats.set_int(MPX() .. "CARACARA_TURR_HITS", 500)
		stats.set_int(MPX() .. "CARACARA_TURR_HEADSHOTS", 500)
		stats.set_int(MPX() .. "CARACARA_TURR_HELDTIME", 5963259)
		stats.set_int(MPX() .. "CARACARA_TURR_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "SPARROW_MINI_KILLS", 500)
		stats.set_int(MPX() .. "SPARROW_MINI_DEATHS", 100)
		stats.set_int(MPX() .. "SPARROW_MINI_SHOTS", 500)
		stats.set_int(MPX() .. "SPARROW_MINI_HITS", 500)
		stats.set_int(MPX() .. "SPARROW_MINI_HEADSHOTS", 500)
		stats.set_int(MPX() .. "SPARROW_MINI_HELDTIME", 5963259)
		stats.set_int(MPX() .. "SPARROW_MINI_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "SPARROW_ROCKET_KILLS", 500)
		stats.set_int(MPX() .. "SPARROW_ROCKET_DEATHS", 100)
		stats.set_int(MPX() .. "SPARROW_ROCKET_SHOTS", 500)
		stats.set_int(MPX() .. "SPARROW_ROCKET_HITS", 500)
		stats.set_int(MPX() .. "SPARROW_ROCKET_HELDTIME", 5963259)
		stats.set_int(MPX() .. "SPARROW_ROCKET_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "APC_CANN_KILLS", 500)
		stats.set_int(MPX() .. "APC_CANN_DEATHS", 100)
		stats.set_int(MPX() .. "APC_CANN_SHOTS", 500)
		stats.set_int(MPX() .. "APC_CANN_HITS", 500)
		stats.set_int(MPX() .. "APC_CANN_HELDTIME", 5963259)
		stats.set_int(MPX() .. "APC_CANN_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "APC_MISS_KILLS", 500)
		stats.set_int(MPX() .. "APC_MISS_DEATHS", 100)
		stats.set_int(MPX() .. "APC_MISS_SHOTS", 500)
		stats.set_int(MPX() .. "APC_MISS_HITS", 500)
		stats.set_int(MPX() .. "APC_MISS_HELDTIME", 5963259)
		stats.set_int(MPX() .. "APC_MISS_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "APC_MG_KILLS", 500)
		stats.set_int(MPX() .. "APC_MG_DEATHS", 100)
		stats.set_int(MPX() .. "APC_MG_SHOTS", 500)
		stats.set_int(MPX() .. "APC_MG_HITS", 500)
		stats.set_int(MPX() .. "APC_MG_HEADSHOTS", 500)
		stats.set_int(MPX() .. "APC_MG_HELDTIME", 5963259)
		stats.set_int(MPX() .. "APC_MG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "ARDENT_MG_KILLS", 500)
		stats.set_int(MPX() .. "ARDENT_MG_DEATHS", 100)
		stats.set_int(MPX() .. "ARDENT_MG_SHOTS", 500)
		stats.set_int(MPX() .. "ARDENT_MG_HITS", 500)
		stats.set_int(MPX() .. "ARDENT_MG_HEADSHOTS", 500)
		stats.set_int(MPX() .. "ARDENT_MG_HELDTIME", 5963259)
		stats.set_int(MPX() .. "ARDENT_MG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "DUNE3_MG_KILLS", 500)
		stats.set_int(MPX() .. "DUNE3_MG_DEATHS", 100)
		stats.set_int(MPX() .. "DUNE3_MG_SHOTS", 500)
		stats.set_int(MPX() .. "DUNE3_MG_HITS", 500)
		stats.set_int(MPX() .. "DUNE3_MG_HEADSHOTS", 500)
		stats.set_int(MPX() .. "DUNE3_MG_HELDTIME", 5963259)
		stats.set_int(MPX() .. "DUNE3_MG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "DUNE3_GL_KILLS", 500)
		stats.set_int(MPX() .. "DUNE3_GL_DEATHS", 100)
		stats.set_int(MPX() .. "DUNE3_GL_SHOTS", 500)
		stats.set_int(MPX() .. "DUNE3_GL_HITS", 500)
		stats.set_int(MPX() .. "DUNE3_GL_HELDTIME", 5963259)
		stats.set_int(MPX() .. "DUNE3_GL_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "DUNE3_MINI_KILLS", 500)
		stats.set_int(MPX() .. "DUNE3_MINI_DEATHS", 100)
		stats.set_int(MPX() .. "DUNE3_MINI_SHOTS", 500)
		stats.set_int(MPX() .. "DUNE3_MINI_HITS", 500)
		stats.set_int(MPX() .. "DUNE3_MINI_HEADSHOTS", 500)
		stats.set_int(MPX() .. "DUNE3_MINI_HELDTIME", 5963259)
		stats.set_int(MPX() .. "DUNE3_MINI_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "HALFTRACK_DUAL_KILLS", 500)
		stats.set_int(MPX() .. "HALFTRACK_DUAL_DEATHS", 100)
		stats.set_int(MPX() .. "HALFTRACK_DUAL_SHOTS", 500)
		stats.set_int(MPX() .. "HALFTRACK_DUAL_HITS", 500)
		stats.set_int(MPX() .. "HALFTRACK_DUAL_HEADSHOTS", 500)
		stats.set_int(MPX() .. "HALFTRACK_DUAL_HELDTIME", 5963259)
		stats.set_int(MPX() .. "HALFTRACK_DUAL_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "HALFTRACK_QUAD_KILLS", 500)
		stats.set_int(MPX() .. "HALFTRACK_QUAD_DEATHS", 100)
		stats.set_int(MPX() .. "HALFTRACK_QUAD_SHOTS", 500)
		stats.set_int(MPX() .. "HALFTRACK_QUAD_HITS", 500)
		stats.set_int(MPX() .. "HALFTRACK_QUAD_HEADSHOTS", 500)
		stats.set_int(MPX() .. "HALFTRACK_QUAD_HELDTIME", 5963259)
		stats.set_int(MPX() .. "HALFTRACK_QUAD_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "INSURGENT3_MINI_KILLS", 500)
		stats.set_int(MPX() .. "INSURGENT3_MINI_DEATHS", 100)
		stats.set_int(MPX() .. "INSURGENT3_MINI_SHOTS", 500)
		stats.set_int(MPX() .. "INSURGENT3_MINI_HITS", 500)
		stats.set_int(MPX() .. "INSURGENT3_MINI_HEADSHOTS", 500)
		stats.set_int(MPX() .. "INSURGENT3_MINI_HELDTIME", 5963259)
		stats.set_int(MPX() .. "INSURGENT3_MINI_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "INSURGENT3_TURR_KILLS", 500)
		stats.set_int(MPX() .. "INSURGENT3_TURR_DEATHS", 100)
		stats.set_int(MPX() .. "INSURGENT3_TURR_SHOTS", 500)
		stats.set_int(MPX() .. "INSURGENT3_TURR_HITS", 500)
		stats.set_int(MPX() .. "INSURGENT3_TURR_HEADSHOTS", 500)
		stats.set_int(MPX() .. "INSURGENT3_TURR_HELDTIME", 5963259)
		stats.set_int(MPX() .. "INSURGENT3_TURR_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "NIGHTSHARK_MG_KILLS", 500)
		stats.set_int(MPX() .. "NIGHTSHARK_MG_DEATHS", 100)
		stats.set_int(MPX() .. "NIGHTSHARK_MG_SHOTS", 500)
		stats.set_int(MPX() .. "NIGHTSHARK_MG_HITS", 500)
		stats.set_int(MPX() .. "NIGHTSHARK_MG_HEADSHOTS", 500)
		stats.set_int(MPX() .. "NIGHTSHARK_MG_HELDTIME", 5963259)
		stats.set_int(MPX() .. "NIGHTSHARK_MG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "OPPRESSOR_MG_KILLS", 500)
		stats.set_int(MPX() .. "OPPRESSOR_MG_DEATHS", 100)
		stats.set_int(MPX() .. "OPPRESSOR_MG_SHOTS", 500)
		stats.set_int(MPX() .. "OPPRESSOR_MG_HITS", 500)
		stats.set_int(MPX() .. "OPPRESSOR_MG_HEADSHOTS", 500)
		stats.set_int(MPX() .. "OPPRESSOR_MG_HELDTIME", 5963259)
		stats.set_int(MPX() .. "OPPRESSOR_MG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "OPPRESSOR_MISS_KILLS", 500)
		stats.set_int(MPX() .. "OPPRESSOR_MISS_DEATHS", 100)
		stats.set_int(MPX() .. "OPPRESSOR_MISS_SHOTS", 500)
		stats.set_int(MPX() .. "OPPRESSOR_MISS_HITS", 500)
		stats.set_int(MPX() .. "OPPRESSOR_MISS_HELDTIME", 5963259)
		stats.set_int(MPX() .. "OPPRESSOR_MISS_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "TAMPA3_MISS_KILLS", 500)
		stats.set_int(MPX() .. "TAMPA3_MISS_DEATHS", 100)
		stats.set_int(MPX() .. "TAMPA3_MISS_SHOTS", 500)
		stats.set_int(MPX() .. "TAMPA3_MISS_HITS", 500)
		stats.set_int(MPX() .. "TAMPA3_MISS_HELDTIME", 5963259)
		stats.set_int(MPX() .. "TAMPA3_MISS_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "TAMPA3_MORT_KILLS", 500)
		stats.set_int(MPX() .. "TAMPA3_MORT_DEATHS", 100)
		stats.set_int(MPX() .. "TAMPA3_MORT_SHOTS", 500)
		stats.set_int(MPX() .. "TAMPA3_MORT_HITS", 500)
		stats.set_int(MPX() .. "TAMPA3_MORT_HELDTIME", 5963259)
		stats.set_int(MPX() .. "TAMPA3_MORT_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "TAMPA3_FMINI_KILLS", 500)
		stats.set_int(MPX() .. "TAMPA3_FMINI_DEATHS", 100)
		stats.set_int(MPX() .. "TAMPA3_FMINI_SHOTS", 500)
		stats.set_int(MPX() .. "TAMPA3_FMINI_HITS", 500)
		stats.set_int(MPX() .. "TAMPA3_FMINI_HEADSHOTS", 500)
		stats.set_int(MPX() .. "TAMPA3_FMINI_HELDTIME", 5963259)
		stats.set_int(MPX() .. "TAMPA3_FMINI_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "TAMPA3_DMINI_KILLS", 500)
		stats.set_int(MPX() .. "TAMPA3_DMINI_DEATHS", 100)
		stats.set_int(MPX() .. "TAMPA3_DMINI_SHOTS", 500)
		stats.set_int(MPX() .. "TAMPA3_DMINI_HITS", 500)
		stats.set_int(MPX() .. "TAMPA3_DMINI_HEADSHOTS", 500)
		stats.set_int(MPX() .. "TAMPA3_DMINI_HELDTIME", 5963259)
		stats.set_int(MPX() .. "TAMPA3_DMINI_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "TECHNICAL3_MINI_KILLS", 500)
		stats.set_int(MPX() .. "TECHNICAL3_MINI_DEATHS", 100)
		stats.set_int(MPX() .. "TECHNICAL3_MINI_SHOTS", 500)
		stats.set_int(MPX() .. "TECHNICAL3_MINI_HITS", 500)
		stats.set_int(MPX() .. "TECHNICAL3_MINI_HEADSHOTS", 500)
		stats.set_int(MPX() .. "TECHNICAL3_MINI_HELDTIME", 5963259)
		stats.set_int(MPX() .. "TECHNICAL3_MINI_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "TECHNICAL3_TURR_KILLS", 500)
		stats.set_int(MPX() .. "TECHNICAL3_TURR_DEATHS", 100)
		stats.set_int(MPX() .. "TECHNICAL3_TURR_SHOTS", 500)
		stats.set_int(MPX() .. "TECHNICAL3_TURR_HITS", 500)
		stats.set_int(MPX() .. "TECHNICAL3_TURR_HEADSHOTS", 500)
		stats.set_int(MPX() .. "TECHNICAL3_TURR_HELDTIME", 5963259)
		stats.set_int(MPX() .. "TECHNICAL3_TURR_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "KHANJALI_ROCKET_KILLS", 500)
		stats.set_int(MPX() .. "KHANJALI_ROCKET_DEATHS", 100)
		stats.set_int(MPX() .. "KHANJALI_ROCKET_SHOTS", 500)
		stats.set_int(MPX() .. "KHANJALI_ROCKET_HITS", 500)
		stats.set_int(MPX() .. "KHANJALI_ROCKET_HELDTIME", 5963259)
		stats.set_int(MPX() .. "KHANJALI_ROCKET_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "KHANJALI_HCANN_KILLS", 500)
		stats.set_int(MPX() .. "KHANJALI_HCANN_DEATHS", 100)
		stats.set_int(MPX() .. "KHANJALI_HCANN_SHOTS", 500)
		stats.set_int(MPX() .. "KHANJALI_HCANN_HITS", 500)
		stats.set_int(MPX() .. "KHANJALI_HCANN_HELDTIME", 5963259)
		stats.set_int(MPX() .. "KHANJALI_HCANN_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "KHANJALI_MG_KILLS", 500)
		stats.set_int(MPX() .. "KHANJALI_MG_DEATHS", 100)
		stats.set_int(MPX() .. "KHANJALI_MG_SHOTS", 500)
		stats.set_int(MPX() .. "KHANJALI_MG_HITS", 500)
		stats.set_int(MPX() .. "KHANJALI_MG_HEADSHOTS", 500)
		stats.set_int(MPX() .. "KHANJALI_MG_HELDTIME", 5963259)
		stats.set_int(MPX() .. "KHANJALI_MG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "KHANJALI_GL_KILLS", 500)
		stats.set_int(MPX() .. "KHANJALI_GL_DEATHS", 100)
		stats.set_int(MPX() .. "KHANJALI_GL_SHOTS", 500)
		stats.set_int(MPX() .. "KHANJALI_GL_HITS", 500)
		stats.set_int(MPX() .. "KHANJALI_GL_HELDTIME", 5963259)
		stats.set_int(MPX() .. "KHANJALI_GL_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "REVOLTER_MG_KILLS", 500)
		stats.set_int(MPX() .. "REVOLTER_MG_DEATHS", 100)
		stats.set_int(MPX() .. "REVOLTER_MG_SHOTS", 500)
		stats.set_int(MPX() .. "REVOLTER_MG_HITS", 500)
		stats.set_int(MPX() .. "REVOLTER_MG_HEADSHOTS", 500)
		stats.set_int(MPX() .. "REVOLTER_MG_HELDTIME", 5963259)
		stats.set_int(MPX() .. "REVOLTER_MG_ENEMY_KILLS", 500)
		stats.set_int(MPX() .. "SAVESTRA_MG_KILLS", 500)
		stats.set_int(MPX() .. "SAVESTRA_MG_DEATHS", 100)
		stats.set_int(MPX() .. "SAVESTRA_MG_SHOTS", 500)
		stats.set_int(MPX() .. "SAVESTRA_MG_HITS", 500)
		stats.set_int(MPX() .. "SAVESTRA_MG_HEADSHOTS", 500)	
		stats.set_int("MPPLY_NUM_CAPTURES_CREATED", 100)
		stats.set_int("MPPLY_PILOT_SCHOOL_MEDAL_0", -1)
		stats.set_int("MPPLY_PILOT_SCHOOL_MEDAL_1", -1)
		stats.set_int("MPPLY_PILOT_SCHOOL_MEDAL_2", -1)
		stats.set_int("MPPLY_PILOT_SCHOOL_MEDAL_3", -1)
		stats.set_int("MPPLY_PILOT_SCHOOL_MEDAL_4", -1)
		stats.set_int("MPPLY_PILOT_SCHOOL_MEDAL_5", -1)
		stats.set_int("MPPLY_PILOT_SCHOOL_MEDAL_6", -1)
		stats.set_int("MPPLY_PILOT_SCHOOL_MEDAL_7", -1)
		stats.set_int("MPPLY_PILOT_SCHOOL_MEDAL_8", -1)
		stats.set_int("MPPLY_PILOT_SCHOOL_MEDAL_9", -1)
		stats.set_int("MPPLY_HEIST_ACH_TRACKER", -1)
		stats.set_int("MPPLY_GANGOPS_ALLINORDER", 100)
		stats.set_int("MPPLY_GANGOPS_LOYALTY", 100)
		stats.set_int("MPPLY_GANGOPS_CRIMMASMD", 100)
		stats.set_int("MPPLY_GANGOPS_LOYALTY2", 100)
		stats.set_int("MPPLY_GANGOPS_LOYALTY3", 100)
		stats.set_int("MPPLY_GANGOPS_CRIMMASMD2", 100)
		stats.set_int("MPPLY_GANGOPS_CRIMMASMD3", 100)
		stats.set_int("MPPLY_GANGOPS_SUPPORT", 100)
		stats.set_int("MPPLY_AWD_FM_CR_DM_MADE", 600)
		stats.set_int("MPPLY_AWD_FM_CR_RACES_MADE", 1000)
		stats.set_int("MPPLY_AWD_FM_CR_MISSION_SCORE", 100)
		stats.set_int("MPPLY_TOTAL_RACES_WON", 500)
		stats.set_int("MPPLY_TOTAL_RACES_LOST", 250)
		stats.set_int("MPPLY_TOTAL_CUSTOM_RACES_WON", 500)
		stats.set_int("MPPLY_TOTAL_DEATHMATCH_LOST", 250)
		stats.set_int("MPPLY_TOTAL_DEATHMATCH_WON", 500)
		stats.set_int("MPPLY_TOTAL_TDEATHMATCH_LOST", 250)
		stats.set_int("MPPLY_TOTAL_TDEATHMATCH_WON", 500)
		stats.set_int("MPPLY_SHOOTINGRANGE_WINS", 500)
		stats.set_int("MPPLY_SHOOTINGRANGE_LOSSES", 250)
		stats.set_int("MPPLY_TENNIS_MATCHES_WON", 500)
		stats.set_int("MPPLY_TENNIS_MATCHES_LOST", 250)
		stats.set_int("MPPLY_GOLF_WINS", 500)
		stats.set_int("MPPLY_GOLF_LOSSES", 250)
		stats.set_int("MPPLY_DARTS_TOTAL_WINS", 500)
		stats.set_int("MPPLY_DARTS_TOTAL_MATCHES", 750)
		stats.set_int("MPPLY_SHOOTINGRANGE_TOTAL_MATCH", 800)
		stats.set_int("MPPLY_BJ_WINS", 500)
		stats.set_int("MPPLY_BJ_LOST", 250)
		stats.set_int("MPPLY_RACE_2_POINT_WINS", 500)
		stats.set_int("MPPLY_RACE_2_POINT_LOST", 250)
		stats.set_int("MPPLY_KILLS_PLAYERS", 3593)
		stats.set_int("MPPLY_DEATHS_PLAYER", 1002)
		stats.set_int("MPPLY_MISSIONS_CREATED", 500)
		stats.set_int("MPPLY_LTS_CREATED", 500)
		stats.set_int("MPPLY_AWD_FM_CR_PLAYED_BY_PEEP", 1598)
		stats.set_int("MPPLY_FM_MISSION_LIKES", 1500)
		stats.set_int("MPPLY_TOTAL_PLAYING_TIME", 2073600000)
		stats.set_int("MPPLY_LEADERBOARD_PLAYING_TIME", 2073600000)
		stats.set_int("MPPLY_MP_PLAYING_TIME_NEW", 2073600000)
		stats.set_int("MPPLY_LONGEST_PLAYING_TIME", 2073600000)
		stats.set_int("MPPLY_TIME_DRIVING_CAR", 2073600000)
		stats.set_int("MPPLY_TIME_DRIVING_PLANE", 2073600000)
		stats.set_int("MPPLY_TIME_DRIVING_HELI", 2073600000)
		stats.set_int("MPPLY_TIME_DRIVING_QUADBIKE", 2073600000)
		stats.set_int("MPPLY_TIME_DRIVING_BIKE", 2073600000)
		stats.set_int("MPPLY_TIME_DRIVING_BICYCLE", 2073600000)
		stats.set_int("MPPLY_TIME_DRIVING_BOAT", 2073600000)
		stats.set_int("MPPLY_TIME_DRIVING_SUBMARINE", 2073600000)
		stats.set_int("MPPLY_TIME_SWIMMING", 2073600000)
		stats.set_int("MPPLY_TIME_WALKING", 2073600000)
		stats.set_int("MPPLY_TIME_UNDERWATER", 2073600000)
		stats.set_int("MPPLY_TIME_IN_WATER", 2073600000)
		stats.set_int("MPPLY_TIME_IN_COVER", 2073600000)
		stats.set_int("MPPLY_TIME_DRIVING_PASSENGER", 2073600000)
		stats.set_int("MPPLY_TOTAL_TIME_SPENT_ON_PHONE", 2073600000)
		stats.set_int("MPPLY_TIME_AS_A_PASSENGER", 2073600000)
		stats.set_int("MPPLY_TIME_AS_A_DRIVER", 2073600000)
		stats.set_int("MPPLY_TIME_SPENT_FLYING", 2073600000)
		stats.set_int("MPPLY_TIME_IN_CAR", 2073600000)
		stats.set_int("MPPLY_TOTAL_TIME_SPENT_DEATHMAT", 2073600000)
		stats.set_int("MPPLY_TOTAL_TIME_SPENT_FREEMODE", 2073600000)
		stats.set_int("MPPLY_TOTAL_TIME_MISSION_CREATO", 2073600000)
		stats.set_int("MPPLY_TOTAL_TIME_SPENT_RACES", 2073600000)
		stats.set_int("MPPLY_TOTAL_TIME_SPENT_ON_MISS", 2073600000)
		stats.set_int("MPPLY_TOTAL_TIME_UNDERWATER", 2073600000)
		stats.set_int("MPPLY_TOTAL_TIME_CINEMA", 2073600000)
		stats.set_int("MPPLY_TOTAL_TIME_LOAD_SCREEN", 2073600000)
		stats.set_int("MPPLY_TOTAL_TIME_IN_LOBBY", 2073600000)
		stats.set_int("MPPLY_TOTAL_TIME_SPENT_DEATHMAT", 2147483647)
		stats.set_int("MPPLY_TOTAL_TIME_SPENT_RACES", 2147483647)
		stats.set_int("MPPLY_TOTAL_TIME_LOAD_SCREEN", 1047483647)
		stats.set_int("MPPLY_TOTAL_TIME_IN_LOBBY", 1047483647)
		stats.set_int(MPX() .. "TIME_AS_A_DRIVER", 2147483647)
		stats.set_int(MPX() .. "TIME_SPENT_FLYING", 2147483647)
		stats.set_int(MPX() .. "TIME_IN_CAR", 2147483647)
		stats.set_int(MPX() .. "TIME_AS_A_PASSENGER", 2147483647)
		stats.set_int(MPX() .. "TOTAL_TIME_CINEMA", 2147483647)
		stats.set_int(MPX() .. "TOTAL_CHASE_TIME", 432000000)
		stats.set_int(MPX() .. "ARN_SPEC_BOX_TIME_MS", 86400000)
		stats.set_int(MPX() .. "LONGEST_PLAYING_TIME", 1047483647)
		stats.set_int(MPX() .. "TIME_DRIVING_CAR", 1047483647)
		stats.set_int(MPX() .. "TIME_DRIVING_PLANE", 1047483647)
		stats.set_int(MPX() .. "TIME_DRIVING_HELI", 1047483647)
		stats.set_int(MPX() .. "TIME_DRIVING_QUADBIKE", 1047483647)
		stats.set_int(MPX() .. "TIME_DRIVING_BIKE", 1047483647)
		stats.set_int(MPX() .. "TIME_DRIVING_BICYCLE", 1047483647)
		stats.set_int(MPX() .. "TIME_DRIVING_BOAT", 1047483647)
		stats.set_int(MPX() .. "TIME_DRIVING_SUBMARINE", 1047483647)
		stats.set_int(MPX() .. "TIME_SWIMMING", 1047483647)
		stats.set_int(MPX() .. "TIME_WALKING", 1047483647)
		stats.set_int(MPX() .. "TIME_UNDERWATER", 1047483647)
		stats.set_int(MPX() .. "TIME_IN_WATER", 1047483647)
		stats.set_int(MPX() .. "TIME_IN_COVER", 1047483647)
		stats.set_int(MPX() .. "TIME_DRIVING_PASSENGER", 1047483647)
		stats.set_int(MPX() .. "TOTAL_TIME_SPENT_ON_PHONE", 1047483647)
		stats.set_int(MPX() .. "TIME_AS_A_PASSENGER", 1047483647)
		stats.set_int(MPX() .. "TIME_AS_A_DRIVER", 1047483647)
		stats.set_int(MPX() .. "TIME_SPENT_FLYING", 1047483647)
		stats.set_int(MPX() .. "TIME_IN_CAR", 1047483647)
		stats.set_int(MPX() .. "TOTAL_TIME_UNDERWATER", 1047483647)
		stats.set_int(MPX() .. "TOTAL_TIME_CINEMA", 1047483647)
		stats.set_bool(MPX() .. "AWD_TEEING_OFF", true)
		stats.set_bool(MPX() .. "AWD_PARTY_NIGHT", true)
		stats.set_bool(MPX() .. "AWD_BILLIONAIRE_GAMES", true)
		stats.set_bool(MPX() .. "AWD_HOOD_PASS", true)
		stats.set_bool(MPX() .. "AWD_STUDIO_TOUR", true)
		stats.set_bool(MPX() .. "AWD_DONT_MESS_DRE", true)
		stats.set_bool(MPX() .. "AWD_BACKUP", true)
		stats.set_bool(MPX() .. "AWD_SHORTFRANK_1", true)
		stats.set_bool(MPX() .. "AWD_SHORTFRANK_2", true)
		stats.set_bool(MPX() .. "AWD_SHORTFRANK_3", true)
		stats.set_bool(MPX() .. "AWD_CONTR_KILLER", true)
		stats.set_bool(MPX() .. "AWD_DOGS_BEST_FRIEND", true)
		stats.set_bool(MPX() .. "AWD_MUSIC_STUDIO", true)
		stats.set_bool(MPX() .. "AWD_SHORTLAMAR_1", true)
		stats.set_bool(MPX() .. "AWD_SHORTLAMAR_2", true)
		stats.set_bool(MPX() .. "AWD_SHORTLAMAR_3", true)
		stats.set_bool(MPX() .. "BS_FRANKLIN_DIALOGUE_0", true)
		stats.set_bool(MPX() .. "BS_FRANKLIN_DIALOGUE_1", true)
		stats.set_bool(MPX() .. "BS_FRANKLIN_DIALOGUE_2", true)
		stats.set_bool(MPX() .. "BS_IMANI_D_APP_SETUP", true)
		stats.set_bool(MPX() .. "BS_IMANI_D_APP_STRAND", true)
		stats.set_bool(MPX() .. "BS_IMANI_D_APP_PARTY", true)
		stats.set_bool(MPX() .. "BS_IMANI_D_APP_PARTY_2", true)
		stats.set_bool(MPX() .. "BS_IMANI_D_APP_PARTY_F", true)
		stats.set_bool(MPX() .. "BS_IMANI_D_APP_BILL", true)
		stats.set_bool(MPX() .. "BS_IMANI_D_APP_BILL_2", true)
		stats.set_bool(MPX() .. "BS_IMANI_D_APP_BILL_F", true)
		stats.set_bool(MPX() .. "BS_IMANI_D_APP_HOOD", true)
		stats.set_bool(MPX() .. "BS_IMANI_D_APP_HOOD_2", true)
		stats.set_bool(MPX() .. "BS_IMANI_D_APP_HOOD_F", true)
		stats.set_bool(MPX() .. "AWD_SCOPEOUT", true)
		stats.set_bool(MPX() .. "AWD_CREWEDUP", true)
		stats.set_bool(MPX() .. "AWD_MOVINGON", true)
		stats.set_bool(MPX() .. "AWD_CSYONS26MOCAMP", true)
		stats.set_bool(MPX() .. "AWD_GUNMAN", true)
		stats.set_bool(MPX() .. "AWD_SMASHNGRAB", true)
		stats.set_bool(MPX() .. "AWD_INPLAINSI", true)
		stats.set_bool(MPX() .. "AWD_UNDETECTED", true)
		stats.set_bool(MPX() .. "AWD_ALLROUND", true)
		stats.set_bool(MPX() .. "AWD_ELITETHEIF", true)
		stats.set_bool(MPX() .. "AWD_CSYONS26", true)
		stats.set_bool(MPX() .. "AWD_SUPPORTACT", true)
		stats.set_bool(MPX() .. "AWD_SHAFTED", true)
		stats.set_bool(MPX() .. "AWD_COLLECTOR", true)
		stats.set_bool(MPX() .. "AWD_DEADEYE", true)
		stats.set_bool(MPX() .. "AWD_PISTOLSATDAWN", true)
		stats.set_bool(MPX() .. "AWD_TRAFFICAVOI", true)
		stats.set_bool(MPX() .. "AWD_CANTCATCHBRA", true)
		stats.set_bool(MPX() .. "AWD_WIZHARD", true)
		stats.set_bool(MPX() .. "AWD_APEESCAP", true)
		stats.set_bool(MPX() .. "AWD_MONKEYKIND", true)
		stats.set_bool(MPX() .. "AWD_AQUAAPE", true)
		stats.set_bool(MPX() .. "AWD_KEEPFAITH", true)
		stats.set_bool(MPX() .. "AWD_TRUELOVE", true)
		stats.set_bool(MPX() .. "AWD_NEMESIS", true)
		stats.set_bool(MPX() .. "AWD_FRIENDZONED", true)
		stats.set_bool(MPX() .. "IAP_CHALLENGE_0", true)
		stats.set_bool(MPX() .. "IAP_CHALLENGE_1", true)
		stats.set_bool(MPX() .. "IAP_CHALLENGE_2v", true)
		stats.set_bool(MPX() .. "IAP_CHALLENGE_3", true)
		stats.set_bool(MPX() .. "IAP_CHALLENGE_4v", true)
		stats.set_bool(MPX() .. "IAP_GOLD_TANK", true)
		stats.set_bool(MPX() .. "SCGW_WON_NO_DEATHS", true)
		stats.set_bool(MPX() .. "AWD_KINGOFQUB3D", true)
		stats.set_bool(MPX() .. "AWD_QUBISM", true)
		stats.set_bool(MPX() .. "AWD_QUIBITS", true)
		stats.set_bool(MPX() .. "AWD_GODOFQUB3D", true)
		stats.set_bool(MPX() .. "AWD_STRAIGHT_TO_VIDEO", true)
		stats.set_bool(MPX() .. "AWD_MONKEY_C_MONKEY_DO", true)
		stats.set_bool(MPX() .. "AWD_TRAINED_TO_KILL", true)
		stats.set_bool(MPX() .. "AWD_DIRECTOR", true)
		stats.set_bool(MPX() .. "VCM_FLOW_CS_RSC_SEEN", true)
		stats.set_bool(MPX() .. "VCM_FLOW_CS_BWL_SEEN", true)
		stats.set_bool(MPX() .. "VCM_FLOW_CS_MTG_SEEN", true)
		stats.set_bool(MPX() .. "VCM_FLOW_CS_OIL_SEEN", true)
		stats.set_bool(MPX() .. "VCM_FLOW_CS_DEF_SEEN", true)
		stats.set_bool(MPX() .. "VCM_FLOW_CS_FIN_SEEN", true)
		stats.set_bool(MPX() .. "WAS_CHAR_TRANSFERED", true)
		stats.set_bool(MPX() .. "CL_RACE_MODDED_CAR", true)
		stats.set_bool(MPX() .. "CL_DRIVE_RALLY", true)
		stats.set_bool(MPX() .. "CL_PLAY_GTA_RACE", true)
		stats.set_bool(MPX() .. "CL_PLAY_BOAT_RACE", true)
		stats.set_bool(MPX() .. "CL_PLAY_FOOT_RACE", true)
		stats.set_bool(MPX() .. "CL_PLAY_TEAM_DM", true)
		stats.set_bool(MPX() .. "CL_PLAY_VEHICLE_DM", true)
		stats.set_bool(MPX() .. "CL_PLAY_MISSION_CONTACT", true)
		stats.set_bool(MPX() .. "CL_PLAY_A_PLAYLIST", true)
		stats.set_bool(MPX() .. "CL_PLAY_POINT_TO_POINT", true)
		stats.set_bool(MPX() .. "CL_PLAY_ONE_ON_ONE_DM", true)
		stats.set_bool(MPX() .. "CL_PLAY_ONE_ON_ONE_RACE", true)
		stats.set_bool(MPX() .. "CL_SURV_A_BOUNTY", true)
		stats.set_bool(MPX() .. "CL_SET_WANTED_LVL_ON_PLAY", true)
		stats.set_bool(MPX() .. "CL_GANG_BACKUP_GANGS", true)
		stats.set_bool(MPX() .. "CL_GANG_BACKUP_LOST", true)
		stats.set_bool(MPX() .. "CL_GANG_BACKUP_VAGOS", true)
		stats.set_bool(MPX() .. "CL_CALL_MERCENARIES", true)
		stats.set_bool(MPX() .. "CL_PHONE_MECH_DROP_CAR", true)
		stats.set_bool(MPX() .. "CL_GONE_OFF_RADAR", true)
		stats.set_bool(MPX() .. "CL_FILL_TITAN", true)
		stats.set_bool(MPX() .. "CL_MOD_CAR_USING_APP", true)
		stats.set_bool(MPX() .. "CL_MOD_CAR_USING_APP", true)
		stats.set_bool(MPX() .. "CL_BUY_INSURANCE", true)
		stats.set_bool(MPX() .. "CL_BUY_GARAGE", true)
		stats.set_bool(MPX() .. "CL_ENTER_FRIENDS_HOUSE", true)
		stats.set_bool(MPX() .. "CL_CALL_STRIPPER_HOUSE", true)
		stats.set_bool(MPX() .. "CL_CALL_FRIEND", true)
		stats.set_bool(MPX() .. "CL_SEND_FRIEND_REQUEST", true)
		stats.set_bool(MPX() .. "CL_W_WANTED_PLAYER_TV", true)
		stats.set_bool(MPX() .. "PILOT_ASPASSEDLESSON_0", true)
		stats.set_bool(MPX() .. "PILOT_ASPASSEDLESSON_1", true)
		stats.set_bool(MPX() .. "PILOT_ASPASSEDLESSON_2", true)
		stats.set_bool(MPX() .. "PILOT_ASPASSEDLESSON_3", true)
		stats.set_bool(MPX() .. "PILOT_ASPASSEDLESSON_4", true)
		stats.set_bool(MPX() .. "PILOT_ASPASSEDLESSON_5", true)
		stats.set_bool(MPX() .. "PILOT_ASPASSEDLESSON_6", true)
		stats.set_bool(MPX() .. "PILOT_ASPASSEDLESSON_7", true)
		stats.set_bool(MPX() .. "PILOT_ASPASSEDLESSON_8", true)
		stats.set_bool(MPX() .. "PILOT_ASPASSEDLESSON_9", true)
		stats.set_bool(MPX() .. "AWD_FIRST_TIME1", true)
		stats.set_bool(MPX() .. "AWD_FIRST_TIME2", true)
		stats.set_bool(MPX() .. "AWD_FIRST_TIME3", true)
		stats.set_bool(MPX() .. "AWD_FIRST_TIME4", true)
		stats.set_bool(MPX() .. "AWD_FIRST_TIME5", true)
		stats.set_bool(MPX() .. "AWD_FIRST_TIME6", true)
		stats.set_bool(MPX() .. "AWD_ALL_IN_ORDER", true)
		stats.set_bool(MPX() .. "AWD_SUPPORTING_ROLE", true)
		stats.set_bool(MPX() .. "AWD_ACTIVATE_2_PERSON_KEY", true)
		stats.set_bool(MPX() .. "AWD_ALL_ROLES_HEIST", true)
		stats.set_bool(MPX() .. "AWD_LEADER", true)
		stats.set_bool(MPX() .. "AWD_SURVIVALIST", true)
		stats.set_bool(MPX() .. "AWD_BUY_EVERY_GUN", true)
		stats.set_bool(MPX() .. "AWD_DAILYOBJMONTHBONUS", true)
		stats.set_bool(MPX() .. "AWD_DAILYOBJWEEKBONUS", true)
		stats.set_bool(MPX() .. "AWD_DRIVELESTERCAR5MINS", true)
		stats.set_bool(MPX() .. "AWD_FINISH_HEIST_NO_DAMAGE", true)
		stats.set_bool(MPX() .. "AWD_FM25DIFFERENTDM", true)
		stats.set_bool(MPX() .. "AWD_FM25DIFFERENTRACES", true)
		stats.set_bool(MPX() .. "AWD_FM25DIFITEMSCLOTHES", true)
		stats.set_bool(MPX() .. "AWD_FMFURTHESTWHEELIE", true)
		stats.set_bool(MPX() .. "AWD_FM6DARTCHKOUT", true)
		stats.set_bool(MPX() .. "AWD_FM_GOLF_HOLE_IN_1", true)
		stats.set_bool(MPX() .. "AWD_FM_SHOOTRANG_GRAN_WON", true)
		stats.set_bool(MPX() .. "AWD_FM_TENNIS_5_SET_WINS", true)
		stats.set_bool(MPX() .. "AWD_FMATTGANGHQ", true)
		stats.set_bool(MPX() .. "AWD_FMFULLYMODDEDCAR", true)
		stats.set_bool(MPX() .. "AWD_FMKILL3ANDWINGTARACE", true)
		stats.set_bool(MPX() .. "AWD_FMKILLSTREAKSDM", true)
		stats.set_bool(MPX() .. "AWD_FMMOSTKILLSGANGHIDE", true)
		stats.set_bool(MPX() .. "AWD_FMMOSTKILLSSURVIVE", true)
		stats.set_bool(MPX() .. "AWD_FMPICKUPDLCCRATE1ST", true)
		stats.set_bool(MPX() .. "AWD_FMRACEWORLDRECHOLDER", true)
		stats.set_bool(MPX() .. "AWD_FMTATTOOALLBODYPARTS", true)
		stats.set_bool(MPX() .. "AWD_FMWINALLRACEMODES", true)
		stats.set_bool(MPX() .. "AWD_FMWINCUSTOMRACE", true)
		stats.set_bool(MPX() .. "AWD_FMWINEVERYGAMEMODE", true)
		stats.set_bool(MPX() .. "AWD_SPLIT_HEIST_TAKE_EVENLY", true)
		stats.set_bool(MPX() .. "AWD_STORE_20_CAR_IN_GARAGES", true)
		stats.set_bool(MPX() .. "SR_TIER_1_REWARD", true)
		stats.set_bool(MPX() .. "SR_TIER_3_REWARD", true)
		stats.set_bool(MPX() .. "SR_INCREASE_THROW_CAP", true)
		stats.set_bool(MPX() .. "AWD_CLUB_COORD", true)
		stats.set_bool(MPX() .. "AWD_CLUB_HOTSPOT", true)
		stats.set_bool(MPX() .. "AWD_CLUB_CLUBBER", true)
		stats.set_bool(MPX() .. "AWD_BEGINNER", true)
		stats.set_bool(MPX() .. "AWD_FIELD_FILLER", true)
		stats.set_bool(MPX() .. "AWD_ARMCHAIR_RACER", true)
		stats.set_bool(MPX() .. "AWD_LEARNER", true)
		stats.set_bool(MPX() .. "AWD_SUNDAY_DRIVER", true)
		stats.set_bool(MPX() .. "AWD_THE_ROOKIE", true)
		stats.set_bool(MPX() .. "AWD_BUMP_AND_RUN", true)
		stats.set_bool(MPX() .. "AWD_GEAR_HEAD", true)
		stats.set_bool(MPX() .. "AWD_DOOR_SLAMMER", true)
		stats.set_bool(MPX() .. "AWD_HOT_LAP", true)
		stats.set_bool(MPX() .. "AWD_ARENA_AMATEUR", true)
		stats.set_bool(MPX() .. "AWD_PAINT_TRADER", true)
		stats.set_bool(MPX() .. "AWD_SHUNTER", true)
		stats.set_bool(MPX() .. "AWD_JOCK", true)
		stats.set_bool(MPX() .. "AWD_WARRIOR", true)
		stats.set_bool(MPX() .. "AWD_T_BONE", true)
		stats.set_bool(MPX() .. "AWD_MAYHEM", true)
		stats.set_bool(MPX() .. "AWD_WRECKER", true)
		stats.set_bool(MPX() .. "AWD_CRASH_COURSE", true)
		stats.set_bool(MPX() .. "AWD_ARENA_LEGEND", true)
		stats.set_bool(MPX() .. "AWD_PEGASUS", true)
		stats.set_bool(MPX() .. "AWD_CONTACT_SPORT", true)
		stats.set_bool(MPX() .. "AWD_UNSTOPPABLE", true)
		stats.set_bool(MPX() .. "LOW_FLOW_CS_DRV_SEEN", true)
		stats.set_bool(MPX() .. "LOW_FLOW_CS_TRA_SEEN", true)
		stats.set_bool(MPX() .. "LOW_FLOW_CS_FUN_SEEN", true)
		stats.set_bool(MPX() .. "LOW_FLOW_CS_PHO_SEEN", true)
		stats.set_bool(MPX() .. "LOW_FLOW_CS_FIN_SEEN", true)
		stats.set_bool(MPX() .. "LOW_BEN_INTRO_CS_SEEN", true)
		stats.set_bool(MPX() .. "CASINOPSTAT_BOOL0", true)
		stats.set_bool(MPX() .. "CASINOPSTAT_BOOL1", true)
		stats.set_bool(MPX() .. "FILM4SHIRTUNLOCK", true)
		stats.set_bool(MPX() .. "FILM5SHIRTUNLOCK", true)
		stats.set_bool(MPX() .. "FILM6SHIRTUNLOCK", true)
		stats.set_bool(MPX() .. "FILM7SHIRTUNLOCK", true)
		stats.set_bool(MPX() .. "FILM8SHIRTUNLOCK", true)
		stats.set_bool(MPX() .. "FILM9SHIRTUNLOCK", true)
		stats.set_bool(MPX() .. "ACCOUNTANTSHIRTUNLOCK", true)
		stats.set_bool(MPX() .. "BAHAMAMAMASHIRTUNLOCK", true)
		stats.set_bool(MPX() .. "DRONESHIRTUNLOCK", true)
		stats.set_bool(MPX() .. "GROTTISHIRTUNLOCK", true)
		stats.set_bool(MPX() .. "GOLFSHIRTUNLOCK", true)
		stats.set_bool(MPX() .. "MAISONETTESHIRTUNLOCK", true)
		stats.set_bool(MPX() .. "MANOPAUSESHIRTUNLOCK", true)
		stats.set_bool(MPX() .. "MELTDOWNSHIRTUNLOCK", true)
		stats.set_bool(MPX() .. "PACIFICBLUFFSSHIRTUNLOCK", true)
		stats.set_bool(MPX() .. "CSYONS26LAPSSHIRTUNLOCK", true)
		stats.set_bool(MPX() .. "TENNISSHIRTUNLOCK", true)
		stats.set_bool(MPX() .. "TOESHOESSHIRTUNLOCK", true)
		stats.set_bool(MPX() .. "VANILLAUNICORNSHIRTUNLOCK", true)
		stats.set_bool(MPX() .. "MARLOWESHIRTUNLOCK", true)
		stats.set_bool(MPX() .. "CRESTSHIRTUNLOCK", true)
		stats.set_bool("MPPLY_AWD_GANGOPS_ALLINORDER", true)
		stats.set_bool("MPPLY_AWD_GANGOPS_SUPPORT", true)
		stats.set_bool("MPPLY_AWD_GANGOPS_LOYALTY2", true)
		stats.set_bool("MPPLY_AWD_GANGOPS_CRIMMASMD2", true)
		stats.set_bool("MPPLY_AWD_GANGOPS_LOYALTY3", true)
		stats.set_bool("MPPLY_AWD_GANGOPS_CRIMMASMD3", true)
		stats.set_bool("MPPLY_AWD_GANGOPS_LOYALTY", true)
		stats.set_bool("MPPLY_AWD_GANGOPS_CRIMMASMD", true)
		stats.set_bool("MPPLY_MELEECHLENGECOMPLETED", true)
		stats.set_bool("MPPLY_HEADSHOTCHLENGECOMPLETED", true)
		stats.set_bool("MPPLY_AWD_COMPLET_HEIST_MEM", true)
		stats.set_bool("MPPLY_AWD_COMPLET_HEIST_1STPER", true)
		stats.set_bool("MPPLY_AWD_FLEECA_FIN", true)
		stats.set_bool("MPPLY_AWD_HST_ORDER", true)
		stats.set_bool("MPPLY_AWD_HST_SAME_TEAM", true)
		stats.set_bool("MPPLY_AWD_HST_ULT_CHAL", true)
		stats.set_bool("MPPLY_AWD_HUMANE_FIN", true)
		stats.set_bool("MPPLY_AWD_PACIFIC_FIN", true)
		stats.set_bool("MPPLY_AWD_PRISON_FIN", true)
		stats.set_bool("MPPLY_AWD_SERIESA_FIN", true)
		stats.set_bool("MPPLY_AWD_GANGOPS_IAA", true)
		stats.set_bool("MPPLY_AWD_GANGOPS_SUBMARINE", true)
		stats.set_bool("MPPLY_AWD_GANGOPS_MISSILE", true)
			stats.set_int(MPX() .. "AWD_FM_DM_WINS", 50)
			stats.set_int(MPX() .. "AWD_FM_TDM_WINS", 50)
			stats.set_int(MPX() .. "AWD_FM_TDM_MVP", 50)
			stats.set_int(MPX() .. "AWD_RACES_WON", 50)
			stats.set_int(MPX() .. "AWD_FMWINAIRRACE", 25)
			stats.set_int(MPX() .. "AWD_FMWINSEARACE", 25)
			stats.set_int(MPX() .. "AWD_FM_GTA_RACES_WON", 50)
			stats.set_bool(MPX() .. "AWD_FMKILL3ANDWINGTARACE", true)
			stats.set_int(MPX() .. "AWD_FMRALLYWONDRIVE", 25)
			stats.set_int(MPX() .. "AWD_FMRALLYWONNAV", 25)
			stats.set_bool(MPX() .. "AWD_FMWINCUSTOMRACE", true)
			stats.set_int(MPX() .. "AWD_FMWINRACETOPOINTS", 25)
			stats.set_bool(MPX() .. "CL_RACE_MODDED_CAR", true)
			stats.set_int(MPX() .. "AWD_FM_RACE_LAST_FIRST", 25)
			stats.set_bool(MPX() .. "AWD_FMRACEWORLDRECHOLDER", true)
			stats.set_int(MPX() .. "AWD_FM_RACES_FASTEST_LAP", 50)
			stats.set_bool(MPX() .. "AWD_FMWINALLRACEMODES", true)
			stats.set_int(MPX() .. "AWD_FMHORDWAVESSURVIVE", 10)
			stats.set_int(MPX() .. "NUMBER_SLIPSTREAMS_IN_RACE", 100)
			stats.set_int(MPX() .. "NUMBER_TURBO_STARTS_IN_RACE", 50)
			stats.set_int(MPX() .. "AWD_NO_ARMWRESTLING_WINS", 25)
			stats.set_int(MPX() .. "MOST_ARM_WRESTLING_WINS", 25)
			stats.set_int(MPX() .. "AWD_WIN_AT_DARTS", 25)
			stats.set_int(MPX() .. "AWD_FM_GOLF_WON", 25)
			stats.set_int(MPX() .. "AWD_FM_TENNIS_WON", 25)
			stats.set_bool(MPX() .. "AWD_FM_TENNIS_5_SET_WINS", true)
			stats.set_bool(MPX() .. "AWD_FM_TENNIS_STASETWIN", true)
			stats.set_int(MPX() .. "AWD_FM_SHOOTRANG_CT_WON", 25)
			stats.set_int(MPX() .. "AWD_FM_SHOOTRANG_RT_WON", 25)
			stats.set_int(MPX() .. "AWD_FM_SHOOTRANG_TG_WON", 25)
			stats.set_bool(MPX() .. "AWD_FM_SHOOTRANG_GRAN_WON", true)
			stats.set_bool(MPX() .. "AWD_FMWINEVERYGAMEMODE", true)
			stats.set_int(MPX() .. "AWD_WIN_CAPTURES", 50)
			stats.set_int(MPX() .. "AWD_WIN_CAPTURE_DONT_DYING", 25)
			stats.set_int(MPX() .. "AWD_WIN_LAST_TEAM_STANDINGS", 50)
			stats.set_int(MPX() .. "AWD_ONLY_PLAYER_ALIVE_LTS", 50)
			stats.set_int(MPX() .. "AWD_KILL_TEAM_YOURSELF_LTS", 25)
			stats.set_int(MPX() .. "AIR_LAUNCHES_OVER_40M", 25)
			stats.set_int(MPX() .. "AWD_CARS_EXPORTED", 50)
			stats.set_int(MPX() .. "AWD_LESTERDELIVERVEHICLES", 25)
			stats.set_int(MPX() .. "TOTAL_RACES_WON", 500)
			stats.set_int(MPX() .. "TOTAL_RACES_LOST", 250)
			stats.set_int(MPX() .. "TOTAL_CUSTOM_RACES_WON", 500)
			stats.set_int(MPX() .. "TOTAL_DEATHMATCH_LOST", 250)
			stats.set_int(MPX() .. "TOTAL_DEATHMATCH_WON", 500)
			stats.set_int(MPX() .. "TOTAL_TDEATHMATCH_LOST", 250)
			stats.set_int(MPX() .. "TOTAL_TDEATHMATCH_WON", 500)
			stats.set_int(MPX() .. "SHOOTINGRANGE_WINS", 500)
			stats.set_int(MPX() .. "SHOOTINGRANGE_LOSSES", 250)
			stats.set_int(MPX() .. "TENNIS_MATCHES_WON", 500)
			stats.set_int(MPX() .. "TENNIS_MATCHES_LOST", 250)
			stats.set_int(MPX() .. "GOLF_WINS", 500)
			stats.set_int(MPX() .. "GOLF_LOSSES", 250)
			stats.set_int(MPX() .. "DARTS_TOTAL_WINS", 500)
			stats.set_int(MPX() .. "DARTS_TOTAL_MATCHES", 750)
			stats.set_int(MPX() .. "SHOOTINGRANGE_TOTAL_MATCH", 800)
			stats.set_int(MPX() .. "BJ_WINS", 500)
			stats.set_int(MPX() .. "BJ_LOST", 250)
			stats.set_int(MPX() .. "RACE_2_POINT_WINS", 500)
			stats.set_int(MPX() .. "RACE_2_POINT_LOST", 250)
			stats.set_int(MPX() .. "KILLS_PLAYERS", 3593)
			stats.set_int(MPX() .. "DEATHS_PLAYER", 1002)
			stats.set_int(MPX() .. "MISSIONS_CREATED", 500)
			stats.set_int(MPX() .. "LTS_CREATED", 500)
			stats.set_int(MPX() .. "FM_MISSION_LIKES", 1500)
			stats.set_bool(MPX() .. "AWD_FM25DIFFERENTDM", true)
			stats.set_int(MPX() .. "CR_DIFFERENT_DM", 25)
			stats.set_bool(MPX() .. "AWD_FM25DIFFERENTRACES", true)
			stats.set_int(MPX() .. "CR_DIFFERENT_RACES", 25)
			stats.set_int(MPX() .. "AWD_PARACHUTE_JUMPS_20M", 25)
			stats.set_int(MPX() .. "AWD_PARACHUTE_JUMPS_50M", 25)
			stats.set_int(MPX() .. "AWD_FMBASEJMP", 25)
			stats.set_bool(MPX() .. "AWD_FMATTGANGHQ", true)
			stats.set_bool(MPX() .. "AWD_FM6DARTCHKOUT", true)
			stats.set_int(MPX() .. "AWD_FM_GOLF_BIRDIES", 25)
			stats.set_bool(MPX() .. "AWD_FM_GOLF_HOLE_IN_1", true)
			stats.set_int(MPX() .. "AWD_FM_TENNIS_ACE", 25)
			stats.set_int(MPX() .. "AWD_FMBBETWIN", 50000)
			stats.set_int(MPX() .. "AWD_LAPDANCES", 25)
			stats.set_int(MPX() .. "AWD_FMCRATEDROPS", 25)
			stats.set_bool(MPX() .. "AWD_FMPICKUPDLCCRATE1ST", true)
			stats.set_bool(MPX() .. "AWD_FM25DIFITEMSCLOTHES", true)
			stats.set_int(MPX() .. "AWD_NO_HAIRCUTS", 25)
			stats.set_bool(MPX() .. "AWD_BUY_EVERY_GUN", true)
			stats.set_bool(MPX() .. "AWD_DRIVELESTERCAR5MINS", true)
			stats.set_bool(MPX() .. "AWD_FMTATTOOALLBODYPARTS", true)
			stats.set_int(MPX() .. "AWD_DROPOFF_CAP_PACKAGES", 100)
			stats.set_int(MPX() .. "AWD_PICKUP_CAP_PACKAGES", 100)
			stats.set_int(MPX() .. "AWD_MENTALSTATE_TO_NORMAL", 50)
			stats.set_bool(MPX() .. "AWD_STORE_20_CAR_IN_GARAGES", true)
			stats.set_int(MPX() .. "AWD_TRADE_IN_YOUR_CSYONS26PERTY", 25)
			stats.set_bool(MPX() .. "AWD_DAILYOBJWEEKBONUS", true)
			stats.set_bool(MPX() .. "AWD_DAILYOBJMONTHBONUS", true)
			stats.set_int(MPX() .. "AWD_FM_CR_DM_MADE", 25)
			stats.set_int(MPX() .. "AWD_FM_CR_RACES_MADE", 25)
			stats.set_int(MPX() .. "AWD_FM_CR_PLAYED_BY_PEEP", 1598)
			stats.set_int(MPX() .. "AWD_FM_CR_MISSION_SCORE", 100)
			stats.set_bool(MPX() .. "CL_DRIVE_RALLY", true)
			stats.set_bool(MPX() .. "CL_PLAY_GTA_RACE", true)
			stats.set_bool(MPX() .. "CL_PLAY_BOAT_RACE", true)
			stats.set_bool(MPX() .. "CL_PLAY_FOOT_RACE", true)
			stats.set_bool(MPX() .. "CL_PLAY_TEAM_DM", true)
			stats.set_bool(MPX() .. "CL_PLAY_VEHICLE_DM", true)
			stats.set_bool(MPX() .. "CL_PLAY_MISSION_CONTACT", true)
			stats.set_bool(MPX() .. "CL_PLAY_A_PLAYLIST", true)
			stats.set_bool(MPX() .. "CL_PLAY_POINT_TO_POINT", true)
			stats.set_bool(MPX() .. "CL_PLAY_ONE_ON_ONE_DM", true)
			stats.set_bool(MPX() .. "CL_PLAY_ONE_ON_ONE_RACE", true)
			stats.set_bool(MPX() .. "CL_SURV_A_BOUNTY", true)
			stats.set_bool(MPX() .. "CL_SET_WANTED_LVL_ON_PLAY", true)
			stats.set_bool(MPX() .. "CL_GANG_BACKUP_GANGS", true)
			stats.set_bool(MPX() .. "CL_GANG_BACKUP_LOST", true)
			stats.set_bool(MPX() .. "CL_GANG_BACKUP_VAGOS", true)
			stats.set_bool(MPX() .. "CL_CALL_MERCENARIES", true)
			stats.set_bool(MPX() .. "CL_PHONE_MECH_DROP_CAR", true)
			stats.set_bool(MPX() .. "CL_GONE_OFF_RADAR", true)
			stats.set_bool(MPX() .. "CL_FILL_TITAN", true)
			stats.set_bool(MPX() .. "CL_MOD_CAR_USING_APP", true)
			stats.set_bool(MPX() .. "CL_MOD_CAR_USING_APP", true)
			stats.set_bool(MPX() .. "CL_BUY_INSURANCE", true)
			stats.set_bool(MPX() .. "CL_BUY_GARAGE", true)
			stats.set_bool(MPX() .. "CL_ENTER_FRIENDS_HOUSE", true)
			stats.set_bool(MPX() .. "CL_CALL_STRIPPER_HOUSE", true)
			stats.set_bool(MPX() .. "CL_CALL_FRIEND", true)
			stats.set_bool(MPX() .. "CL_SEND_FRIEND_REQUEST", true)
			stats.set_bool(MPX() .. "CL_W_WANTED_PLAYER_TV", true)
			stats.set_bool(MPX() .. "FM_INTRO_CUT_DONE", true)
			stats.set_bool(MPX() .. "FM_INTRO_MISS_DONE", true)
			stats.set_bool(MPX() .. "SHOOTINGRANGE_SEEN_TUT", true)
			stats.set_bool(MPX() .. "TENNIS_SEEN_TUTORIAL", true)
			stats.set_bool(MPX() .. "DARTS_SEEN_TUTORIAL", true)
			stats.set_bool(MPX() .. "ARMWRESTLING_SEEN_TUTORIAL", true)
			stats.set_bool(MPX() .. "HAS_WATCHED_BENNY_CUTSCE", true)
			stats.set_int(MPX() .. "NO_PHOTOS_TAKEN", 100)
			stats.set_int(MPX() .. "BOUNTSONU", 200)
			stats.set_int(MPX() .. "BOUNTPLACED", 500)
			stats.set_int(MPX() .. "BETAMOUNT", 500)
			stats.set_int(MPX() .. "CRARMWREST", 500)
			stats.set_int(MPX() .. "CRBASEJUMP", 500)
			stats.set_int(MPX() .. "CRDARTS", 500)
			stats.set_int(MPX() .. "CRDM", 500)
			stats.set_int(MPX() .. "CRGANGHIDE", 500)
			stats.set_int(MPX() .. "CRGOLF", 500)
			stats.set_int(MPX() .. "CRHORDE", 500)
			stats.set_int(MPX() .. "CRMISSION", 500)
			stats.set_int(MPX() .. "CRSHOOTRNG", 500)
			stats.set_int(MPX() .. "CRTENNIS", 500)
			stats.set_int(MPX() .. "NO_TIMES_CINEMA", 500)
			stats.set_int(MPX() .. "CHAR_WEAP_UNLOCKED", -1)
			stats.set_int(MPX() .. "CHAR_WEAP_UNLOCKED2", -1)
			stats.set_int(MPX() .. "CHAR_WEAP_UNLOCKED3", -1)
			stats.set_int(MPX() .. "CHAR_WEAP_UNLOCKED4", -1)
			stats.set_int(MPX() .. "CHAR_WEAP_ADDON_1_UNLCK", -1)
			stats.set_int(MPX() .. "CHAR_WEAP_ADDON_2_UNLCK", -1)
			stats.set_int(MPX() .. "CHAR_WEAP_ADDON_3_UNLCK", -1)
			stats.set_int(MPX() .. "CHAR_WEAP_ADDON_4_UNLCK", -1)
			stats.set_int(MPX() .. "CHAR_WEAP_FREE", -1)
			stats.set_int(MPX() .. "CHAR_WEAP_FREE2", -1)
			stats.set_int(MPX() .. "CHAR_FM_WEAP_FREE", -1)
			stats.set_int(MPX() .. "CHAR_FM_WEAP_FREE2", -1)
			stats.set_int(MPX() .. "CHAR_FM_WEAP_FREE3", -1)
			stats.set_int(MPX() .. "CHAR_FM_WEAP_FREE4", -1)
			stats.set_int(MPX() .. "CHAR_WEAP_PURCHASED", -1)
			stats.set_int(MPX() .. "CHAR_WEAP_PURCHASED2", -1)
			stats.set_int(MPX() .. "WEAPON_PICKUP_BITSET", -1)
			stats.set_int(MPX() .. "WEAPON_PICKUP_BITSET2", -1)
			stats.set_int(MPX() .. "CHAR_FM_WEAP_UNLOCKED", -1)
			stats.set_int(MPX() .. "NO_WEAPONS_UNLOCK", -1)
			stats.set_int(MPX() .. "NO_WEAPON_MODS_UNLOCK", -1)
			stats.set_int(MPX() .. "NO_WEAPON_CLR_MOD_UNLOCK", -1) 
			stats.set_int(MPX() .. "CHAR_FM_WEAP_UNLOCKED2", -1)
			stats.set_int(MPX() .. "CHAR_FM_WEAP_UNLOCKED3", -1)
			stats.set_int(MPX() .. "CHAR_FM_WEAP_UNLOCKED4", -1)
			stats.set_int(MPX() .. "CHAR_KIT_1_FM_UNLCK", -1)
			stats.set_int(MPX() .. "CHAR_KIT_2_FM_UNLCK", -1)
			stats.set_int(MPX() .. "CHAR_KIT_3_FM_UNLCK", -1)
			stats.set_int(MPX() .. "CHAR_KIT_4_FM_UNLCK", -1)
			stats.set_int(MPX() .. "CHAR_KIT_5_FM_UNLCK", -1)
			stats.set_int(MPX() .. "CHAR_KIT_6_FM_UNLCK", -1)
			stats.set_int(MPX() .. "CHAR_KIT_7_FM_UNLCK", -1)
			stats.set_int(MPX() .. "CHAR_KIT_8_FM_UNLCK", -1)
			stats.set_int(MPX() .. "CHAR_KIT_9_FM_UNLCK", -1)
			stats.set_int(MPX() .. "CHAR_KIT_10_FM_UNLCK", -1)
			stats.set_int(MPX() .. "CHAR_KIT_11_FM_UNLCK", -1)
			stats.set_int(MPX() .. "CHAR_KIT_12_FM_UNLCK", -1)
			stats.set_int(MPX() .. "CHAR_KIT_FM_PURCHASE", -1)
			stats.set_int(MPX() .. "CHAR_WEAP_FM_PURCHASE", -1)
			stats.set_int(MPX() .. "CHAR_WEAP_FM_PURCHASE2", -1)
			stats.set_int(MPX() .. "CHAR_WEAP_FM_PURCHASE3", -1)
			stats.set_int(MPX() .. "CHAR_WEAP_FM_PURCHASE4", -1)
			stats.set_int(MPX() .. "FIREWORK_TYPE_1_WHITE", 1000)
			stats.set_int(MPX() .. "FIREWORK_TYPE_1_RED", 1000)
			stats.set_int(MPX() .. "FIREWORK_TYPE_1_BLUE", 1000)
			stats.set_int(MPX() .. "FIREWORK_TYPE_2_WHITE", 1000)
			stats.set_int(MPX() .. "FIREWORK_TYPE_2_RED", 1000)
			stats.set_int(MPX() .. "FIREWORK_TYPE_2_BLUE", 1000)
			stats.set_int(MPX() .. "FIREWORK_TYPE_3_WHITE", 1000)
			stats.set_int(MPX() .. "FIREWORK_TYPE_3_RED", 1000)
			stats.set_int(MPX() .. "FIREWORK_TYPE_3_BLUE", 1000)
			stats.set_int(MPX() .. "FIREWORK_TYPE_4_WHITE", 1000)
			stats.set_int(MPX() .. "FIREWORK_TYPE_4_RED", 1000)
			stats.set_int(MPX() .. "FIREWORK_TYPE_4_BLUE", 1000)
			stats.set_int(MPX() .. "WEAP_FM_ADDON_PURCH", -1)
		for i = 2, 19 do stats.set_int(MPX() .. "WEAP_FM_ADDON_PURCH"..i, -1) end
		for j = 1, 19 do stats.set_int(MPX() .. "CHAR_FM_WEAP_ADDON_"..j.."_UNLCK", -1) end
		for m = 1, 41 do stats.set_int(MPX() .. "CHAR_KIT_"..m.."_FM_UNLCK", -1) end
		for l = 2, 41 do stats.set_int(MPX() .. "CHAR_KIT_FM_PURCHASE"..l, -1) end
			stats.set_int(MPX() .. "AWD_FMTIME5STARWANTED", 120)
			stats.set_int(MPX() .. "AWD_5STAR_WANTED_AVOIDANCE", 50)
			stats.set_int(MPX() .. "AWD_FMSHOOTDOWNCOPHELI", 25)
			stats.set_int(MPX() .. "AWD_VEHICLES_JACKEDR", 500)
			stats.set_int(MPX() .. "AWD_SECURITY_CARS_ROBBED", 25)
			stats.set_int(MPX() .. "AWD_HOLD_UP_SHOPS", 20)
			stats.set_int(MPX() .. "AWD_ODISTRACTCOPSNOEATH", 25)
			stats.set_int(MPX() .. "AWD_ENEMYDRIVEBYKILLS", 100)
			stats.set_int(MPX() .. "CHAR_WANTED_LEVEL_TIME5STAR", 18000000)
			stats.set_int(MPX() .. "CARS_COPS_EXPLODED", 300)
			stats.set_int(MPX() .. "BIKES_EXPLODED", 100)
			stats.set_int(MPX() .. "BOATS_EXPLODED", 168)
			stats.set_int(MPX() .. "HELIS_EXPLODED", 98)
			stats.set_int(MPX() .. "PLANES_EXPLODED", 138)
			stats.set_int(MPX() .. "QUADBIKE_EXPLODED", 50)
			stats.set_int(MPX() .. "BICYCLE_EXPLODED", 48)
			stats.set_int(MPX() .. "SUBMARINE_EXPLODED", 28)
			stats.set_int(MPX() .. "TIRES_POPPED_BY_GUNSHOT", 500)
			stats.set_int(MPX() .. "NUMBER_CRASHES_CARS", 300)
			stats.set_int(MPX() .. "NUMBER_CRASHES_BIKES", 300)
			stats.set_int(MPX() .. "BAILED_FROM_VEHICLE", 300)
			stats.set_int(MPX() .. "NUMBER_CRASHES_QUADBIKES", 300)
			stats.set_int(MPX() .. "NUMBER_STOLEN_COP_VEHICLE", 300)
			stats.set_int(MPX() .. "NUMBER_STOLEN_CARS", 300)
			stats.set_int(MPX() .. "NUMBER_STOLEN_BIKES", 300)
			stats.set_int(MPX() .. "NUMBER_STOLEN_BOATS", 300)
			stats.set_int(MPX() .. "NUMBER_STOLEN_HELIS", 300)
			stats.set_int(MPX() .. "NUMBER_STOLEN_PLANES", 300)
			stats.set_int(MPX() .. "NUMBER_STOLEN_QUADBIKES", 300)
			stats.set_int(MPX() .. "NUMBER_STOLEN_BICYCLES", 300)
			stats.set_int(MPX() .. "MC_CONTRIBUTION_POINTS", 1000)
			stats.set_int(MPX() .. "MEMBERSMARKEDFORDEATH", 700)
			stats.set_int(MPX() .. "MCKILLS", 500)
			stats.set_int(MPX() .. "MCDEATHS", 700)
			stats.set_int(MPX() .. "RIVALPRESIDENTKILLS", 700)
			stats.set_int(MPX() .. "RIVALCEOANDVIPKILLS", 700)
			stats.set_int(MPX() .. "CLUBHOUSECONTRACTSCOMPLETE", 700)
			stats.set_int(MPX() .. "CLUBHOUSECONTRACTEARNINGS", 32698547)
			stats.set_int(MPX() .. "CLUBCHALLENGESCOMPLETED", 700)
			stats.set_int(MPX() .. "MEMBERCHALLENGESCOMPLETED", 700)
			stats.set_int(MPX() .. "GHKILLS", 500)
			stats.set_int(MPX() .. "HORDELVL", 10)
			stats.set_int(MPX() .. "HORDKILLS", 500)
			stats.set_int(MPX() .. "UNIQUECRATES", 500)
			stats.set_int(MPX() .. "BJWINS", 500)
			stats.set_int(MPX() .. "HORDEWINS", 500)
			stats.set_int(MPX() .. "MCMWINS", 500)
			stats.set_int(MPX() .. "GANGHIDWINS", 500)
			stats.set_int(MPX() .. "KILLS", 800)
			stats.set_int(MPX() .. "HITS_PEDS_VEHICLES", 100)
			stats.set_int(MPX() .. "SHOTS", 1000)
			stats.set_int(MPX() .. "HEADSHOTS", 100)
			stats.set_int(MPX() .. "KILLS_ARMED", 650)
			stats.set_int(MPX() .. "SUCCESSFUL_COUNTERS", 100)
			stats.set_int(MPX() .. "KILLS_PLAYERS", 3593)
			stats.set_int(MPX() .. "DEATHS_PLAYER", 1002)
			stats.set_int(MPX() .. "KILLS_STEALTH", 100)
			stats.set_int(MPX() .. "KILLS_INNOCENTS", 500)
			stats.set_int(MPX() .. "KILLS_ENEMY_GANG_MEMBERS", 500)
			stats.set_int(MPX() .. "KILLS_FRIENDLY_GANG_MEMBERS", 500)
			stats.set_int(MPX() .. "KILLS_BY_OTHERS", 100)
			stats.set_int(MPX() .. "BIGGEST_VICTIM_KILLS", 500)
			stats.set_int(MPX() .. "ARCHENEMY_KILLS", 500)
			stats.set_int(MPX() .. "KILLS_COP", 4500)
			stats.set_int(MPX() .. "KILLS_SWAT", 500)
			stats.set_int(MPX() .. "STARS_ATTAINED", 5000)
			stats.set_int(MPX() .. "STARS_EVADED", 4000)
			stats.set_int(MPX() .. "VEHEXPORTED", 500)
			stats.set_int(MPX() .. "TOTAL_NO_SHOPS_HELD_UP", 100)
			stats.set_int(MPX() .. "CR_GANGATTACK_CITY", 1000)
			stats.set_int(MPX() .. "CR_GANGATTACK_COUNTRY", 1000)
			stats.set_int(MPX() .. "CR_GANGATTACK_LOST", 1000)
			stats.set_int(MPX() .. "CR_GANGATTACK_VAGOS", 1000)
			stats.set_int(MPX() .. "NO_NON_CONTRACT_RACE_WIN", 500)
			stats.set_int(MPX() .. "DIED_IN_DROWNING", 833)
			stats.set_int(MPX() .. "DIED_IN_DROWNINGINVEHICLE", 833)
			stats.set_int(MPX() .. "DIED_IN_EXPLOSION", 833)
			stats.set_int(MPX() .. "DIED_IN_FALL", 833)
			stats.set_int(MPX() .. "DIED_IN_FIRE", 833)
			stats.set_int(MPX() .. "DIED_IN_ROAD", 833)
			stats.set_int(MPX() .. "GRENADE_ENEMY_KILLS", 50)
			stats.set_int(MPX() .. "MICROSMG_ENEMY_KILLS", 500)
			stats.set_int(MPX() .. "SMG_ENEMY_KILLS", 500)
			stats.set_int(MPX() .. "ASLTSMG_ENEMY_KILLS", 500)
			stats.set_int(MPX() .. "CRBNRIFLE_ENEMY_KILLS", 500)
			stats.set_int(MPX() .. "ADVRIFLE_ENEMY_KILLS", 500)
			stats.set_int(MPX() .. "MG_ENEMY_KILLS", 500)
			stats.set_int(MPX() .. "CMBTMG_ENEMY_KILLS", 500)
			stats.set_int(MPX() .. "ASLTMG_ENEMY_KILLS", 500)
			stats.set_int(MPX() .. "RPG_ENEMY_KILLS", 500)
			stats.set_int(MPX() .. "PISTOL_ENEMY_KILLS", 500)
			stats.set_int(MPX() .. "PLAYER_HEADSHOTS", 500)
			stats.set_int(MPX() .. "SAWNOFF_ENEMY_KILLS", 500)
			stats.set_int(MPX() .. "STKYBMB_ENEMY_KILLS", 50)
			stats.set_int(MPX() .. "UNARMED_ENEMY_KILLS", 50)
			stats.set_int(MPX() .. "SNIPERRFL_ENEMY_KILLS", 500)
			stats.set_int(MPX() .. "HVYSNIPER_ENEMY_KILLS", 500)
			stats.set_int(MPX() .. "AWD_50_VEHICLES_BLOWNUP", 500)
			stats.set_int(MPX() .. "CARS_EXPLODED", 500)
			stats.set_int(MPX() .. "AWD_CAR_EXPORT", 100)
			stats.set_int(MPX() .. "AWD_FMDRIVEWITHOUTCRASH", 30)
			stats.set_int(MPX() .. "AWD_PASSENGERTIME", 4)
			stats.set_int(MPX() .. "AWD_TIME_IN_HELICOPTER", 4)
			stats.set_int(MPX() .. "AWD_VEHICLE_JUMP_OVER_40M", 25)
			stats.set_int(MPX() .. "MOST_FLIPS_IN_ONE_JUMP", 5)
			stats.set_int(MPX() .. "MOST_SPINS_IN_ONE_JUMP", 5)
			stats.set_int(MPX() .. "CHAR_FM_VEHICLE_1_UNLCK", -1)
			stats.set_int(MPX() .. "CHAR_FM_VEHICLE_2_UNLCK", -1)
			stats.set_int(MPX() .. "NO_CARS_REPAIR", 1000)
			stats.set_int(MPX() .. "VEHICLES_SPRAYED", 500)
			stats.set_int(MPX() .. "NUMBER_NEAR_MISS_NOCRASH", 500)
			stats.set_int(MPX() .. "USJS_FOUND", 50)
			stats.set_int(MPX() .. "USJS_COMPLETED", 50)
			stats.set_int(MPX() .. "USJS_TOTAL_COMPLETED", 50)
			stats.set_int(MPX() .. "CRDEADLINE", 5)
			stats.set_int(MPX() .. "FAVOUTFITBIKETIMECURRENT", 2069146067)
			stats.set_int(MPX() .. "FAVOUTFITBIKETIME1ALLTIME", 2069146067)
			stats.set_int(MPX() .. "FAVOUTFITBIKETYPECURRENT", 2069146067)
			stats.set_int(MPX() .. "FAVOUTFITBIKETYPEALLTIME", 2069146067)
			stats.set_int(MPX() .. "LONGEST_WHEELIE_DIST", 1000)
			stats.set_int(MPX() .. "RACES_WON", 50)
			stats.set_int(MPX() .. "COUNT_HOTRING_RACE", 20)
			stats.set_bool(MPX() .. "AWD_FMFURTHESTWHEELIE", true)
			stats.set_bool(MPX() .. "AWD_FMFULLYMODDEDCAR", true)
			stats.set_int(MPX() .. "AWD_100_HEADSHOTS", 500)
			stats.set_int(MPX() .. "AWD_FMOVERALLKILLS", 1000)
			stats.set_int(MPX() .. "AWD_FMKILLBOUNTY", 25)
			stats.set_int(MPX() .. "AWD_FM_DM_3KILLSAMEGUY", 50)
			stats.set_int(MPX() .. "AWD_FM_DM_KILLSTREAK", 100)
			stats.set_int(MPX() .. "AWD_FM_DM_STOLENKILL", 50)
			stats.set_int(MPX() .. "AWD_FM_DM_TOTALKILLS", 500)
			stats.set_bool(MPX() .. "AWD_FMKILLSTREAKSDM", true)
			stats.set_bool(MPX() .. "AWD_FMMOSTKILLSGANGHIDE", true)
			stats.set_bool(MPX() .. "AWD_FMMOSTKILLSSURVIVE", true)
			stats.set_int(MPX() .. "AWD_FMREVENGEKILLSDM", 50)
			stats.set_int(MPX() .. "AWD_KILL_CARRIER_CAPTURE", 100)
			stats.set_int(MPX() .. "AWD_NIGHTVISION_KILLS", 100)
			stats.set_int(MPX() .. "AWD_KILL_PSYCHOPATHS", 100)
			stats.set_int(MPX() .. "AWD_TAKEDOWNSMUGPLANE", 50)
			stats.set_int(MPX() .. "AWD_100_KILLS_PISTOL", 500)
			stats.set_int(MPX() .. "AWD_100_KILLS_SMG", 500)
			stats.set_int(MPX() .. "AWD_100_KILLS_SHOTGUN", 500)
			stats.set_int(MPX() .. "ASLTRIFLE_ENEMY_KILLS", 500)
			stats.set_int(MPX() .. "AWD_100_KILLS_SNIPER", 500)
			stats.set_int(MPX() .. "MG_ENEMY_KILLS", 500)
			stats.set_int(MPX() .. "AWD_25_KILLS_STICKYBOMBS", 50)
			stats.set_int(MPX() .. "AWD_50_KILLS_GRENADES", 50)
			stats.set_int(MPX() .. "AWD_50_KILLS_ROCKETLAUNCH", 50)
			stats.set_int(MPX() .. "AWD_20_KILLS_MELEE", 50)
			stats.set_int(MPX() .. "AWD_CAR_BOMBS_ENEMY_KILLS", 25)
			stats.set_int(MPX() .. "MELEEKILLS", 700)
			stats.set_int(MPX() .. "HITS", 10000)
			stats.set_int(MPX() .. "DEATHS", 499)
			stats.set_int(MPX() .. "HIGHEST_SKITTLES", 900)
			stats.set_int(MPX() .. "NUMBER_NEAR_MISS", 1000)
			stats.set_int(MPX() .. "AWD_FINISH_HEISTS", 50)
			stats.set_int(MPX() .. "AWD_FINISH_HEIST_SETUP_JOB", 50)
			stats.set_int(MPX() .. "AWD_COMPLETE_HEIST_NOT_DIE", -1)
			stats.set_bool(MPX() .. "AWD_FINISH_HEIST_NO_DAMAGE", true)
			stats.set_int(MPX() .. "AWD_WIN_GOLD_MEDAL_HEISTS", 25)
			stats.set_int(MPX() .. "AWD_DO_HEIST_AS_MEMBER", 25)
			stats.set_int(MPX() .. "AWD_DO_HEIST_AS_THE_LEADER", 25)
			stats.set_bool(MPX() .. "AWD_SPLIT_HEIST_TAKE_EVENLY", true)
			stats.set_bool(MPX() .. "AWD_ACTIVATE_2_PERSON_KEY", true)
			stats.set_int(MPX() .. "AWD_CONTROL_CROWDS", 25)
			stats.set_bool(MPX() .. "AWD_ALL_ROLES_HEIST", true)
			stats.set_int(MPX() .. "HEIST_COMPLETION", 25)
			stats.set_int(MPX() .. "HEISTS_ORGANISED", -1)
			stats.set_int(MPX() .. "HEIST_START", -1)
			stats.set_int(MPX() .. "HEIST_END", -1)
			stats.set_int(MPX() .. "CUTSCENE_MID_PRISON", -1)
			stats.set_int(MPX() .. "CUTSCENE_MID_HUMANE", -1)
			stats.set_int(MPX() .. "CUTSCENE_MID_NARC", -1)
			stats.set_int(MPX() .. "CUTSCENE_MID_ORNATE", -1)
			stats.set_int(MPX() .. "CR_FLEECA_PREP_1", -1)
			stats.set_int(MPX() .. "CR_FLEECA_PREP_2", -1)
			stats.set_int(MPX() .. "CR_FLEECA_FINALE", -1)
			stats.set_int(MPX() .. "CR_PRISON_PLANE", -1)
			stats.set_int(MPX() .. "CR_PRISON_BUS", -1)
			stats.set_int(MPX() .. "CR_PRISON_STATION", -1)
			stats.set_int(MPX() .. "CR_PRISON_UNFINISHED_BIZ", -1)
			stats.set_int(MPX() .. "CR_PRISON_FINALE", -1)
			stats.set_int(MPX() .. "CR_HUMANE_KEY_CODES", -1)
			stats.set_int(MPX() .. "CR_HUMANE_ARMORDILLOS", -1)
			stats.set_int(MPX() .. "CR_HUMANE_EMP", -1)
			stats.set_int(MPX() .. "CR_HUMANE_VALKYRIE", -1)
			stats.set_int(MPX() .. "CR_HUMANE_FINALE", -1)
			stats.set_int(MPX() .. "CR_NARC_COKE", -1)
			stats.set_int(MPX() .. "CR_NARC_TRASH_TRUCK", -1)
			stats.set_int(MPX() .. "CR_NARC_BIKERS", -1)
			stats.set_int(MPX() .. "CR_NARC_WEED", -1)
			stats.set_int(MPX() .. "CR_NARC_STEAL_METH", -1)
			stats.set_int(MPX() .. "CR_NARC_FINALE", -1)
			stats.set_int(MPX() .. "CR_PACIFIC_TRUCKS", -1)
			stats.set_int(MPX() .. "CR_PACIFIC_WITSEC", -1)
			stats.set_int(MPX() .. "CR_PACIFIC_HACK", -1)
			stats.set_int(MPX() .. "CR_PACIFIC_BIKES", -1)
			stats.set_int(MPX() .. "CR_PACIFIC_CONVOY", -1)
			stats.set_int(MPX() .. "CR_PACIFIC_FINALE", -1)
			stats.set_int(MPX() .. "HEIST_ACH_TRACKER", -1)
			stats.set_int(MPX() .. "WIN_GOLD_MEDAL_HEISTS", 25)
			stats.set_bool(MPX() .. "AWD_FLEECA_FIN", true)
			stats.set_bool(MPX() .. "AWD_PRISON_FIN", true)
			stats.set_bool(MPX() .. "AWD_HUMANE_FIN", true)
			stats.set_bool(MPX() .. "AWD_SERIESA_FIN", true)
			stats.set_bool(MPX() .. "AWD_PACIFIC_FIN", true)
			stats.set_bool(MPX() .. "AWD_HST_ORDER", true)
			stats.set_bool(MPX() .. "AWD_COMPLET_HEIST_MEM", true)
			stats.set_bool(MPX() .. "AWD_COMPLET_HEIST_1STPER", true)
			stats.set_bool(MPX() .. "AWD_HST_SAME_TEAM", true)
			stats.set_bool(MPX() .. "AWD_HST_ULT_CHAL", true)
			stats.set_bool(MPX() .. "AWD_MATCHING_OUTFIT_HEIST", true)
			stats.set_bool(MPX() .. "HEIST_PLANNING_DONE_PRINT", true)
			stats.set_bool(MPX() .. "HEIST_PLANNING_DONE_HELP_0", true)
			stats.set_bool(MPX() .. "HEIST_PLANNING_DONE_HELP_1", true)
			stats.set_bool(MPX() .. "HEIST_PRE_PLAN_DONE_HELP_0", true)
			stats.set_bool(MPX() .. "HEIST_CUTS_DONE_FINALE", true)
			stats.set_bool(MPX() .. "HEIST_IS_TUTORIAL", true)
			stats.set_bool(MPX() .. "HEIST_STRAND_INTRO_DONE", true)
			stats.set_bool(MPX() .. "HEIST_CUTS_DONE_ORNATE", true)
			stats.set_bool(MPX() .. "HEIST_CUTS_DONE_PRISON", true)
			stats.set_bool(MPX() .. "HEIST_CUTS_DONE_BIOLAB", true)
			stats.set_bool(MPX() .. "HEIST_CUTS_DONE_NARCOTIC", true)
			stats.set_bool(MPX() .. "HEIST_CUTS_DONE_TUTORIAL", true)
			stats.set_bool(MPX() .. "HEIST_AWARD_DONE_PREP", true)
			stats.set_bool(MPX() .. "HEIST_AWARD_BOUGHT_IN", true)
			stats.set_int(MPX() .. "HEIST_PLANNING_STAGE", -1)
			stats.set_int(MPX() .. "GANGOPS_HEIST_STATUS", -1)
			stats.set_int(MPX() .. "GANGOPS_HEIST_STATUS", -229384)
			stats.set_int(MPX() .. "GANGOPS_FM_MISSION_CSYONS26G", -1)
			stats.set_int(MPX() .. "GANGOPS_FLOW_MISSION_CSYONS26G", -1)
			stats.set_int(MPX() .. "GANGOPS_ALLINORDER", 100)
			stats.set_int(MPX() .. "GANGOPS_LOYALTY", 100)
			stats.set_int(MPX() .. "GANGOPS_CRIMMASMD", 100)
			stats.set_int(MPX() .. "GANGOPS_LOYALTY2", 100)
			stats.set_int(MPX() .. "GANGOPS_LOYALTY3", 100)
			stats.set_int(MPX() .. "GANGOPS_CRIMMASMD2", 100)
			stats.set_int(MPX() .. "GANGOPS_CRIMMASMD3", 100)
			stats.set_int(MPX() .. "GANGOPS_SUPPORT", 100)
			stats.set_int(MPX() .. "CR_GANGOP_MORGUE", 10)
			stats.set_int(MPX() .. "CR_GANGOP_DELUXO", 10)
			stats.set_int(MPX() .. "CR_GANGOP_SERVERFARM", 10)
			stats.set_int(MPX() .. "CR_GANGOP_IAABASE_FIN", 10)
			stats.set_int(MPX() .. "CR_GANGOP_STEALOSPREY", 10)
			stats.set_int(MPX() .. "CR_GANGOP_FOUNDRY", 10)
			stats.set_int(MPX() .. "CR_GANGOP_RIOTVAN", 10)
			stats.set_int(MPX() .. "CR_GANGOP_SUBMARINECAR", 10)
			stats.set_int(MPX() .. "CR_GANGOP_SUBMARINE_FIN", 10)
			stats.set_int(MPX() .. "CR_GANGOP_PREDATOR", 10)
			stats.set_int(MPX() .. "CR_GANGOP_BMLAUNCHER", 10)
			stats.set_int(MPX() .. "CR_GANGOP_BCCUSTOM", 10)
			stats.set_int(MPX() .. "CR_GANGOP_STEALTHTANKS", 10)
			stats.set_int(MPX() .. "CR_GANGOP_SPYPLANE", 10)
			stats.set_int(MPX() .. "CR_GANGOP_FINALE", 10)
			stats.set_int(MPX() .. "CR_GANGOP_FINALE_P2", 10)
			stats.set_int(MPX() .. "CR_GANGOP_FINALE_P3", 10)
			stats.set_bool(MPX() .. "AWD_GANGOPS_IAA", true)
			stats.set_bool(MPX() .. "AWD_GANGOPS_SUBMARINE", true)
			stats.set_bool(MPX() .. "AWD_GANGOPS_MISSILE", true)
			stats.set_bool(MPX() .. "AWD_GANGOPS_ALLINORDER", true)
			stats.set_bool(MPX() .. "AWD_GANGOPS_LOYALTY", true)
			stats.set_bool(MPX() .. "AWD_GANGOPS_LOYALTY2", true)
			stats.set_bool(MPX() .. "AWD_GANGOPS_LOYALTY3", true)
			stats.set_bool(MPX() .. "AWD_GANGOPS_CRIMMASMD", true)
			stats.set_bool(MPX() .. "AWD_GANGOPS_CRIMMASMD2", true)
			stats.set_bool(MPX() .. "AWD_GANGOPS_CRIMMASMD3", true)
			stats.set_bool(MPX() .. "AWD_GANGOPS_SUPPORT", true)
		for j = 0, 63 do stats.set_bool_masked(MPX().."GANGOPSPSTAT_BOOL0", true, j, MPX()) end
			stats.set_masked_int(MPX().."DLCSMUGCHARPSTAT_INT260", 3, 16, 8)
			stats.set_masked_int(MPX().."BUSINESSBATPSTAT_INT260", 3, 24, 8)
			stats.set_masked_int(MPX().."BUSINESSBATPSTAT_INT260", 3, 32, 8)
			stats.set_masked_int(MPX().."BUSINESSBATPSTAT_INT260", 3, 40, 8)
			stats.set_masked_int(MPX().."BUSINESSBATPSTAT_INT260", 3, 48, 8)
			stats.set_int(MPX() .. "AWD_DANCE_TO_SOLOMUN", 120)
			stats.set_int(MPX() .. "AWD_DANCE_TO_TALEOFUS", 120)
			stats.set_int(MPX() .. "AWD_DANCE_TO_DIXON", 120)
			stats.set_int(MPX() .. "AWD_DANCE_TO_BLKMAD", 120)
			stats.set_int(MPX() .. "AWD_CLUB_DRUNK", 200)
			stats.set_int(MPX() .. "NIGHTCLUB_VIP_APPEAR", 700)
			stats.set_int(MPX() .. "NIGHTCLUB_JOBS_DONE", 700)
			stats.set_int(MPX() .. "NIGHTCLUB_EARNINGS", 5721002)
			stats.set_int(MPX() .. "HUB_SALES_COMPLETED", 1001)
			stats.set_int(MPX() .. "HUB_EARNINGS", 20721002)
			stats.set_int(MPX() .. "DANCE_COMBO_DURATION_MINS", 3600000)
			stats.set_int(MPX() .. "NIGHTCLUB_PLAYER_APPEAR", 100)
			stats.set_int(MPX() .. "LIFETIME_HUB_GOODS_SOLD", 784672)
			stats.set_int(MPX() .. "LIFETIME_HUB_GOODS_MADE", 507822)
			stats.set_int(MPX() .. "DANCEPERFECTOWNCLUB", 120)
			stats.set_int(MPX() .. "NUMUNIQUEPLYSINCLUB", 120)
			stats.set_int(MPX() .. "DANCETODIFFDJS", 4)
			stats.set_int(MPX() .. "NIGHTCLUB_HOTSPOT_TIME_MS", 3600000)
			stats.set_int(MPX() .. "NIGHTCLUB_CONT_TOTAL", 20)
			stats.set_int(MPX() .. "NIGHTCLUB_CONT_MISSION", -1)
			stats.set_int(MPX() .. "CLUB_CONTRABAND_MISSION", 1000)
			stats.set_int(MPX() .. "HUB_CONTRABAND_MISSION", 1000)
			stats.set_bool(MPX() .. "AWD_CLUB_HOTSPOT", true)
			stats.set_bool(MPX() .. "AWD_CLUB_CLUBBER", true)
			stats.set_bool(MPX() .. "AWD_CLUB_COORD", true)
		for j = 0, 63 do stats.set_bool_masked(MPX().."BUSINESSBATPSTAT_BOOL0", true, j, MPX()) stats.set_bool_masked(MPX().."BUSINESSBATPSTAT_BOOL1", true, j, MPX()) end
		if (stats.get_masked_int(MPX().."BUSINESSBATPSTAT_INT380", 0, 8) <20) then stats.set_masked_int(MPX().."BUSINESSBATPSTAT_INT380", 20, 0, 8) end
			stats.set_masked_int(MPX().."BUSINESSBATPSTAT_INT379", 50, 8, 8)
			stats.set_masked_int(MPX().."BUSINESSBATPSTAT_INT379", 100, 16, 8) 
			stats.set_masked_int(MPX().."BUSINESSBATPSTAT_INT379", 20, 24, 8) 
			stats.set_masked_int(MPX().."BUSINESSBATPSTAT_INT379", 80, 32, 8) 
			stats.set_masked_int(MPX().."BUSINESSBATPSTAT_INT379", 60, 40, 8) 
			stats.set_masked_int(MPX().."BUSINESSBATPSTAT_INT379", 40, 48, 8) 
			stats.set_masked_int(MPX().."BUSINESSBATPSTAT_INT379", 10, 56, 8)
			stats.set_int(MPX() .. "ARN_BS_TRINKET_TICKERS", -1)
			stats.set_int(MPX() .. "ARN_BS_TRINKET_SAVED", -1)
			stats.set_int(MPX() .. "AWD_WATCH_YOUR_STEP", 50)
			stats.set_int(MPX() .. "AWD_TOWER_OFFENSE", 50)
			stats.set_int(MPX() .. "AWD_READY_FOR_WAR", 50)
			stats.set_int(MPX() .. "AWD_THROUGH_A_LENS", 50)
			stats.set_int(MPX() .. "AWD_SPINNER", 50)
			stats.set_int(MPX() .. "AWD_YOUMEANBOOBYTRAPS", 50)
			stats.set_int(MPX() .. "AWD_MASTER_BANDITO", 50)
			stats.set_int(MPX() .. "AWD_SITTING_DUCK", 50)
			stats.set_int(MPX() .. "AWD_CROWDPARTICIPATION", 50)
			stats.set_int(MPX() .. "AWD_KILL_OR_BE_KILLED", 50)
			stats.set_int(MPX() .. "AWD_MASSIVE_SHUNT", 50)
			stats.set_int(MPX() .. "AWD_YOURE_OUTTA_HERE", 200)
			stats.set_int(MPX() .. "AWD_WEVE_GOT_ONE", 50)
			stats.set_int(MPX() .. "AWD_ARENA_WAGEWORKER", 1000000)
			stats.set_int(MPX() .. "AWD_TIME_SERVED", 1000)
			stats.set_int(MPX() .. "AWD_TOP_SCORE", 55000)
			stats.set_int(MPX() .. "AWD_CAREER_WINNER", 1000)
			stats.set_int(MPX() .. "ARENAWARS_SP", 0)
			stats.set_int(MPX() .. "ARENAWARS_SKILL_LEVEL", 20)
			stats.set_int(MPX() .. "ARENAWARS_SP_LIFETIME", 100)
			stats.set_int(MPX() .. "ARENAWARS_AP", 0)
			stats.set_int(MPX() .. "ARENAWARS_AP_TIER", 1000)
			stats.set_int(MPX() .. "ARENAWARS_AP_LIFETIME", 5055000)
			stats.set_int(MPX() .. "ARENAWARS_CARRER_UNLK", -1)
			stats.set_int(MPX() .. "ARN_W_THEME_SCIFI", 1000)
			stats.set_int(MPX() .. "ARN_W_THEME_APOC", 1000)
			stats.set_int(MPX() .. "ARN_W_THEME_CONS", 1000)
			stats.set_int(MPX() .. "ARN_W_PASS_THE_BOMB", 1000)
			stats.set_int(MPX() .. "ARN_W_DETONATION", 1000)
			stats.set_int(MPX() .. "ARN_W_ARCADE_RACE", 1000)
			stats.set_int(MPX() .. "ARN_W_CTF", 1000)
			stats.set_int(MPX() .. "ARN_W_TAG_TEAM", 1000)
			stats.set_int(MPX() .. "ARN_W_DESTR_DERBY", 1000)
			stats.set_int(MPX() .. "ARN_W_CARNAGE", 1000)
			stats.set_int(MPX() .. "ARN_W_MONSTER_JAM", 1000)
			stats.set_int(MPX() .. "ARN_W_GAMES_MASTERS", 1000)
			stats.set_int(MPX() .. "ARN_L_PASS_THE_BOMB", 500)
			stats.set_int(MPX() .. "ARN_L_DETONATION", 500)
			stats.set_int(MPX() .. "ARN_L_ARCADE_RACE", 500)
			stats.set_int(MPX() .. "ARN_L_CTF", 500)
			stats.set_int(MPX() .. "ARN_L_TAG_TEAM", 500)
			stats.set_int(MPX() .. "ARN_L_DESTR_DERBY", 500)
			stats.set_int(MPX() .. "ARN_L_CARNAGE", 500)
			stats.set_int(MPX() .. "ARN_L_MONSTER_JAM", 500)
			stats.set_int(MPX() .. "ARN_L_GAMES_MASTERS", 500)
			stats.set_int(MPX() .. "NUMBER_OF_CHAMP_BOUGHT", 1000)
			stats.set_int(MPX() .. "ARN_SPECTATOR_KILLS", 1000)
			stats.set_int(MPX() .. "ARN_LIFETIME_KILLS", 1000)
			stats.set_int(MPX() .. "ARN_LIFETIME_DEATHS", 500)
			stats.set_int(MPX() .. "ARENAWARS_CARRER_WINS", 1000)
			stats.set_int(MPX() .. "ARENAWARS_CARRER_WINT", 1000)
			stats.set_int(MPX() .. "ARENAWARS_MATCHES_PLYD", 1000)
			stats.set_int(MPX() .. "ARENAWARS_MATCHES_PLYDT", 1000)
			stats.set_int(MPX() .. "ARN_SPEC_BOX_TIME_MS", 86400000)
			stats.set_int(MPX() .. "ARN_SPECTATOR_DRONE", 1000)
			stats.set_int(MPX() .. "ARN_SPECTATOR_CAMS", 1000)
			stats.set_int(MPX() .. "ARN_SMOKE", 1000)
			stats.set_int(MPX() .. "ARN_DRINK", 1000)
			stats.set_int(MPX() .. "ARN_VEH_MONSTER", 1000)
			stats.set_int(MPX() .. "ARN_VEH_MONSTER", 1000)
			stats.set_int(MPX() .. "ARN_VEH_MONSTER", 1000)
			stats.set_int(MPX() .. "ARN_VEH_CERBERUS", 1000)
			stats.set_int(MPX() .. "ARN_VEH_CERBERUS2", 1000)
			stats.set_int(MPX() .. "ARN_VEH_CERBERUS3", 1000)
			stats.set_int(MPX() .. "ARN_VEH_BRUISER", 1000)
			stats.set_int(MPX() .. "ARN_VEH_BRUISER2", 1000)
			stats.set_int(MPX() .. "ARN_VEH_BRUISER3", 1000)
			stats.set_int(MPX() .. "ARN_VEH_SLAMVAN4", 1000)
			stats.set_int(MPX() .. "ARN_VEH_SLAMVAN5", 1000)
			stats.set_int(MPX() .. "ARN_VEH_SLAMVAN6", 1000)
			stats.set_int(MPX() .. "ARN_VEH_BRUTUS", 1000)
			stats.set_int(MPX() .. "ARN_VEH_BRUTUS2", 1000)
			stats.set_int(MPX() .. "ARN_VEH_BRUTUS3", 1000)
			stats.set_int(MPX() .. "ARN_VEH_SCARAB", 1000)
			stats.set_int(MPX() .. "ARN_VEH_SCARAB2", 1000)
			stats.set_int(MPX() .. "ARN_VEH_SCARAB3", 1000)
			stats.set_int(MPX() .. "ARN_VEH_DOMINATOR4", 1000)
			stats.set_int(MPX() .. "ARN_VEH_DOMINATOR5", 1000)
			stats.set_int(MPX() .. "ARN_VEH_DOMINATOR6", 1000)
			stats.set_int(MPX() .. "ARN_VEH_IMPALER2", 1000)
			stats.set_int(MPX() .. "ARN_VEH_IMPALER3", 1000)
			stats.set_int(MPX() .. "ARN_VEH_IMPALER4", 1000)
			stats.set_int(MPX() .. "ARN_VEH_ISSI4", 1000)
			stats.set_int(MPX() .. "ARN_VEH_ISSI5", 1000)
			stats.set_int(MPX() .. "ARN_VEH_ISSI", 61000)
			stats.set_int(MPX() .. "ARN_VEH_IMPERATOR", 1000)
			stats.set_int(MPX() .. "ARN_VEH_IMPERATOR2", 1000)
			stats.set_int(MPX() .. "ARN_VEH_IMPERATOR3", 1000)
			stats.set_int(MPX() .. "ARN_VEH_ZR380", 1000)
			stats.set_int(MPX() .. "ARN_VEH_ZR3802", 1000)
			stats.set_int(MPX() .. "ARN_VEH_ZR3803", 1000)
			stats.set_int(MPX() .. "ARN_VEH_DEATHBIKE", 1000)
			stats.set_int(MPX() .. "ARN_VEH_DEATHBIKE2", 1000)
			stats.set_int(MPX() .. "ARN_VEH_DEATHBIKE3", 1000)
			stats.set_bool(MPX() .. "AWD_BEGINNER", true)
			stats.set_bool(MPX() .. "AWD_FIELD_FILLER", true)
			stats.set_bool(MPX() .. "AWD_ARMCHAIR_RACER", true)
			stats.set_bool(MPX() .. "AWD_LEARNER", true)
			stats.set_bool(MPX() .. "AWD_SUNDAY_DRIVER", true)
			stats.set_bool(MPX() .. "AWD_THE_ROOKIE", true)
			stats.set_bool(MPX() .. "AWD_BUMP_AND_RUN", true)
			stats.set_bool(MPX() .. "AWD_GEAR_HEAD", true)
			stats.set_bool(MPX() .. "AWD_DOOR_SLAMMER", true)
			stats.set_bool(MPX() .. "AWD_HOT_LAP", true)
			stats.set_bool(MPX() .. "AWD_ARENA_AMATEUR", true)
			stats.set_bool(MPX() .. "AWD_PAINT_TRADER", true)
			stats.set_bool(MPX() .. "AWD_SHUNTER", true)
			stats.set_bool(MPX() .. "AWD_JOCK", true)
			stats.set_bool(MPX() .. "AWD_WARRIOR", true)
			stats.set_bool(MPX() .. "AWD_T_BONE", true)
			stats.set_bool(MPX() .. "AWD_MAYHEM", true)
			stats.set_bool(MPX() .. "AWD_WRECKER", true)
			stats.set_bool(MPX() .. "AWD_CRASH_COURSE", true)
			stats.set_bool(MPX() .. "AWD_ARENA_LEGEND", true)
			stats.set_bool(MPX() .. "AWD_PEGASUS", true)
			stats.set_bool(MPX() .. "AWD_UNSTOPPABLE", true)
			stats.set_bool(MPX() .. "AWD_CONTACT_SPORT", true)
			stats.set_masked_int(MPX().."ARENAWARSPSTAT_INT", 1, 35, 8)
		for i = 0, 8 do for j = 0, 63 do stats.set_bool_masked(MPX().."ARENAWARSPSTAT_BOOL"..i, true, j, MPX()) end end
			stats.set_int(MPX() .. "AWD_ODD_JOBS", 50)
			stats.set_int(MPX() .. "VCM_FLOW_CSYONS26GRESS", -1)
			stats.set_int(MPX() .. "VCM_STORY_CSYONS26GRESS", 5)
			stats.set_bool(MPX() .. "AWD_FIRST_TIME1", true)
			stats.set_bool(MPX() .. "AWD_FIRST_TIME2", true)
			stats.set_bool(MPX() .. "AWD_FIRST_TIME3", true)
			stats.set_bool(MPX() .. "AWD_FIRST_TIME4", true)
			stats.set_bool(MPX() .. "AWD_FIRST_TIME5", true)
			stats.set_bool(MPX() .. "AWD_FIRST_TIME6", true)
			stats.set_bool(MPX() .. "AWD_ALL_IN_ORDER", true)
			stats.set_bool(MPX() .. "AWD_SUPPORTING_ROLE", true)
			stats.set_bool(MPX() .. "AWD_LEADER", true)
			stats.set_bool(MPX() .. "AWD_SURVIVALIST", true)
			Paragon = stats.get_bool(MPX() .. "CAS_VEHICLE_REWARD") if Paragon == true then stats.set_bool(MPX() .. "CAS_VEHICLE_REWARD",true) else stats.set_bool(MPX() .. "CAS_VEHICLE_REWARD", false) end
		for i = 0, 6 do for j = 0, 63 do stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL"..i, true, j, MPX()) end end
			stats.set_int(MPX() .. "CAS_HEIST_NOTS", -1)
			stats.set_int(MPX() .. "CAS_HEIST_FLOW", -1)
			stats.set_int(MPX() .. "SIGNAL_JAMMERS_COLLECTED", 50)
			stats.set_int(MPX() .. "AWD_PREPARATION", 40)
			stats.set_int(MPX() .. "AWD_ASLEEPONJOB", 20)
			stats.set_int(MPX() .. "AWD_DAICASHCRAB", 100000)
			stats.set_int(MPX() .. "AWD_BIGBRO", 40)
			stats.set_int(MPX() .. "AWD_SHARPSHOOTER", 40)
			stats.set_int(MPX() .. "AWD_RACECHAMP", 40)
			stats.set_int(MPX() .. "AWD_BATSWORD", 1000000)
			stats.set_int(MPX() .. "AWD_COINPURSE", 950000)
			stats.set_int(MPX() .. "AWD_ASTROCHIMP", 3000000)
			stats.set_int(MPX() .. "AWD_MASTERFUL", 40000)
			stats.set_int(MPX() .. "H3_BOARD_DIALOGUE0", -1)
			stats.set_int(MPX() .. "H3_BOARD_DIALOGUE1", -1)
			stats.set_int(MPX() .. "H3_BOARD_DIALOGUE2", -1)
			stats.set_int(MPX() .. "H3_VEHICLESUSED", -1)
			stats.set_int(MPX() .. "H3_CR_STEALTH_1A", 100)
			stats.set_int(MPX() .. "H3_CR_STEALTH_2B_RAPP", 100)
			stats.set_int(MPX() .. "H3_CR_STEALTH_2C_SIDE", 100)
			stats.set_int(MPX() .. "H3_CR_STEALTH_3A", 100)
			stats.set_int(MPX() .. "H3_CR_STEALTH_4A", 100)
			stats.set_int(MPX() .. "H3_CR_STEALTH_5A", 100)
			stats.set_int(MPX() .. "H3_CR_SUBTERFUGE_1A", 100)
			stats.set_int(MPX() .. "H3_CR_SUBTERFUGE_2A", 100)
			stats.set_int(MPX() .. "H3_CR_SUBTERFUGE_2B", 100)
			stats.set_int(MPX() .. "H3_CR_SUBTERFUGE_3A", 100)
			stats.set_int(MPX() .. "H3_CR_SUBTERFUGE_3B", 100)
			stats.set_int(MPX() .. "H3_CR_SUBTERFUGE_4A", 100)
			stats.set_int(MPX() .. "H3_CR_SUBTERFUGE_5A", 100)
			stats.set_int(MPX() .. "H3_CR_DIRECT_1A", 100)
			stats.set_int(MPX() .. "H3_CR_DIRECT_2A1", 100)
			stats.set_int(MPX() .. "H3_CR_DIRECT_2A2", 100)
			stats.set_int(MPX() .. "H3_CR_DIRECT_2BP", 100)
			stats.set_int(MPX() .. "H3_CR_DIRECT_2C", 100)
			stats.set_int(MPX() .. "H3_CR_DIRECT_3A", 100)
			stats.set_int(MPX() .. "H3_CR_DIRECT_4A", 100)
			stats.set_int(MPX() .. "H3_CR_DIRECT_5A", 100)
			stats.set_int(MPX() .. "CR_ORDER", 100)
			stats.set_bool(MPX() .. "AWD_SCOPEOUT", true)
			stats.set_bool(MPX() .. "AWD_CREWEDUP", true)
			stats.set_bool(MPX() .. "AWD_MOVINGON", true)
			stats.set_bool(MPX() .. "AWD_CSYONS26MOCAMP", true)
			stats.set_bool(MPX() .. "AWD_GUNMAN", true)
			stats.set_bool(MPX() .. "AWD_SMASHNGRAB", true)
			stats.set_bool(MPX() .. "AWD_INPLAINSI", true)
			stats.set_bool(MPX() .. "AWD_UNDETECTED", true)
			stats.set_bool(MPX() .. "AWD_ALLROUND", true)
			stats.set_bool(MPX() .. "AWD_ELITETHEIF", true)
			stats.set_bool(MPX() .. "AWD_CSYONS26", true)
			stats.set_bool(MPX() .. "AWD_SUPPORTACT", true)
			stats.set_bool(MPX() .. "AWD_SHAFTED", true)
			stats.set_bool(MPX() .. "AWD_COLLECTOR", true)
			stats.set_bool(MPX() .. "AWD_DEADEYE", true)
			stats.set_bool(MPX() .. "AWD_PISTOLSATDAWN", true)
			stats.set_bool(MPX() .. "AWD_TRAFFICAVOI", true)
			stats.set_bool(MPX() .. "AWD_CANTCATCHBRA", true)
			stats.set_bool(MPX() .. "AWD_WIZHARD", true)
			stats.set_bool(MPX() .. "AWD_APEESCAPE", true)
			stats.set_bool(MPX() .. "AWD_MONKEYKIND", true)
			stats.set_bool(MPX() .. "AWD_AQUAAPE", true)
			stats.set_bool(MPX() .. "AWD_KEEPFAITH", true)
			stats.set_bool(MPX() .. "AWD_TRUELOVE", true)
			stats.set_bool(MPX() .. "AWD_NEMESIS", true)
			stats.set_bool(MPX() .. "AWD_FRIENDZONED", true)
			stats.set_bool(MPX() .. "VCM_FLOW_CS_RSC_SEEN", true)
			stats.set_bool(MPX() .. "VCM_FLOW_CS_BWL_SEEN", true)
			stats.set_bool(MPX() .. "VCM_FLOW_CS_MTG_SEEN", true)
			stats.set_bool(MPX() .. "VCM_FLOW_CS_OIL_SEEN", true)
			stats.set_bool(MPX() .. "VCM_FLOW_CS_DEF_SEEN", true)
			stats.set_bool(MPX() .. "VCM_FLOW_CS_FIN_SEEN", true)
			stats.set_bool(MPX() .. "HELP_FURIA", true)
			stats.set_bool(MPX() .. "HELP_MINITAN", true)
			stats.set_bool(MPX() .. "HELP_YOSEMITE2", true)
			stats.set_bool(MPX() .. "HELP_ZHABA", true)
			stats.set_bool(MPX() .. "HELP_IMORGEN", true)
			stats.set_bool(MPX() .. "HELP_SULTAN2", true)
			stats.set_bool(MPX() .. "HELP_VAGRANT", true)
			stats.set_bool(MPX() .. "HELP_VSTR", true)
			stats.set_bool(MPX() .. "HELP_STRYDER", true)
			stats.set_bool(MPX() .. "HELP_SUGOI", true)
			stats.set_bool(MPX() .. "HELP_KANJO", true)
			stats.set_bool(MPX() .. "HELP_FORMULA", true)
			stats.set_bool(MPX() .. "HELP_FORMULA2", true)
			stats.set_bool(MPX() .. "HELP_JB7002", true)
		for i = 0, 4 do for j = 0, 63 do stats.set_bool_masked(MPX().."CASINOHSTPSTAT_BOOL"..i, true, j, MPX()) end end
			stats.set_int(MPX() .. "AWD_PREPARATION", 50)
			stats.set_int(MPX() .. "AWD_ASLEEPONJOB", 20)
			stats.set_int(MPX() .. "AWD_DAICASHCRAB", 100000)
			stats.set_int(MPX() .. "AWD_BIGBRO", 40)
			stats.set_int(MPX() .. "AWD_SHARPSHOOTER", 40)
			stats.set_int(MPX() .. "AWD_RACECHAMP", 40)
			stats.set_int(MPX() .. "AWD_BATSWORD", 1000000)
			stats.set_int(MPX() .. "AWD_COINPURSE", 950000)
			stats.set_int(MPX() .. "AWD_ASTROCHIMP", 3000000)
			stats.set_int(MPX() .. "AWD_MASTERFUL", 40000)
			stats.set_int(MPX() .. "SCGW_NUM_WINS_GANG_0", 50)
			stats.set_int(MPX() .. "SCGW_NUM_WINS_GANG_1", 50)
			stats.set_int(MPX() .. "SCGW_NUM_WINS_GANG_2", 50)
			stats.set_int(MPX() .. "SCGW_NUM_WINS_GANG_3", 50)
			stats.set_int(MPX() .. "CH_ARC_CAB_CLAW_TROPHY", -1)
			stats.set_int(MPX() .. "CH_ARC_CAB_LOVE_TROPHY", -1)
			stats.set_int(MPX() .. "IAP_MAX_MOON_DIST", 2147483647)
			stats.set_int(MPX() .. "SCGW_INITIALS_0", 69644)
			stats.set_int(MPX() .. "SCGW_INITIALS_1", 50333)
			stats.set_int(MPX() .. "SCGW_INITIALS_2", 63512)
			stats.set_int(MPX() .. "SCGW_INITIALS_3", 46136)
			stats.set_int(MPX() .. "SCGW_INITIALS_4", 21638)
			stats.set_int(MPX() .. "SCGW_INITIALS_5", 2133)
			stats.set_int(MPX() .. "SCGW_INITIALS_6", 1215)
			stats.set_int(MPX() .. "SCGW_INITIALS_7", 2444)
			stats.set_int(MPX() .. "SCGW_INITIALS_8", 38023)
			stats.set_int(MPX() .. "SCGW_INITIALS_9", 2233)
			stats.set_int(MPX() .. "FOOTAGE_INITIALS_0",0)
			stats.set_int(MPX() .. "FOOTAGE_INITIALS_1", 64)
			stats.set_int(MPX() .. "FOOTAGE_INITIALS_2", 8457)
			stats.set_int(MPX() .. "FOOTAGE_INITIALS_3", 91275)
			stats.set_int(MPX() .. "FOOTAGE_INITIALS_4", 53260)
			stats.set_int(MPX() .. "FOOTAGE_INITIALS_5", 78663)
			stats.set_int(MPX() .. "FOOTAGE_INITIALS_6", 25103)
			stats.set_int(MPX() .. "FOOTAGE_INITIALS_7", 102401)
			stats.set_int(MPX() .. "FOOTAGE_INITIALS_8", 12672)
			stats.set_int(MPX() .. "FOOTAGE_INITIALS_9", 74380)
			stats.set_int(MPX() .. "FOOTAGE_SCORE_0", 284544)
			stats.set_int(MPX() .. "FOOTAGE_SCORE_1", 275758)
			stats.set_int(MPX() .. "FOOTAGE_SCORE_2", 100000)
			stats.set_int(MPX() .. "FOOTAGE_SCORE_3", 90000)
			stats.set_int(MPX() .. "FOOTAGE_SCORE_4", 80000)
			stats.set_int(MPX() .. "FOOTAGE_SCORE_5", 70000)
			stats.set_int(MPX() .. "FOOTAGE_SCORE_6", 60000)
			stats.set_int(MPX() .. "FOOTAGE_SCORE_7", 50000)
			stats.set_int(MPX() .. "FOOTAGE_SCORE_8", 40000)
			stats.set_int(MPX() .. "FOOTAGE_SCORE_9", 30000)
		for i = 0, 9 do stats.set_int(MPX() .. "IAP_INITIALS_"..i, 50) 
			stats.set_int(MPX() .. "IAP_SCORE_"..i, 50) 
			stats.set_int(MPX() .. "IAP_SCORE_"..i, 50) 
			stats.set_int(MPX() .. "SCGW_SCORE_"..i, 50) 
			stats.set_int(MPX() .. "DG_DEFENDER_INITIALS_"..i, 69644) 
			stats.set_int(MPX() .. "DG_DEFENDER_SCORE_"..i, 50) 
			stats.set_int(MPX() .. "DG_MONKEY_INITIALS_"..i, 69644) 
			stats.set_int(MPX() .. "DG_MONKEY_SCORE_"..i, 50) 
			stats.set_int(MPX() .. "DG_PENETRATOR_INITIALS_"..i, 69644) 
			stats.set_int(MPX() .. "DG_PENETRATOR_SCORE_"..i, 50) 
			stats.set_int(MPX() .. "GGSM_INITIALS_"..i, 69644) 
			stats.set_int(MPX() .. "GGSM_SCORE_"..i, 50) 
			stats.set_int(MPX() .. "TWR_INITIALS_"..i, 69644) 
			stats.set_int(MPX() .. "TWR_SCORE_"..i, 50) end 
			stats.set_bool(MPX() .. "AWD_SCOPEOUT", true)
			stats.set_bool(MPX() .. "AWD_CREWEDUP", true)
			stats.set_bool(MPX() .. "AWD_MOVINGON", true)
			stats.set_bool(MPX() .. "AWD_CSYONS26MOCAMP", true)
			stats.set_bool(MPX() .. "AWD_GUNMAN", true)
			stats.set_bool(MPX() .. "AWD_SMASHNGRAB", true)
			stats.set_bool(MPX() .. "AWD_INPLAINSI", true)
			stats.set_bool(MPX() .. "AWD_UNDETECTED", true)
			stats.set_bool(MPX() .. "AWD_ALLROUND", true)
			stats.set_bool(MPX() .. "AWD_ELITETHEIF", true)
			stats.set_bool(MPX() .. "AWD_CSYONS26", true)
			stats.set_bool(MPX() .. "AWD_SUPPORTACT", true)
			stats.set_bool(MPX() .. "AWD_SHAFTED", true)
			stats.set_bool(MPX() .. "AWD_COLLECTOR", true)
			stats.set_bool(MPX() .. "AWD_DEADEYE", true)
			stats.set_bool(MPX() .. "AWD_PISTOLSATDAWN", true)
			stats.set_bool(MPX() .. "AWD_TRAFFICAVOI", true)
			stats.set_bool(MPX() .. "AWD_CANTCATCHBRA", true)
			stats.set_bool(MPX() .. "AWD_WIZHARD", true)
			stats.set_bool(MPX() .. "AWD_APEESCAP", true)
			stats.set_bool(MPX() .. "AWD_MONKEYKIND", true)
			stats.set_bool(MPX() .. "AWD_AQUAAPE", true)
			stats.set_bool(MPX() .. "AWD_KEEPFAITH", true)
			stats.set_bool(MPX() .. "AWD_TRUELOVE", true)
			stats.set_bool(MPX() .. "AWD_NEMESIS", true)
			stats.set_bool(MPX() .. "AWD_FRIENDZONED", true)
			stats.set_bool(MPX() .. "IAP_CHALLENGE_0", true)
			stats.set_bool(MPX() .. "IAP_CHALLENGE_1", true)
			stats.set_bool(MPX() .. "IAP_CHALLENGE_2", true)
			stats.set_bool(MPX() .. "IAP_CHALLENGE_3", true)
			stats.set_bool(MPX() .. "IAP_CHALLENGE_4", true)
			stats.set_bool(MPX() .. "IAP_GOLD_TANK", true)
			stats.set_bool(MPX() .. "SCGW_WON_NO_DEATHS", true)
		for j = 290449, 290468 do globals.set_int(j, 1) end 
		for i = 0, 4 do for j = 0, 63 do stats.set_bool_masked(MPX().."CASINOHSTPSTAT_BOOL"..i, true, j, MPX()) end end 
		for i = 0, 6 do for j = 0, 63 do stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL"..i, true, j, MPX()) end end
			stats.set_bool(MPX() .. "AWD_KINGOFQUB3D", true)
			stats.set_bool(MPX() .. "AWD_QUBISM", true)
			stats.set_bool(MPX() .. "AWD_QUIBITS", true)
			stats.set_bool(MPX() .. "AWD_GODOFQUB3D", true)
			stats.set_bool(MPX() .. "AWD_ELEVENELEVEN", true)
			stats.set_bool(MPX() .. "AWD_GOFOR11TH", true)
			stats.set_masked_int(MPX().."SU20PSTAT_INT", 1, 35, 8)
		for i = 0, 1 do for j = 0, 63 do stats.set_bool_masked(MPX().."SU20PSTAT_BOOL"..i, true, j, MPX()) stats.set_bool_masked(MPX().."SU20TATTOOSTAT_BOOL"..i, true, j, MPX()) end end
			stats.set_bool(MPX() .. "AWD_INTELGATHER", true)
			stats.set_bool(MPX() .. "AWD_COMPOUNDINFILT", true)
			stats.set_bool(MPX() .. "AWD_LOOT_FINDER", true)
			stats.set_bool(MPX() .. "AWD_MAX_DISRUPT", true)
			stats.set_bool(MPX() .. "AWD_THE_ISLAND_HEIST", true)
			stats.set_bool(MPX() .. "AWD_GOING_ALONE", true)
			stats.set_bool(MPX() .. "AWD_TEAM_WORK", true)
			stats.set_bool(MPX() .. "AWD_MIXING_UP", true)
			stats.set_bool(MPX() .. "AWD_TEAM_WORK", true)
			stats.set_bool(MPX() .. "AWD_MIXING_UP", true)
			stats.set_bool(MPX() .. "AWD_CSYONS26_THIEF", true)
			stats.set_bool(MPX() .. "AWD_CAT_BURGLAR", true)
			stats.set_bool(MPX() .. "AWD_ONE_OF_THEM", true)
			stats.set_bool(MPX() .. "AWD_GOLDEN_GUN", true)
			stats.set_bool(MPX() .. "AWD_ELITE_THIEF", true)
			stats.set_bool(MPX() .. "AWD_CSYONS26FESSIONAL", true)
			stats.set_bool(MPX() .. "AWD_HELPING_OUT", true)
			stats.set_bool(MPX() .. "AWD_COURIER", true)
			stats.set_bool(MPX() .. "AWD_PARTY_VIBES", true)
			stats.set_bool(MPX() .. "AWD_HELPING_HAND", true)
			stats.set_bool(MPX() .. "AWD_ELEVENELEVEN", true)
			stats.set_bool(MPX() .. "COMPLETE_H4_F_USING_VETIR", true)
			stats.set_bool(MPX() .. "COMPLETE_H4_F_USING_LONGFIN", true)
			stats.set_bool(MPX() .. "COMPLETE_H4_F_USING_ANNIH", true)
			stats.set_bool(MPX() .. "COMPLETE_H4_F_USING_ALKONOS", true)
			stats.set_bool(MPX() .. "COMPLETE_H4_F_USING_PATROLB", true)
			stats.set_int(MPX() .. "AWD_LOSTANDFOUND", 500000)
			stats.set_int(MPX() .. "AWD_SUNSET", 1800000)
			stats.set_int(MPX() .. "AWD_TREASURE_HUNTER", 1000000)
			stats.set_int(MPX() .. "AWD_WRECK_DIVING", 1000000)
			stats.set_int(MPX() .. "AWD_KEINEMUSIK", 1800000)
			stats.set_int(MPX() .. "AWD_PALMS_TRAX", 1800000)
			stats.set_int(MPX() .. "AWD_MOODYMANN", 1800000)
			stats.set_int(MPX() .. "AWD_FILL_YOUR_BAGS", 1000000000)
			stats.set_int(MPX() .. "AWD_WELL_PREPARED", 80)
			stats.set_int(MPX() .. "H4_H4_DJ_MISSIONS", -1)
			stats.set_int(MPX() .. "H4CNF_APCSYONS26ACH", -1)
			stats.set_int(MPX() .. "H4_MISSIONS", -1)
			stats.set_int(MPX() .. "H4_PLAYTHROUGH_STATUS", 100)
		for i = 0, 2 do for j = 0, 63 do stats.set_bool_masked(MPX().."HISLANDPSTAT_BOOL"..i, true, j, MPX()) end end
			stats.set_int(MPX() .. "AWD_CAR_CLUB_MEM", 100)
			stats.set_int(MPX() .. "AWD_SPRINTRACER", 50)
			stats.set_int(MPX() .. "AWD_STREETRACER", 50)
			stats.set_int(MPX() .. "AWD_PURSUITRACER", 50)
			stats.set_int(MPX() .. "AWD_TEST_CAR", 240)
			stats.set_int(MPX() .. "AWD_AUTO_SHOP", 50)	
			stats.set_int(MPX() .. "AWD_GROUNDWORK", 40)
			stats.set_int(MPX() .. "AWD_CAR_EXPORT", 100)
			stats.set_int(MPX() .. "AWD_ROBBERY_CONTRACT", 100)
			stats.set_int(MPX() .. "AWD_FACES_OF_DEATH", 100)
			stats.set_bool(MPX() .. "AWD_CAR_CLUB", true)
			stats.set_bool(MPX() .. "AWD_CSYONS26_CAR_EXPORT", true)
			stats.set_bool(MPX() .. "AWD_UNION_DEPOSITORY", true)
			stats.set_bool(MPX() .. "AWD_MILITARY_CONVOY", true)
			stats.set_bool(MPX() .. "AWD_FLEECA_BANK", true)
			stats.set_bool(MPX() .. "AWD_FREIGHT_TRAIN", true)
			stats.set_bool(MPX() .. "AWD_BOLINGBROKE_ASS", true)
			stats.set_bool(MPX() .. "AWD_IAA_RAID", true)
			stats.set_bool(MPX() .. "AWD_METH_JOB", true)
			stats.set_bool(MPX() .. "AWD_BUNKER_RAID", true)
			stats.set_bool(MPX() .. "AWD_STRAIGHT_TO_VIDEO", true)
			stats.set_bool(MPX() .. "AWD_MONKEY_C_MONKEY_DO", true)
			stats.set_bool(MPX() .. "AWD_TRAINED_TO_KILL", true)
			stats.set_bool(MPX() .. "AWD_DIRECTOR", true)
		for i = 0, 8 do for j = 0, 63 do stats.set_bool_masked(MPX().."TUNERPSTAT_BOOL"..i, true, j, MPX()) end end
			stats.set_int(MPX() .. "AWD_CONTRACTOR", 50)
			stats.set_int(MPX() .. "AWD_COLD_CALLER", 50)
			stats.set_int(MPX() .. "AWD_CSYONS26DUCER", 60)
			stats.set_int(MPX() .. "FIXERTELEPHONEHITSCOMPL", 10)
			stats.set_int(MPX() .. "PAYPHONE_BONUS_KILL_METHOD", 10)
			stats.set_int(MPX() .. "PAYPHONE_BONUS_KILL_METHOD", -1)
			stats.set_int(MPX() .. "FIXER_GENERAL_BS", -1)
			stats.set_int(MPX() .. "FIXER_COMPLETED_BS", -1)
			stats.set_int(MPX() .. "FIXER_STORY_BS", -1)
			stats.set_int(MPX() .. "FIXER_STORY_STRAND", -1)
			stats.set_int(MPX() .. "FIXER_STORY_COOLDOWN", -1)
			stats.set_int(MPX() .. "FIXER_COUNT", 510)
			stats.set_int(MPX() .. "FIXER_SC_VEH_RECOVERED", 85)
			stats.set_int(MPX() .. "FIXER_SC_VAL_RECOVERED", 85)
			stats.set_int(MPX() .. "FIXER_SC_GANG_TERMINATED", 85)
			stats.set_int(MPX() .. "FIXER_SC_VIP_RESCUED", 85)
			stats.set_int(MPX() .. "FIXER_SC_ASSETS_CSYONS26TECTED", 85)
			stats.set_int(MPX() .. "FIXER_SC_EQ_DESTROYED", 85)
			stats.set_int(MPX() .. "FIXER_EARNINGS", 19734860)
			stats.set_bool(MPX() .. "AWD_TEEING_OFF", true)
			stats.set_bool(MPX() .. "AWD_PARTY_NIGHT", true)
			stats.set_bool(MPX() .. "AWD_BILLIONAIRE_GAMES", true)
			stats.set_bool(MPX() .. "AWD_HOOD_PASS", true)
			stats.set_bool(MPX() .. "AWD_STUDIO_TOUR", true)
			stats.set_bool(MPX() .. "AWD_DONT_MESS_DRE", true)
			stats.set_bool(MPX() .. "AWD_BACKUP", true)
			stats.set_bool(MPX() .. "AWD_SHORTFRANK_1", true)
			stats.set_bool(MPX() .. "AWD_SHORTFRANK_2", true)
			stats.set_bool(MPX() .. "AWD_SHORTFRANK_3", true)
			stats.set_bool(MPX() .. "AWD_CONTR_KILLER", true)
			stats.set_bool(MPX() .. "AWD_DOGS_BEST_FRIEND", true)
			stats.set_bool(MPX() .. "AWD_MUSIC_STUDIO", true)
			stats.set_bool(MPX() .. "AWD_SHORTLAMAR_1", true)
			stats.set_bool(MPX() .. "AWD_SHORTLAMAR_2", true)
			stats.set_bool(MPX() .. "AWD_SHORTLAMAR_3", true)
			stats.set_bool(MPX() .. "BS_FRANKLIN_DIALOGUE_0", true)
			stats.set_bool(MPX() .. "BS_FRANKLIN_DIALOGUE_1", true)
			stats.set_bool(MPX() .. "BS_FRANKLIN_DIALOGUE_2", true)
			stats.set_bool(MPX() .. "BS_IMANI_D_APP_SETUP", true)
			stats.set_bool(MPX() .. "BS_IMANI_D_APP_STRAND", true)
			stats.set_bool(MPX() .. "BS_IMANI_D_APP_PARTY", true)
			stats.set_bool(MPX() .. "BS_IMANI_D_APP_PARTY_2", true)
			stats.set_bool(MPX() .. "BS_IMANI_D_APP_PARTY_F", true)
			stats.set_bool(MPX() .. "BS_IMANI_D_APP_BILL", true)
			stats.set_bool(MPX() .. "BS_IMANI_D_APP_BILL_2", true)
			stats.set_bool(MPX() .. "BS_IMANI_D_APP_BILL_F", true)
			stats.set_bool(MPX() .. "BS_IMANI_D_APP_HOOD", true)
			stats.set_bool(MPX() .. "BS_IMANI_D_APP_HOOD_2", true)
			stats.set_bool(MPX() .. "BS_IMANI_D_APP_HOOD_F", true)
		for j = 0, 63 do stats.set_bool_masked(MPX().."FIXERPSTAT_BOOL0", true, j, MPX()) stats.set_bool_masked(MPX().."FIXERPSTAT_BOOL1", true, j, MPX()) stats.set_bool_masked(MPX().."FIXERTATTOOSTAT_BOOL0", true, j, MPX()) end end)
			stats.set_int(MPX() .. "AWD_FM_DM_WINS", 50)
			stats.set_int(MPX() .. "AWD_FM_TDM_WINS", 50)
			stats.set_int(MPX() .. "AWD_FM_TDM_MVP", 50)
			stats.set_int(MPX() .. "AWD_RACES_WON", 50)
			stats.set_int(MPX() .. "AWD_FMWINAIRRACE", 25)
			stats.set_int(MPX() .. "AWD_FMWINSEARACE", 25)
			stats.set_int(MPX() .. "AWD_FM_GTA_RACES_WON", 50)
			stats.set_bool(MPX() .. "AWD_FMKILL3ANDWINGTARACE", true)
			stats.set_int(MPX() .. "AWD_FMRALLYWONDRIVE", 25)
			stats.set_int(MPX() .. "AWD_FMRALLYWONNAV", 25)
			stats.set_bool(MPX() .. "AWD_FMWINCUSTOMRACE", true)
			stats.set_int(MPX() .. "AWD_FMWINRACETOPOINTS", 25)
			stats.set_bool(MPX() .. "CL_RACE_MODDED_CAR", true)
			stats.set_int(MPX() .. "AWD_FM_RACE_LAST_FIRST", 25)
			stats.set_bool(MPX() .. "AWD_FMRACEWORLDRECHOLDER", true)
			stats.set_int(MPX() .. "AWD_FM_RACES_FASTEST_LAP", 50)
			stats.set_bool(MPX() .. "AWD_FMWINALLRACEMODES", true)
			stats.set_int(MPX() .. "AWD_FMHORDWAVESSURVIVE", 10)
			stats.set_int(MPX() .. "NUMBER_SLIPSTREAMS_IN_RACE", 100)
			stats.set_int(MPX() .. "NUMBER_TURBO_STARTS_IN_RACE", 50)
			stats.set_int(MPX() .. "AWD_NO_ARMWRESTLING_WINS", 25)
			stats.set_int(MPX() .. "MOST_ARM_WRESTLING_WINS", 25)
			stats.set_int(MPX() .. "AWD_WIN_AT_DARTS", 25)
			stats.set_int(MPX() .. "AWD_FM_GOLF_WON", 25)
			stats.set_int(MPX() .. "AWD_FM_TENNIS_WON", 25)
			stats.set_bool(MPX() .. "AWD_FM_TENNIS_5_SET_WINS", true)
			stats.set_bool(MPX() .. "AWD_FM_TENNIS_STASETWIN", true)
			stats.set_int(MPX() .. "AWD_FM_SHOOTRANG_CT_WON", 25)
			stats.set_int(MPX() .. "AWD_FM_SHOOTRANG_RT_WON", 25)
			stats.set_int(MPX() .. "AWD_FM_SHOOTRANG_TG_WON", 25)
			stats.set_bool(MPX() .. "AWD_FM_SHOOTRANG_GRAN_WON", true)
			stats.set_bool(MPX() .. "AWD_FMWINEVERYGAMEMODE", true)
			stats.set_int(MPX() .. "AWD_WIN_CAPTURES", 50)
			stats.set_int(MPX() .. "AWD_WIN_CAPTURE_DONT_DYING", 25)
			stats.set_int(MPX() .. "AWD_WIN_LAST_TEAM_STANDINGS", 50)
			stats.set_int(MPX() .. "AWD_ONLY_PLAYER_ALIVE_LTS", 50)
			stats.set_int(MPX() .. "AWD_KILL_TEAM_YOURSELF_LTS", 25)
			stats.set_int(MPX() .. "AIR_LAUNCHES_OVER_40M", 25)
			stats.set_int(MPX() .. "AWD_CARS_EXPORTED", 50)
			stats.set_int(MPX() .. "AWD_LESTERDELIVERVEHICLES", 25)
			stats.set_int(MPX() .. "TOTAL_RACES_WON", 500)
			stats.set_int(MPX() .. "TOTAL_RACES_LOST", 250)
			stats.set_int(MPX() .. "TOTAL_CUSTOM_RACES_WON", 500)
			stats.set_int(MPX() .. "TOTAL_DEATHMATCH_LOST", 250)
			stats.set_int(MPX() .. "TOTAL_DEATHMATCH_WON", 500)
			stats.set_int(MPX() .. "TOTAL_TDEATHMATCH_LOST", 250)
			stats.set_int(MPX() .. "TOTAL_TDEATHMATCH_WON", 500)
			stats.set_int(MPX() .. "SHOOTINGRANGE_WINS", 500)
			stats.set_int(MPX() .. "SHOOTINGRANGE_LOSSES", 250)
			stats.set_int(MPX() .. "TENNIS_MATCHES_WON", 500)
			stats.set_int(MPX() .. "TENNIS_MATCHES_LOST", 250)
			stats.set_int(MPX() .. "GOLF_WINS", 500)
			stats.set_int(MPX() .. "GOLF_LOSSES", 250)
			stats.set_int(MPX() .. "DARTS_TOTAL_WINS", 500)
			stats.set_int(MPX() .. "DARTS_TOTAL_MATCHES", 750)
			stats.set_int(MPX() .. "SHOOTINGRANGE_TOTAL_MATCH", 800)
			stats.set_int(MPX() .. "BJ_WINS", 500)
			stats.set_int(MPX() .. "BJ_LOST", 250)
			stats.set_int(MPX() .. "RACE_2_POINT_WINS", 500)
			stats.set_int(MPX() .. "RACE_2_POINT_LOST", 250)
			stats.set_int(MPX() .. "KILLS_PLAYERS", 3593)
			stats.set_int(MPX() .. "DEATHS_PLAYER", 1002)
			stats.set_int(MPX() .. "MISSIONS_CREATED", 500)
			stats.set_int(MPX() .. "LTS_CREATED", 500)
			stats.set_int(MPX() .. "FM_MISSION_LIKES", 1500)
			stats.set_bool(MPX() .. "AWD_FM25DIFFERENTDM", true)
			stats.set_int(MPX() .. "CR_DIFFERENT_DM", 25)
			stats.set_bool(MPX() .. "AWD_FM25DIFFERENTRACES", true)
			stats.set_int(MPX() .. "CR_DIFFERENT_RACES", 25)
			stats.set_int(MPX() .. "AWD_PARACHUTE_JUMPS_20M", 25)
			stats.set_int(MPX() .. "AWD_PARACHUTE_JUMPS_50M", 25)
			stats.set_int(MPX() .. "AWD_FMBASEJMP", 25)
			stats.set_bool(MPX() .. "AWD_FMATTGANGHQ", true)
			stats.set_bool(MPX() .. "AWD_FM6DARTCHKOUT", true)
			stats.set_int(MPX() .. "AWD_FM_GOLF_BIRDIES", 25)
			stats.set_bool(MPX() .. "AWD_FM_GOLF_HOLE_IN_1", true)
			stats.set_int(MPX() .. "AWD_FM_TENNIS_ACE", 25)
			stats.set_int(MPX() .. "AWD_FMBBETWIN", 50000)
			stats.set_int(MPX() .. "AWD_LAPDANCES", 25)
			stats.set_int(MPX() .. "AWD_FMCRATEDROPS", 25)
			stats.set_bool(MPX() .. "AWD_FMPICKUPDLCCRATE1ST", true)
			stats.set_bool(MPX() .. "AWD_FM25DIFITEMSCLOTHES", true)
			stats.set_int(MPX() .. "AWD_NO_HAIRCUTS", 25)
			stats.set_bool(MPX() .. "AWD_BUY_EVERY_GUN", true)
			stats.set_bool(MPX() .. "AWD_DRIVELESTERCAR5MINS", true)
			stats.set_bool(MPX() .. "AWD_FMTATTOOALLBODYPARTS", true)
			stats.set_int(MPX() .. "AWD_DROPOFF_CAP_PACKAGES", 100)
			stats.set_int(MPX() .. "AWD_PICKUP_CAP_PACKAGES", 100)
			stats.set_int(MPX() .. "AWD_MENTALSTATE_TO_NORMAL", 50)
			stats.set_bool(MPX() .. "AWD_STORE_20_CAR_IN_GARAGES", true)
			stats.set_int(MPX() .. "AWD_TRADE_IN_YOUR_CSYONS26PERTY", 25)
			stats.set_bool(MPX() .. "AWD_DAILYOBJWEEKBONUS", true)
			stats.set_bool(MPX() .. "AWD_DAILYOBJMONTHBONUS", true)
			stats.set_int(MPX() .. "AWD_FM_CR_DM_MADE", 25)
			stats.set_int(MPX() .. "AWD_FM_CR_RACES_MADE", 25)
			stats.set_int(MPX() .. "AWD_FM_CR_PLAYED_BY_PEEP", 1598)
			stats.set_int(MPX() .. "AWD_FM_CR_MISSION_SCORE", 100)
			stats.set_bool(MPX() .. "CL_DRIVE_RALLY", true)
			stats.set_bool(MPX() .. "CL_PLAY_GTA_RACE", true)
			stats.set_bool(MPX() .. "CL_PLAY_BOAT_RACE", true)
			stats.set_bool(MPX() .. "CL_PLAY_FOOT_RACE", true)
			stats.set_bool(MPX() .. "CL_PLAY_TEAM_DM", true)
			stats.set_bool(MPX() .. "CL_PLAY_VEHICLE_DM", true)
			stats.set_bool(MPX() .. "CL_PLAY_MISSION_CONTACT", true)
			stats.set_bool(MPX() .. "CL_PLAY_A_PLAYLIST", true)
			stats.set_bool(MPX() .. "CL_PLAY_POINT_TO_POINT", true)
			stats.set_bool(MPX() .. "CL_PLAY_ONE_ON_ONE_DM", true)
			stats.set_bool(MPX() .. "CL_PLAY_ONE_ON_ONE_RACE", true)
			stats.set_bool(MPX() .. "CL_SURV_A_BOUNTY", true)
			stats.set_bool(MPX() .. "CL_SET_WANTED_LVL_ON_PLAY", true)
			stats.set_bool(MPX() .. "CL_GANG_BACKUP_GANGS", true)
			stats.set_bool(MPX() .. "CL_GANG_BACKUP_LOST", true)
			stats.set_bool(MPX() .. "CL_GANG_BACKUP_VAGOS", true)
			stats.set_bool(MPX() .. "CL_CALL_MERCENARIES", true)
			stats.set_bool(MPX() .. "CL_PHONE_MECH_DROP_CAR", true)
			stats.set_bool(MPX() .. "CL_GONE_OFF_RADAR", true)
			stats.set_bool(MPX() .. "CL_FILL_TITAN", true)
			stats.set_bool(MPX() .. "CL_MOD_CAR_USING_APP", true)
			stats.set_bool(MPX() .. "CL_MOD_CAR_USING_APP", true)
			stats.set_bool(MPX() .. "CL_BUY_INSURANCE", true)
			stats.set_bool(MPX() .. "CL_BUY_GARAGE", true)
			stats.set_bool(MPX() .. "CL_ENTER_FRIENDS_HOUSE", true)
			stats.set_bool(MPX() .. "CL_CALL_STRIPPER_HOUSE", true)
			stats.set_bool(MPX() .. "CL_CALL_FRIEND", true)
			stats.set_bool(MPX() .. "CL_SEND_FRIEND_REQUEST", true)
			stats.set_bool(MPX() .. "CL_W_WANTED_PLAYER_TV", true)
			stats.set_bool(MPX() .. "FM_INTRO_CUT_DONE", true)
			stats.set_bool(MPX() .. "FM_INTRO_MISS_DONE", true)
			stats.set_bool(MPX() .. "SHOOTINGRANGE_SEEN_TUT", true)
			stats.set_bool(MPX() .. "TENNIS_SEEN_TUTORIAL", true)
			stats.set_bool(MPX() .. "DARTS_SEEN_TUTORIAL", true)
			stats.set_bool(MPX() .. "ARMWRESTLING_SEEN_TUTORIAL", true)
			stats.set_bool(MPX() .. "HAS_WATCHED_BENNY_CUTSCE", true)
			stats.set_int(MPX() .. "NO_PHOTOS_TAKEN", 100)
			stats.set_int(MPX() .. "BOUNTSONU", 200)
			stats.set_int(MPX() .. "BOUNTPLACED", 500)
			stats.set_int(MPX() .. "BETAMOUNT", 500)
			stats.set_int(MPX() .. "CRARMWREST", 500)
			stats.set_int(MPX() .. "CRBASEJUMP", 500)
			stats.set_int(MPX() .. "CRDARTS", 500)
			stats.set_int(MPX() .. "CRDM", 500)
			stats.set_int(MPX() .. "CRGANGHIDE", 500)
			stats.set_int(MPX() .. "CRGOLF", 500)
			stats.set_int(MPX() .. "CRHORDE", 500)
			stats.set_int(MPX() .. "CRMISSION", 500)
			stats.set_int(MPX() .. "CRSHOOTRNG", 500)
			stats.set_int(MPX() .. "CRTENNIS", 500)
			stats.set_int(MPX() .. "NO_TIMES_CINEMA", 500)
			stats.set_int(MPX() .. "CHAR_WEAP_UNLOCKED", -1)
			stats.set_int(MPX() .. "CHAR_WEAP_UNLOCKED2", -1)
			stats.set_int(MPX() .. "CHAR_WEAP_UNLOCKED3", -1)
			stats.set_int(MPX() .. "CHAR_WEAP_UNLOCKED4", -1)
			stats.set_int(MPX() .. "CHAR_WEAP_ADDON_1_UNLCK", -1)
			stats.set_int(MPX() .. "CHAR_WEAP_ADDON_2_UNLCK", -1)
			stats.set_int(MPX() .. "CHAR_WEAP_ADDON_3_UNLCK", -1)
			stats.set_int(MPX() .. "CHAR_WEAP_ADDON_4_UNLCK", -1)
			stats.set_int(MPX() .. "CHAR_WEAP_FREE", -1)
			stats.set_int(MPX() .. "CHAR_WEAP_FREE2", -1)
			stats.set_int(MPX() .. "CHAR_FM_WEAP_FREE", -1)
			stats.set_int(MPX() .. "CHAR_FM_WEAP_FREE2", -1)
			stats.set_int(MPX() .. "CHAR_FM_WEAP_FREE3", -1)
			stats.set_int(MPX() .. "CHAR_FM_WEAP_FREE4", -1)
			stats.set_int(MPX() .. "CHAR_WEAP_PURCHASED", -1)
			stats.set_int(MPX() .. "CHAR_WEAP_PURCHASED2", -1)
			stats.set_int(MPX() .. "WEAPON_PICKUP_BITSET", -1)
			stats.set_int(MPX() .. "WEAPON_PICKUP_BITSET2", -1)
			stats.set_int(MPX() .. "CHAR_FM_WEAP_UNLOCKED", -1)
			stats.set_int(MPX() .. "NO_WEAPONS_UNLOCK", -1)
			stats.set_int(MPX() .. "NO_WEAPON_MODS_UNLOCK", -1)
			stats.set_int(MPX() .. "NO_WEAPON_CLR_MOD_UNLOCK", -1) 
			stats.set_int(MPX() .. "CHAR_FM_WEAP_UNLOCKED2", -1)
			stats.set_int(MPX() .. "CHAR_FM_WEAP_UNLOCKED3", -1)
			stats.set_int(MPX() .. "CHAR_FM_WEAP_UNLOCKED4", -1)
			stats.set_int(MPX() .. "CHAR_KIT_1_FM_UNLCK", -1)
			stats.set_int(MPX() .. "CHAR_KIT_2_FM_UNLCK", -1)
			stats.set_int(MPX() .. "CHAR_KIT_3_FM_UNLCK", -1)
			stats.set_int(MPX() .. "CHAR_KIT_4_FM_UNLCK", -1)
			stats.set_int(MPX() .. "CHAR_KIT_5_FM_UNLCK", -1)
			stats.set_int(MPX() .. "CHAR_KIT_6_FM_UNLCK", -1)
			stats.set_int(MPX() .. "CHAR_KIT_7_FM_UNLCK", -1)
			stats.set_int(MPX() .. "CHAR_KIT_8_FM_UNLCK", -1)
			stats.set_int(MPX() .. "CHAR_KIT_9_FM_UNLCK", -1)
			stats.set_int(MPX() .. "CHAR_KIT_10_FM_UNLCK", -1)
			stats.set_int(MPX() .. "CHAR_KIT_11_FM_UNLCK", -1)
			stats.set_int(MPX() .. "CHAR_KIT_12_FM_UNLCK", -1)
			stats.set_int(MPX() .. "CHAR_KIT_FM_PURCHASE", -1)
			stats.set_int(MPX() .. "CHAR_WEAP_FM_PURCHASE", -1)
			stats.set_int(MPX() .. "CHAR_WEAP_FM_PURCHASE2", -1)
			stats.set_int(MPX() .. "CHAR_WEAP_FM_PURCHASE3", -1)
			stats.set_int(MPX() .. "CHAR_WEAP_FM_PURCHASE4", -1)
			stats.set_int(MPX() .. "FIREWORK_TYPE_1_WHITE", 1000)
			stats.set_int(MPX() .. "FIREWORK_TYPE_1_RED", 1000)
			stats.set_int(MPX() .. "FIREWORK_TYPE_1_BLUE", 1000)
			stats.set_int(MPX() .. "FIREWORK_TYPE_2_WHITE", 1000)
			stats.set_int(MPX() .. "FIREWORK_TYPE_2_RED", 1000)
			stats.set_int(MPX() .. "FIREWORK_TYPE_2_BLUE", 1000)
			stats.set_int(MPX() .. "FIREWORK_TYPE_3_WHITE", 1000)
			stats.set_int(MPX() .. "FIREWORK_TYPE_3_RED", 1000)
			stats.set_int(MPX() .. "FIREWORK_TYPE_3_BLUE", 1000)
			stats.set_int(MPX() .. "FIREWORK_TYPE_4_WHITE", 1000)
			stats.set_int(MPX() .. "FIREWORK_TYPE_4_RED", 1000)
			stats.set_int(MPX() .. "FIREWORK_TYPE_4_BLUE", 1000)
			stats.set_int(MPX() .. "WEAP_FM_ADDON_PURCH", -1)
		for i = 2, 19 do stats.set_int(MPX() .. "WEAP_FM_ADDON_PURCH"..i, -1) end
		for j = 1, 19 do stats.set_int(MPX() .. "CHAR_FM_WEAP_ADDON_"..j.."_UNLCK", -1) end
		for m = 1, 41 do stats.set_int(MPX() .. "CHAR_KIT_"..m.."_FM_UNLCK", -1) end
		for l = 2, 41 do stats.set_int(MPX() .. "CHAR_KIT_FM_PURCHASE"..l, -1) end
			stats.set_int(MPX() .. "AWD_FMTIME5STARWANTED", 120)
			stats.set_int(MPX() .. "AWD_5STAR_WANTED_AVOIDANCE", 50)
			stats.set_int(MPX() .. "AWD_FMSHOOTDOWNCOPHELI", 25)
			stats.set_int(MPX() .. "AWD_VEHICLES_JACKEDR", 500)
			stats.set_int(MPX() .. "AWD_SECURITY_CARS_ROBBED", 25)
			stats.set_int(MPX() .. "AWD_HOLD_UP_SHOPS", 20)
			stats.set_int(MPX() .. "AWD_ODISTRACTCOPSNOEATH", 25)
			stats.set_int(MPX() .. "AWD_ENEMYDRIVEBYKILLS", 100)
			stats.set_int(MPX() .. "CHAR_WANTED_LEVEL_TIME5STAR", 18000000)
			stats.set_int(MPX() .. "CARS_COPS_EXPLODED", 300)
			stats.set_int(MPX() .. "BIKES_EXPLODED", 100)
			stats.set_int(MPX() .. "BOATS_EXPLODED", 168)
			stats.set_int(MPX() .. "HELIS_EXPLODED", 98)
			stats.set_int(MPX() .. "PLANES_EXPLODED", 138)
			stats.set_int(MPX() .. "QUADBIKE_EXPLODED", 50)
			stats.set_int(MPX() .. "BICYCLE_EXPLODED", 48)
			stats.set_int(MPX() .. "SUBMARINE_EXPLODED", 28)
			stats.set_int(MPX() .. "TIRES_POPPED_BY_GUNSHOT", 500)
			stats.set_int(MPX() .. "NUMBER_CRASHES_CARS", 300)
			stats.set_int(MPX() .. "NUMBER_CRASHES_BIKES", 300)
			stats.set_int(MPX() .. "BAILED_FROM_VEHICLE", 300)
			stats.set_int(MPX() .. "NUMBER_CRASHES_QUADBIKES", 300)
			stats.set_int(MPX() .. "NUMBER_STOLEN_COP_VEHICLE", 300)
			stats.set_int(MPX() .. "NUMBER_STOLEN_CARS", 300)
			stats.set_int(MPX() .. "NUMBER_STOLEN_BIKES", 300)
			stats.set_int(MPX() .. "NUMBER_STOLEN_BOATS", 300)
			stats.set_int(MPX() .. "NUMBER_STOLEN_HELIS", 300)
			stats.set_int(MPX() .. "NUMBER_STOLEN_PLANES", 300)
			stats.set_int(MPX() .. "NUMBER_STOLEN_QUADBIKES", 300)
			stats.set_int(MPX() .. "NUMBER_STOLEN_BICYCLES", 300)
			stats.set_int(MPX() .. "MC_CONTRIBUTION_POINTS", 1000)
			stats.set_int(MPX() .. "MEMBERSMARKEDFORDEATH", 700)
			stats.set_int(MPX() .. "MCKILLS", 500)
			stats.set_int(MPX() .. "MCDEATHS", 700)
			stats.set_int(MPX() .. "RIVALPRESIDENTKILLS", 700)
			stats.set_int(MPX() .. "RIVALCEOANDVIPKILLS", 700)
			stats.set_int(MPX() .. "CLUBHOUSECONTRACTSCOMPLETE", 700)
			stats.set_int(MPX() .. "CLUBHOUSECONTRACTEARNINGS", 32698547)
			stats.set_int(MPX() .. "CLUBCHALLENGESCOMPLETED", 700)
			stats.set_int(MPX() .. "MEMBERCHALLENGESCOMPLETED", 700)
			stats.set_int(MPX() .. "GHKILLS", 500)
			stats.set_int(MPX() .. "HORDELVL", 10)
			stats.set_int(MPX() .. "HORDKILLS", 500)
			stats.set_int(MPX() .. "UNIQUECRATES", 500)
			stats.set_int(MPX() .. "BJWINS", 500)
			stats.set_int(MPX() .. "HORDEWINS", 500)
			stats.set_int(MPX() .. "MCMWINS", 500)
			stats.set_int(MPX() .. "GANGHIDWINS", 500)
			stats.set_int(MPX() .. "KILLS", 800)
			stats.set_int(MPX() .. "HITS_PEDS_VEHICLES", 100)
			stats.set_int(MPX() .. "SHOTS", 1000)
			stats.set_int(MPX() .. "HEADSHOTS", 100)
			stats.set_int(MPX() .. "KILLS_ARMED", 650)
			stats.set_int(MPX() .. "SUCCESSFUL_COUNTERS", 100)
			stats.set_int(MPX() .. "KILLS_PLAYERS", 3593)
			stats.set_int(MPX() .. "DEATHS_PLAYER", 1002)
			stats.set_int(MPX() .. "KILLS_STEALTH", 100)
			stats.set_int(MPX() .. "KILLS_INNOCENTS", 500)
			stats.set_int(MPX() .. "KILLS_ENEMY_GANG_MEMBERS", 500)
			stats.set_int(MPX() .. "KILLS_FRIENDLY_GANG_MEMBERS", 500)
			stats.set_int(MPX() .. "KILLS_BY_OTHERS", 100)
			stats.set_int(MPX() .. "BIGGEST_VICTIM_KILLS", 500)
			stats.set_int(MPX() .. "ARCHENEMY_KILLS", 500)
			stats.set_int(MPX() .. "KILLS_COP", 4500)
			stats.set_int(MPX() .. "KILLS_SWAT", 500)
			stats.set_int(MPX() .. "STARS_ATTAINED", 5000)
			stats.set_int(MPX() .. "STARS_EVADED", 4000)
			stats.set_int(MPX() .. "VEHEXPORTED", 500)
			stats.set_int(MPX() .. "TOTAL_NO_SHOPS_HELD_UP", 100)
			stats.set_int(MPX() .. "CR_GANGATTACK_CITY", 1000)
			stats.set_int(MPX() .. "CR_GANGATTACK_COUNTRY", 1000)
			stats.set_int(MPX() .. "CR_GANGATTACK_LOST", 1000)
			stats.set_int(MPX() .. "CR_GANGATTACK_VAGOS", 1000)
			stats.set_int(MPX() .. "NO_NON_CONTRACT_RACE_WIN", 500)
			stats.set_int(MPX() .. "DIED_IN_DROWNING", 833)
			stats.set_int(MPX() .. "DIED_IN_DROWNINGINVEHICLE", 833)
			stats.set_int(MPX() .. "DIED_IN_EXPLOSION", 833)
			stats.set_int(MPX() .. "DIED_IN_FALL", 833)
			stats.set_int(MPX() .. "DIED_IN_FIRE", 833)
			stats.set_int(MPX() .. "DIED_IN_ROAD", 833)
			stats.set_int(MPX() .. "GRENADE_ENEMY_KILLS", 50)
			stats.set_int(MPX() .. "MICROSMG_ENEMY_KILLS", 500)
			stats.set_int(MPX() .. "SMG_ENEMY_KILLS", 500)
			stats.set_int(MPX() .. "ASLTSMG_ENEMY_KILLS", 500)
			stats.set_int(MPX() .. "CRBNRIFLE_ENEMY_KILLS", 500)
			stats.set_int(MPX() .. "ADVRIFLE_ENEMY_KILLS", 500)
			stats.set_int(MPX() .. "MG_ENEMY_KILLS", 500)
			stats.set_int(MPX() .. "CMBTMG_ENEMY_KILLS", 500)
			stats.set_int(MPX() .. "ASLTMG_ENEMY_KILLS", 500)
			stats.set_int(MPX() .. "RPG_ENEMY_KILLS", 500)
			stats.set_int(MPX() .. "PISTOL_ENEMY_KILLS", 500)
			stats.set_int(MPX() .. "PLAYER_HEADSHOTS", 500)
			stats.set_int(MPX() .. "SAWNOFF_ENEMY_KILLS", 500)
			stats.set_int(MPX() .. "STKYBMB_ENEMY_KILLS", 50)
			stats.set_int(MPX() .. "UNARMED_ENEMY_KILLS", 50)
			stats.set_int(MPX() .. "SNIPERRFL_ENEMY_KILLS", 500)
			stats.set_int(MPX() .. "HVYSNIPER_ENEMY_KILLS", 500)
			stats.set_int(MPX() .. "AWD_50_VEHICLES_BLOWNUP", 500)
			stats.set_int(MPX() .. "CARS_EXPLODED", 500)
			stats.set_int(MPX() .. "AWD_CAR_EXPORT", 100)
			stats.set_int(MPX() .. "AWD_FMDRIVEWITHOUTCRASH", 30)
			stats.set_int(MPX() .. "AWD_PASSENGERTIME", 4)
			stats.set_int(MPX() .. "AWD_TIME_IN_HELICOPTER", 4)
			stats.set_int(MPX() .. "AWD_VEHICLE_JUMP_OVER_40M", 25)
			stats.set_int(MPX() .. "MOST_FLIPS_IN_ONE_JUMP", 5)
			stats.set_int(MPX() .. "MOST_SPINS_IN_ONE_JUMP", 5)
			stats.set_int(MPX() .. "CHAR_FM_VEHICLE_1_UNLCK", -1)
			stats.set_int(MPX() .. "CHAR_FM_VEHICLE_2_UNLCK", -1)
			stats.set_int(MPX() .. "NO_CARS_REPAIR", 1000)
			stats.set_int(MPX() .. "VEHICLES_SPRAYED", 500)
			stats.set_int(MPX() .. "NUMBER_NEAR_MISS_NOCRASH", 500)
			stats.set_int(MPX() .. "USJS_FOUND", 50)
			stats.set_int(MPX() .. "USJS_COMPLETED", 50)
			stats.set_int(MPX() .. "USJS_TOTAL_COMPLETED", 50)
			stats.set_int(MPX() .. "CRDEADLINE", 5)
			stats.set_int(MPX() .. "FAVOUTFITBIKETIMECURRENT", 2069146067)
			stats.set_int(MPX() .. "FAVOUTFITBIKETIME1ALLTIME", 2069146067)
			stats.set_int(MPX() .. "FAVOUTFITBIKETYPECURRENT", 2069146067)
			stats.set_int(MPX() .. "FAVOUTFITBIKETYPEALLTIME", 2069146067)
			stats.set_int(MPX() .. "LONGEST_WHEELIE_DIST", 1000)
			stats.set_int(MPX() .. "RACES_WON", 50)
			stats.set_int(MPX() .. "COUNT_HOTRING_RACE", 20)
			stats.set_bool(MPX() .. "AWD_FMFURTHESTWHEELIE", true)
			stats.set_bool(MPX() .. "AWD_FMFULLYMODDEDCAR", true)
			stats.set_int(MPX() .. "AWD_100_HEADSHOTS", 500)
			stats.set_int(MPX() .. "AWD_FMOVERALLKILLS", 1000)
			stats.set_int(MPX() .. "AWD_FMKILLBOUNTY", 25)
			stats.set_int(MPX() .. "AWD_FM_DM_3KILLSAMEGUY", 50)
			stats.set_int(MPX() .. "AWD_FM_DM_KILLSTREAK", 100)
			stats.set_int(MPX() .. "AWD_FM_DM_STOLENKILL", 50)
			stats.set_int(MPX() .. "AWD_FM_DM_TOTALKILLS", 500)
			stats.set_bool(MPX() .. "AWD_FMKILLSTREAKSDM", true)
			stats.set_bool(MPX() .. "AWD_FMMOSTKILLSGANGHIDE", true)
			stats.set_bool(MPX() .. "AWD_FMMOSTKILLSSURVIVE", true)
			stats.set_int(MPX() .. "AWD_FMREVENGEKILLSDM", 50)
			stats.set_int(MPX() .. "AWD_KILL_CARRIER_CAPTURE", 100)
			stats.set_int(MPX() .. "AWD_NIGHTVISION_KILLS", 100)
			stats.set_int(MPX() .. "AWD_KILL_PSYCHOPATHS", 100)
			stats.set_int(MPX() .. "AWD_TAKEDOWNSMUGPLANE", 50)
			stats.set_int(MPX() .. "AWD_100_KILLS_PISTOL", 500)
			stats.set_int(MPX() .. "AWD_100_KILLS_SMG", 500)
			stats.set_int(MPX() .. "AWD_100_KILLS_SHOTGUN", 500)
			stats.set_int(MPX() .. "ASLTRIFLE_ENEMY_KILLS", 500)
			stats.set_int(MPX() .. "AWD_100_KILLS_SNIPER", 500)
			stats.set_int(MPX() .. "MG_ENEMY_KILLS", 500)
			stats.set_int(MPX() .. "AWD_25_KILLS_STICKYBOMBS", 50)
			stats.set_int(MPX() .. "AWD_50_KILLS_GRENADES", 50)
			stats.set_int(MPX() .. "AWD_50_KILLS_ROCKETLAUNCH", 50)
			stats.set_int(MPX() .. "AWD_20_KILLS_MELEE", 50)
			stats.set_int(MPX() .. "AWD_CAR_BOMBS_ENEMY_KILLS", 25)
			stats.set_int(MPX() .. "MELEEKILLS", 700)
			stats.set_int(MPX() .. "HITS", 10000)
			stats.set_int(MPX() .. "DEATHS", 499)
			stats.set_int(MPX() .. "HIGHEST_SKITTLES", 900)
			stats.set_int(MPX() .. "NUMBER_NEAR_MISS", 1000)
			stats.set_int(MPX() .. "AWD_FINISH_HEISTS", 50)
			stats.set_int(MPX() .. "AWD_FINISH_HEIST_SETUP_JOB", 50)
			stats.set_int(MPX() .. "AWD_COMPLETE_HEIST_NOT_DIE", -1)
			stats.set_bool(MPX() .. "AWD_FINISH_HEIST_NO_DAMAGE", true)
			stats.set_int(MPX() .. "AWD_WIN_GOLD_MEDAL_HEISTS", 25)
			stats.set_int(MPX() .. "AWD_DO_HEIST_AS_MEMBER", 25)
			stats.set_int(MPX() .. "AWD_DO_HEIST_AS_THE_LEADER", 25)
			stats.set_bool(MPX() .. "AWD_SPLIT_HEIST_TAKE_EVENLY", true)
			stats.set_bool(MPX() .. "AWD_ACTIVATE_2_PERSON_KEY", true)
			stats.set_int(MPX() .. "AWD_CONTROL_CROWDS", 25)
			stats.set_bool(MPX() .. "AWD_ALL_ROLES_HEIST", true)
			stats.set_int(MPX() .. "HEIST_COMPLETION", 25)
			stats.set_int(MPX() .. "HEISTS_ORGANISED", -1)
			stats.set_int(MPX() .. "HEIST_START", -1)
			stats.set_int(MPX() .. "HEIST_END", -1)
			stats.set_int(MPX() .. "CUTSCENE_MID_PRISON", -1)
			stats.set_int(MPX() .. "CUTSCENE_MID_HUMANE", -1)
			stats.set_int(MPX() .. "CUTSCENE_MID_NARC", -1)
			stats.set_int(MPX() .. "CUTSCENE_MID_ORNATE", -1)
			stats.set_int(MPX() .. "CR_FLEECA_PREP_1", -1)
			stats.set_int(MPX() .. "CR_FLEECA_PREP_2", -1)
			stats.set_int(MPX() .. "CR_FLEECA_FINALE", -1)
			stats.set_int(MPX() .. "CR_PRISON_PLANE", -1)
			stats.set_int(MPX() .. "CR_PRISON_BUS", -1)
			stats.set_int(MPX() .. "CR_PRISON_STATION", -1)
			stats.set_int(MPX() .. "CR_PRISON_UNFINISHED_BIZ", -1)
			stats.set_int(MPX() .. "CR_PRISON_FINALE", -1)
			stats.set_int(MPX() .. "CR_HUMANE_KEY_CODES", -1)
			stats.set_int(MPX() .. "CR_HUMANE_ARMORDILLOS", -1)
			stats.set_int(MPX() .. "CR_HUMANE_EMP", -1)
			stats.set_int(MPX() .. "CR_HUMANE_VALKYRIE", -1)
			stats.set_int(MPX() .. "CR_HUMANE_FINALE", -1)
			stats.set_int(MPX() .. "CR_NARC_COKE", -1)
			stats.set_int(MPX() .. "CR_NARC_TRASH_TRUCK", -1)
			stats.set_int(MPX() .. "CR_NARC_BIKERS", -1)
			stats.set_int(MPX() .. "CR_NARC_WEED", -1)
			stats.set_int(MPX() .. "CR_NARC_STEAL_METH", -1)
			stats.set_int(MPX() .. "CR_NARC_FINALE", -1)
			stats.set_int(MPX() .. "CR_PACIFIC_TRUCKS", -1)
			stats.set_int(MPX() .. "CR_PACIFIC_WITSEC", -1)
			stats.set_int(MPX() .. "CR_PACIFIC_HACK", -1)
			stats.set_int(MPX() .. "CR_PACIFIC_BIKES", -1)
			stats.set_int(MPX() .. "CR_PACIFIC_CONVOY", -1)
			stats.set_int(MPX() .. "CR_PACIFIC_FINALE", -1)
			stats.set_int("MPPLY_HEIST_ACH_TRACKER", -1)
			stats.set_int("MPPLY_WIN_GOLD_MEDAL_HEISTS", 25)
			stats.set_bool("MPPLY_AWD_FLEECA_FIN", true)
			stats.set_bool("MPPLY_AWD_PRISON_FIN", true)
			stats.set_bool("MPPLY_AWD_HUMANE_FIN", true)
			stats.set_bool("MPPLY_AWD_SERIESA_FIN", true)
			stats.set_bool("MPPLY_AWD_PACIFIC_FIN", true)
			stats.set_bool("MPPLY_AWD_HST_ORDER", true)
			stats.set_bool("MPPLY_AWD_COMPLET_HEIST_MEM", true)
			stats.set_bool("MPPLY_AWD_COMPLET_HEIST_1STPER", true)
			stats.set_bool("MPPLY_AWD_HST_SAME_TEAM", true)
			stats.set_bool("MPPLY_AWD_HST_ULT_CHAL", true)
			stats.set_bool(MPX() .. "AWD_MATCHING_OUTFIT_HEIST", true)
			stats.set_bool(MPX() .. "HEIST_PLANNING_DONE_PRINT", true)
			stats.set_bool(MPX() .. "HEIST_PLANNING_DONE_HELP_0", true)
			stats.set_bool(MPX() .. "HEIST_PLANNING_DONE_HELP_1", true)
			stats.set_bool(MPX() .. "HEIST_PRE_PLAN_DONE_HELP_0", true)
			stats.set_bool(MPX() .. "HEIST_CUTS_DONE_FINALE", true)
			stats.set_bool(MPX() .. "HEIST_IS_TUTORIAL", true)
			stats.set_bool(MPX() .. "HEIST_STRAND_INTRO_DONE", true)
			stats.set_bool(MPX() .. "HEIST_CUTS_DONE_ORNATE", true)
			stats.set_bool(MPX() .. "HEIST_CUTS_DONE_PRISON", true)
			stats.set_bool(MPX() .. "HEIST_CUTS_DONE_BIOLAB", true)
			stats.set_bool(MPX() .. "HEIST_CUTS_DONE_NARCOTIC", true)
			stats.set_bool(MPX() .. "HEIST_CUTS_DONE_TUTORIAL", true)
			stats.set_bool(MPX() .. "HEIST_AWARD_DONE_PREP", true)
			stats.set_bool(MPX() .. "HEIST_AWARD_BOUGHT_IN", true)
			stats.set_int(MPX() .. "HEIST_PLANNING_STAGE", -1)
			stats.set_int(MPX() .. "GANGOPS_HEIST_STATUS", -1)
			stats.set_int(MPX() .. "GANGOPS_HEIST_STATUS", -229384)
			stats.set_int(MPX() .. "GANGOPS_FM_MISSION_CSYONS26G", -1)
			stats.set_int(MPX() .. "GANGOPS_FLOW_MISSION_CSYONS26G", -1)
			stats.set_int("MPPLY_GANGOPS_ALLINORDER", 100)
			stats.set_int("MPPLY_GANGOPS_LOYALTY", 100)
			stats.set_int("MPPLY_GANGOPS_CRIMMASMD", 100)
			stats.set_int("MPPLY_GANGOPS_LOYALTY2", 100)
			stats.set_int("MPPLY_GANGOPS_LOYALTY3", 100)
			stats.set_int("MPPLY_GANGOPS_CRIMMASMD2", 100)
			stats.set_int("MPPLY_GANGOPS_CRIMMASMD3", 100)
			stats.set_int("MPPLY_GANGOPS_SUPPORT", 100)
			stats.set_int(MPX() .. "CR_GANGOP_MORGUE", 10)
			stats.set_int(MPX() .. "CR_GANGOP_DELUXO", 10)
			stats.set_int(MPX() .. "CR_GANGOP_SERVERFARM", 10)
			stats.set_int(MPX() .. "CR_GANGOP_IAABASE_FIN", 10)
			stats.set_int(MPX() .. "CR_GANGOP_STEALOSPREY", 10)
			stats.set_int(MPX() .. "CR_GANGOP_FOUNDRY", 10)
			stats.set_int(MPX() .. "CR_GANGOP_RIOTVAN", 10)
			stats.set_int(MPX() .. "CR_GANGOP_SUBMARINECAR", 10)
			stats.set_int(MPX() .. "CR_GANGOP_SUBMARINE_FIN", 10)
			stats.set_int(MPX() .. "CR_GANGOP_PREDATOR", 10)
			stats.set_int(MPX() .. "CR_GANGOP_BMLAUNCHER", 10)
			stats.set_int(MPX() .. "CR_GANGOP_BCCUSTOM", 10)
			stats.set_int(MPX() .. "CR_GANGOP_STEALTHTANKS", 10)
			stats.set_int(MPX() .. "CR_GANGOP_SPYPLANE", 10)
			stats.set_int(MPX() .. "CR_GANGOP_FINALE", 10)
			stats.set_int(MPX() .. "CR_GANGOP_FINALE_P2", 10)
			stats.set_int(MPX() .. "CR_GANGOP_FINALE_P3", 10)
			stats.set_bool("MPPLY_AWD_GANGOPS_IAA", true)
			stats.set_bool("MPPLY_AWD_GANGOPS_SUBMARINE", true)
			stats.set_bool("MPPLY_AWD_GANGOPS_MISSILE", true)
			stats.set_bool("MPPLY_AWD_GANGOPS_ALLINORDER", true)
			stats.set_bool("MPPLY_AWD_GANGOPS_LOYALTY", true)
			stats.set_bool("MPPLY_AWD_GANGOPS_LOYALTY2", true)
			stats.set_bool("MPPLY_AWD_GANGOPS_LOYALTY3", true)
			stats.set_bool("MPPLY_AWD_GANGOPS_CRIMMASMD", true)
			stats.set_bool("MPPLY_AWD_GANGOPS_CRIMMASMD2", true)
			stats.set_bool("MPPLY_AWD_GANGOPS_CRIMMASMD3", true)
			stats.set_bool("MPPLY_AWD_GANGOPS_SUPPORT", true)
		for j = 0, 63 do stats.set_bool_masked(MPX() .. "GANGOPSPSTAT_BOOL0", true, j, MPX()) end
			stats.set_masked_int(MPX() .. "DLCSMUGCHARPSTAT_INT260", 3, 16, 8)
			stats.set_masked_int(MPX() .. "BUSINESSBATPSTAT_INT260", 3, 24, 8)
			stats.set_masked_int(MPX() .. "BUSINESSBATPSTAT_INT260", 3, 32, 8)
			stats.set_masked_int(MPX() .. "BUSINESSBATPSTAT_INT260", 3, 40, 8)
			stats.set_masked_int(MPX() .. "BUSINESSBATPSTAT_INT260", 3, 48, 8)
			stats.set_int(MPX() .. "AWD_DANCE_TO_SOLOMUN", 120)
			stats.set_int(MPX() .. "AWD_DANCE_TO_TALEOFUS", 120)
			stats.set_int(MPX() .. "AWD_DANCE_TO_DIXON", 120)
			stats.set_int(MPX() .. "AWD_DANCE_TO_BLKMAD", 120)
			stats.set_int(MPX() .. "AWD_CLUB_DRUNK", 200)
			stats.set_int(MPX() .. "NIGHTCLUB_VIP_APPEAR", 700)
			stats.set_int(MPX() .. "NIGHTCLUB_JOBS_DONE", 700)
			stats.set_int(MPX() .. "NIGHTCLUB_EARNINGS", 5721002)
			stats.set_int(MPX() .. "HUB_SALES_COMPLETED", 1001)
			stats.set_int(MPX() .. "HUB_EARNINGS", 20721002)
			stats.set_int(MPX() .. "DANCE_COMBO_DURATION_MINS", 3600000)
			stats.set_int(MPX() .. "NIGHTCLUB_PLAYER_APPEAR", 100)
			stats.set_int(MPX() .. "LIFETIME_HUB_GOODS_SOLD", 784672)
			stats.set_int(MPX() .. "LIFETIME_HUB_GOODS_MADE", 507822)
			stats.set_int(MPX() .. "DANCEPERFECTOWNCLUB", 120)
			stats.set_int(MPX() .. "NUMUNIQUEPLYSINCLUB", 120)
			stats.set_int(MPX() .. "DANCETODIFFDJS", 4)
			stats.set_int(MPX() .. "NIGHTCLUB_HOTSPOT_TIME_MS", 3600000)
			stats.set_int(MPX() .. "NIGHTCLUB_CONT_TOTAL", 20)
			stats.set_int(MPX() .. "NIGHTCLUB_CONT_MISSION", -1)
			stats.set_int(MPX() .. "CLUB_CONTRABAND_MISSION", 1000)
			stats.set_int(MPX() .. "HUB_CONTRABAND_MISSION", 1000)
			stats.set_bool(MPX() .. "AWD_CLUB_HOTSPOT", true)
			stats.set_bool(MPX() .. "AWD_CLUB_CLUBBER", true)
			stats.set_bool(MPX() .. "AWD_CLUB_COORD", true)
		for j = 0, 63 do stats.set_bool_masked(MPX().."BUSINESSBATPSTAT_BOOL0", true, j, MPX()) 
						 stats.set_bool_masked(MPX().."BUSINESSBATPSTAT_BOOL1", true, j, MPX()) end
		if (stats.get_masked_int(MPX().."BUSINESSBATPSTAT_INT380", 0, 8) <20) then 
		    stats.set_masked_int(MPX().."BUSINESSBATPSTAT_INT380", 20, 0, 8) end
			stats.set_masked_int(MPX().."BUSINESSBATPSTAT_INT379", 50, 8, 8)
			stats.set_masked_int(MPX().."BUSINESSBATPSTAT_INT379", 100, 16, 8) 
			stats.set_masked_int(MPX().."BUSINESSBATPSTAT_INT379", 20, 24, 8) 
			stats.set_masked_int(MPX().."BUSINESSBATPSTAT_INT379", 80, 32, 8) 
			stats.set_masked_int(MPX().."BUSINESSBATPSTAT_INT379", 60, 40, 8) 
			stats.set_masked_int(MPX().."BUSINESSBATPSTAT_INT379", 40, 48, 8) 
			stats.set_masked_int(MPX().."BUSINESSBATPSTAT_INT379", 10, 56, 8)
			stats.set_int(MPX() .. "ARN_BS_TRINKET_TICKERS", -1)
			stats.set_int(MPX() .. "ARN_BS_TRINKET_SAVED", -1)
			stats.set_int(MPX() .. "AWD_WATCH_YOUR_STEP", 50)
			stats.set_int(MPX() .. "AWD_TOWER_OFFENSE", 50)
			stats.set_int(MPX() .. "AWD_READY_FOR_WAR", 50)
			stats.set_int(MPX() .. "AWD_THROUGH_A_LENS", 50)
			stats.set_int(MPX() .. "AWD_SPINNER", 50)
			stats.set_int(MPX() .. "AWD_YOUMEANBOOBYTRAPS", 50)
			stats.set_int(MPX() .. "AWD_MASTER_BANDITO", 50)
			stats.set_int(MPX() .. "AWD_SITTING_DUCK", 50)
			stats.set_int(MPX() .. "AWD_CROWDPARTICIPATION", 50)
			stats.set_int(MPX() .. "AWD_KILL_OR_BE_KILLED", 50)
			stats.set_int(MPX() .. "AWD_MASSIVE_SHUNT", 50)
			stats.set_int(MPX() .. "AWD_YOURE_OUTTA_HERE", 200)
			stats.set_int(MPX() .. "AWD_WEVE_GOT_ONE", 50)
			stats.set_int(MPX() .. "AWD_ARENA_WAGEWORKER", 1000000)
			stats.set_int(MPX() .. "AWD_TIME_SERVED", 1000)
			stats.set_int(MPX() .. "AWD_TOP_SCORE", 55000)
			stats.set_int(MPX() .. "AWD_CAREER_WINNER", 1000)
			stats.set_int(MPX() .. "ARENAWARS_SP", 0)
			stats.set_int(MPX() .. "ARENAWARS_SKILL_LEVEL", 20)
			stats.set_int(MPX() .. "ARENAWARS_SP_LIFETIME", 100)
			stats.set_int(MPX() .. "ARENAWARS_AP", 0)
			stats.set_int(MPX() .. "ARENAWARS_AP_TIER", 1000)
			stats.set_int(MPX() .. "ARENAWARS_AP_LIFETIME", 5055000)
			stats.set_int(MPX() .. "ARENAWARS_CARRER_UNLK", -1)
			stats.set_int(MPX() .. "ARN_W_THEME_SCIFI", 1000)
			stats.set_int(MPX() .. "ARN_W_THEME_APOC", 1000)
			stats.set_int(MPX() .. "ARN_W_THEME_CONS", 1000)
			stats.set_int(MPX() .. "ARN_W_PASS_THE_BOMB", 1000)
			stats.set_int(MPX() .. "ARN_W_DETONATION", 1000)
			stats.set_int(MPX() .. "ARN_W_ARCADE_RACE", 1000)
			stats.set_int(MPX() .. "ARN_W_CTF", 1000)
			stats.set_int(MPX() .. "ARN_W_TAG_TEAM", 1000)
			stats.set_int(MPX() .. "ARN_W_DESTR_DERBY", 1000)
			stats.set_int(MPX() .. "ARN_W_CARNAGE", 1000)
			stats.set_int(MPX() .. "ARN_W_MONSTER_JAM", 1000)
			stats.set_int(MPX() .. "ARN_W_GAMES_MASTERS", 1000)
			stats.set_int(MPX() .. "ARN_L_PASS_THE_BOMB", 500)
			stats.set_int(MPX() .. "ARN_L_DETONATION", 500)
			stats.set_int(MPX() .. "ARN_L_ARCADE_RACE", 500)
			stats.set_int(MPX() .. "ARN_L_CTF", 500)
			stats.set_int(MPX() .. "ARN_L_TAG_TEAM", 500)
			stats.set_int(MPX() .. "ARN_L_DESTR_DERBY", 500)
			stats.set_int(MPX() .. "ARN_L_CARNAGE", 500)
			stats.set_int(MPX() .. "ARN_L_MONSTER_JAM", 500)
			stats.set_int(MPX() .. "ARN_L_GAMES_MASTERS", 500)
			stats.set_int(MPX() .. "NUMBER_OF_CHAMP_BOUGHT", 1000)
			stats.set_int(MPX() .. "ARN_SPECTATOR_KILLS", 1000)
			stats.set_int(MPX() .. "ARN_LIFETIME_KILLS", 1000)
			stats.set_int(MPX() .. "ARN_LIFETIME_DEATHS", 500)
			stats.set_int(MPX() .. "ARENAWARS_CARRER_WINS", 1000)
			stats.set_int(MPX() .. "ARENAWARS_CARRER_WINT", 1000)
			stats.set_int(MPX() .. "ARENAWARS_MATCHES_PLYD", 1000)
			stats.set_int(MPX() .. "ARENAWARS_MATCHES_PLYDT", 1000)
			stats.set_int(MPX() .. "ARN_SPEC_BOX_TIME_MS", 86400000)
			stats.set_int(MPX() .. "ARN_SPECTATOR_DRONE", 1000)
			stats.set_int(MPX() .. "ARN_SPECTATOR_CAMS", 1000)
			stats.set_int(MPX() .. "ARN_SMOKE", 1000)
			stats.set_int(MPX() .. "ARN_DRINK", 1000)
			stats.set_int(MPX() .. "ARN_VEH_MONSTER", 1000)
			stats.set_int(MPX() .. "ARN_VEH_MONSTER", 1000)
			stats.set_int(MPX() .. "ARN_VEH_MONSTER", 1000)
			stats.set_int(MPX() .. "ARN_VEH_CERBERUS", 1000)
			stats.set_int(MPX() .. "ARN_VEH_CERBERUS2", 1000)
			stats.set_int(MPX() .. "ARN_VEH_CERBERUS3", 1000)
			stats.set_int(MPX() .. "ARN_VEH_BRUISER", 1000)
			stats.set_int(MPX() .. "ARN_VEH_BRUISER2", 1000)
			stats.set_int(MPX() .. "ARN_VEH_BRUISER3", 1000)
			stats.set_int(MPX() .. "ARN_VEH_SLAMVAN4", 1000)
			stats.set_int(MPX() .. "ARN_VEH_SLAMVAN5", 1000)
			stats.set_int(MPX() .. "ARN_VEH_SLAMVAN6", 1000)
			stats.set_int(MPX() .. "ARN_VEH_BRUTUS", 1000)
			stats.set_int(MPX() .. "ARN_VEH_BRUTUS2", 1000)
			stats.set_int(MPX() .. "ARN_VEH_BRUTUS3", 1000)
			stats.set_int(MPX() .. "ARN_VEH_SCARAB", 1000)
			stats.set_int(MPX() .. "ARN_VEH_SCARAB2", 1000)
			stats.set_int(MPX() .. "ARN_VEH_SCARAB3", 1000)
			stats.set_int(MPX() .. "ARN_VEH_DOMINATOR4", 1000)
			stats.set_int(MPX() .. "ARN_VEH_DOMINATOR5", 1000)
			stats.set_int(MPX() .. "ARN_VEH_DOMINATOR6", 1000)
			stats.set_int(MPX() .. "ARN_VEH_IMPALER2", 1000)
			stats.set_int(MPX() .. "ARN_VEH_IMPALER3", 1000)
			stats.set_int(MPX() .. "ARN_VEH_IMPALER4", 1000)
			stats.set_int(MPX() .. "ARN_VEH_ISSI4", 1000)
			stats.set_int(MPX() .. "ARN_VEH_ISSI5", 1000)
			stats.set_int(MPX() .. "ARN_VEH_ISSI", 61000)
			stats.set_int(MPX() .. "ARN_VEH_IMPERATOR", 1000)
			stats.set_int(MPX() .. "ARN_VEH_IMPERATOR2", 1000)
			stats.set_int(MPX() .. "ARN_VEH_IMPERATOR3", 1000)
			stats.set_int(MPX() .. "ARN_VEH_ZR380", 1000)
			stats.set_int(MPX() .. "ARN_VEH_ZR3802", 1000)
			stats.set_int(MPX() .. "ARN_VEH_ZR3803", 1000)
			stats.set_int(MPX() .. "ARN_VEH_DEATHBIKE", 1000)
			stats.set_int(MPX() .. "ARN_VEH_DEATHBIKE2", 1000)
			stats.set_int(MPX() .. "ARN_VEH_DEATHBIKE3", 1000)
			stats.set_bool(MPX() .. "AWD_BEGINNER", true)
			stats.set_bool(MPX() .. "AWD_FIELD_FILLER", true)
			stats.set_bool(MPX() .. "AWD_ARMCHAIR_RACER", true)
			stats.set_bool(MPX() .. "AWD_LEARNER", true)
			stats.set_bool(MPX() .. "AWD_SUNDAY_DRIVER", true)
			stats.set_bool(MPX() .. "AWD_THE_ROOKIE", true)
			stats.set_bool(MPX() .. "AWD_BUMP_AND_RUN", true)
			stats.set_bool(MPX() .. "AWD_GEAR_HEAD", true)
			stats.set_bool(MPX() .. "AWD_DOOR_SLAMMER", true)
			stats.set_bool(MPX() .. "AWD_HOT_LAP", true)
			stats.set_bool(MPX() .. "AWD_ARENA_AMATEUR", true)
			stats.set_bool(MPX() .. "AWD_PAINT_TRADER", true)
			stats.set_bool(MPX() .. "AWD_SHUNTER", true)
			stats.set_bool(MPX() .. "AWD_JOCK", true)
			stats.set_bool(MPX() .. "AWD_WARRIOR", true)
			stats.set_bool(MPX() .. "AWD_T_BONE", true)
			stats.set_bool(MPX() .. "AWD_MAYHEM", true)
			stats.set_bool(MPX() .. "AWD_WRECKER", true)
			stats.set_bool(MPX() .. "AWD_CRASH_COURSE", true)
			stats.set_bool(MPX() .. "AWD_ARENA_LEGEND", true)
			stats.set_bool(MPX() .. "AWD_PEGASUS", true)
			stats.set_bool(MPX() .. "AWD_UNSTOPPABLE", true)
			stats.set_bool(MPX() .. "AWD_CONTACT_SPORT", true)
			stats.set_masked_int(MPX().."ARENAWARSPSTAT_INT", 1, 35, 8)
		for i = 0, 8 do for j = 0, 63 do stats.set_bool_masked(MPX().."ARENAWARSPSTAT_BOOL"..i, true, j, MPX()) end end
			stats.set_int(MPX() .. "AWD_ODD_JOBS", 50)
			stats.set_int(MPX() .. "VCM_FLOW_CSYONS26GRESS", -1)
			stats.set_int(MPX() .. "VCM_STORY_CSYONS26GRESS", 5)
			stats.set_bool(MPX() .. "AWD_FIRST_TIME1", true)
			stats.set_bool(MPX() .. "AWD_FIRST_TIME2", true)
			stats.set_bool(MPX() .. "AWD_FIRST_TIME3", true)
			stats.set_bool(MPX() .. "AWD_FIRST_TIME4", true)
			stats.set_bool(MPX() .. "AWD_FIRST_TIME5", true)
			stats.set_bool(MPX() .. "AWD_FIRST_TIME6", true)
			stats.set_bool(MPX() .. "AWD_ALL_IN_ORDER", true)
			stats.set_bool(MPX() .. "AWD_SUPPORTING_ROLE", true)
			stats.set_bool(MPX() .. "AWD_LEADER", true)
			stats.set_bool(MPX() .. "AWD_SURVIVALIST", true)
			Paragon = stats.get_bool(MPX() .. "CAS_VEHICLE_REWARD") if Paragon == true then 
					  stats.set_bool(MPX() .. "CAS_VEHICLE_REWARD", true) else 
					  stats.set_bool(MPX() .. "CAS_VEHICLE_REWARD", false) end
		for i = 0, 6 do for j = 0, 63 do stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL"..i, true, j, MPX()) end end
			stats.set_int(MPX() .. "CAS_HEIST_NOTS", -1)
			stats.set_int(MPX() .. "CAS_HEIST_FLOW", -1)
			stats.set_int(MPX() .. "SIGNAL_JAMMERS_COLLECTED", 50)
			stats.set_int(MPX() .. "AWD_PREPARATION", 40)
			stats.set_int(MPX() .. "AWD_ASLEEPONJOB", 20)
			stats.set_int(MPX() .. "AWD_DAICASHCRAB", 100000)
			stats.set_int(MPX() .. "AWD_BIGBRO", 40)
			stats.set_int(MPX() .. "AWD_SHARPSHOOTER", 40)
			stats.set_int(MPX() .. "AWD_RACECHAMP", 40)
			stats.set_int(MPX() .. "AWD_BATSWORD", 1000000)
			stats.set_int(MPX() .. "AWD_COINPURSE", 950000)
			stats.set_int(MPX() .. "AWD_ASTROCHIMP", 3000000)
			stats.set_int(MPX() .. "AWD_MASTERFUL", 40000)
			stats.set_int(MPX() .. "H3_BOARD_DIALOGUE0", -1)
			stats.set_int(MPX() .. "H3_BOARD_DIALOGUE1", -1)
			stats.set_int(MPX() .. "H3_BOARD_DIALOGUE2", -1)
			stats.set_int(MPX() .. "H3_VEHICLESUSED", -1)
			stats.set_int(MPX() .. "H3_CR_STEALTH_1A", 100)
			stats.set_int(MPX() .. "H3_CR_STEALTH_2B_RAPP", 100)
			stats.set_int(MPX() .. "H3_CR_STEALTH_2C_SIDE", 100)
			stats.set_int(MPX() .. "H3_CR_STEALTH_3A", 100)
			stats.set_int(MPX() .. "H3_CR_STEALTH_4A", 100)
			stats.set_int(MPX() .. "H3_CR_STEALTH_5A", 100)
			stats.set_int(MPX() .. "H3_CR_SUBTERFUGE_1A", 100)
			stats.set_int(MPX() .. "H3_CR_SUBTERFUGE_2A", 100)
			stats.set_int(MPX() .. "H3_CR_SUBTERFUGE_2B", 100)
			stats.set_int(MPX() .. "H3_CR_SUBTERFUGE_3A", 100)
			stats.set_int(MPX() .. "H3_CR_SUBTERFUGE_3B", 100)
			stats.set_int(MPX() .. "H3_CR_SUBTERFUGE_4A", 100)
			stats.set_int(MPX() .. "H3_CR_SUBTERFUGE_5A", 100)
			stats.set_int(MPX() .. "H3_CR_DIRECT_1A", 100)
			stats.set_int(MPX() .. "H3_CR_DIRECT_2A1", 100)
			stats.set_int(MPX() .. "H3_CR_DIRECT_2A2", 100)
			stats.set_int(MPX() .. "H3_CR_DIRECT_2BP", 100)
			stats.set_int(MPX() .. "H3_CR_DIRECT_2C", 100)
			stats.set_int(MPX() .. "H3_CR_DIRECT_3A", 100)
			stats.set_int(MPX() .. "H3_CR_DIRECT_4A", 100)
			stats.set_int(MPX() .. "H3_CR_DIRECT_5A", 100)
			stats.set_int(MPX() .. "CR_ORDER", 100)
			stats.set_bool(MPX() .. "AWD_SCOPEOUT", true)
			stats.set_bool(MPX() .. "AWD_CREWEDUP", true)
			stats.set_bool(MPX() .. "AWD_MOVINGON", true)
			stats.set_bool(MPX() .. "AWD_CSYONS26MOCAMP", true)
			stats.set_bool(MPX() .. "AWD_GUNMAN", true)
			stats.set_bool(MPX() .. "AWD_SMASHNGRAB", true)
			stats.set_bool(MPX() .. "AWD_INPLAINSI", true)
			stats.set_bool(MPX() .. "AWD_UNDETECTED", true)
			stats.set_bool(MPX() .. "AWD_ALLROUND", true)
			stats.set_bool(MPX() .. "AWD_ELITETHEIF", true)
			stats.set_bool(MPX() .. "AWD_CSYONS26", true)
			stats.set_bool(MPX() .. "AWD_SUPPORTACT", true)
			stats.set_bool(MPX() .. "AWD_SHAFTED", true)
			stats.set_bool(MPX() .. "AWD_COLLECTOR", true)
			stats.set_bool(MPX() .. "AWD_DEADEYE", true)
			stats.set_bool(MPX() .. "AWD_PISTOLSATDAWN", true)
			stats.set_bool(MPX() .. "AWD_TRAFFICAVOI", true)
			stats.set_bool(MPX() .. "AWD_CANTCATCHBRA", true)
			stats.set_bool(MPX() .. "AWD_WIZHARD", true)
			stats.set_bool(MPX() .. "AWD_APEESCAPE", true)
			stats.set_bool(MPX() .. "AWD_MONKEYKIND", true)
			stats.set_bool(MPX() .. "AWD_AQUAAPE", true)
			stats.set_bool(MPX() .. "AWD_KEEPFAITH", true)
			stats.set_bool(MPX() .. "AWD_TRUELOVE", true)
			stats.set_bool(MPX() .. "AWD_NEMESIS", true)
			stats.set_bool(MPX() .. "AWD_FRIENDZONED", true)
			stats.set_bool(MPX() .. "VCM_FLOW_CS_RSC_SEEN", true)
			stats.set_bool(MPX() .. "VCM_FLOW_CS_BWL_SEEN", true)
			stats.set_bool(MPX() .. "VCM_FLOW_CS_MTG_SEEN", true)
			stats.set_bool(MPX() .. "VCM_FLOW_CS_OIL_SEEN", true)
			stats.set_bool(MPX() .. "VCM_FLOW_CS_DEF_SEEN", true)
			stats.set_bool(MPX() .. "VCM_FLOW_CS_FIN_SEEN", true)
			stats.set_bool(MPX() .. "HELP_FURIA", true)
			stats.set_bool(MPX() .. "HELP_MINITAN", true)
			stats.set_bool(MPX() .. "HELP_YOSEMITE2", true)
			stats.set_bool(MPX() .. "HELP_ZHABA", true)
			stats.set_bool(MPX() .. "HELP_IMORGEN", true)
			stats.set_bool(MPX() .. "HELP_SULTAN2", true)
			stats.set_bool(MPX() .. "HELP_VAGRANT", true)
			stats.set_bool(MPX() .. "HELP_VSTR", true)
			stats.set_bool(MPX() .. "HELP_STRYDER", true)
			stats.set_bool(MPX() .. "HELP_SUGOI", true)
			stats.set_bool(MPX() .. "HELP_KANJO", true)
			stats.set_bool(MPX() .. "HELP_FORMULA", true)
			stats.set_bool(MPX() .. "HELP_FORMULA2", true)
			stats.set_bool(MPX() .. "HELP_JB7002", true)
		for i = 0, 4 do for j = 0, 63 do stats.set_bool_masked(MPX().."CASINOHSTPSTAT_BOOL"..i, true, j, MPX()) end end
			stats.set_int(MPX() .. "AWD_PREPARATION", 50)
			stats.set_int(MPX() .. "AWD_ASLEEPONJOB", 20)
			stats.set_int(MPX() .. "AWD_DAICASHCRAB", 100000)
			stats.set_int(MPX() .. "AWD_BIGBRO", 40)
			stats.set_int(MPX() .. "AWD_SHARPSHOOTER", 40)
			stats.set_int(MPX() .. "AWD_RACECHAMP", 40)
			stats.set_int(MPX() .. "AWD_BATSWORD", 1000000)
			stats.set_int(MPX() .. "AWD_COINPURSE", 950000)
			stats.set_int(MPX() .. "AWD_ASTROCHIMP", 3000000)
			stats.set_int(MPX() .. "AWD_MASTERFUL", 40000)
			stats.set_int(MPX() .. "SCGW_NUM_WINS_GANG_0", 50)
			stats.set_int(MPX() .. "SCGW_NUM_WINS_GANG_1", 50)
			stats.set_int(MPX() .. "SCGW_NUM_WINS_GANG_2", 50)
			stats.set_int(MPX() .. "SCGW_NUM_WINS_GANG_3", 50)
			stats.set_int(MPX() .. "CH_ARC_CAB_CLAW_TROPHY", -1)
			stats.set_int(MPX() .. "CH_ARC_CAB_LOVE_TROPHY", -1)
			stats.set_int(MPX() .. "IAP_MAX_MOON_DIST", 2147483647)
			stats.set_int(MPX() .. "SCGW_INITIALS_0", 69644)
			stats.set_int(MPX() .. "SCGW_INITIALS_1", 50333)
			stats.set_int(MPX() .. "SCGW_INITIALS_2", 63512)
			stats.set_int(MPX() .. "SCGW_INITIALS_3", 46136)
			stats.set_int(MPX() .. "SCGW_INITIALS_4", 21638)
			stats.set_int(MPX() .. "SCGW_INITIALS_5", 2133)
			stats.set_int(MPX() .. "SCGW_INITIALS_6", 1215)
			stats.set_int(MPX() .. "SCGW_INITIALS_7", 2444)
			stats.set_int(MPX() .. "SCGW_INITIALS_8", 38023)
			stats.set_int(MPX() .. "SCGW_INITIALS_9", 2233)
			stats.set_int(MPX() .. "FOOTAGE_INITIALS_0",0)
			stats.set_int(MPX() .. "FOOTAGE_INITIALS_1", 64)
			stats.set_int(MPX() .. "FOOTAGE_INITIALS_2", 8457)
			stats.set_int(MPX() .. "FOOTAGE_INITIALS_3", 91275)
			stats.set_int(MPX() .. "FOOTAGE_INITIALS_4", 53260)
			stats.set_int(MPX() .. "FOOTAGE_INITIALS_5", 78663)
			stats.set_int(MPX() .. "FOOTAGE_INITIALS_6", 25103)
			stats.set_int(MPX() .. "FOOTAGE_INITIALS_7", 102401)
			stats.set_int(MPX() .. "FOOTAGE_INITIALS_8", 12672)
			stats.set_int(MPX() .. "FOOTAGE_INITIALS_9", 74380)
			stats.set_int(MPX() .. "FOOTAGE_SCORE_0", 284544)
			stats.set_int(MPX() .. "FOOTAGE_SCORE_1", 275758)
			stats.set_int(MPX() .. "FOOTAGE_SCORE_2", 100000)
			stats.set_int(MPX() .. "FOOTAGE_SCORE_3", 90000)
			stats.set_int(MPX() .. "FOOTAGE_SCORE_4", 80000)
			stats.set_int(MPX() .. "FOOTAGE_SCORE_5", 70000)
			stats.set_int(MPX() .. "FOOTAGE_SCORE_6", 60000)
			stats.set_int(MPX() .. "FOOTAGE_SCORE_7", 50000)
			stats.set_int(MPX() .. "FOOTAGE_SCORE_8", 40000)
			stats.set_int(MPX() .. "FOOTAGE_SCORE_9", 30000)
  for i = 0, 9 do stats.set_int(MPX() .. "IAP_INITIALS_"..i, 50) 
			stats.set_int(MPX() .. "IAP_SCORE_"..i, 50) 
			stats.set_int(MPX() .. "IAP_SCORE_"..i, 50) 
			stats.set_int(MPX() .. "SCGW_SCORE_"..i, 50) 
			stats.set_int(MPX() .. "DG_DEFENDER_INITIALS_"..i, 69644) 
			stats.set_int(MPX() .. "DG_DEFENDER_SCORE_"..i, 50) 
			stats.set_int(MPX() .. "DG_MONKEY_INITIALS_"..i, 69644) 
			stats.set_int(MPX() .. "DG_MONKEY_SCORE_"..i, 50) 
			stats.set_int(MPX() .. "DG_PENETRATOR_INITIALS_"..i, 69644) 
			stats.set_int(MPX() .. "DG_PENETRATOR_SCORE_"..i, 50) 
			stats.set_int(MPX() .. "GGSM_INITIALS_"..i, 69644) 
			stats.set_int(MPX() .. "GGSM_SCORE_"..i, 50) 
			stats.set_int(MPX() .. "TWR_INITIALS_"..i, 69644) 
			stats.set_int(MPX() .. "TWR_SCORE_"..i, 50) end 
			stats.set_bool(MPX() .. "AWD_SCOPEOUT", true)
			stats.set_bool(MPX() .. "AWD_CREWEDUP", true)
			stats.set_bool(MPX() .. "AWD_MOVINGON", true)
			stats.set_bool(MPX() .. "AWD_CSYONS26MOCAMP", true)
			stats.set_bool(MPX() .. "AWD_GUNMAN", true)
			stats.set_bool(MPX() .. "AWD_SMASHNGRAB", true)
			stats.set_bool(MPX() .. "AWD_INPLAINSI", true)
			stats.set_bool(MPX() .. "AWD_UNDETECTED", true)
			stats.set_bool(MPX() .. "AWD_ALLROUND", true)
			stats.set_bool(MPX() .. "AWD_ELITETHEIF", true)
			stats.set_bool(MPX() .. "AWD_CSYONS26", true)
			stats.set_bool(MPX() .. "AWD_SUPPORTACT", true)
			stats.set_bool(MPX() .. "AWD_SHAFTED", true)
			stats.set_bool(MPX() .. "AWD_COLLECTOR", true)
			stats.set_bool(MPX() .. "AWD_DEADEYE", true)
			stats.set_bool(MPX() .. "AWD_PISTOLSATDAWN", true)
			stats.set_bool(MPX() .. "AWD_TRAFFICAVOI", true)
			stats.set_bool(MPX() .. "AWD_CANTCATCHBRA", true)
			stats.set_bool(MPX() .. "AWD_WIZHARD", true)
			stats.set_bool(MPX() .. "AWD_APEESCAP", true)
			stats.set_bool(MPX() .. "AWD_MONKEYKIND", true)
			stats.set_bool(MPX() .. "AWD_AQUAAPE", true)
			stats.set_bool(MPX() .. "AWD_KEEPFAITH", true)
			stats.set_bool(MPX() .. "AWD_TRUELOVE", true)
			stats.set_bool(MPX() .. "AWD_NEMESIS", true)
			stats.set_bool(MPX() .. "AWD_FRIENDZONED", true)
			stats.set_bool(MPX() .. "IAP_CHALLENGE_0", true)
			stats.set_bool(MPX() .. "IAP_CHALLENGE_1", true)
			stats.set_bool(MPX() .. "IAP_CHALLENGE_2", true)
			stats.set_bool(MPX() .. "IAP_CHALLENGE_3", true)
			stats.set_bool(MPX() .. "IAP_CHALLENGE_4", true)
			stats.set_bool(MPX() .. "IAP_GOLD_TANK", true)
			stats.set_bool(MPX() .. "SCGW_WON_NO_DEATHS", true)
		for j = 290449, 290468 do globals.set_int(j, 1) end 
		for i = 0, 4 do for j = 0, 63 do stats.set_bool_masked(MPX().."CASINOHSTPSTAT_BOOL"..i, true, j, MPX()) end end 
		for i = 0, 6 do for j = 0, 63 do stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL"..i, true, j, MPX()) end end
			stats.set_bool(MPX() .. "AWD_KINGOFQUB3D", true)
			stats.set_bool(MPX() .. "AWD_QUBISM", true)
			stats.set_bool(MPX() .. "AWD_QUIBITS", true)
			stats.set_bool(MPX() .. "AWD_GODOFQUB3D", true)
			stats.set_bool(MPX() .. "AWD_ELEVENELEVEN", true)
			stats.set_bool(MPX() .. "AWD_GOFOR11TH", true)
			stats.set_masked_int(MPX().."SU20PSTAT_INT", 1, 35, 8)
		for i = 0, 1 do for j = 0, 63 do stats.set_bool_masked(MPX().."SU20PSTAT_BOOL"..i, true, j, MPX()) 
										 stats.set_bool_masked(MPX().."SU20TATTOOSTAT_BOOL"..i, true, j, MPX()) end end
			stats.set_bool(MPX() .. "AWD_INTELGATHER", true)
			stats.set_bool(MPX() .. "AWD_COMPOUNDINFILT", true)
			stats.set_bool(MPX() .. "AWD_LOOT_FINDER", true)
			stats.set_bool(MPX() .. "AWD_MAX_DISRUPT", true)
			stats.set_bool(MPX() .. "AWD_THE_ISLAND_HEIST", true)
			stats.set_bool(MPX() .. "AWD_GOING_ALONE", true)
			stats.set_bool(MPX() .. "AWD_TEAM_WORK", true)
			stats.set_bool(MPX() .. "AWD_MIXING_UP", true)
			stats.set_bool(MPX() .. "AWD_TEAM_WORK", true)
			stats.set_bool(MPX() .. "AWD_MIXING_UP", true)
			stats.set_bool(MPX() .. "AWD_CSYONS26_THIEF", true)
			stats.set_bool(MPX() .. "AWD_CAT_BURGLAR", true)
			stats.set_bool(MPX() .. "AWD_ONE_OF_THEM", true)
			stats.set_bool(MPX() .. "AWD_GOLDEN_GUN", true)
			stats.set_bool(MPX() .. "AWD_ELITE_THIEF", true)
			stats.set_bool(MPX() .. "AWD_CSYONS26FESSIONAL", true)
			stats.set_bool(MPX() .. "AWD_HELPING_OUT", true)
			stats.set_bool(MPX() .. "AWD_COURIER", true)
			stats.set_bool(MPX() .. "AWD_PARTY_VIBES", true)
			stats.set_bool(MPX() .. "AWD_HELPING_HAND", true)
			stats.set_bool(MPX() .. "AWD_ELEVENELEVEN", true)
			stats.set_bool(MPX() .. "COMPLETE_H4_F_USING_VETIR", true)
			stats.set_bool(MPX() .. "COMPLETE_H4_F_USING_LONGFIN", true)
			stats.set_bool(MPX() .. "COMPLETE_H4_F_USING_ANNIH", true)
			stats.set_bool(MPX() .. "COMPLETE_H4_F_USING_ALKONOS", true)
			stats.set_bool(MPX() .. "COMPLETE_H4_F_USING_PATROLB", true)
			stats.set_int(MPX() .. "AWD_LOSTANDFOUND", 500000)
			stats.set_int(MPX() .. "AWD_SUNSET", 1800000)
			stats.set_int(MPX() .. "AWD_TREASURE_HUNTER", 1000000)
			stats.set_int(MPX() .. "AWD_WRECK_DIVING", 1000000)
			stats.set_int(MPX() .. "AWD_KEINEMUSIK", 1800000)
			stats.set_int(MPX() .. "AWD_PALMS_TRAX", 1800000)
			stats.set_int(MPX() .. "AWD_MOODYMANN", 1800000)
			stats.set_int(MPX() .. "AWD_FILL_YOUR_BAGS", 1000000000)
			stats.set_int(MPX() .. "AWD_WELL_PREPARED", 80)
			stats.set_int(MPX() .. "H4_H4_DJ_MISSIONS", -1)
			stats.set_int(MPX() .. "H4CNF_APCSYONS26ACH", -1)
			stats.set_int(MPX() .. "H4_MISSIONS", -1)
			stats.set_int(MPX() .. "H4_PLAYTHROUGH_STATUS", 100)
		for i = 0, 2 do for j = 0, 63 do stats.set_bool_masked(MPX().."HISLANDPSTAT_BOOL"..i, true, j, MPX()) end end
			stats.set_int(MPX() .. "AWD_CAR_CLUB_MEM", 100)
			stats.set_int(MPX() .. "AWD_SPRINTRACER", 50)
			stats.set_int(MPX() .. "AWD_STREETRACER", 50)
			stats.set_int(MPX() .. "AWD_PURSUITRACER", 50)
			stats.set_int(MPX() .. "AWD_TEST_CAR", 240)
			stats.set_int(MPX() .. "AWD_AUTO_SHOP", 50)	
			stats.set_int(MPX() .. "AWD_GROUNDWORK", 40)
			stats.set_int(MPX() .. "AWD_CAR_EXPORT", 100)
			stats.set_int(MPX() .. "AWD_ROBBERY_CONTRACT", 100)
			stats.set_int(MPX() .. "AWD_FACES_OF_DEATH", 100)
			stats.set_bool(MPX() .. "AWD_CAR_CLUB", true)
			stats.set_bool(MPX() .. "AWD_CSYONS26_CAR_EXPORT", true)
			stats.set_bool(MPX() .. "AWD_UNION_DEPOSITORY", true)
			stats.set_bool(MPX() .. "AWD_MILITARY_CONVOY", true)
			stats.set_bool(MPX() .. "AWD_FLEECA_BANK", true)
			stats.set_bool(MPX() .. "AWD_FREIGHT_TRAIN", true)
			stats.set_bool(MPX() .. "AWD_BOLINGBROKE_ASS", true)
			stats.set_bool(MPX() .. "AWD_IAA_RAID", true)
			stats.set_bool(MPX() .. "AWD_METH_JOB", true)
			stats.set_bool(MPX() .. "AWD_BUNKER_RAID", true)
			stats.set_bool(MPX() .. "AWD_STRAIGHT_TO_VIDEO", true)
			stats.set_bool(MPX() .. "AWD_MONKEY_C_MONKEY_DO", true)
			stats.set_bool(MPX() .. "AWD_TRAINED_TO_KILL", true)
			stats.set_bool(MPX() .. "AWD_DIRECTOR", true)
		for i = 0, 8 do for j = 0, 63 do stats.set_bool_masked(MPX().."TUNERPSTAT_BOOL"..i, true, j, MPX()) end end 
			stats.set_int(MPX() .. "AWD_CONTRACTOR", 50)
			stats.set_int(MPX() .. "AWD_COLD_CALLER", 50)
			stats.set_int(MPX() .. "AWD_CSYONS26DUCER", 60)
			stats.set_int(MPX() .. "FIXERTELEPHONEHITSCOMPL", 10)
			stats.set_int(MPX() .. "PAYPHONE_BONUS_KILL_METHOD", 10)
			stats.set_int(MPX() .. "PAYPHONE_BONUS_KILL_METHOD", -1)
			stats.set_int(MPX() .. "FIXER_GENERAL_BS", -1)
			stats.set_int(MPX() .. "FIXER_COMPLETED_BS", -1)
			stats.set_int(MPX() .. "FIXER_STORY_BS", -1)
			stats.set_int(MPX() .. "FIXER_STORY_STRAND", -1)
			stats.set_int(MPX() .. "FIXER_STORY_COOLDOWN", -1)
			stats.set_int(MPX() .. "FIXER_COUNT", 510)
			stats.set_int(MPX() .. "FIXER_SC_VEH_RECOVERED", 85)
			stats.set_int(MPX() .. "FIXER_SC_VAL_RECOVERED", 85)
			stats.set_int(MPX() .. "FIXER_SC_GANG_TERMINATED", 85)
			stats.set_int(MPX() .. "FIXER_SC_VIP_RESCUED", 85)
			stats.set_int(MPX() .. "FIXER_SC_ASSETS_CSYONS26TECTED", 85)
			stats.set_int(MPX() .. "FIXER_SC_EQ_DESTROYED", 85)
			stats.set_int(MPX() .. "FIXER_EARNINGS", 19734860)
			stats.set_bool(MPX() .. "AWD_TEEING_OFF", true)
			stats.set_bool(MPX() .. "AWD_PARTY_NIGHT", true)
			stats.set_bool(MPX() .. "AWD_BILLIONAIRE_GAMES", true)
			stats.set_bool(MPX() .. "AWD_HOOD_PASS", true)
			stats.set_bool(MPX() .. "AWD_STUDIO_TOUR", true)
			stats.set_bool(MPX() .. "AWD_DONT_MESS_DRE", true)
			stats.set_bool(MPX() .. "AWD_BACKUP", true)
			stats.set_bool(MPX() .. "AWD_SHORTFRANK_1", true)
			stats.set_bool(MPX() .. "AWD_SHORTFRANK_2", true)
			stats.set_bool(MPX() .. "AWD_SHORTFRANK_3", true)
			stats.set_bool(MPX() .. "AWD_CONTR_KILLER", true)
			stats.set_bool(MPX() .. "AWD_DOGS_BEST_FRIEND", true)
			stats.set_bool(MPX() .. "AWD_MUSIC_STUDIO", true)
			stats.set_bool(MPX() .. "AWD_SHORTLAMAR_1", true)
			stats.set_bool(MPX() .. "AWD_SHORTLAMAR_2", true)
			stats.set_bool(MPX() .. "AWD_SHORTLAMAR_3", true)
			stats.set_bool(MPX() .. "BS_FRANKLIN_DIALOGUE_0", true)
			stats.set_bool(MPX() .. "BS_FRANKLIN_DIALOGUE_1", true)
			stats.set_bool(MPX() .. "BS_FRANKLIN_DIALOGUE_2", true)
			stats.set_bool(MPX() .. "BS_IMANI_D_APP_SETUP", true)
			stats.set_bool(MPX() .. "BS_IMANI_D_APP_STRAND", true)
			stats.set_bool(MPX() .. "BS_IMANI_D_APP_PARTY", true)
			stats.set_bool(MPX() .. "BS_IMANI_D_APP_PARTY_2", true)
			stats.set_bool(MPX() .. "BS_IMANI_D_APP_PARTY_F", true)
			stats.set_bool(MPX() .. "BS_IMANI_D_APP_BILL", true)
			stats.set_bool(MPX() .. "BS_IMANI_D_APP_BILL_2", true)
			stats.set_bool(MPX() .. "BS_IMANI_D_APP_BILL_F", true)
			stats.set_bool(MPX() .. "BS_IMANI_D_APP_HOOD", true)
			stats.set_bool(MPX() .. "BS_IMANI_D_APP_HOOD_2", true)
			stats.set_bool(MPX() .. "BS_IMANI_D_APP_HOOD_F", true)
		for j = 0, 63 do stats.set_bool_masked(MPX().."FIXERPSTAT_BOOL0", true, j, MPX()) 
						 stats.set_bool_masked(MPX().."FIXERPSTAT_BOOL1", true, j, MPX()) 
						 stats.set_bool_masked(MPX().."FIXERTATTOOSTAT_BOOL0", true, j, MPX()) end 

	CSYONS25:add_action("Remove Full Unlock Alls", function()
		stats.set_int(MPX() .. "AWD_FM_DM_WINS", 0)
		stats.set_int(MPX() .. "AWD_FM_TDM_WINS", 0)
		stats.set_int(MPX() .. "AWD_FM_TDM_MVP", 0)
		stats.set_int(MPX() .. "AWD_RACES_WON", 0)
		stats.set_int(MPX() .. "AWD_FMWINAIRRACE", 0)
		stats.set_int(MPX() .. "AWD_FMWINSEARACE", 0)
		stats.set_int(MPX() .. "AWD_FM_GTA_RACES_WON", 0)
		stats.set_int(MPX() .. "AWD_FMRALLYWONDRIVE", 0)
		stats.set_int(MPX() .. "AWD_FMRALLYWONNAV", 0)
		stats.set_int(MPX() .. "AWD_FMWINRACETOPOINTS", 0)
		stats.set_int(MPX() .. "AWD_FM_RACE_LAST_FIRST", 0)
		stats.set_int(MPX() .. "AWD_FM_RACES_FASTEST_LAP", 0)
		stats.set_int(MPX() .. "AWD_FMHORDWAVESSURVIVE", 0)
		stats.set_int(MPX() .. "NUMBER_SLIPSTREAMS_IN_RACE", 0)
		stats.set_int(MPX() .. "NUMBER_TURBO_STARTS_IN_RACE", 0)
		stats.set_int(MPX() .. "AWD_NO_ARMWRESTLING_WINS", 0)
		stats.set_int(MPX() .. "MOST_ARM_WRESTLING_WINS", 0)
		stats.set_int(MPX() .. "AWD_WIN_AT_DARTS", 0)
		stats.set_int(MPX() .. "AWD_FM_GOLF_WON", 0)
		stats.set_int(MPX() .. "AWD_FM_TENNIS_WON", 0)
		stats.set_int(MPX() .. "AWD_FM_SHOOTRANG_CT_WON", 0)
		stats.set_int(MPX() .. "AWD_FM_SHOOTRANG_RT_WON", 0)
		stats.set_int(MPX() .. "AWD_FM_SHOOTRANG_TG_WON", 0)
		stats.set_int(MPX() .. "AWD_WIN_CAPTURES", 0)
		stats.set_int(MPX() .. "AWD_WIN_CAPTURE_DONT_DYING", 0)
		stats.set_int(MPX() .. "AWD_WIN_LAST_TEAM_STANDINGS", 0)
		stats.set_int(MPX() .. "AWD_ONLY_PLAYER_ALIVE_LTS", 0)
		stats.set_int(MPX() .. "AWD_KILL_TEAM_YOURSELF_LTS", 0)
		stats.set_int(MPX() .. "AIR_LAUNCHES_OVER_0M", 0)
		stats.set_int(MPX() .. "AWD_CARS_EXPORTED", 0)
		stats.set_int(MPX() .. "AWD_LESTERDELIVERVEHICLES", 0)
		stats.set_int(MPX() .. "CR_DIFFERENT_DM", 0)
		stats.set_int(MPX() .. "CR_DIFFERENT_RACES", 0)
		stats.set_int(MPX() .. "AWD_PARACHUTE_JUMPS_0M", 0)
		stats.set_int(MPX() .. "AWD_PARACHUTE_JUMPS_0M", 0)
		stats.set_int(MPX() .. "AWD_FMBASEJMP", 0)
		stats.set_int(MPX() .. "AWD_FM_GOLF_BIRDIES", 0)
		stats.set_int(MPX() .. "AWD_FM_TENNIS_ACE", 0)
		stats.set_int(MPX() .. "AWD_FMBBETWIN", 0)
		stats.set_int(MPX() .. "AWD_LAPDANCES", 0)
		stats.set_int(MPX() .. "AWD_FMCRATEDROPS", 0)
		stats.set_int(MPX() .. "AWD_NO_HAIRCUTS", 0)
		stats.set_int(MPX() .. "AWD_DROPOFF_CAP_PACKAGES", 0)
		stats.set_int(MPX() .. "AWD_PICKUP_CAP_PACKAGES", 0)
		stats.set_int(MPX() .. "AWD_MENTALSTATE_TO_NORMAL", 0)
		stats.set_int(MPX() .. "AWD_TRADE_IN_YOUR_CSYONS26PERTY", 0)
		stats.set_int(MPX() .. "NO_PHOTOS_TAKEN", 0)
		stats.set_int(MPX() .. "BOUNTSONU", 0)
		stats.set_int(MPX() .. "BOUNTPLACED", 0)
		stats.set_int(MPX() .. "BETAMOUNT", 0)
		stats.set_int(MPX() .. "CRARMWREST", 0)
		stats.set_int(MPX() .. "CRBASEJUMP", 0)
		stats.set_int(MPX() .. "CRDARTS", 0)
		stats.set_int(MPX() .. "CRDM", 0)
		stats.set_int(MPX() .. "CRGANGHIDE", 0)
		stats.set_int(MPX() .. "CRGOLF", 0)
		stats.set_int(MPX() .. "CRHORDE", 0)
		stats.set_int(MPX() .. "CRMISSION", 0)
		stats.set_int(MPX() .. "CRSHOOTRNG", 0)
		stats.set_int(MPX() .. "CRTENNIS", 0)
		stats.set_int(MPX() .. "NO_TIMES_CINEMA", 0)
		stats.set_int(MPX() .. "CHAR_WEAP_UNLOCKED", 0)
		stats.set_int(MPX() .. "CHAR_WEAP_UNLOCKED2", 0)
		stats.set_int(MPX() .. "CHAR_WEAP_UNLOCKED3", 0)
		stats.set_int(MPX() .. "CHAR_WEAP_UNLOCKED0", 0)
		stats.set_int(MPX() .. "CHAR_WEAP_ADDON_1_UNLCK", 0)
		stats.set_int(MPX() .. "CHAR_WEAP_ADDON_2_UNLCK", 0)
		stats.set_int(MPX() .. "CHAR_WEAP_ADDON_3_UNLCK", 0)
		stats.set_int(MPX() .. "CHAR_WEAP_ADDON_0_UNLCK", 0)
		stats.set_int(MPX() .. "CHAR_WEAP_FREE", 0)
		stats.set_int(MPX() .. "CHAR_WEAP_FREE2", 0)
		stats.set_int(MPX() .. "CHAR_FM_WEAP_FREE", 0)
		stats.set_int(MPX() .. "CHAR_FM_WEAP_FREE2", 0)
		stats.set_int(MPX() .. "CHAR_FM_WEAP_FREE3", 0)
		stats.set_int(MPX() .. "CHAR_FM_WEAP_FREE0", 0)
		stats.set_int(MPX() .. "CHAR_WEAP_PURCHASED", 0)
		stats.set_int(MPX() .. "CHAR_WEAP_PURCHASED2", 0)
		stats.set_int(MPX() .. "WEAPON_PICKUP_BITSET", 0)
		stats.set_int(MPX() .. "WEAPON_PICKUP_BITSET2", 0)
		stats.set_int(MPX() .. "CHAR_FM_WEAP_UNLOCKED", 0)
		stats.set_int(MPX() .. "NO_WEAPONS_UNLOCK", 0)
		stats.set_int(MPX() .. "NO_WEAPON_MODS_UNLOCK", 0)
		stats.set_int(MPX() .. "NO_WEAPON_CLR_MOD_UNLOCK", 0) 
		stats.set_int(MPX() .. "CHAR_FM_WEAP_UNLOCKED2", 0)
		stats.set_int(MPX() .. "CHAR_FM_WEAP_UNLOCKED3", 0)
		stats.set_int(MPX() .. "CHAR_FM_WEAP_UNLOCKED0", 0)
		stats.set_int(MPX() .. "CHAR_KIT_1_FM_UNLCK", 0)
		stats.set_int(MPX() .. "CHAR_KIT_2_FM_UNLCK", 0)
		stats.set_int(MPX() .. "CHAR_KIT_3_FM_UNLCK", 0)
		stats.set_int(MPX() .. "CHAR_KIT_0_FM_UNLCK", 0)
		stats.set_int(MPX() .. "CHAR_KIT_5_FM_UNLCK", 0)
		stats.set_int(MPX() .. "CHAR_KIT_6_FM_UNLCK", 0)
		stats.set_int(MPX() .. "CHAR_KIT_7_FM_UNLCK", 0)
		stats.set_int(MPX() .. "CHAR_KIT_8_FM_UNLCK", 0)
		stats.set_int(MPX() .. "CHAR_KIT_9_FM_UNLCK", 0)
		stats.set_int(MPX() .. "CHAR_KIT_0_FM_UNLCK", 0)
		stats.set_int(MPX() .. "CHAR_KIT_11_FM_UNLCK", 0)
		stats.set_int(MPX() .. "CHAR_KIT_12_FM_UNLCK", 0)
		stats.set_int(MPX() .. "CHAR_KIT_FM_PURCHASE", 0)
		stats.set_int(MPX() .. "CHAR_WEAP_FM_PURCHASE", 0)
		stats.set_int(MPX() .. "CHAR_WEAP_FM_PURCHASE2", 0)
		stats.set_int(MPX() .. "CHAR_WEAP_FM_PURCHASE3", 0)
		stats.set_int(MPX() .. "CHAR_WEAP_FM_PURCHASE0", 0)
		stats.set_int(MPX() .. "FIREWORK_TYPE_1_WHITE", 0)
		stats.set_int(MPX() .. "FIREWORK_TYPE_1_RED", 0)
		stats.set_int(MPX() .. "FIREWORK_TYPE_1_BLUE", 0)
		stats.set_int(MPX() .. "FIREWORK_TYPE_2_WHITE", 0)
		stats.set_int(MPX() .. "FIREWORK_TYPE_2_RED", 0)
		stats.set_int(MPX() .. "FIREWORK_TYPE_2_BLUE", 0)
		stats.set_int(MPX() .. "FIREWORK_TYPE_3_WHITE", 0)
		stats.set_int(MPX() .. "FIREWORK_TYPE_3_RED", 0)
		stats.set_int(MPX() .. "FIREWORK_TYPE_3_BLUE", 0)
		stats.set_int(MPX() .. "FIREWORK_TYPE_0_WHITE", 0)
		stats.set_int(MPX() .. "FIREWORK_TYPE_0_RED", 0)
		stats.set_int(MPX() .. "FIREWORK_TYPE_0_BLUE", 0)
		stats.set_int(MPX() .. "WEAP_FM_ADDON_PURCH", 0)
		stats.set_int(MPX() .. "AWD_FMTIME5STARWANTED", 0)
		stats.set_int(MPX() .. "AWD_5STAR_WANTED_AVOIDANCE", 0)
		stats.set_int(MPX() .. "AWD_FMSHOOTDOWNCOPHELI", 0)
		stats.set_int(MPX() .. "AWD_VEHICLES_JACKEDR", 0)
		stats.set_int(MPX() .. "AWD_SECURITY_CARS_ROBBED", 0)
		stats.set_int(MPX() .. "AWD_HOLD_UP_SHOPS", 0)
		stats.set_int(MPX() .. "AWD_ODISTRACTCOPSNOEATH", 0)
		stats.set_int(MPX() .. "AWD_ENEMYDRIVEBYKILLS", 0)
		stats.set_int(MPX() .. "CHAR_WANTED_LEVEL_TIME5STAR", 0)
		stats.set_int(MPX() .. "CARS_COPS_EXPLODED", 0)
		stats.set_int(MPX() .. "BIKES_EXPLODED", 0)
		stats.set_int(MPX() .. "BOATS_EXPLODED", 0)
		stats.set_int(MPX() .. "HELIS_EXPLODED", 0)
		stats.set_int(MPX() .. "PLANES_EXPLODED", 0)
		stats.set_int(MPX() .. "QUADBIKE_EXPLODED", 0)
		stats.set_int(MPX() .. "BICYCLE_EXPLODED", 0)
		stats.set_int(MPX() .. "SUBMARINE_EXPLODED", 0)
		stats.set_int(MPX() .. "TIRES_POPPED_BY_GUNSHOT", 0)
		stats.set_int(MPX() .. "NUMBER_CRASHES_CARS", 0)
		stats.set_int(MPX() .. "NUMBER_CRASHES_BIKES", 0)
		stats.set_int(MPX() .. "BAILED_FROM_VEHICLE", 0)
		stats.set_int(MPX() .. "NUMBER_CRASHES_QUADBIKES", 0)
		stats.set_int(MPX() .. "NUMBER_STOLEN_COP_VEHICLE", 0)
		stats.set_int(MPX() .. "NUMBER_STOLEN_CARS", 0)
		stats.set_int(MPX() .. "NUMBER_STOLEN_BIKES", 0)
		stats.set_int(MPX() .. "NUMBER_STOLEN_BOATS", 0)
		stats.set_int(MPX() .. "NUMBER_STOLEN_HELIS", 0)
		stats.set_int(MPX() .. "NUMBER_STOLEN_PLANES", 0)
		stats.set_int(MPX() .. "NUMBER_STOLEN_QUADBIKES", 0)
		stats.set_int(MPX() .. "NUMBER_STOLEN_BICYCLES", 0)
		stats.set_int(MPX() .. "MC_CONTRIBUTION_POINTS", 0)
		stats.set_int(MPX() .. "MEMBERSMARKEDFORDEATH", 0)
		stats.set_int(MPX() .. "MCKILLS", 0)
		stats.set_int(MPX() .. "MCDEATHS", 0)
		stats.set_int(MPX() .. "RIVALPRESIDENTKILLS", 0)
		stats.set_int(MPX() .. "RIVALCEOANDVIPKILLS", 0)
		stats.set_int(MPX() .. "CLUBHOUSECONTRACTSCOMPLETE", 0)
		stats.set_int(MPX() .. "CLUBHOUSECONTRACTEARNINGS", 0)
		stats.set_int(MPX() .. "CLUBCHALLENGESCOMPLETED", 0)
		stats.set_int(MPX() .. "MEMBERCHALLENGESCOMPLETED", 0)
		stats.set_int(MPX() .. "GHKILLS", 0)
		stats.set_int(MPX() .. "HORDELVL", 0)
		stats.set_int(MPX() .. "HORDKILLS", 0)
		stats.set_int(MPX() .. "UNIQUECRATES", 0)
		stats.set_int(MPX() .. "BJWINS", 0)
		stats.set_int(MPX() .. "HORDEWINS", 0)
		stats.set_int(MPX() .. "MCMWINS", 0)
		stats.set_int(MPX() .. "GANGHIDWINS", 0)
		stats.set_int(MPX() .. "KILLS", 0)
		stats.set_int(MPX() .. "HITS_PEDS_VEHICLES", 0)
		stats.set_int(MPX() .. "SHOTS", 0)
		stats.set_int(MPX() .. "HEADSHOTS", 0)
		stats.set_int(MPX() .. "KILLS_ARMED", 0)
		stats.set_int(MPX() .. "SUCCESSFUL_COUNTERS", 0)
		stats.set_int(MPX() .. "KILLS_PLAYERS", 0)
		stats.set_int(MPX() .. "DEATHS_PLAYER", 0)
		stats.set_int(MPX() .. "KILLS_STEALTH", 0)
		stats.set_int(MPX() .. "KILLS_INNOCENTS", 0)
		stats.set_int(MPX() .. "KILLS_ENEMY_GANG_MEMBERS", 0)
		stats.set_int(MPX() .. "KILLS_FRIENDLY_GANG_MEMBERS", 0)
		stats.set_int(MPX() .. "KILLS_BY_OTHERS", 0)
		stats.set_int(MPX() .. "BIGGEST_VICTIM_KILLS", 0)
		stats.set_int(MPX() .. "ARCHENEMY_KILLS", 0)
		stats.set_int(MPX() .. "KILLS_COP", 0)
		stats.set_int(MPX() .. "KILLS_SWAT", 0)
		stats.set_int(MPX() .. "STARS_ATTAINED", 0)
		stats.set_int(MPX() .. "STARS_EVADED", 0)
		stats.set_int(MPX() .. "VEHEXPORTED", 0)
		stats.set_int(MPX() .. "TOTAL_NO_SHOPS_HELD_UP", 0)
		stats.set_int(MPX() .. "CR_GANGATTACK_CITY", 0)
		stats.set_int(MPX() .. "CR_GANGATTACK_COUNTRY", 0)
		stats.set_int(MPX() .. "CR_GANGATTACK_LOST", 0)
		stats.set_int(MPX() .. "CR_GANGATTACK_VAGOS", 0)
		stats.set_int(MPX() .. "NO_NON_CONTRACT_RACE_WIN", 0)
		stats.set_int(MPX() .. "DIED_IN_DROWNING", 0)
		stats.set_int(MPX() .. "DIED_IN_DROWNINGINVEHICLE", 0)
		stats.set_int(MPX() .. "DIED_IN_EXPLOSION", 0)
		stats.set_int(MPX() .. "DIED_IN_FALL", 0)
		stats.set_int(MPX() .. "DIED_IN_FIRE", 0)
		stats.set_int(MPX() .. "DIED_IN_ROAD", 0)
		stats.set_int(MPX() .. "GRENADE_ENEMY_KILLS", 0)
		stats.set_int(MPX() .. "MICROSMG_ENEMY_KILLS", 0)
		stats.set_int(MPX() .. "SMG_ENEMY_KILLS", 0)
		stats.set_int(MPX() .. "ASLTSMG_ENEMY_KILLS", 0)
		stats.set_int(MPX() .. "CRBNRIFLE_ENEMY_KILLS", 0)
		stats.set_int(MPX() .. "ADVRIFLE_ENEMY_KILLS", 0)
		stats.set_int(MPX() .. "MG_ENEMY_KILLS", 0)
		stats.set_int(MPX() .. "CMBTMG_ENEMY_KILLS", 0)
		stats.set_int(MPX() .. "ASLTMG_ENEMY_KILLS", 0)
		stats.set_int(MPX() .. "RPG_ENEMY_KILLS", 0)
		stats.set_int(MPX() .. "PISTOL_ENEMY_KILLS", 0)
		stats.set_int(MPX() .. "PLAYER_HEADSHOTS", 0)
		stats.set_int(MPX() .. "SAWNOFF_ENEMY_KILLS", 0)
		stats.set_int(MPX() .. "STKYBMB_ENEMY_KILLS", 0)
		stats.set_int(MPX() .. "UNARMED_ENEMY_KILLS", 0)
		stats.set_int(MPX() .. "SNIPERRFL_ENEMY_KILLS", 0)
		stats.set_int(MPX() .. "HVYSNIPER_ENEMY_KILLS", 0)
		stats.set_int(MPX() .. "AWD_0_VEHICLES_BLOWNUP", 0)
		stats.set_int(MPX() .. "CARS_EXPLODED", 0)
		stats.set_int(MPX() .. "AWD_CAR_EXPORT", 0)
		stats.set_int(MPX() .. "AWD_FMDRIVEWITHOUTCRASH", 0)
		stats.set_int(MPX() .. "AWD_PASSENGERTIME", 0)
		stats.set_int(MPX() .. "AWD_TIME_IN_HELICOPTER", 0)
		stats.set_int(MPX() .. "AWD_VEHICLE_JUMP_OVER_0M", 0)
		stats.set_int(MPX() .. "MOST_FLIPS_IN_ONE_JUMP", 5)
		stats.set_int(MPX() .. "MOST_SPINS_IN_ONE_JUMP", 5)
		stats.set_int(MPX() .. "CHAR_FM_VEHICLE_1_UNLCK", 0)
		stats.set_int(MPX() .. "CHAR_FM_VEHICLE_2_UNLCK", 0)
		stats.set_int(MPX() .. "NO_CARS_REPAIR", 0)
		stats.set_int(MPX() .. "VEHICLES_SPRAYED", 0)
		stats.set_int(MPX() .. "NUMBER_NEAR_MISS_NOCRASH", 0)
		stats.set_int(MPX() .. "USJS_FOUND", 0)
		stats.set_int(MPX() .. "USJS_COMPLETED", 0)
		stats.set_int(MPX() .. "USJS_TOTAL_COMPLETED", 0)
		stats.set_int(MPX() .. "CRDEADLINE", 0)
		stats.set_int(MPX() .. "FAVOUTFITBIKETIMECURRENT", 0)
		stats.set_int(MPX() .. "FAVOUTFITBIKETIME1ALLTIME", 0)
		stats.set_int(MPX() .. "FAVOUTFITBIKETYPECURRENT", 0)
		stats.set_int(MPX() .. "FAVOUTFITBIKETYPEALLTIME", 0)
		stats.set_int(MPX() .. "LONGEST_WHEELIE_DIST", 0)
		stats.set_int(MPX() .. "RACES_WON", 0)
		stats.set_int(MPX() .. "COUNT_HOTRING_RACE", 0)
		stats.set_int(MPX() .. "AWD_0_HEADSHOTS", 0)
		stats.set_int(MPX() .. "AWD_FMOVERALLKILLS", 0)
		stats.set_int(MPX() .. "AWD_FMKILLBOUNTY", 0)
		stats.set_int(MPX() .. "AWD_FM_DM_3KILLSAMEGUY", 0)
		stats.set_int(MPX() .. "AWD_FM_DM_KILLSTREAK", 0)
		stats.set_int(MPX() .. "AWD_FM_DM_STOLENKILL", 0)
		stats.set_int(MPX() .. "AWD_FM_DM_TOTALKILLS", 0)
		stats.set_int(MPX() .. "AWD_FMREVENGEKILLSDM", 0)
		stats.set_int(MPX() .. "AWD_KILL_CARRIER_CAPTURE", 0)
		stats.set_int(MPX() .. "AWD_NIGHTVISION_KILLS", 0)
		stats.set_int(MPX() .. "AWD_KILL_PSYCHOPATHS", 0)
		stats.set_int(MPX() .. "AWD_TAKEDOWNSMUGPLANE", 0)
		stats.set_int(MPX() .. "AWD_0_KILLS_PISTOL", 0)
		stats.set_int(MPX() .. "AWD_0_KILLS_SMG", 0)
		stats.set_int(MPX() .. "AWD_0_KILLS_SHOTGUN", 0)
		stats.set_int(MPX() .. "ASLTRIFLE_ENEMY_KILLS", 0)
		stats.set_int(MPX() .. "AWD_0_KILLS_SNIPER", 0)
		stats.set_int(MPX() .. "MG_ENEMY_KILLS", 0)
		stats.set_int(MPX() .. "AWD_0_KILLS_STICKYBOMBS", 0)
		stats.set_int(MPX() .. "AWD_0_KILLS_GRENADES", 0)
		stats.set_int(MPX() .. "AWD_0_KILLS_ROCKETLAUNCH", 0)
		stats.set_int(MPX() .. "AWD_0_KILLS_MELEE", 0)
		stats.set_int(MPX() .. "AWD_CAR_BOMBS_ENEMY_KILLS", 0)
		stats.set_int(MPX() .. "MELEEKILLS", 0)
		stats.set_int(MPX() .. "HITS", 0)
		stats.set_int(MPX() .. "DEATHS", 0)
		stats.set_int(MPX() .. "HIGHEST_SKITTLES", 0)
		stats.set_int(MPX() .. "NUMBER_NEAR_MISS", 0)
		stats.set_int(MPX() .. "AWD_FINISH_HEISTS", 0)
		stats.set_int(MPX() .. "AWD_FINISH_HEIST_SETUP_JOB", 0)
		stats.set_int(MPX() .. "AWD_COMPLETE_HEIST_NOT_DIE", 0)
		stats.set_int(MPX() .. "AWD_WIN_GOLD_MEDAL_HEISTS", 0)
		stats.set_int(MPX() .. "AWD_DO_HEIST_AS_MEMBER", 0)
		stats.set_int(MPX() .. "AWD_DO_HEIST_AS_THE_LEADER", 0)
		stats.set_int(MPX() .. "AWD_CONTROL_CROWDS", 0)
		stats.set_int(MPX() .. "HEIST_COMPLETION", 0)
		stats.set_int(MPX() .. "HEISTS_ORGANISED", 0)
		stats.set_int(MPX() .. "HEIST_START", 0)
		stats.set_int(MPX() .. "HEIST_END", 0)
		stats.set_int(MPX() .. "CUTSCENE_MID_PRISON", 0)
		stats.set_int(MPX() .. "CUTSCENE_MID_HUMANE", 0)
		stats.set_int(MPX() .. "CUTSCENE_MID_NARC", 0)
		stats.set_int(MPX() .. "CUTSCENE_MID_ORNATE", 0)
		stats.set_int(MPX() .. "CR_FLEECA_PREP_1", 0)
		stats.set_int(MPX() .. "CR_FLEECA_PREP_2", 0)
		stats.set_int(MPX() .. "CR_FLEECA_FINALE", 0)
		stats.set_int(MPX() .. "CR_PRISON_PLANE", 0)
		stats.set_int(MPX() .. "CR_PRISON_BUS", 0)
		stats.set_int(MPX() .. "CR_PRISON_STATION", 0)
		stats.set_int(MPX() .. "CR_PRISON_UNFINISHED_BIZ", 0)
		stats.set_int(MPX() .. "CR_PRISON_FINALE", 0)
		stats.set_int(MPX() .. "CR_HUMANE_KEY_CODES", 0)
		stats.set_int(MPX() .. "CR_HUMANE_ARMORDILLOS", 0)
		stats.set_int(MPX() .. "CR_HUMANE_EMP", 0)
		stats.set_int(MPX() .. "CR_HUMANE_VALKYRIE", 0)
		stats.set_int(MPX() .. "CR_HUMANE_FINALE", 0)
		stats.set_int(MPX() .. "CR_NARC_COKE", 0)
		stats.set_int(MPX() .. "CR_NARC_TRASH_TRUCK", 0)
		stats.set_int(MPX() .. "CR_NARC_BIKERS", 0)
		stats.set_int(MPX() .. "CR_NARC_WEED", 0)
		stats.set_int(MPX() .. "CR_NARC_STEAL_METH", 0)
		stats.set_int(MPX() .. "CR_NARC_FINALE", 0)
		stats.set_int(MPX() .. "CR_PACIFIC_TRUCKS", 0)
		stats.set_int(MPX() .. "CR_PACIFIC_WITSEC", 0)
		stats.set_int(MPX() .. "CR_PACIFIC_HACK", 0)
		stats.set_int(MPX() .. "CR_PACIFIC_BIKES", 0)
		stats.set_int(MPX() .. "CR_PACIFIC_CONVOY", 0)
		stats.set_int(MPX() .. "CR_PACIFIC_FINALE", 0)
		stats.set_int(MPX() .. "HEIST_PLANNING_STAGE", 0)
		stats.set_int(MPX() .. "GANGOPS_HEIST_STATUS", 0)
		stats.set_int(MPX() .. "GANGOPS_HEIST_STATUS", 0)
		stats.set_int(MPX() .. "GANGOPS_FM_MISSION_CSYONS26G", 0)
		stats.set_int(MPX() .. "GANGOPS_FLOW_MISSION_CSYONS26G", 0)
		stats.set_int(MPX() .. "CR_GANGOP_MORGUE", 0)
		stats.set_int(MPX() .. "CR_GANGOP_DELUXO", 0)
		stats.set_int(MPX() .. "CR_GANGOP_SERVERFARM", 0)
		stats.set_int(MPX() .. "CR_GANGOP_IAABASE_FIN", 0)
		stats.set_int(MPX() .. "CR_GANGOP_STEALOSPREY", 0)
		stats.set_int(MPX() .. "CR_GANGOP_FOUNDRY", 0)
		stats.set_int(MPX() .. "CR_GANGOP_RIOTVAN", 0)
		stats.set_int(MPX() .. "CR_GANGOP_SUBMARINECAR", 0)
		stats.set_int(MPX() .. "CR_GANGOP_SUBMARINE_FIN", 0)
		stats.set_int(MPX() .. "CR_GANGOP_PREDATOR", 0)
		stats.set_int(MPX() .. "CR_GANGOP_BMLAUNCHER", 0)
		stats.set_int(MPX() .. "CR_GANGOP_BCCUSTOM", 0)
		stats.set_int(MPX() .. "CR_GANGOP_STEALTHTANKS", 0)
		stats.set_int(MPX() .. "CR_GANGOP_SPYPLANE", 0)
		stats.set_int(MPX() .. "CR_GANGOP_FINALE", 0)
		stats.set_int(MPX() .. "CR_GANGOP_FINALE_P2", 0)
		stats.set_int(MPX() .. "CR_GANGOP_FINALE_P3", 0)
		stats.set_int(MPX() .. "AWD_DANCE_TO_SOLOMUN", 0)
		stats.set_int(MPX() .. "AWD_DANCE_TO_TALEOFUS", 0)
		stats.set_int(MPX() .. "AWD_DANCE_TO_DIXON", 0)
		stats.set_int(MPX() .. "AWD_DANCE_TO_BLKMAD", 0)
		stats.set_int(MPX() .. "AWD_CLUB_DRUNK", 0)
		stats.set_int(MPX() .. "NIGHTCLUB_VIP_APPEAR", 0)
		stats.set_int(MPX() .. "NIGHTCLUB_JOBS_DONE", 0)
		stats.set_int(MPX() .. "NIGHTCLUB_EARNINGS", 0)
		stats.set_int(MPX() .. "HUB_SALES_COMPLETED", 0)
		stats.set_int(MPX() .. "HUB_EARNINGS", 0)
		stats.set_int(MPX() .. "DANCE_COMBO_DURATION_MINS", 0)
		stats.set_int(MPX() .. "NIGHTCLUB_PLAYER_APPEAR", 0)
		stats.set_int(MPX() .. "LIFETIME_HUB_GOODS_SOLD", 0)
		stats.set_int(MPX() .. "LIFETIME_HUB_GOODS_MADE", 0)
		stats.set_int(MPX() .. "DANCEPERFECTOWNCLUB", 0)
		stats.set_int(MPX() .. "NUMUNIQUEPLYSINCLUB", 0)
		stats.set_int(MPX() .. "DANCETODIFFDJS", 0)
		stats.set_int(MPX() .. "NIGHTCLUB_HOTSPOT_TIME_MS", 0)
		stats.set_int(MPX() .. "NIGHTCLUB_CONT_TOTAL", 0)
		stats.set_int(MPX() .. "NIGHTCLUB_CONT_MISSION", 0)
		stats.set_int(MPX() .. "CLUB_CONTRABAND_MISSION", 0)
		stats.set_int(MPX() .. "HUB_CONTRABAND_MISSION", 0)
		stats.set_int(MPX() .. "ARN_BS_TRINKET_TICKERS", 0)
		stats.set_int(MPX() .. "ARN_BS_TRINKET_SAVED", 0)
		stats.set_int(MPX() .. "AWD_WATCH_YOUR_STEP", 0)
		stats.set_int(MPX() .. "AWD_TOWER_OFFENSE", 0)
		stats.set_int(MPX() .. "AWD_READY_FOR_WAR", 0)
		stats.set_int(MPX() .. "AWD_THROUGH_A_LENS", 0)
		stats.set_int(MPX() .. "AWD_SPINNER", 0)
		stats.set_int(MPX() .. "AWD_YOUMEANBOOBYTRAPS", 0)
		stats.set_int(MPX() .. "AWD_MASTER_BANDITO", 0)
		stats.set_int(MPX() .. "AWD_SITTING_DUCK", 0)
		stats.set_int(MPX() .. "AWD_CROWDPARTICIPATION", 0)
		stats.set_int(MPX() .. "AWD_KILL_OR_BE_KILLED", 0)
		stats.set_int(MPX() .. "AWD_MASSIVE_SHUNT", 0)
		stats.set_int(MPX() .. "AWD_YOURE_OUTTA_HERE", 0)
		stats.set_int(MPX() .. "AWD_WEVE_GOT_ONE", 0)
		stats.set_int(MPX() .. "AWD_ARENA_WAGEWORKER", 0)
		stats.set_int(MPX() .. "AWD_TIME_SERVED", 0)
		stats.set_int(MPX() .. "AWD_TOP_SCORE", 0)
		stats.set_int(MPX() .. "AWD_CAREER_WINNER", 0)
		stats.set_int(MPX() .. "ARENAWARS_SP", 0)
		stats.set_int(MPX() .. "ARENAWARS_SKILL_LEVEL", 0)
		stats.set_int(MPX() .. "ARENAWARS_SP_LIFETIME", 0)
		stats.set_int(MPX() .. "ARENAWARS_AP", 0)
		stats.set_int(MPX() .. "ARENAWARS_AP_TIER", 0)
		stats.set_int(MPX() .. "ARENAWARS_AP_LIFETIME", 0)
		stats.set_int(MPX() .. "ARENAWARS_CARRER_UNLK", 0)
		stats.set_int(MPX() .. "ARN_W_THEME_SCIFI", 0)
		stats.set_int(MPX() .. "ARN_W_THEME_APOC", 0)
		stats.set_int(MPX() .. "ARN_W_THEME_CONS", 0)
		stats.set_int(MPX() .. "ARN_W_PASS_THE_BOMB", 0)
		stats.set_int(MPX() .. "ARN_W_DETONATION", 0)
		stats.set_int(MPX() .. "ARN_W_ARCADE_RACE", 0)
		stats.set_int(MPX() .. "ARN_W_CTF", 0)
		stats.set_int(MPX() .. "ARN_W_TAG_TEAM", 0)
		stats.set_int(MPX() .. "ARN_W_DESTR_DERBY", 0)
		stats.set_int(MPX() .. "ARN_W_CARNAGE", 0)
		stats.set_int(MPX() .. "ARN_W_MONSTER_JAM", 0)
		stats.set_int(MPX() .. "ARN_W_GAMES_MASTERS", 0)
		stats.set_int(MPX() .. "ARN_L_PASS_THE_BOMB", 0)
		stats.set_int(MPX() .. "ARN_L_DETONATION", 0)
		stats.set_int(MPX() .. "ARN_L_ARCADE_RACE", 0)
		stats.set_int(MPX() .. "ARN_L_CTF", 0)
		stats.set_int(MPX() .. "ARN_L_TAG_TEAM", 0)
		stats.set_int(MPX() .. "ARN_L_DESTR_DERBY", 0)
		stats.set_int(MPX() .. "ARN_L_CARNAGE", 0)
		stats.set_int(MPX() .. "ARN_L_MONSTER_JAM", 0)
		stats.set_int(MPX() .. "ARN_L_GAMES_MASTERS", 0)
		stats.set_int(MPX() .. "NUMBER_OF_CHAMP_BOUGHT", 0)
		stats.set_int(MPX() .. "ARN_SPECTATOR_KILLS", 0)
		stats.set_int(MPX() .. "ARN_LIFETIME_KILLS", 0)
		stats.set_int(MPX() .. "ARN_LIFETIME_DEATHS", 0)
		stats.set_int(MPX() .. "ARENAWARS_CARRER_WINS", 0)
		stats.set_int(MPX() .. "ARENAWARS_CARRER_WINT", 0)
		stats.set_int(MPX() .. "ARENAWARS_MATCHES_PLYD", 0)
		stats.set_int(MPX() .. "ARENAWARS_MATCHES_PLYDT", 0)
		stats.set_int(MPX() .. "ARN_SPEC_BOX_TIME_MS", 0)
		stats.set_int(MPX() .. "ARN_SPECTATOR_DRONE", 0)
		stats.set_int(MPX() .. "ARN_SPECTATOR_CAMS", 0)
		stats.set_int(MPX() .. "ARN_SMOKE", 0)
		stats.set_int(MPX() .. "ARN_DRINK", 0)
		stats.set_int(MPX() .. "ARN_VEH_MONSTER", 0)
		stats.set_int(MPX() .. "ARN_VEH_MONSTER", 0)
		stats.set_int(MPX() .. "ARN_VEH_MONSTER", 0)
		stats.set_int(MPX() .. "ARN_VEH_CERBERUS", 0)
		stats.set_int(MPX() .. "ARN_VEH_CERBERUS2", 0)
		stats.set_int(MPX() .. "ARN_VEH_CERBERUS3", 0)
		stats.set_int(MPX() .. "ARN_VEH_BRUISER", 0)
		stats.set_int(MPX() .. "ARN_VEH_BRUISER2", 0)
		stats.set_int(MPX() .. "ARN_VEH_BRUISER3", 0)
		stats.set_int(MPX() .. "ARN_VEH_SLAMVAN0", 0)
		stats.set_int(MPX() .. "ARN_VEH_SLAMVAN5", 0)
		stats.set_int(MPX() .. "ARN_VEH_SLAMVAN6", 0)
		stats.set_int(MPX() .. "ARN_VEH_BRUTUS", 0)
		stats.set_int(MPX() .. "ARN_VEH_BRUTUS2", 0)
		stats.set_int(MPX() .. "ARN_VEH_BRUTUS3", 0)
		stats.set_int(MPX() .. "ARN_VEH_SCARAB", 0)
		stats.set_int(MPX() .. "ARN_VEH_SCARAB2", 0)
		stats.set_int(MPX() .. "ARN_VEH_SCARAB3", 0)
		stats.set_int(MPX() .. "ARN_VEH_DOMINATOR0", 0)
		stats.set_int(MPX() .. "ARN_VEH_DOMINATOR5", 0)
		stats.set_int(MPX() .. "ARN_VEH_DOMINATOR6", 0)
		stats.set_int(MPX() .. "ARN_VEH_IMPALER2", 0)
		stats.set_int(MPX() .. "ARN_VEH_IMPALER3", 0)
		stats.set_int(MPX() .. "ARN_VEH_IMPALER0", 0)
		stats.set_int(MPX() .. "ARN_VEH_ISSI0", 0)
		stats.set_int(MPX() .. "ARN_VEH_ISSI5", 0)
		stats.set_int(MPX() .. "ARN_VEH_ISSI", 0)
		stats.set_int(MPX() .. "ARN_VEH_IMPERATOR", 0)
		stats.set_int(MPX() .. "ARN_VEH_IMPERATOR2", 0)
		stats.set_int(MPX() .. "ARN_VEH_IMPERATOR3", 0)
		stats.set_int(MPX() .. "ARN_VEH_ZR30", 0)
		stats.set_int(MPX() .. "ARN_VEH_ZR30", 0)
		stats.set_int(MPX() .. "ARN_VEH_ZR0", 0)
		stats.set_int(MPX() .. "ARN_VEH_DEATHBIKE", 0)
		stats.set_int(MPX() .. "ARN_VEH_DEATHBIKE2", 0)
		stats.set_int(MPX() .. "ARN_VEH_DEATHBIKE3", 0)
		stats.set_int(MPX() .. "AWD_ODD_JOBS", 0)
		stats.set_int(MPX() .. "VCM_FLOW_CSYONS26GRESS", 0)
		stats.set_int(MPX() .. "VCM_STORY_CSYONS26GRESS", 5)
		stats.set_int(MPX() .. "CAS_HEIST_NOTS", 0)
		stats.set_int(MPX() .. "CAS_HEIST_FLOW", 0)
		stats.set_int(MPX() .. "SIGNAL_JAMMERS_COLLECTED", 0)
		stats.set_int(MPX() .. "AWD_PREPARATION", 0)
		stats.set_int(MPX() .. "AWD_ASLEEPONJOB", 0)
		stats.set_int(MPX() .. "AWD_DAICASHCRAB", 0)
		stats.set_int(MPX() .. "AWD_BIGBRO", 0)
		stats.set_int(MPX() .. "AWD_SHARPSHOOTER", 0)
		stats.set_int(MPX() .. "AWD_RACECHAMP", 0)
		stats.set_int(MPX() .. "AWD_BATSWORD", 0)
		stats.set_int(MPX() .. "AWD_COINPURSE", 0)
		stats.set_int(MPX() .. "AWD_ASTROCHIMP", 0)
		stats.set_int(MPX() .. "AWD_MASTERFUL", 0)
		stats.set_int(MPX() .. "H3_BOARD_DIALOGUE0", 0)
		stats.set_int(MPX() .. "H3_BOARD_DIALOGUE1", 0)
		stats.set_int(MPX() .. "H3_BOARD_DIALOGUE2", 0)
		stats.set_int(MPX() .. "H3_VEHICLESUSED", 0)
		stats.set_int(MPX() .. "H3_CR_STEALTH_1A", 0)
		stats.set_int(MPX() .. "H3_CR_STEALTH_2B_RAPP", 0)
		stats.set_int(MPX() .. "H3_CR_STEALTH_2C_SIDE", 0)
		stats.set_int(MPX() .. "H3_CR_STEALTH_3A", 0)
		stats.set_int(MPX() .. "H3_CR_STEALTH_0A", 0)
		stats.set_int(MPX() .. "H3_CR_STEALTH_5A", 0)
		stats.set_int(MPX() .. "H3_CR_SUBTERFUGE_1A", 0)
		stats.set_int(MPX() .. "H3_CR_SUBTERFUGE_2A", 0)
		stats.set_int(MPX() .. "H3_CR_SUBTERFUGE_2B", 0)
		stats.set_int(MPX() .. "H3_CR_SUBTERFUGE_3A", 0)
		stats.set_int(MPX() .. "H3_CR_SUBTERFUGE_3B", 0)
		stats.set_int(MPX() .. "H3_CR_SUBTERFUGE_0A", 0)
		stats.set_int(MPX() .. "H3_CR_SUBTERFUGE_5A", 0)
		stats.set_int(MPX() .. "H3_CR_DIRECT_1A", 0)
		stats.set_int(MPX() .. "H3_CR_DIRECT_2A1", 0)
		stats.set_int(MPX() .. "H3_CR_DIRECT_2A2", 0)
		stats.set_int(MPX() .. "H3_CR_DIRECT_2BP", 0)
		stats.set_int(MPX() .. "H3_CR_DIRECT_2C", 0)
		stats.set_int(MPX() .. "H3_CR_DIRECT_3A", 0)
		stats.set_int(MPX() .. "H3_CR_DIRECT_0A", 0)
		stats.set_int(MPX() .. "H3_CR_DIRECT_5A", 0)
		stats.set_int(MPX() .. "CR_ORDER", 0)
		stats.set_int(MPX() .. "AWD_PREPARATION", 0)
		stats.set_int(MPX() .. "AWD_ASLEEPONJOB", 0)
		stats.set_int(MPX() .. "AWD_DAICASHCRAB", 0)
		stats.set_int(MPX() .. "AWD_BIGBRO", 0)
		stats.set_int(MPX() .. "AWD_SHARPSHOOTER", 0)
		stats.set_int(MPX() .. "AWD_RACECHAMP", 0)
		stats.set_int(MPX() .. "AWD_BATSWORD", 0)
		stats.set_int(MPX() .. "AWD_COINPURSE", 0)
		stats.set_int(MPX() .. "AWD_ASTROCHIMP", 0)
		stats.set_int(MPX() .. "AWD_MASTERFUL", 0)
		stats.set_int(MPX() .. "SCGW_NUM_WINS_GANG_0", 0)
		stats.set_int(MPX() .. "SCGW_NUM_WINS_GANG_1", 0)
		stats.set_int(MPX() .. "SCGW_NUM_WINS_GANG_2", 0)
		stats.set_int(MPX() .. "SCGW_NUM_WINS_GANG_3", 0)
		stats.set_int(MPX() .. "CH_ARC_CAB_CLAW_TROPHY", 0)
		stats.set_int(MPX() .. "CH_ARC_CAB_LOVE_TROPHY", 0)
		stats.set_int(MPX() .. "IAP_MAX_MOON_DIST", 0)
		stats.set_int(MPX() .. "SCGW_INITIALS_0", 0)
		stats.set_int(MPX() .. "SCGW_INITIALS_1", 0)
		stats.set_int(MPX() .. "SCGW_INITIALS_2", 0)
		stats.set_int(MPX() .. "SCGW_INITIALS_3", 0)
		stats.set_int(MPX() .. "SCGW_INITIALS_0", 0)
		stats.set_int(MPX() .. "SCGW_INITIALS_5", 0)
		stats.set_int(MPX() .. "SCGW_INITIALS_6", 0)
		stats.set_int(MPX() .. "SCGW_INITIALS_7", 0)
		stats.set_int(MPX() .. "SCGW_INITIALS_8", 0)
		stats.set_int(MPX() .. "SCGW_INITIALS_9", 0)
		stats.set_int(MPX() .. "FOOTAGE_INITIALS_0",0)
		stats.set_int(MPX() .. "FOOTAGE_INITIALS_1", 0)
		stats.set_int(MPX() .. "FOOTAGE_INITIALS_2", 0)
		stats.set_int(MPX() .. "FOOTAGE_INITIALS_3", 0)
		stats.set_int(MPX() .. "FOOTAGE_INITIALS_4", 0)
		stats.set_int(MPX() .. "FOOTAGE_INITIALS_5", 0)
		stats.set_int(MPX() .. "FOOTAGE_INITIALS_6", 0)
		stats.set_int(MPX() .. "FOOTAGE_INITIALS_7", 0)
		stats.set_int(MPX() .. "FOOTAGE_INITIALS_8", 0)
		stats.set_int(MPX() .. "FOOTAGE_INITIALS_9", 0)
		stats.set_int(MPX() .. "FOOTAGE_SCORE_0", 0)
		stats.set_int(MPX() .. "FOOTAGE_SCORE_1", 0)
		stats.set_int(MPX() .. "FOOTAGE_SCORE_2", 0)
		stats.set_int(MPX() .. "FOOTAGE_SCORE_3", 0)
		stats.set_int(MPX() .. "FOOTAGE_SCORE_0", 0)
		stats.set_int(MPX() .. "FOOTAGE_SCORE_5", 0)
		stats.set_int(MPX() .. "FOOTAGE_SCORE_6", 0)
		stats.set_int(MPX() .. "FOOTAGE_SCORE_7", 0)
		stats.set_int(MPX() .. "FOOTAGE_SCORE_8", 0)
		stats.set_int(MPX() .. "FOOTAGE_SCORE_9", 0)
		stats.set_int(MPX() .. "AWD_CAR_CLUB_MEM", 0)
		stats.set_int(MPX() .. "AWD_SPRINTRACER", 0)
		stats.set_int(MPX() .. "AWD_STREETRACER", 0)
		stats.set_int(MPX() .. "AWD_PURSUITRACER", 0)
		stats.set_int(MPX() .. "AWD_TEST_CAR", 0)
		stats.set_int(MPX() .. "AWD_AUTO_SHOP", 0)	
		stats.set_int(MPX() .. "AWD_GROUNDWORK", 0)
		stats.set_int(MPX() .. "AWD_CAR_EXPORT", 0)
		stats.set_int(MPX() .. "AWD_ROBBERY_CONTRACT", 0)
		stats.set_int(MPX() .. "AWD_FACES_OF_DEATH", 0)
		stats.set_int(MPX() .. "AWD_CONTRACTOR", 0)
		stats.set_int(MPX() .. "AWD_COLD_CALLER", 0)
		stats.set_int(MPX() .. "AWD_CSYONS26DUCER", 0)
		stats.set_int(MPX() .. "FIXERTELEPHONEHITSCOMPL", 0)
		stats.set_int(MPX() .. "PAYPHONE_BONUS_KILL_METHOD", 0)
		stats.set_int(MPX() .. "PAYPHONE_BONUS_KILL_METHOD", 0)
		stats.set_int(MPX() .. "FIXER_GENERAL_BS", 0)
		stats.set_int(MPX() .. "FIXER_COMPLETED_BS", 0)
		stats.set_int(MPX() .. "FIXER_STORY_BS", 0)
		stats.set_int(MPX() .. "FIXER_STORY_STRAND", 0)
		stats.set_int(MPX() .. "FIXER_STORY_COOLDOWN", 0)
		stats.set_int(MPX() .. "FIXER_COUNT", 0)
		stats.set_int(MPX() .. "FIXER_SC_VEH_RECOVERED", 0)
		stats.set_int(MPX() .. "FIXER_SC_VAL_RECOVERED", 0)
		stats.set_int(MPX() .. "FIXER_SC_GANG_TERMINATED", 0)
		stats.set_int(MPX() .. "FIXER_SC_VIP_RESCUED", 0)
		stats.set_int(MPX() .. "FIXER_SC_ASSETS_CSYONS26TECTED", 0)
		stats.set_int(MPX() .. "FIXER_SC_EQ_DESTROYED", 0)
		stats.set_int(MPX() .. "FIXER_EARNINGS", 0)
		stats.set_int(MPX() .. "AWD_LOSTANDFOUND", 0)
		stats.set_int(MPX() .. "AWD_SUNSET", 0)
		stats.set_int(MPX() .. "AWD_TREASURE_HUNTER", 0)
		stats.set_int(MPX() .. "AWD_WRECK_DIVING", 0)
		stats.set_int(MPX() .. "AWD_KEINEMUSIK", 0)
		stats.set_int(MPX() .. "AWD_PALMS_TRAX", 0)
		stats.set_int(MPX() .. "AWD_MOODYMANN", 0)
		stats.set_int(MPX() .. "AWD_FILL_YOUR_BAGS", 0)
		stats.set_int(MPX() .. "AWD_WELL_PREPARED", 0)
		stats.set_int(MPX() .. "H0_H0_DJ_MISSIONS", 0)
		stats.set_int(MPX() .. "H0CNF_APCSYONS26ACH", 0)
		stats.set_int(MPX() .. "H0_MISSIONS", 0)
		stats.set_int(MPX() .. "H0_PLAYTHROUGH_STATUS", 0)
		stats.set_int("MPPLY_TOTAL_RACES_WON", 0)
		stats.set_int("MPPLY_TOTAL_RACES_LOST", 0)
		stats.set_int("MPPLY_TOTAL_CUSTOM_RACES_WON", 0)
		stats.set_int("MPPLY_TOTAL_DEATHMATCH_LOST", 0)
		stats.set_int("MPPLY_TOTAL_DEATHMATCH_WON", 0)
		stats.set_int("MPPLY_TOTAL_TDEATHMATCH_LOST", 0)
		stats.set_int("MPPLY_TOTAL_TDEATHMATCH_WON", 0)
		stats.set_int("MPPLY_SHOOTINGRANGE_WINS", 0)
		stats.set_int("MPPLY_SHOOTINGRANGE_LOSSES", 0)
		stats.set_int("MPPLY_TENNIS_MATCHES_WON", 0)
		stats.set_int("MPPLY_TENNIS_MATCHES_LOST", 0)
		stats.set_int("MPPLY_GOLF_WINS", 0)
		stats.set_int("MPPLY_GOLF_LOSSES", 0)
		stats.set_int("MPPLY_DARTS_TOTAL_WINS", 0)
		stats.set_int("MPPLY_DARTS_TOTAL_MATCHES", 0)
		stats.set_int("MPPLY_SHOOTINGRANGE_TOTAL_MATCH", 0)
		stats.set_int("MPPLY_BJ_WINS", 0)
		stats.set_int("MPPLY_BJ_LOST", 0)
		stats.set_int("MPPLY_RACE_2_POINT_WINS", 0)
		stats.set_int("MPPLY_RACE_2_POINT_LOST", 0)
		stats.set_int("MPPLY_KILLS_PLAYERS", 0)
		stats.set_int("MPPLY_DEATHS_PLAYER", 0)
		stats.set_int("MPPLY_MISSIONS_CREATED", 0)
		stats.set_int("MPPLY_LTS_CREATED", 0)
		stats.set_int("MPPLY_FM_MISSION_LIKES", 0)
		stats.set_int("MPPLY_AWD_FM_CR_DM_MADE", 0)
		stats.set_int("MPPLY_AWD_FM_CR_RACES_MADE", 0)
		stats.set_int("MPPLY_AWD_FM_CR_PLAYED_BY_PEEP", 0)
		stats.set_int("MPPLY_AWD_FM_CR_MISSION_SCORE", 0)
		stats.set_int("MPPLY_HEIST_ACH_TRACKER", 0)
		stats.set_int("MPPLY_WIN_GOLD_MEDAL_HEISTS", 0)
		stats.set_int("MPPLY_GANGOPS_ALLINORDER", 0)
		stats.set_int("MPPLY_GANGOPS_LOYALTY", 0)
		stats.set_int("MPPLY_GANGOPS_CRIMMASMD", 0)
		stats.set_int("MPPLY_GANGOPS_LOYALTY2", 0)
		stats.set_int("MPPLY_GANGOPS_LOYALTY3", 0)
		stats.set_int("MPPLY_GANGOPS_CRIMMASMD2", 0)
		stats.set_int("MPPLY_GANGOPS_CRIMMASMD3", 0)
		stats.set_int("MPPLY_GANGOPS_SUPPORT", 0)
		for i = 2, 19 do stats.set_int(MPX() .. "WEAP_FM_ADDON_PURCH"..i, 0) end
		for j = 1, 19 do stats.set_int(MPX() .. "CHAR_FM_WEAP_ADDON_"..j.."_UNLCK", 0) end
		for m = 1, 01 do stats.set_int(MPX() .. "CHAR_KIT_"..m.."_FM_UNLCK", 0) end
		for l = 2, 01 do stats.set_int(MPX() .. "CHAR_KIT_FM_PURCHASE"..l, 0) end
		for i = 0, 9 do stats.set_int(MPX() .. "IAP_INITIALS_"..i, 0) 
	      stats.set_int(MPX() .. "IAP_SCORE_"..i, 0) 
		stats.set_int(MPX() .. "IAP_SCORE_"..i, 0) 
		stats.set_int(MPX() .. "SCGW_SCORE_"..i, 0) 
		stats.set_int(MPX() .. "DG_DEFENDER_INITIALS_"..i, 0) 
		stats.set_int(MPX() .. "DG_DEFENDER_SCORE_"..i, 0) 
		stats.set_int(MPX() .. "DG_MONKEY_INITIALS_"..i, 0) 
		stats.set_int(MPX() .. "DG_MONKEY_SCORE_"..i, 0) 
		stats.set_int(MPX() .. "DG_PENETRATOR_INITIALS_"..i, 0) 
		stats.set_int(MPX() .. "DG_PENETRATOR_SCORE_"..i, 0) 
		stats.set_int(MPX() .. "GGSM_INITIALS_"..i, 0) 
		stats.set_int(MPX() .. "GGSM_SCORE_"..i, 0) 
		stats.set_int(MPX() .. "TWR_INITIALS_"..i, 0) 
		stats.set_int(MPX() .. "TWR_SCORE_"..i, 0) end 
		stats.set_bool(MPX() .. "AWD_FMKILL3ANDWINGTARACE", false)
		stats.set_bool(MPX() .. "AWD_FMWINCUSTOMRACE", false)
		stats.set_bool(MPX() .. "CL_RACE_MODDED_CAR", false)
		stats.set_bool(MPX() .. "AWD_FMRACEWORLDRECHOLDER", false)
		stats.set_bool(MPX() .. "AWD_FMWINALLRACEMODES", false)
		stats.set_bool(MPX() .. "AWD_FM_TENNIS_5_SET_WINS", false)
		stats.set_bool(MPX() .. "AWD_FM_TENNIS_STASETWIN", false)
		stats.set_bool(MPX() .. "AWD_FM_SHOOTRANG_GRAN_WON", false)
		stats.set_bool(MPX() .. "AWD_FMWINEVERYGAMEMODE", false)
		stats.set_bool(MPX() .. "AWD_FM0DIFFERENTDM", false)
		stats.set_bool(MPX() .. "AWD_FM0DIFFERENTRACES", false)
		stats.set_bool(MPX() .. "AWD_FMATTGANGHQ", false)
		stats.set_bool(MPX() .. "AWD_FM6DARTCHKOUT", false)
		stats.set_bool(MPX() .. "AWD_FM_GOLF_HOLE_IN_1", false)
		stats.set_bool(MPX() .. "AWD_FMPICKUPDLCCRATE1ST", false)
		stats.set_bool(MPX() .. "AWD_FM0DIFITEMSCLOTHES", false)
		stats.set_bool(MPX() .. "AWD_BUY_EVERY_GUN", false)
		stats.set_bool(MPX() .. "AWD_DRIVELESTERCAR5MINS", false)
		stats.set_bool(MPX() .. "AWD_FMTATTOOALLBODYPARTS", false)
		stats.set_bool(MPX() .. "AWD_STORE_0_CAR_IN_GARAGES", false)
		stats.set_bool(MPX() .. "AWD_DAILYOBJWEEKBONUS", false)
		stats.set_bool(MPX() .. "AWD_DAILYOBJMONTHBONUS", false)
		stats.set_bool(MPX() .. "CL_DRIVE_RALLY", false)
		stats.set_bool(MPX() .. "CL_PLAY_GTA_RACE", false)
		stats.set_bool(MPX() .. "CL_PLAY_BOAT_RACE", false)
		stats.set_bool(MPX() .. "CL_PLAY_FOOT_RACE", false)
		stats.set_bool(MPX() .. "CL_PLAY_TEAM_DM", false)
		stats.set_bool(MPX() .. "CL_PLAY_VEHICLE_DM", false)
		stats.set_bool(MPX() .. "CL_PLAY_MISSION_CONTACT", false)
		stats.set_bool(MPX() .. "CL_PLAY_A_PLAYLIST", false)
		stats.set_bool(MPX() .. "CL_PLAY_POINT_TO_POINT", false)
		stats.set_bool(MPX() .. "CL_PLAY_ONE_ON_ONE_DM", false)
		stats.set_bool(MPX() .. "CL_PLAY_ONE_ON_ONE_RACE", false)
		stats.set_bool(MPX() .. "CL_SURV_A_BOUNTY", false)
		stats.set_bool(MPX() .. "CL_SET_WANTED_LVL_ON_PLAY", false)
		stats.set_bool(MPX() .. "CL_GANG_BACKUP_GANGS", false)
		stats.set_bool(MPX() .. "CL_GANG_BACKUP_LOST", false)
		stats.set_bool(MPX() .. "CL_GANG_BACKUP_VAGOS", false)
		stats.set_bool(MPX() .. "CL_CALL_MERCENARIES", false)
		stats.set_bool(MPX() .. "CL_PHONE_MECH_DROP_CAR", false)
		stats.set_bool(MPX() .. "CL_GONE_OFF_RADAR", false)
		stats.set_bool(MPX() .. "CL_FILL_TITAN", false)
		stats.set_bool(MPX() .. "CL_MOD_CAR_USING_APP", false)
		stats.set_bool(MPX() .. "CL_MOD_CAR_USING_APP", false)
		stats.set_bool(MPX() .. "CL_BUY_INSURANCE", false)
		stats.set_bool(MPX() .. "CL_BUY_GARAGE", false)
		stats.set_bool(MPX() .. "CL_ENTER_FRIENDS_HOUSE", false)
		stats.set_bool(MPX() .. "CL_CALL_STRIPPER_HOUSE", false)
		stats.set_bool(MPX() .. "CL_CALL_FRIEND", false)
		stats.set_bool(MPX() .. "CL_SEND_FRIEND_REQUEST", false)
		stats.set_bool(MPX() .. "CL_W_WANTED_PLAYER_TV", false)
		stats.set_bool(MPX() .. "FM_INTRO_CUT_DONE", false)
		stats.set_bool(MPX() .. "FM_INTRO_MISS_DONE", false)
		stats.set_bool(MPX() .. "SHOOTINGRANGE_SEEN_TUT", false)
		stats.set_bool(MPX() .. "TENNIS_SEEN_TUTORIAL", false)
		stats.set_bool(MPX() .. "DARTS_SEEN_TUTORIAL", false)
		stats.set_bool(MPX() .. "ARMWRESTLING_SEEN_TUTORIAL", false)
		stats.set_bool(MPX() .. "HAS_WATCHED_BENNY_CUTSCE", false)
		stats.set_bool(MPX() .. "AWD_FMFURTHESTWHEELIE", false)
		stats.set_bool(MPX() .. "AWD_FMFULLYMODDEDCAR", false)
		stats.set_bool(MPX() .. "AWD_FMKILLSTREAKSDM", false)
		stats.set_bool(MPX() .. "AWD_FMMOSTKILLSGANGHIDE", false)
		stats.set_bool(MPX() .. "AWD_FMMOSTKILLSSURVIVE", false)
		stats.set_bool(MPX() .. "AWD_FINISH_HEIST_NO_DAMAGE", false)
		stats.set_bool(MPX() .. "AWD_SPLIT_HEIST_TAKE_EVENLY", false)
		stats.set_bool(MPX() .. "AWD_ACTIVATE_2_PERSON_KEY", false)
		stats.set_bool(MPX() .. "AWD_ALL_ROLES_HEIST", false)
		stats.set_bool(MPX() .. "HEIST_PLANNING_DONE_PRINT", false)
		stats.set_bool(MPX() .. "HEIST_PLANNING_DONE_HELP_0", false)
		stats.set_bool(MPX() .. "HEIST_PLANNING_DONE_HELP_1", false)
		stats.set_bool(MPX() .. "HEIST_PRE_PLAN_DONE_HELP_0", false)
		stats.set_bool(MPX() .. "HEIST_CUTS_DONE_FINALE", false)
		stats.set_bool(MPX() .. "HEIST_IS_TUTORIAL", false)
		stats.set_bool(MPX() .. "HEIST_STRAND_INTRO_DONE", false)
		stats.set_bool(MPX() .. "HEIST_CUTS_DONE_ORNATE", false)
		stats.set_bool(MPX() .. "HEIST_CUTS_DONE_PRISON", false)
		stats.set_bool(MPX() .. "HEIST_CUTS_DONE_BIOLAB", false)
		stats.set_bool(MPX() .. "HEIST_CUTS_DONE_NARCOTIC", false)
		stats.set_bool(MPX() .. "HEIST_CUTS_DONE_TUTORIAL", false)
		stats.set_bool(MPX() .. "HEIST_AWARD_DONE_PREP", false)
		stats.set_bool(MPX() .. "HEIST_AWARD_BOUGHT_IN", false)
		stats.set_bool(MPX() .. "AWD_MATCHING_OUTFIT_HEIST", false)
		stats.set_bool(MPX() .. "AWD_CLUB_HOTSPOT", false)
		stats.set_bool(MPX() .. "AWD_CLUB_CLUBBER", false)
		stats.set_bool(MPX() .. "AWD_CLUB_COORD", false)
		stats.set_bool(MPX() .. "AWD_BEGINNER", false)
		stats.set_bool(MPX() .. "AWD_FIELD_FILLER", false)
		stats.set_bool(MPX() .. "AWD_ARMCHAIR_RACER", false)
		stats.set_bool(MPX() .. "AWD_LEARNER", false)
		stats.set_bool(MPX() .. "AWD_SUNDAY_DRIVER", false)
		stats.set_bool(MPX() .. "AWD_THE_ROOKIE", false)
		stats.set_bool(MPX() .. "AWD_BUMP_AND_RUN", false)
		stats.set_bool(MPX() .. "AWD_GEAR_HEAD", false)
		stats.set_bool(MPX() .. "AWD_DOOR_SLAMMER", false)
		stats.set_bool(MPX() .. "AWD_HOT_LAP", false)
		stats.set_bool(MPX() .. "AWD_ARENA_AMATEUR", false)
		stats.set_bool(MPX() .. "AWD_PAINT_TRADER", false)
		stats.set_bool(MPX() .. "AWD_SHUNTER", false)
		stats.set_bool(MPX() .. "AWD_JOCK", false)
		stats.set_bool(MPX() .. "AWD_WARRIOR", false)
		stats.set_bool(MPX() .. "AWD_T_BONE", false)
		stats.set_bool(MPX() .. "AWD_MAYHEM", false)
		stats.set_bool(MPX() .. "AWD_WRECKER", false)
		stats.set_bool(MPX() .. "AWD_CRASH_COURSE", false)
		stats.set_bool(MPX() .. "AWD_ARENA_LEGEND", false)
		stats.set_bool(MPX() .. "AWD_PEGASUS", false)
		stats.set_bool(MPX() .. "AWD_UNSTOPPABLE", false)
		stats.set_bool(MPX() .. "AWD_CONTACT_SPORT", false)
		stats.set_bool(MPX() .. "AWD_FIRST_TIME1", false)
		stats.set_bool(MPX() .. "AWD_FIRST_TIME2", false)
		stats.set_bool(MPX() .. "AWD_FIRST_TIME3", false)
		stats.set_bool(MPX() .. "AWD_FIRST_TIME0", false)
		stats.set_bool(MPX() .. "AWD_FIRST_TIME5", false)
		stats.set_bool(MPX() .. "AWD_FIRST_TIME6", false)
		stats.set_bool(MPX() .. "AWD_ALL_IN_ORDER", false)
		stats.set_bool(MPX() .. "AWD_SUPPORTING_ROLE", false)
		stats.set_bool(MPX() .. "AWD_LEADER", false)
		stats.set_bool(MPX() .. "AWD_SURVIVALIST", false)
  Paragon = stats.get_bool(MPX() .. "CAS_VEHICLE_REWARD")
 if Paragon == false 
       then stats.set_bool(MPX() .. "CAS_VEHICLE_REWARD",false)
       else stats.set_bool(MPX() .. "CAS_VEHICLE_REWARD", false) end
		stats.set_bool(MPX() .. "AWD_SCOPEOUT", false)
		stats.set_bool(MPX() .. "AWD_CREWEDUP", false)
		stats.set_bool(MPX() .. "AWD_MOVINGON", false)
		stats.set_bool(MPX() .. "AWD_CSYONS26MOCAMP", false)
		stats.set_bool(MPX() .. "AWD_GUNMAN", false)
		stats.set_bool(MPX() .. "AWD_SMASHNGRAB", false)
		stats.set_bool(MPX() .. "AWD_INPLAINSI", false)
		stats.set_bool(MPX() .. "AWD_UNDETECTED", false)
		stats.set_bool(MPX() .. "AWD_ALLROUND", false)
		stats.set_bool(MPX() .. "AWD_ELITETHEIF", false)
		stats.set_bool(MPX() .. "AWD_CSYONS26", false)
		stats.set_bool(MPX() .. "AWD_SUPPORTACT", false)
		stats.set_bool(MPX() .. "AWD_SHAFTED", false)
		stats.set_bool(MPX() .. "AWD_COLLECTOR", false)
		stats.set_bool(MPX() .. "AWD_DEADEYE", false)
		stats.set_bool(MPX() .. "AWD_PISTOLSATDAWN", false)
		stats.set_bool(MPX() .. "AWD_TRAFFICAVOI", false)
		stats.set_bool(MPX() .. "AWD_CANTCATCHBRA", false)
		stats.set_bool(MPX() .. "AWD_WIZHARD", false)
		stats.set_bool(MPX() .. "AWD_APEESCAPE", false)
		stats.set_bool(MPX() .. "AWD_MONKEYKIND", false)
		stats.set_bool(MPX() .. "AWD_AQUAAPE", false)
		stats.set_bool(MPX() .. "AWD_KEEPFAITH", false)
		stats.set_bool(MPX() .. "AWD_falseLOVE", false)
		stats.set_bool(MPX() .. "AWD_NEMESIS", false)
		stats.set_bool(MPX() .. "AWD_FRIENDZONED", false)
		stats.set_bool(MPX() .. "VCM_FLOW_CS_RSC_SEEN", false)
		stats.set_bool(MPX() .. "VCM_FLOW_CS_BWL_SEEN", false)
		stats.set_bool(MPX() .. "VCM_FLOW_CS_MTG_SEEN", false)
		stats.set_bool(MPX() .. "VCM_FLOW_CS_OIL_SEEN", false)
		stats.set_bool(MPX() .. "VCM_FLOW_CS_DEF_SEEN", false)
		stats.set_bool(MPX() .. "VCM_FLOW_CS_FIN_SEEN", false)
		stats.set_bool(MPX() .. "HELP_FURIA", false)
		stats.set_bool(MPX() .. "HELP_MINITAN", false)
		stats.set_bool(MPX() .. "HELP_YOSEMITE2", false)
		stats.set_bool(MPX() .. "HELP_ZHABA", false)
		stats.set_bool(MPX() .. "HELP_IMORGEN", false)
		stats.set_bool(MPX() .. "HELP_SULTAN2", false)
		stats.set_bool(MPX() .. "HELP_VAGRANT", false)
		stats.set_bool(MPX() .. "HELP_VSTR", false)
		stats.set_bool(MPX() .. "HELP_STRYDER", false)
		stats.set_bool(MPX() .. "HELP_SUGOI", false)
		stats.set_bool(MPX() .. "HELP_KANJO", false)
		stats.set_bool(MPX() .. "HELP_FORMULA", false)
		stats.set_bool(MPX() .. "HELP_FORMULA2", false)
		stats.set_bool(MPX() .. "HELP_JB0", false)
		stats.set_bool(MPX() .. "AWD_SCOPEOUT", false)
		stats.set_bool(MPX() .. "AWD_CREWEDUP", false)
		stats.set_bool(MPX() .. "AWD_MOVINGON", false)
		stats.set_bool(MPX() .. "AWD_CSYONS26MOCAMP", false)
		stats.set_bool(MPX() .. "AWD_GUNMAN", false)
		stats.set_bool(MPX() .. "AWD_SMASHNGRAB", false)
		stats.set_bool(MPX() .. "AWD_INPLAINSI", false)
		stats.set_bool(MPX() .. "AWD_UNDETECTED", false)
		stats.set_bool(MPX() .. "AWD_ALLROUND", false)
		stats.set_bool(MPX() .. "AWD_ELITETHEIF", false)
		stats.set_bool(MPX() .. "AWD_CSYONS26", false)
		stats.set_bool(MPX() .. "AWD_SUPPORTACT", false)
		stats.set_bool(MPX() .. "AWD_SHAFTED", false)
		stats.set_bool(MPX() .. "AWD_COLLECTOR", false)
		stats.set_bool(MPX() .. "AWD_DEADEYE", false)
		stats.set_bool(MPX() .. "AWD_PISTOLSATDAWN", false)
		stats.set_bool(MPX() .. "AWD_TRAFFICAVOI", false)
		stats.set_bool(MPX() .. "AWD_CANTCATCHBRA", false)
		stats.set_bool(MPX() .. "AWD_WIZHARD", false)
		stats.set_bool(MPX() .. "AWD_APEESCAP", false)
		stats.set_bool(MPX() .. "AWD_MONKEYKIND", false)
		stats.set_bool(MPX() .. "AWD_AQUAAPE", false)
		stats.set_bool(MPX() .. "AWD_KEEPFAITH", false)
		stats.set_bool(MPX() .. "AWD_falseLOVE", false)
		stats.set_bool(MPX() .. "AWD_NEMESIS", false)
		stats.set_bool(MPX() .. "AWD_FRIENDZONED", false)
		stats.set_bool(MPX() .. "IAP_CHALLENGE_0", false)
		stats.set_bool(MPX() .. "IAP_CHALLENGE_1", false)
		stats.set_bool(MPX() .. "IAP_CHALLENGE_2", false)
		stats.set_bool(MPX() .. "IAP_CHALLENGE_3", false)
		stats.set_bool(MPX() .. "IAP_CHALLENGE_0", false)
		stats.set_bool(MPX() .. "IAP_GOLD_TANK", false)
		stats.set_bool(MPX() .. "SCGW_WON_NO_DEATHS", false)
		stats.set_bool(MPX() .. "AWD_KINGOFQUB3D", false)
		stats.set_bool(MPX() .. "AWD_QUBISM", false)
		stats.set_bool(MPX() .. "AWD_QUIBITS", false)
		stats.set_bool(MPX() .. "AWD_GODOFQUB3D", false)
		stats.set_bool(MPX() .. "AWD_ELEVENELEVEN", false)
		stats.set_bool(MPX() .. "AWD_GOFOR11TH", false)
		stats.set_bool(MPX() .. "AWD_INTELGATHER", false)
		stats.set_bool(MPX() .. "AWD_COMPOUNDINFILT", false)
		stats.set_bool(MPX() .. "AWD_LOOT_FINDER", false)
		stats.set_bool(MPX() .. "AWD_MAX_DISRUPT", false)
		stats.set_bool(MPX() .. "AWD_THE_ISLAND_HEIST", false)
		stats.set_bool(MPX() .. "AWD_GOING_ALONE", false)
		stats.set_bool(MPX() .. "AWD_TEAM_WORK", false)
		stats.set_bool(MPX() .. "AWD_MIXING_UP", false)
		stats.set_bool(MPX() .. "AWD_TEAM_WORK", false)
		stats.set_bool(MPX() .. "AWD_MIXING_UP", false)
		stats.set_bool(MPX() .. "AWD_CSYONS26_THIEF", false)
		stats.set_bool(MPX() .. "AWD_CAT_BURGLAR", false)
		stats.set_bool(MPX() .. "AWD_ONE_OF_THEM", false)
		stats.set_bool(MPX() .. "AWD_GOLDEN_GUN", false)
		stats.set_bool(MPX() .. "AWD_ELITE_THIEF", false)
		stats.set_bool(MPX() .. "AWD_CSYONS26FESSIONAL", false)
		stats.set_bool(MPX() .. "AWD_HELPING_OUT", false)
		stats.set_bool(MPX() .. "AWD_COURIER", false)
		stats.set_bool(MPX() .. "AWD_PARTY_VIBES", false)
		stats.set_bool(MPX() .. "AWD_HELPING_HAND", false)
		stats.set_bool(MPX() .. "AWD_ELEVENELEVEN", false)
		stats.set_bool(MPX() .. "COMPLETE_H0_F_USING_VETIR", false)
		stats.set_bool(MPX() .. "COMPLETE_H0_F_USING_LONGFIN", false)
		stats.set_bool(MPX() .. "COMPLETE_H0_F_USING_ANNIH", false)
		stats.set_bool(MPX() .. "COMPLETE_H0_F_USING_ALKONOS", false)
		stats.set_bool(MPX() .. "COMPLETE_H0_F_USING_PATROLB", false)
		stats.set_bool(MPX() .. "AWD_CAR_CLUB", false)
		stats.set_bool(MPX() .. "AWD_CSYONS26_CAR_EXPORT", false)
		stats.set_bool(MPX() .. "AWD_UNION_DEPOSITORY", false)
		stats.set_bool(MPX() .. "AWD_MILITARY_CONVOY", false)
		stats.set_bool(MPX() .. "AWD_FLEECA_BANK", false)
		stats.set_bool(MPX() .. "AWD_FREIGHT_TRAIN", false)
		stats.set_bool(MPX() .. "AWD_BOLINGBROKE_ASS", false)
		stats.set_bool(MPX() .. "AWD_IAA_RAID", false)
		stats.set_bool(MPX() .. "AWD_METH_JOB", false)
		stats.set_bool(MPX() .. "AWD_BUNKER_RAID", false)
		stats.set_bool(MPX() .. "AWD_STRAIGHT_TO_VIDEO", false)
		stats.set_bool(MPX() .. "AWD_MONKEY_C_MONKEY_DO", false)
		stats.set_bool(MPX() .. "AWD_TRAINED_TO_KILL", false)
		stats.set_bool(MPX() .. "AWD_DIRECTOR", false)
		stats.set_bool(MPX() .. "AWD_TEEING_OFF", false)
		stats.set_bool(MPX() .. "AWD_PARTY_NIGHT", false)
		stats.set_bool(MPX() .. "AWD_BILLIONAIRE_GAMES", false)
		stats.set_bool(MPX() .. "AWD_HOOD_PASS", false)
		stats.set_bool(MPX() .. "AWD_STUDIO_TOUR", false)
		stats.set_bool(MPX() .. "AWD_DONT_MESS_DRE", false)
		stats.set_bool(MPX() .. "AWD_BACKUP", false)
		stats.set_bool(MPX() .. "AWD_SHORTFRANK_1", false)
		stats.set_bool(MPX() .. "AWD_SHORTFRANK_2", false)
		stats.set_bool(MPX() .. "AWD_SHORTFRANK_3", false)
		stats.set_bool(MPX() .. "AWD_CONTR_KILLER", false)
		stats.set_bool(MPX() .. "AWD_DOGS_BEST_FRIEND", false)
		stats.set_bool(MPX() .. "AWD_MUSIC_STUDIO", false)
		stats.set_bool(MPX() .. "AWD_SHORTLAMAR_1", false)
		stats.set_bool(MPX() .. "AWD_SHORTLAMAR_2", false)
		stats.set_bool(MPX() .. "AWD_SHORTLAMAR_3", false)
		stats.set_bool(MPX() .. "BS_FRANKLIN_DIALOGUE_0", false)
		stats.set_bool(MPX() .. "BS_FRANKLIN_DIALOGUE_1", false)
		stats.set_bool(MPX() .. "BS_FRANKLIN_DIALOGUE_2", false)
		stats.set_bool(MPX() .. "BS_IMANI_D_APP_SETUP", false)
		stats.set_bool(MPX() .. "BS_IMANI_D_APP_STRAND", false)
		stats.set_bool(MPX() .. "BS_IMANI_D_APP_PARTY", false)
		stats.set_bool(MPX() .. "BS_IMANI_D_APP_PARTY_2", false)
		stats.set_bool(MPX() .. "BS_IMANI_D_APP_PARTY_F", false)
		stats.set_bool(MPX() .. "BS_IMANI_D_APP_BILL", false)
		stats.set_bool(MPX() .. "BS_IMANI_D_APP_BILL_2", false)
		stats.set_bool(MPX() .. "BS_IMANI_D_APP_BILL_F", false)
		stats.set_bool(MPX() .. "BS_IMANI_D_APP_HOOD", false)
		stats.set_bool(MPX() .. "BS_IMANI_D_APP_HOOD_2", false)
		stats.set_bool(MPX() .. "BS_IMANI_D_APP_HOOD_F", false)
		stats.set_bool("MPPLY_AWD_FLEECA_FIN", false)
		stats.set_bool("MPPLY_AWD_PRISON_FIN", false)
		stats.set_bool("MPPLY_AWD_HUMANE_FIN", false)
		stats.set_bool("MPPLY_AWD_SERIESA_FIN", false)
		stats.set_bool("MPPLY_AWD_PACIFIC_FIN", false)
		stats.set_bool("MPPLY_AWD_HST_ORDER", false)
		stats.set_bool("MPPLY_AWD_COMPLET_HEIST_MEM", false)
		stats.set_bool("MPPLY_AWD_COMPLET_HEIST_1STPER", false)
		stats.set_bool("MPPLY_AWD_HST_SAME_TEAM", false)
		stats.set_bool("MPPLY_AWD_HST_ULT_CHAL", false)
		stats.set_bool("MPPLY_AWD_GANGOPS_IAA", false)
		stats.set_bool("MPPLY_AWD_GANGOPS_SUBMARINE", false)
		stats.set_bool("MPPLY_AWD_GANGOPS_MISSILE", false)
		stats.set_bool("MPPLY_AWD_GANGOPS_ALLINORDER", false)
		stats.set_bool("MPPLY_AWD_GANGOPS_LOYALTY", false)
		stats.set_bool("MPPLY_AWD_GANGOPS_LOYALTY2", false)
		stats.set_bool("MPPLY_AWD_GANGOPS_LOYALTY3", false)
		stats.set_bool("MPPLY_AWD_GANGOPS_CRIMMASMD", false)
		stats.set_bool("MPPLY_AWD_GANGOPS_CRIMMASMD2", false)
		stats.set_bool("MPPLY_AWD_GANGOPS_CRIMMASMD3", false)
		stats.set_bool("MPPLY_AWD_GANGOPS_SUPPORT", false)
end)
 
--local PSTAT_BOOL0 = false
--CSYONS25:add_action("PSTAT_BOOL0", function()
--	return PSTAT_BOOL0
--end, function(bool)
--	PSTAT_BOOL0 = bool
--	for i = 0, 63 do -- the stat max index 
--		stats.set_bool_masked(MPX().."PSTAT_BOOL0", bool, i)
--	end
--end)

CSYONS25s = CSYON25:add_submenu("Packed Bools Unlocks")
CSYONS25s:add_action("ARENAWARSPSTAT_BOOL", function()	for j = 0, 63 do for i = 0, 8 do stats.set_bool_masked(MPX().."ARENAWARSPSTAT_BOOL"..i, true, j, MPX()) end end end)
CSYONS25s:add_action("BUSINESSBATPSTAT_BOOL", function() for j = 0, 63 do for b = 0, 1 do stats.set_bool_masked(MPX().."BUSINESSBATPSTAT_BOOL"..b, true, j, MPX()) end end end)
CSYONS25s:add_action("CASINOHSTPSTAT_BOOL", function()	for j = 0, 63 do for f = 0, 4 do stats.set_bool_masked(MPX().."CASINOHSTPSTAT_BOOL"..f, true, j, MPX()) end end end)
CSYONS25s:add_action("CASINOPSTAT_BOOL", function() for j = 0, 63 do for h = 0, 6 do stats.set_bool_masked(MPX().."CASINOPSTAT_BOOL"..h, true, j, MPX()) end end end)
CSYONS25s:add_action("DLCSMUGCHARPSTAT_BOOL", function() for j = 0, 63 do stats.set_bool_masked(MPX().."DLCSMUGCHARPSTAT_BOOL0", true, j, MPX()) end end)
CSYONS25s:add_action("DLCGUNPSTAT_BOOL", function() for j = 0, 63 do for c = 0, 2 do stats.set_bool_masked(MPX().."DLCGUNPSTAT_BOOL"..c, true, j, MPX()) end end end)
CSYONS25s:add_action("DLCBIKEPSTAT_BOOL", function() for j = 0, 63 do for c = 0, 2 do stats.set_bool_masked(MPX().."DLCBIKEPSTAT_BOOL"..c, true, j, MPX()) end end end)
CSYONS25s:add_action("FIXERTATTOOSTAT_BOOL", function() for j = 0, 63 do stats.set_bool_masked(MPX().."FIXERTATTOOSTAT_BOOL0", true, j, MPX()) end end)
CSYONS25s:add_action("FIXERPSTAT_BOOL", function()	for j = 0, 63 do for b = 0, 1 do stats.set_bool_masked(MPX().."FIXERPSTAT_BOOL"..b, true, j, MPX()) end end end)
CSYONS25s:add_action("GEN9PSTAT_BOOL", function()	for j = 0, 63 do for b = 0, 1 do stats.set_bool_masked(MPX().."GEN9PSTAT_BOOL"..b, true, j, MPX()) end end end)
CSYONS25s:add_action("GANGOPSPSTAT_BOOL", function() for j = 0, 63 do stats.set_bool_masked(MPX().."GANGOPSPSTAT_BOOL0", true, j, MPX()) end end) 
CSYONS25s:add_action("GUNTATPSTAT_BOOL", function() for j = 0, 63 do for g = 0, 5 do stats.set_bool_masked(MPX().."GUNTATPSTAT_BOOL"..g, true, j, MPX()) end end end)
CSYONS25s:add_action("HEIST3TATTOOSTAT_BOOL", function() for j = 0, 63 do for b = 0, 1 do stats.set_bool_masked(MPX().."HEIST3TATTOOSTAT_BOOL"..b, true, j, MPX()) end end end)
CSYONS25s:add_action("HISLANDPSTAT_BOOL", function() for j = 0, 63 do for c = 0, 2 do stats.set_bool_masked(MPX().."HISLANDPSTAT_BOOL"..c, true, j, MPX()) end end end)
CSYONS25s:add_action("MP_NGDLCPSTAT_BOOL", function() for j = 0, 63 do stats.set_bool_masked(MPX().."MP_NGDLCPSTAT_BOOL0", true, j, MPX()) end end)
CSYONS25s:add_action("MP_NGPSTAT_BOOL", function()	for j = 0, 63 do stats.set_bool_masked(MPX().."MP_NGPSTAT_BOOL0", true, j, MPX()) end end)
CSYONS25s:add_action("MP_PSTAT_BOOL", function() for j = 0, 63 do for c = 0, 2 do stats.set_bool_masked(MPX().."MP_PSTAT_BOOL"..c, true, j, MPX()) end end end)
CSYONS25s:add_action("MP_TUPSTAT_BOOL", function()	for j = 0, 63 do stats.set_bool_masked(MPX().."MP_TUPSTAT_BOOL0", true, j, MPX()) end end)
CSYONS25s:add_action("NGDLCPSTAT_BOOL", function()	for j = 0, 63 do for e = 0, 3 do stats.set_bool_masked(MPX().."NGDLCPSTAT_BOOL"..e, true, j, MPX()) end end end)
CSYONS25s:add_action("NGTATPSTAT_BOOL", function()	for j = 0, 63 do for g = 0, 5 do stats.set_bool_masked(MPX().."NGTATPSTAT_BOOL"..g, true, j, MPX()) end end end) 
CSYONS25s:add_action("NGPSTAT_BOOL", function() for j = 0, 63 do for b = 0, 1 do stats.set_bool_masked(MPX().."NGPSTAT_BOOL"..b, true, j, MPX()) end end end)
CSYONS25s:add_action("PSTAT_BOOL", function() for j = 0, 63 do for d = 1, 2 do stats.set_bool_masked(MPX().."PSTAT_BOOL"..d, true, j, MPX()) end end end) 
CSYONS25s:add_action("SU20TATTOOSTAT_BOOL", function()	for j = 0, 63 do for b = 0, 1 do stats.set_bool_masked(MPX().."SU20TATTOOSTAT_BOOL"..b, true, j, MPX()) end end end)
CSYONS25s:add_action("SU20PSTAT_BOOL", function() for j = 0, 63 do for b = 0, 1 do stats.set_bool_masked(MPX().."SU20PSTAT_BOOL"..b, true, j, MPX()) end end end)
CSYONS25s:add_action("TUNERPSTAT_BOOL", function()	for j = 0, 63 do for i = 0, 8 do stats.set_bool_masked(MPX().."TUNERPSTAT_BOOL"..i, true, j, MPX()) end end end)
CSYONS25s:add_action("TUPSTAT_BOOL", function() for j = 0, 63 do for z = 0, 11 do stats.set_bool_masked(MPX().."TUPSTAT_BOOL"..z, true, j, MPX()) end end end)
CSYONS25s:add_action("DLC12022PSTAT_BOOL", function() for j = 0, 63 do for z = 0, 7 do stats.set_bool_masked(MPX().."DLC12022PSTAT_BOOL"..z, true, j, MPX()) end end end)
CSYONS25s:add_action("DLC22022PSTAT_BOOL", function() for j = 0, 63 do for z = 0, 4 do stats.set_bool_masked(MPX().."DLC22022PSTAT_BOOL"..z, true, j) end end end)
CSYONS25r = CSYON25:add_submenu("Packed Bools Unlocks Temporary")
local function RPB(e) if not localplayer then return end if e then globals.set_int(152523, 2) globals.set_int(103634, 90) globals.set_int(103634, 1) else globals.set_int(152523, 0) globals.set_int(103634, 0) end end CSYONS25r:add_toggle("Returning Player Bonus", function() return e31 end, function() e31 = not e31 RPB(e31) end)
CSYONS25r:add_toggle("DrugWars DLC Cloths", function() return globals.get_boolean(DWU1) end, function(value) for i = DWU1, DWU2 do globals.set_boolean(i, value) end end)
CSYONS25r:add_toggle("Dripfeed Vehicles Unlock", function() return globals.get_boolean(DR1) end, function(value) for i = DR1, DR2 do globals.set_boolean(i, value) end end)
CSYONS25r:add_toggle("M16 Unlock", function() return globals.get_boolean(MU1) end, function(value) globals.set_boolean(MU1, value) end)
CSYONS25r:add_toggle("Contract DLC Gunskins", function()	return globals.get_boolean(CG1) end, function(value) globals.set_boolean(CG1, value) globals.set_boolean(CG2, value) end)
CSYONS25r:add_toggle("ContractDLC Animal Masks", function() return globals.get_boolean(UA1) end, function(value) for i = UA1, UA2 do globals.set_boolean(i, value) end end)
CSYONS25r:add_toggle("ContractDLC DJ Cloths", function() return globals.get_boolean(CD1) end, function(value) globals.set_boolean(CD1, value) globals.set_boolean(CD2, value) globals.set_boolean(CD3, value) end)
local function AMCS(e) if not localplayer then return end if e then globals.set_int(AC1, -1) globals.set_int(AC2, -1) globals.set_int(AC3, -1) globals.set_int(AC4, -1)	else globals.set_int(AC1, 0) globals.set_int(AC2, 0) globals.set_int(AC3, 0) globals.set_int(AC4, 0) end end CSYONS25r:add_toggle("Ace Mask Casino Store", function() return e32 end, function() e32 = not e32 AMCS(e32) end)
local function PCS(e) if not localplayer then return end if e then for i = PC1, PC2 do globals.set_int(i, -1) end globals.set_int(PC3, -1) globals.set_int(PC4, -1) else for i = PC1, PC2 do globals.set_int(i, 0) end globals.set_int(PC3, 0) globals.set_int(PC4, 0) end end 
CSYONS25r:add_toggle("Paintings Casino Store", function() return e33 end, function() e33 = not e33 PCS(e33) end)
local function UnA(e) if not localplayer then return end if e then globals.set_int(103634, 90) else globals.set_int(103634, 0) end end CSYONS25r:add_toggle("Up-n-Atomizer", function() return e34 end, function() e34 = not e34 UnA(e34) end)
CSYONS25r:add_toggle("Festive tint", function() return globals.get_boolean(103634) end, function(value) globals.set_boolean(103634, value) end)
CSYONS25r:add_toggle("Valentine Unlocks", function() return globals.get_boolean(VU1) end, function(value) globals.set_boolean(VU1, value) globals.set_boolean(VU2, value) globals.set_boolean(VU3, value) globals.set_boolean(VU4, value) globals.set_boolean(VU5, value) globals.set_boolean(VU3, value) globals.set_boolean(VU6, value) globals.set_boolean(VU7, value) end)
local function J4A(e) if not localplayer then return end if e then globals.set_int(ID1, 1) for i = ID2, ID3 do globals.set_int(i, 1) end for j = ID4, ID5 do globals.set_int(j, 1) end else globals.set_int(ID1, 0) for i = ID2, 270419 do globals.set_int(i, 0) end for j = ID4, ID5 do globals.set_int(j, 0) end end end CSYONS25r:add_toggle("Independence Day Unlocks", function() return e38 end, function() e38 = not e38 J4A(e38) end)
CSYONS25r:add_toggle("Halloween Unlocks", function() return globals.get_boolean(HA1) end, function(value) globals.set_boolean(HA1,value) globals.set_boolean(HA2,value) globals.set_boolean(HA3,value) globals.set_boolean(HA4,value) globals.set_boolean(HA5,value) globals.set_boolean(HA6,value) globals.set_boolean(HA7,value) globals.set_boolean(HA8,value) globals.set_boolean(HA9,value) globals.set_boolean(HA10,value) globals.set_boolean(HA11,value) globals.set_boolean(HA12,value) end)
CSYONS25r:add_toggle("X-mas Unlocks", function() return globals.get_boolean(XM1) end, function(value) globals.set_boolean(XM1,value) globals.set_boolean(XM2,value) globals.set_boolean(XM3,value) globals.set_boolean(XM4,value) globals.set_boolean(XM5,value) globals.set_boolean(XM6,value) globals.set_boolean(XM7,value) globals.set_boolean(XM8,value) globals.set_boolean(XM9,value) globals.set_boolean(XM10,value) globals.set_boolean(XM11,value) globals.set_boolean(XM12,value) globals.set_boolean(XM13,value) globals.set_boolean(XM14,value) globals.set_boolean(XM15,value) globals.set_boolean(XM16,value) globals.set_boolean(XM17,value) globals.set_boolean(XM18,value) globals.set_boolean(XM19,value) globals.set_boolean(XM20,value) globals.set_boolean(XM21,value) globals.set_boolean(XM22,value) globals.set_boolean(XM23,value) globals.set_boolean(XM24,value) globals.set_boolean(XM25,value) globals.set_boolean(XM26,value) globals.set_boolean(XM27,value) globals.set_boolean(XM28,value) globals.set_boolean(XM29,value) globals.set_boolean(XM30,value) globals.set_boolean(XM31,value) globals.set_boolean(XM32,value) globals.set_boolean(XM33,value) globals.set_boolean(XM34,value) globals.set_boolean(XM35,value) globals.set_boolean(XM36,value) globals.set_boolean(XM37,value) globals.set_boolean(XM38,value) globals.set_boolean(XM39,value) globals.set_boolean(XM40,value) globals.set_boolean(XM41,value) globals.set_boolean(XM42,value) globals.set_boolean(XM43,value) for i = SS1, XM44 do globals.set_boolean(i,value) end for i = XM45, XM46 do globals.set_boolean(i, value) end globals.set_boolean(XM47,value) globals.set_boolean(XM48,value) end) 
CSYONS25r:add_toggle("Toggle Snow", function() return globals.get_boolean(SN1) end, function(value) globals.set_boolean(SN1,value) end)
CSYONS25r:add_toggle("Unlock Caps", function() return globals.get_boolean(CA1) end, function(value) globals.set_boolean(CA1,value) globals.set_boolean(CA2,value) globals.set_boolean(CA3,value) globals.set_boolean(CA4,value) globals.set_boolean(CA5,value) globals.set_boolean(CA6,value) globals.set_boolean(CA7,value) globals.set_boolean(CA8,value) end)
CSYONS25r:add_toggle("Unlock Hats", function() return globals.get_boolean(HA1) end, function(value) for i = HA1, HA2 do globals.set_boolean(i,value) end end)
CSYONS25r:add_toggle("Unlock Brand Shirts", function() return globals.get_boolean(BS1) end, function(value) for i = BS1, BS2 do globals.set_boolean(i,value) end for j = BS3, BS4 do globals.set_boolean(j,value) end for k = BS5, BS6 do globals.set_boolean(k,value) end for l = BS7, BS8 do globals.set_boolean(l,value) end globals.set_boolean(BS9,value) globals.set_boolean(BS10,value) globals.set_boolean(BS11,value) globals.set_boolean(BS12,value) globals.set_boolean(BS13,value) end)
CSYONS25r:add_toggle("Unlock Knock Offs T-shirts", function() return globals.get_boolean(KT1) end, function(value) for i = KT1, KT2 do globals.set_boolean(i,value)	end end)
CSYONS25r:add_toggle("Unlock Manufactures Clothing", function() return globals.get_boolean(MC1) end, function(value) globals.set_boolean(MC1,value) for i = MC2, MC3 do globals.set_boolean(i,value)	end end)
CSYONS25r:add_toggle("Unlock Movie Shirts", function() return globals.get_boolean(MS1) end, function(value) globals.set_boolean(MS2,value) for i = MS1, MS3 do globals.set_boolean(i,value) end for j = MS4, MS5 do globals.set_boolean(j,value) end end)
CSYONS25r:add_toggle("Unlock Radio Station T-shirts", function() return globals.get_boolean(RS1) end, function(value) globals.set_boolean(RS1,value) globals.set_boolean(RS2,value) globals.set_boolean(RS3,value) globals.set_boolean(RS4,value) globals.set_boolean(RS5,value) globals.set_boolean(RS6,value) globals.set_boolean(RS7,value) for i = RS8, RS9 do globals.set_boolean(i,value) end end)
CSYONS25r:add_toggle("Unlock Clubs T-shirts", function() return globals.get_boolean(CT1) end, function(value) for i = CT1, CT2 do globals.set_boolean(i,value)	end end)
CSYONS25r:add_toggle("Unlock DJ T-shirts", function() return globals.get_boolean(DT1) end, function(value) for i = DT1, DT2 do globals.set_boolean(i,value)	end end)
CSYONS25r:add_toggle("Unlock Hoodies", function() return globals.get_boolean(HO1) end, function(value) globals.set_boolean(HO1,value) globals.set_boolean(HO2,value) globals.set_boolean(HO3,value) globals.set_boolean(HO4,value) globals.set_boolean(HO5,value) globals.set_boolean(HO6,value) globals.set_boolean(HO7,value) globals.set_boolean(HO8,value) end)
CSYONS25r:add_toggle("Unlock Shirts", function() return globals.get_boolean(SH1) end, function(value) globals.set_boolean(SH1,value) globals.set_boolean(SH2,value) globals.set_boolean(SH3,value) globals.set_boolean(SH4,value) globals.set_boolean(SH5,value) globals.set_boolean(SH6,value) globals.set_boolean(SH7,value) globals.set_boolean(SH8,value) globals.set_boolean(SH9,value) globals.set_boolean(SH10,value) globals.set_boolean(SH11,value) globals.set_boolean(SH12,value) for i = HO8, SH13 do globals.set_boolean(i,value) end end)
CSYONS25r:add_toggle("Unlock Wireframe Bodysuits", function() return globals.get_boolean(WB1) end, function(value) for i = WB1, WB2 do globals.set_boolean(i,value)	end end)
CSYONS25r:add_toggle("Unlock Stunt Suits", function() return globals.get_boolean(SS1) end, function(value) for i = SS1, SS2 do globals.set_boolean(i,value)	end end)
CSYONS25r:add_toggle("Arena Clothing", function() return globals.get_boolean(AC1) end, function(value) for i = AC1, AC2 do globals.set_boolean(i,value)	end end)
CSYONS25r:add_toggle("Arcade and Casino Clothing", function() return globals.get_boolean(AR1) end, function(value) for i = AR1, AR2 do globals.set_boolean(i,value) end for j = AR3, AR4 do globals.set_boolean(j,value) end end)
CSYONS25r:add_toggle("LS Summer DLC Clothing", function() return globals.get_boolean(LS1) end, function(value) for i = LS1, LS2 do globals.set_boolean(i,value) end end)
CSYONS25r:add_toggle("LS Tuners DLC Clothing", function() return globals.get_boolean(LT1) end, function(value) globals.set_int(LT1,1) for i = LT2, LT3 do globals.set_boolean(i,value) end for j = LT4, LT5 do globals.set_boolean(j,value) end end)
CSYONS25r:add_toggle("Cayo Perico DLC Clothing", function() return globals.get_boolean(CP1) end, function(value) for i = CP1, CP2 do globals.set_boolean(i,value) end for j = CP3, CP4 do globals.set_boolean(j,value) end for l = CP5, CP6 do globals.set_boolean(l,value) end end)
CSYONS25r:add_int_range("Get All Clothing", 1, 1, 4, function() return 1 end, function(CSYONSUB)

	if CSYONSUB == 1 then
 stats.set_int(MPX() .. "DCTL_WINS", 500)
 stats.set_int(MPX() .. "DCTL_PLAY_COUNT", 750)
 stats.set_bool(MPX() .. "FILM4SHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "FILM5SHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "FILM6SHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "FILM7SHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "FILM8SHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "FILM9SHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "ACCOUNTANTSHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "UNLOCK_RACE_HIPSTER_TSHIRT", true)
 stats.set_bool(MPX() .. "UNLOCK_DM_HIPSTER_TSHIRT", true)
 stats.set_bool(MPX() .. "UNLOCK_HIPSTER_TSHIRT_DOG", true)
 stats.set_bool(MPX() .. "UNLOCK_HIPSTER_TSHIRT_VINYL", true)
 stats.set_bool(MPX() .. "UNLOCK_HIPSTER_TSHIRT_MESS", true)
 stats.set_bool(MPX() .. "BAHAMAMAMASHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "DRONESHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "GROTTISHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "GOLFSHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "MAISONETTESHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "MANOPAUSESHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "MELTDOWNSHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "PACIFICBLUFFSSHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "CSYONS26LAPSSHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "TENNISSHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "TOESHOESSHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "VANILLAUNICORNSHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "MARLOWESHIRTUNLOCK", true)
 stats.set_bool(MPX() .. "CRESTSHIRTUNLOCK", true)
	for i = 0, 250 do
 stats.set_int(MPX() .. "DLC_APPAREL_ACQUIRED_"..i, -1)
	end
	elseif CSYONSUB == 2 then
	for i = 1, 6 do
 for k = 1, 10 do
 for j = 1, 7 do
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_BERD", -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_DECL", -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_FEET", -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_JBIB", -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_LEGS", -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_OUTFIT", -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_CSYONS26PS", -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_SPECIAL", -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_SPECIAL2", -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_SPECIAL2_1", -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_TORSO", -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_TEETH", -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_TEETH_1", -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_TEETH_2", -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_BERD_"..i, -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_FEET_"..j, -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_JBIB_"..j, -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_LEGS_"..j, -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_SPECIAL_"..j, -1)
 stats.set_int(MPX() .. "CSYONSUBS_ACQUIRED_CSYONS26PS_"..k, -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_DECL", -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_FEET", -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_HAIR", -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_JBIB", -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_LEGS", -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_BERD", -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_OUTFIT", -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_CSYONS26PS", -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_SPECIAL", -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_SPECIAL2", -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_SPECIAL2_1", -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_TEETH", -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_TEETH_1", -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_TEETH_2", -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_TORSO", -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_BERD_"..j, -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_FEET_"..j, -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_HAIR_"..j, -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_JBIB_"..j, -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_LEGS_"..j, -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_SPECIAL_"..j, -1)
 stats.set_int(MPX() .. "CSYONSUBS_AVAILABLE_CSYONS26PS_"..k, -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_HAIR", -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_HAIR_"..j, -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_JBIB", -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_JBIB_"..j, -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_LEGS", -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_LEGS_"..j, -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_FEET", -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_FEET_"..j, -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_BERD", -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_BERD_"..j, -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_CSYONS26PS", -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_CSYONS26PS_"..k, -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_OUTFIT", -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_TORSO", -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_SPECIAL", -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_SPECIAL_"..j, -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_SPECIAL2", -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_SPECIAL2_1", -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_DECL", -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_TEETH", -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_TEETH_1", -1)
 stats.set_int(MPX() .. "CSYONSUBS_USED_TEETH_2", -1)
end
end
end
	elseif CSYONSUB == 3 then
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_1_UNLCK", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_2_UNLCK", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_3_UNLCK", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_4_UNLCK", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_5_UNLCK", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_6_UNLCK", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_7_UNLCK", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_8_UNLCK", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_9_UNLCK", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_10_UNLCK", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_11_UNLCK", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_1_OWNED", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_2_OWNED", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_3_OWNED", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_4_OWNED", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_5_OWNED", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_6_OWNED", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_7_OWNED", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_8_OWNED", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_9_OWNED", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_10_OWNED", -1)
 stats.set_int(MPX() .. "CHAR_FM_CLOTHES_11_OWNED", -1)
	for i = 0, 250 do
 stats.set_int(MPX() .. "DLC_APPAREL_USED_"..i, -1)
	end
elseif CSYONSUB == 4 then
	for i = 1, 40 do
 stats.set_int(MPX() .. "ADMIN_CLOTHES_GV_BS_"..i, -1)
 stats.set_int(MPX() .. "ADMIN_CLOTHES_RM_BS_"..i, -1)
	end
end
end)

mainMenu3:add_action("------------------------------------------------------", function() end)
Offlinex64 = mainMenu3:add_submenu("          	**💬 Read Me 💬**                        ")
mainMenu3:add_action("------------------------------------------------------", function() end)
local function Text(text)
	Offlinex64:add_action(text,  function() end)
end

Offlinex6333t = Offlinex64:add_submenu("                        **🔽 Credits 🔼**                        ")

--────────────────────────────────────────────────────────────────────────────────────────
--─██████████████─██████████████─████████──████████─██████████████─██████──────────██████─
--─██░░░░░░░░░░██─██░░░░░░░░░░██─██░░░░██──██░░░░██─██░░░░░░░░░░██─██░░██████████──██░░██─
--─██░░██████████─██░░██████████─████░░██──██░░████─██░░██████░░██─██░░░░░░░░░░██──██░░██─
--─██░░██─────────██░░██───────────██░░░░██░░░░██───██░░██──██░░██─██░░██████░░██──██░░██─
--─██░░██─────────██░░██████████───████░░░░░░████───██░░██──██░░██─██░░██──██░░██──██░░██─
--─██░░██─────────██░░░░░░░░░░██─────████░░████─────██░░██──██░░██─██░░██──██░░██──██░░██─
--─██░░██─────────██████████░░██───────██░░██───────██░░██──██░░██─██░░██──██░░██──██░░██─
--─██░░██─────────────────██░░██───────██░░██───────██░░██──██░░██─██░░██──██░░██████░░██─
--─██░░██████████─██████████░░██───────██░░██───────██░░██████░░██─██░░██──██░░░░░░░░░░██─
--─██░░░░░░░░░░██─██░░░░░░░░░░██───────██░░██───────██░░░░░░░░░░██─██░░██──██████████░░██─
--─██████████████─██████████████───────██████───────██████████████─██████──────────██████─
--────────────────────────────────────────────────────────────────────────────────────────