--░█████╗░░██████╗██╗░░░██╗░█████╗░███╗░░██╗
--██╔══██╗██╔════╝╚██╗░██╔╝██╔══██╗████╗░██║
--██║░░╚═╝╚█████╗░░╚████╔╝░██║░░██║██╔██╗██║
--██║░░██╗░╚═══██╗░░╚██╔╝░░██║░░██║██║╚████║
--╚█████╔╝██████╔╝░░░██║░░░╚█████╔╝██║░╚███║
--░╚════╝░╚═════╝░░░░╚═╝░░░░╚════╝░╚═╝░░╚══╝

function CheckOnlineVersion()
	major, minor, build, patch = menu.get_game_version()
	if build ~= 2944 then
		main = menu.add_submenu("⚠The game current version is: "..major.."."..minor.."."..build.."."..patch)
		main:add_submenu("Game updated!!!")
		main:add_submenu("The sctipt is outdated!!!")
	end
end
CheckOnlineVersion()
require_game_build(2944) -- GTA Online version 1.67

local function Textegb(text)
	mainMenu2:add_action(text,  function() end)
end

local function Textes(text)
	Online:add_action(text,  function() end)
end

local function Textg(text)
	Offlinex64:add_action(text,  function() end)
end

--local function Text(text)
--	menu.add_action(text,  function() end)
--end
----------

mainMenu2 = menu.add_submenu("【 CSYON 】 SubMenu Playerlist & Bounty")

Textegb("**************************************************************************")
Textegb("            ** CSYON SubMenu 1.67 **                  ")
Textegb("                               **✅ v13 **                   ")
Textegb("            ** ⚠️Game Build Version 2845⚠️ **                  ")
Textegb("**************************************************************************")
 
Online= mainMenu2:add_submenu("【 CSYON 】 Online Players Csyon Submenu")

Textes("**************************************************************************")
Textes("            ** CSYON SubMenu 1.67 **                  ")
Textes("                               **✅ v13 **                   ")
Textes("            ** ⚠️Game Build Version 2845⚠️ **                  ")
Textes("**************************************************************************")
 
CSYON3 = Online:add_submenu("【 CSYON 】 👨 Online Players")

CSYON5 = Online:add_submenu("【 CSYON 】 👨 Online Player Logs")

CSYON4 = Online:add_submenu("【 CSYON 】 👨 Online Players Bounty")

local sub = CSYON4:add_submenu("【 CSYON 】 👨 Player Bounty")

CSYON21 = Online:add_submenu("【 CSYON 】 ⚠info for help")

CSYONS5 = CSYON5:add_submenu("【 CSYON 】 👨 Players Logs")

CSYONS21 = CSYON21:add_submenu("【 CSYON 】 ⚠ReadMe")
 
----- playerlog start
local function null() end
local function clamp(num, min, max)
	if num > max then return max elseif num < min then return min else return num end
end
local function multstr(s,n)
    for i = 0, n - 1 do
        s = s..s
    end
    return s
end
local function tlen(T)
    local c = 0
    for _ in pairs(T) do c = c + 1 end
    return c
end
local function tind(T, i, b)
    local c = 0
    for k, v in pairs(T) do
        if type(v) == "table" and b then goto c end 
        c = c + 1 
        if c == i then 
            return k, v 
        end
        ::c:: 
    end
end
local function PrintTable(table, offset)
    if not offset then offset = 0 end
    if offset == 0 then print(tostring(table)..":") end
    for k,v in pairs(table) do
        if type(v) == "table" then
            print(multstr("   ",offset)..k.." ("..tostring(v)..") =")
            PrintTable(v, offset + 1)
        else
            print(multstr("   ",offset)..k.." ("..type(v)..") = "..tostring(v))
        end
    end
end
 
local PlayerLog = {}
PlayerLog.Config = {}
PlayerLog.Config.Launches = 0
PlayerLog.Config.LogPlayers = true
PlayerLog.Config.LogModders = true
PlayerLog.Config.SaveInterval = 10
PlayerLog.Config.SaveWait = 0
PlayerLog.Players = {}
PlayerLog.Players.Modders = {}
PlayerLog.LaunchFile = function(bool)
    json.savefile("playerlog_launched", {bool})
end
PlayerLog.LoadLaunchFile = function()
    local s, c = pcall(json.loadfile, "playerlog_launched")
    if s then
        return c[1]
    end
    return false
end
PlayerLog.LoadPlayers = function()
    local s, c = pcall(json.loadfile, "playerlog_players.json")
    if s then
        PlayerLog.Players = c
    end
end
PlayerLog.SavePlayers = function()
    json.savefile("playerlog_players.json", PlayerLog.Players)
end
PlayerLog.LoadConfig = function()
    local s, c = pcall(json.loadfile, "playerlog.json")
    if s then
        PlayerLog.Config = c
    end
end
PlayerLog.SaveConfig = function()
    json.savefile("playerlog.json", PlayerLog.Config)
end
PlayerLog.LoadAll = function()
    PlayerLog.LoadPlayers()
    PlayerLog.LoadConfig()
end
PlayerLog.SaveAll = function()
    PlayerLog.SavePlayers()
    PlayerLog.SaveConfig()
end
PlayerLog.GetPlayer = function(player_name)
    return PlayerLog.Players[player_name]
end
PlayerLog.AddPlayer = function(player_name)
    PlayerLog.Players[player_name] = PlayerLog.Config.Launches
end
PlayerLog.RemovePlayer = function(player_name)
    PlayerLog.Players[player_name] = nil
end
PlayerLog.GetModder = function(player_name)
    return PlayerLog.Players.Modders[player_name]
end
PlayerLog.AddModder = function(player_name, reason)
    PlayerLog.Players.Modders[player_name] = {PlayerLog.Config.Launches, reason}
end
PlayerLog.RemoveModder = function(player_name)
    PlayerLog.Players.Modders[player_name] = nil
end
PlayerLog.IsModder = function(ply)
    if ply == nil then return nil end
    if ply:get_max_health() < 100 then return "Undead Offradar" end
    if ply:is_in_vehicle() and ply:get_godmode() then return "GodMode" end
    if ply:get_run_speed() > 1.0 or ply:get_swim_speed() > 1.0 then return "SpeedHack" end
 
    return nil
end
PlayerLog.BuildLoggedPlayersMenu = function(sub)
    local page = 1
    local maxpages = 1
    local c = 1
    sub:add_bare_item("Page 1 of 1", function() c = tlen(PlayerLog.Players) - 1 maxpages = math.ceil(c/15) page = clamp(page,1,maxpages) return "Page "..page.." of "..maxpages.."| Total Logged: "..c end, null, function() page = page - 1 return "Page "..page.." of "..maxpages.."| Total Logged: "..c end, function() page = page + 1 return "Page "..page.." of "..maxpages.."| Total Logged: "..c end)
    sub:add_bare_item("----------------------------------------------", null, null, null, null)
    sub:add_bare_item("Player Name | Seen Script Launches Ago", null, null, null, null)
    for i = 1, 15 do
        sub:add_bare_item(""..i,function() 
            local name, last_seen = tind(PlayerLog.Players, ((page - 1) * 15) + i, true) 
            if not name then return "" end
            local launches_ago = PlayerLog.Config.Launches - last_seen
            local s = name.."|"..launches_ago
        return s end, null, null, null)
    end
    sub:add_bare_item("----------------------------------------------", null, null, null, null)
end
PlayerLog.BuildLoggedModdersMenu = function(sub)
    local page = 1
    local maxpages = 1
    local c = 1
    sub:add_bare_item("Page 1 of 1", function() c = tlen(PlayerLog.Players.Modders) maxpages = math.ceil(c/15) page = clamp(page,1,maxpages) return "Page "..page.." of "..maxpages.."| Total Logged: "..c end, null, function() page = page - 1 return "Page "..page.." of "..maxpages.."| Total Logged: "..c end, function() page = page + 1 return "Page "..page.." of "..maxpages.."| Total Logged: "..c end)
    sub:add_bare_item("----------------------------------------------", null, null, null, null)
    sub:add_bare_item("Modder Name | Reason / Launches Ago", null, null, null, null)
    for i = 1, 15 do
        sub:add_bare_item(""..i,function() 
            local name, info = tind(PlayerLog.Players.Modders, ((page - 1) * 15) + i) 
            if not name then return "" end
            local last_seen = info[1]
            local reason = info[2]
            local launches_ago = PlayerLog.Config.Launches - last_seen
            local s = name.."|"..tostring(reason).." / "..launches_ago
        return s end, null, null, null)
    end
    sub:add_bare_item("----------------------------------------------", null, null, null, null)
end
 
PlayerLog.LaunchFile(true) -- Creating launch file to tell previous Loop() to end.
sleep(2) -- While we are sleeping we expect Loop() to end when checking for a launch file.
PlayerLog.LaunchFile(false) -- "Removing" launch file to start new Loop().
PlayerLog.LoadAll()
PlayerLog.Config.Launches = PlayerLog.Config.Launches + 1
PlayerLog.SaveConfig()
 
-- Building Menus
local PlayerLogMenu = CSYONS5:add_submenu("Csyon's PlayerLog")
 
local PlayerLogPlayers = PlayerLogMenu:add_submenu("Logged Players")
PlayerLog.BuildLoggedPlayersMenu(PlayerLogPlayers)
PlayerLogPlayers:add_action("Clear Logged Players", function()
    m = PlayerLog.Players.Modders
    PlayerLog.Players = {}
    PlayerLog.Players.Modders = m
    PlayerLog.SavePlayers()
end)
 
local PlayerLogModders = PlayerLogMenu:add_submenu("Logged Modders")
PlayerLog.BuildLoggedModdersMenu(PlayerLogModders)
PlayerLogModders:add_action("Clear Logged Modders", function()
    PlayerLog.Players.Modders = {}
    PlayerLog.SavePlayers()
end)
 
CSYONS5:add_toggle("Log Players", function() return PlayerLog.Config.LogPlayers end, function(v) PlayerLog.Config.LogPlayers = v end)
CSYONS5:add_toggle("Log Modders", function() return PlayerLog.Config.LogModders end, function(v) PlayerLog.Config.LogModders = v end)
CSYONS5:add_int_range("Save Players Interval (Seconds)", 5, 5, 120, function() return PlayerLog.Config.SaveInterval end, function(v) PlayerLog.Config.SaveInterval = v end)
CSYONS5:add_action("Save Config", function() PlayerLog.SaveConfig() end)
 
menu.add_player_action("Mark As Logged Modder", function() PlayerLog.AddModder(player.get_player_name(menu.get_selected_player_index()), "Manually Added") end)
menu.add_player_action("Remove from Modder Log", function() PlayerLog.RemoveModder(player.get_player_name(menu.get_selected_player_index())) end)
-- Main Loop
local LoopCallback = nil 
local function Loop()
    menu.remove_callback(LoopCallback)
    stop = false
    while (true) do
        if not stop then
            if PlayerLog.LoadLaunchFile() then PlayerLog.SavePlayers() stop = true end -- If launch file exists, Loop() "dies" (goes into empty infinite sleep because menu crashes otherwise).
            --PrintTable(PlayerLog.Players)
            for i = 0, 31 do
		        local ply = player.get_player_ped(i)
                if ply == nil or ply == localplayer then goto continue end
                if PlayerLog.Config.LogPlayers then
                    name = player.get_player_name(i)
                    logged = PlayerLog.GetPlayer(name)
                    if not logged or logged < PlayerLog.Config.Launches then
                        PlayerLog.AddPlayer(name)
                    end
                end
                if PlayerLog.Config.LogModders then
                    reason = PlayerLog.IsModder(ply)
                    if reason then
                        name = player.get_player_name(i)
                        logged = PlayerLog.GetModder(name)
                        if not logged or logged[1] < PlayerLog.Config.Launches then
                            PlayerLog.AddModder(name, reason)
                        end
                    end
                end
                ::continue::
            end
            if PlayerLog.Config.SaveWait >= PlayerLog.Config.SaveInterval then
                PlayerLog.SavePlayers()
                PlayerLog.Config.SaveWait = 0
                --print("Saved!")
            end
            PlayerLog.Config.SaveWait = PlayerLog.Config.SaveWait + 1
            sleep(1)
        else
            sleep(1000) -- I HAD TO DO IT. Otherwise when Loop() ends, in case we reload scripts, the menu WILL crash.
        end
    end
end
 
LoopCallback = menu.register_callback("OnScriptsLoaded", Loop)
----- playerlog stop
 
 
----- BOUNTYPLAYERLIST

local function null() end 
 
local function Text(submenu, text)
	if (submenu ~= nil) then
		submenu:add_action(text, null)
	else
		menu.add_action(text, null)
	end
end
 
local function GetPlayerCount()
	return player.get_number_of_players()
end
 
-- 1.66 globals. Found by: me (Csyon).
local global_bountymoney = 2359296 + 1 + (0 * 5568) + 5150 + 14 -- Bounty amount when setting bounty in yourself.
local global_basebounty = 2793046
local global_bountyset = global_basebounty + 1886 + 57 -- Trigger set bounty on yourself.
 
--local global_dropbounty = global_basebounty + 1856 + 17 -- Not consistent, so didn't update it.
local global_overridebase = 262145
local money = 1000;
local minpay = 1000
local numbers = {"1", "19", "69", "228", "666", "1337", "6969", "9696", "10000"}
local npos = 1
 
local function calculateFee(amount)
	local fee = 0
	if amount > minpay then
		fee = (amount - minpay) * -1
	elseif amount < minpay then
		fee = (minpay - amount)
	else
		fee = 0
	end
    return fee
end
 
local function overrideBounty(amount)
    local fee = calculateFee(amount)
	globals.set_int(global_overridebase + 2348, minpay)
	globals.set_int(global_overridebase + 2349, minpay)
	globals.set_int(global_overridebase + 2350, minpay)
	globals.set_int(global_overridebase + 2351, minpay)
	globals.set_int(global_overridebase + 2352, minpay)
	globals.set_int(global_overridebase + 7105, fee)
end
 
local function resetoverrideBounty()
	globals.set_int(global_overridebase + 2348, 2000)
	globals.set_int(global_overridebase + 2349, 4000)
	globals.set_int(global_overridebase + 2350, 6000)
	globals.set_int(global_overridebase + 2351, 8000)
	globals.set_int(global_overridebase + 2352, 10000)
	globals.set_int(global_overridebase + 7105, 1000)
end
 
local function sendbounty(id, amount)
    overrideBounty(amount)
    globals.set_int(global_basebounty + 4564, id)
	globals.set_int(global_basebounty + 4564 + 1, 1)
	globals.set_bool(global_basebounty + 4564 + 2 + 1, true)
    sleep(1)
    resetoverrideBounty()
end
 
--If you ever use this option i hope you know what you're doing
local function i_am_reckless_modmenu_user_i_want_mayhem(amount)
    overrideBounty(amount)
    for i = 0, 31 do
		local ply = player.get_player_ped(i)
		if ply then 
            globals.set_int(global_basebounty + 4564, i)
            globals.set_int(global_basebounty + 4564 + 1, 1)
            globals.set_bool(global_basebounty + 4564 + 2 + 1, true)
        end
        sleep(1)
    end
    resetoverrideBounty()
end
 
local plylist = nil
 
local function makeop()
    local bs = menu.add_player_submenu("CSYON 👪Players Bounty")
    bs:add_int_range("Amount", 100, 0, 10000, function() return money end, function(a) money = a end)
    bs:add_array_item("Nice numbers", numbers, function() return npos end, 
    function(a) 
    	npos = a 
    	money = tonumber(numbers[npos])
    end)
	bs:add_action("Set Bounty", function() sendbounty(menu.get_selected_player_index(), money) end)
end
 
local function updateplylist()
    plylist:clear()
    
    plylist:add_int_range("Amount", 100, 0, 10000, function() return money end, function(a) money = a end)
    plylist:add_array_item("Nice numbers", numbers, function() return npos end, 
    function(a) 
    	npos = a 
    	money = tonumber(numbers[npos])
    end)
    plylist:add_bare_item("---CSYON's Bounty 👪Playerslist, "..GetPlayerCount().." Players---", function() return "---👪CSYON's Bounty Playerslist, "..GetPlayerCount().." 👪Players---" end, null, null, null)
    for i = 0, 31 do
		local ply = player.get_player_ped(i)
		if ply then 
			plylist:add_bare_item(player.get_player_name(i), function() return player.get_player_ped(i) ~= nil and (player.get_player_ped(i) == localplayer and "YOU" or player.get_player_name(i)) or "**Invalid**" end, function() local id = i sendbounty(id, money) end, null, null)
		end
	end
    Text(plylist, "---End---")
    
    --If you ever use this option i hope you know what you're doing
    plylist:add_action("\u{26A0} Set On All Online Players (Long) \u{26A0}", function() i_am_reckless_modmenu_user_i_want_mayhem(money) end)
end
plylist = sub:add_submenu("Set Bounty On Players", function() updateplylist() end)
 
sub:add_int_range("Set Bounty On Yourself", 100, 1, 10000, function() return money end, 
function(a)
	money = a
	globals.set_int(global_bountymoney, money)
	globals.set_int(global_bountyset, 0)
end)
 
sub:add_int_range("Override Lester Bounty", 100, 0, 10000, function() return money end, 
function(a)
	money = a
	overrideBounty(money)
end)
 
sub:add_array_item("Nice numbers", numbers, function() return npos end, 
function(a) 
	npos = a 
	money = tonumber(numbers[npos])
end)
 
--sub:add_action("Lose Bounty", function()
--    globals.set_int(global_dropbounty, 0)
--end)
 
sub:add_action("Reset Lester Override", function()
    resetoverrideBounty()
end)
 
makeop()


----- 
 
----- Playerlist

local Config = {}
Config.SubmenuStyle = false
Config.SlamType = 1
Config.SlamHeight = 1
Config.SlamTypes = {"Rhino", "Khanjali", "Halftrack"}
Config.VehicleSpawnGlobal = 2639889
Config.TrickOrTreatBase = 2765084
Config.TrickOrTreatType = Config.TrickOrTreatBase + 579
Config.TrickOrTreatTimer = Config.TrickOrTreatBase + 581
Config.TrickOrTreatTrigger = Config.TrickOrTreatBase + 581 + 1
Config.ExplodeTpBack = true
Config.VehicleTypes = {}
Config.VehicleTypes["Super"] = {"Krieger", "Prototipo", "T20"}
Config.VehicleTypes["Sports"] = {"Kuruma", "Kuruma2"}
Config.VehicleTypes["Sports Classic"] = {"Toreador", "Ardent"}
Config.VehicleTypes["Millitary"] = {"Rhino", "Khanjali", "Halftrack"}
Config.VehicleTypes["Bikes"] = {"Oppressor", "Oppressor2", "Akuma"}
Config.VehicleTypes["Planes"] = {"Hydra", "Lazer", "Titan", "Cargoplane"}
 
-- Function definitions
local function null() end
 
local function Text(submenu, text)
	if (submenu ~= nil) then
		submenu:add_action(text, null)
	else
		menu.add_action(text, null)
	end
end
 
local function sqrt(i)
	return math.sqrt(i)
end
 
local function DistanceToSqr(vec1, vec2)
	return ((vec2.x - vec1.x)^2) + ((vec2.y - vec1.y)^2) + ((vec2.z - vec1.z)^2)
end
 
local function Distance(vec1, vec2)
	return sqrt(DistanceToSqr(vec1, vec2))
end
 
local function floor(num)
	return math.floor(num)
end
 
local function clamp(num, min, max)
	if num > max then return max elseif num < min then return min else return num end
end
-- Player / Ped functions
 
local function IsPlayer(ped)
	if ped == nil or ped:get_pedtype() >= 4 then
		return false
	end
	return true
end
 
local function IsNPC(ped)
	if ped == nil or ped:get_pedtype() < 4 then
		return false
	end
	return true
end
 
local function IsModder(ply)
	if not IsPlayer(ply) then return false end
	
	if ply:get_max_health() < 100 then return true end
	if ply:is_in_vehicle() and ply:get_godmode() then return true end
	if ply:get_run_speed() > 1.0 or ply:get_swim_speed() > 1.0 then return true end
 
	return false
end
 
local function GetPlayerCount()
	return player.get_number_of_players()
end
 
local function createVehicle(modelhash, pos)
	globals.set_int(Config.VehicleSpawnGlobal + 46, modelhash)
	globals.set_float(Config.VehicleSpawnGlobal + 42, pos.x)
	globals.set_float(Config.VehicleSpawnGlobal + 43, pos.y)
	globals.set_float(Config.VehicleSpawnGlobal + 44, pos.z)
	globals.set_boolean(Config.VehicleSpawnGlobal + 41, true)
end
 
-- Action functions
 
local function GiveVehicle(ply, model)
	if not ply or ply == nil then return end 
	local pos = ply:get_position()
	local heading = ply:get_heading()
	createVehicle(joaat(model), pos + heading * 10)
end
 
local function TeleportToPlayer(ply, seconds)
	if not ply or ply == nil then return end 
	local pos = ply:get_position()
	if seconds then
		if localplayer:is_in_vehicle() then return end
 
		local oldpos = localplayer:get_position() 
	
		localplayer:set_freeze_momentum(true) 
		localplayer:set_config_flag(292,true)
		localplayer:set_position(pos)
	
		sleep(seconds)
	
		localplayer:set_position(oldpos)
		localplayer:set_freeze_momentum(false) 
		localplayer:set_config_flag(292,false)
		return
	end
 
	if not localplayer:is_in_vehicle() then
		localplayer:set_position(pos)
	else
		localplayer:get_current_vehicle():set_position(pos)
	end
end
 
local function TeleportVehiclesToPlayer(ply)
	if not ply or ply == nil then return end 
 
	local pos = ply:get_position()
	local currentvehicle = nil 
 
	if localplayer:is_in_vehicle() then
		currentvehicle = localplayer:get_current_vehicle()
	end
 
	for veh in replayinterface.get_vehicles() do
		if not currentvehicle or currentvehicle ~= veh then
			veh:set_position(pos)
		end
	end
end
 
local function TeleportClosestVehicleToPlayer(ply)
	if not ply or ply == nil then return end 
 
	local pos = ply:get_position()
	local veh = localplayer:get_nearest_vehicle()
	if not veh then return end
 
	veh:set_position(pos)
end
 
local function TeleportPedsToPlayer(ply, dead)
	if not ply or ply == nil then return end 
 
	local pos = ply:get_position()
	for ped in replayinterface.get_peds() do
		if IsNPC(ped) then
			if not ped:is_in_vehicle() then
				if dead then 
					ped:set_health(0)
				end
				ped:set_position(pos)
			end
		end
	end
end
 
local function ExplodePlayer(ply)
	if not ply or ply == nil then return end 
 
	local pos = ply:get_position()
	local currentvehicle = nil 
 
	if localplayer:is_in_vehicle() then
		currentvehicle = localplayer:get_current_vehicle()
	end
 
	for veh in replayinterface.get_vehicles() do
		if not currentvehicle or currentvehicle ~= veh then
			veh:set_rotation(vector3(0,0,180))
			veh:set_health(-1)
			veh:set_position(pos)
		end
	end
end
 
local function LaunchPlayer(ply)
	if not ply or ply == nil then return end 
 
	local currentvehicle = nil 
 
	if localplayer:is_in_vehicle() then
		currentvehicle = localplayer:get_current_vehicle()
	end
	local i = 0
	for veh in replayinterface.get_vehicles() do
		if not currentvehicle or currentvehicle ~= veh then
			local pos = ply:get_position()
			veh:set_rotation(vector3(0,0,0))
			veh:set_gravity(-100)
			veh:set_position(vector3(pos.x, pos.y, pos.z - 20))
		end
	end
	sleep(1)
	for veh in replayinterface.get_vehicles() do
		if not currentvehicle or currentvehicle ~= veh then
			local pos = ply:get_position()
			veh:set_gravity(9.8)
		end
	end
end
 
local function SlamPlayer(ply, model)
	if not ply or ply == nil then return end 
 
	if model then 
		createVehicle(joaat(model), ply:get_position() + vector3(0,0,10 * Config.SlamHeight))
		return
	end
 
	local currentvehicle = nil 
 
	if localplayer:is_in_vehicle() then
		currentvehicle = localplayer:get_current_vehicle()
	end
	local i = 0
	for veh in replayinterface.get_vehicles() do
		if not currentvehicle or currentvehicle ~= veh then
			local pos = ply:get_position()
			veh:set_rotation(vector3(0,0,0))
			veh:set_gravity(10000)
			veh:set_position(vector3(pos.x, pos.y, pos.z + 10 * Config.SlamHeight))
		end
	end
	sleep(1)
	for veh in replayinterface.get_vehicles() do
		if not currentvehicle or currentvehicle ~= veh then
			local pos = ply:get_position()
			veh:set_gravity(9.8)
		end
	end
end
 
-- Player option 
local selectedplayer = -1
 
local function f_p_o(ply_id, ply, ply_name) -- Format Player Option Text
	local text = ""
 
	if (player.get_player_ped(ply_id) == nil) then return "**Invalid**" end
 
	-- Player Name
	if ply == localplayer then
		text = text.."YOU"
	else
		text = text..ply_name
	end
 
	if IsModder(ply) then
		text = text.."*"
	end
 
	-- Is In GodMode, if not then Player Health
	if ply:get_godmode() then
		text = text.." | God"
	else
		local max_hp = ply:get_max_health()
		text = text.." | "..floor(clamp((ply:get_health() - 100), 0, max_hp)/(max_hp - 100)*100).."\u{2665}"
		local armour = ply:get_armour()
		if armour > 0 then
			text = text.." | "..floor(ply:get_armour()).."\u{1f455}"
		end
	end
 
	-- Is In Vehicle
	if ply:is_in_vehicle() then
		text = text.." | \u{1F697}"
	end
 
	-- Player Wanted Level
	local wanted = ply:get_wanted_level()
 
	if wanted > 0 then
		text = text.." | "..wanted.."\u{2730}"
	end
	-- Player's Distance From You
	text = text.." | "..floor(Distance(ply:get_position(), localplayer:get_position())).." m"
	
	return text
end
 
local function add_player_option(submenu, ply_id, ply, ply_name)
	
	local text = f_p_o(ply_id, ply, ply_name)
 
	local d = ply_id
 
	if (submenu ~= nil) then
		submenu:add_bare_item(text, function() return f_p_o(ply_id, ply, ply_name).."|"..(selectedplayer == ply_id and "\u{2713}" or "\u{25A1}")  end, function() selectedplayer = d end, null, null)
	else
		menu.add_bare_item(text, function() return f_p_o(ply_id, ply, ply_name).."|"..(selectedplayer == ply_id and "\u{2713}" or "\u{25A1}") end, function() selectedplayer = d end, null, null)
	end
end
 
local function add_info_option(submenu, text, funcget, forceplayer)
 
	local func = function() 
		local ply = player.get_player_ped(forceplayer and forceplayer or selectedplayer)
		if not ply then return text..": **Invalid**" end
 
		return text..": "..funcget(ply)
	end
 
	if (submenu ~= nil) then
		submenu:add_bare_item(text..": ", func, null, null, null)
	else
		menu.add_bare_item(text..": ", func, null, null, null)
	end
end
 
-- Building Player List 
local CSYONSPL = nil
local was_opened = true
 
local function BuildListSub() -- Deprecated for the moment
	CSYONSPL:add_bare_item("---👪Player List, "..GetPlayerCount().." 👪Players---", function() was_opened = true return "---CSYON's 👪Player List, "..GetPlayerCount().." 👪Players---" end, null, null, null)
 
	local popt = {}
	for i = 0, 31 do
		local ply = player.get_player_ped(i)
		if ply then 
			popt[i] = CSYONSPL:add_submenu(f_p_o(i, ply, player.get_player_name(i))) -- add_player_option(CSYONSPL, i, ply, player.get_player_name(i))
			
			add_info_option(popt[i], "👪Player", function() selectedplayer = i return player.get_player_name(i) end, i)
			local subtp = popt[i]:add_submenu("Teleport Options")
			local subtroll = popt[i]:add_submenu("Trolling Options")
			local subinfo = popt[i]:add_submenu("Player Info")
		
			-- Teleport Options
			add_info_option(subtp, "👪Player", function() return player.get_player_name(selectedplayer) end)
			subtp:add_action("Teleport To Player", function() TeleportToPlayer(player.get_player_ped(selectedplayer)) end)
			subtp:add_int_range("Teleport To Player Then Back", 1, 1, 5, function() return 2 end, function(n) TeleportToPlayer(player.get_player_ped(selectedplayer), n) end)
			subtp:add_action("Teleport Closest Vehicle To Player", function() TeleportClosestVehicleToPlayer(player.get_player_ped(selectedplayer)) end)
			subtp:add_action("Teleport Vehicles To Player", function() TeleportVehiclesToPlayer(player.get_player_ped(selectedplayer)) end)
			subtp:add_action("Teleport Peds To Player", function() TeleportPedsToPlayer(player.get_player_ped(selectedplayer)) end)
			subtp:add_action("Teleport Dead Peds To Player", function() TeleportPedsToPlayer(player.get_player_ped(selectedplayer), true) end)
		
			--Trolling Options
			add_info_option(subtroll, "👪Player", function() return player.get_player_name(selectedplayer) end)
			subtroll:add_action("Launch Player", function() LaunchPlayer(player.get_player_ped(selectedplayer)) end)
			subtroll:add_action("Slam Player", function() SlamPlayer(player.get_player_ped(selectedplayer)) end)
			subtroll:add_action("Explode Player", function() ExplodePlayer(player.get_player_ped(selectedplayer)) end)
			subtroll:add_array_item("Slam Player Using", Config.SlamTypes, function() return Config.SlamType end, function(value) Config.SlamType = value SlamPlayer(player.get_player_ped(selectedplayer), Config.SlamTypes[value]) end)
			subtroll:add_int_range("Slam Height", 1, 0, 10, function() return Config.SlamHeight end, function(v) Config.SlamHeight = v end)

			-- Info Panel
		
			add_info_option(subinfo, "👪Player", function() return player.get_player_name(selectedplayer) end)
			add_info_option(subinfo, "Distance from you", function(p) return floor(Distance(p:get_position(), localplayer:get_position())).." m" end)
			add_info_option(subinfo, "Health", function(p) return floor(clamp((p:get_health() - 100), 0, p:get_max_health())/(p:get_max_health() - 100)*100) end)
			add_info_option(subinfo, "Armour", function(p) return floor(p:get_armour()) end)
			add_info_option(subinfo, "Is In Vehicle", function(p) return (p:is_in_vehicle() and "Yes" or "No") end)
			add_info_option(subinfo, "Vehicle Health", function(p) return ((p:is_in_vehicle() and p:get_current_vehicle() ~= nil) and floor(p:get_current_vehicle():get_health()/(p:get_current_vehicle():get_max_health())*100) or 0) end)
			add_info_option(subinfo, "Is In GodMode", function(p) return (p:get_godmode() and "Yes" or "No") end)
			add_info_option(subinfo, "Is Modder", function(p) return (IsModder(p) and "Yes" or "No") end)
			add_info_option(subinfo, "X", function(p) return p:get_position().x end)
			add_info_option(subinfo, "Y", function(p) return p:get_position().y end)
			add_info_option(subinfo, "Z", function(p) return p:get_position().z end)
		end
	end
end
 
local function BuildList()
	CSYONSPL:add_bare_item("---👪Player List, "..GetPlayerCount().." 👪Players---", function() was_opened = true return "---👪Player List, "..GetPlayerCount().." 👪Players---" end, null, null, null)
 
	for i = 0, 31 do
		local ply = player.get_player_ped(i)
		if ply then 
			add_player_option(CSYONSPL, i, ply, player.get_player_name(i))
		end
	end
 
	Text(CSYONSPL, "---End---")
 
	local subtp = CSYONSPL:add_submenu("Teleport Options")
	local subtroll = CSYONSPL:add_submenu("Trolling Options")
	local subinfo = CSYONSPL:add_submenu("Player Info")
 
	-- Teleport Options
	add_info_option(subtp, "👪Player", function() return player.get_player_name(selectedplayer) end)
	subtp:add_action("Teleport To Player", function() TeleportToPlayer(player.get_player_ped(selectedplayer)) end)
	subtp:add_int_range("Teleport To Player Then Back", 1, 1, 5, function() return 2 end, function(n) TeleportToPlayer(player.get_player_ped(selectedplayer), n) end)
	subtp:add_action("Teleport Closest Vehicle To Player", function() TeleportClosestVehicleToPlayer(player.get_player_ped(selectedplayer)) end)
	subtp:add_action("Teleport Vehicles To Player", function() TeleportVehiclesToPlayer(player.get_player_ped(selectedplayer)) end)
	subtp:add_action("Teleport Peds To Player", function() TeleportPedsToPlayer(player.get_player_ped(selectedplayer)) end)
	subtp:add_action("Teleport Dead Peds To Player", function() TeleportPedsToPlayer(player.get_player_ped(selectedplayer), true) end)
 
	--Trolling Options
	add_info_option(subtroll, "👪Player", function() return player.get_player_name(selectedplayer) end)
	subtroll:add_action("Launch Player", function() LaunchPlayer(player.get_player_ped(selectedplayer)) end)
	subtroll:add_action("Slam Player", function() SlamPlayer(player.get_player_ped(selectedplayer)) end)
	subtroll:add_action("Explode Player", function() ExplodePlayer(player.get_player_ped(selectedplayer)) end)
	subtroll:add_array_item("Slam Player Using", Config.SlamTypes, function() return Config.SlamType end, function(value) Config.SlamType = value SlamPlayer(player.get_player_ped(selectedplayer), Config.SlamTypes[value]) end)
	subtroll:add_int_range("Slam Height", 1, 0, 10, function() return Config.SlamHeight end, function(v) Config.SlamHeight = v end)
	
	-- Info Panel
 
	add_info_option(subinfo, "👪Player", function() return player.get_player_name(selectedplayer) end)
	add_info_option(subinfo, "Distance from you", function(p) return floor(Distance(p:get_position(), localplayer:get_position())).." m" end)
	add_info_option(subinfo, "Health", function(p) return floor(clamp((p:get_health() - 100), 0, p:get_max_health())/(p:get_max_health() - 100)*100) end)
	add_info_option(subinfo, "Armour", function(p) return floor(p:get_armour()) end)
	add_info_option(subinfo, "Is In Vehicle", function(p) return (p:is_in_vehicle() and "Yes" or "No") end)
	add_info_option(subinfo, "Vehicle Health", function(p) return ((p:is_in_vehicle() and p:get_current_vehicle() ~= nil) and floor(p:get_current_vehicle():get_health()/(p:get_current_vehicle():get_max_health())*100) or 0) end)
	add_info_option(subinfo, "Is In GodMode", function(p) return (p:get_godmode() and "Yes" or "No") end)
	add_info_option(subinfo, "Is Modder", function(p) return (IsModder(p) and "Yes" or "No") end)
	add_info_option(subinfo, "X", function(p) return p:get_position().x end)
	add_info_option(subinfo, "Y", function(p) return p:get_position().y end)
	add_info_option(subinfo, "Z", function(p) return p:get_position().z end)
end
 
-- List Updater
 
local function Update()
	CSYONSPL:clear() 
	if Config.SubmenuStyle then 
		BuildListSub() 
	else 
		BuildList() 
	end
end
 
CSYONSPL = CSYON3:add_submenu("【 CSYON 】 👨 Online Noobs", Update)

-----

CSYONS21:add_action("***********************************************************", function() end)
CSYONS21:add_action("for Help join my Discord Server", function() end)
CSYONS21:add_action("https://discord.gg/JaCvtj6yQK", function() end)
CSYONS21:add_action("***********************************************************", function() end)



Offlinex64 = mainMenu2:add_submenu("                        **💬 Read Me 💬**                        ")

	
--────────────────────────────────────────────────────────────────────────────────────────
--─██████████████─██████████████─████████──████████─██████████████─██████──────────██████─
--─██░░░░░░░░░░██─██░░░░░░░░░░██─██░░░░██──██░░░░██─██░░░░░░░░░░██─██░░██████████──██░░██─
--─██░░██████████─██░░██████████─████░░██──██░░████─██░░██████░░██─██░░░░░░░░░░██──██░░██─
--─██░░██─────────██░░██───────────██░░░░██░░░░██───██░░██──██░░██─██░░██████░░██──██░░██─
--─██░░██─────────██░░██████████───████░░░░░░████───██░░██──██░░██─██░░██──██░░██──██░░██─
--─██░░██─────────██░░░░░░░░░░██─────████░░████─────██░░██──██░░██─██░░██──██░░██──██░░██─
--─██░░██─────────██████████░░██───────██░░██───────██░░██──██░░██─██░░██──██░░██──██░░██─
--─██░░██─────────────────██░░██───────██░░██───────██░░██──██░░██─██░░██──██░░██████░░██─
--─██░░██████████─██████████░░██───────██░░██───────██░░██████░░██─██░░██──██░░░░░░░░░░██─
--─██░░░░░░░░░░██─██░░░░░░░░░░██───────██░░██───────██░░░░░░░░░░██─██░░██──██████████░░██─
--─██████████████─██████████████───────██████───────██████████████─██████──────────██████─
--────────────────────────────────────────────────────────────────────────────────────────